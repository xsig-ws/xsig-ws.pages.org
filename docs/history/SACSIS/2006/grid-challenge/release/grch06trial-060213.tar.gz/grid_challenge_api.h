#ifndef _GRID_CHALLENGE_API_H_
#define _GRID_CHALLENGE_API_H_
#ifdef __cplusplus
extern "C" {
#endif

#define GRCH_OK 0
#define GRCH_NG 1

  int GetProblem(const int problem_number, char **filename, char *key);
  int GetElapsedTime(const int problem_number, const char *key, double *elapsed_time);
  int AnswerProblem(const int problem_number, const char *key, const int *belong_to, int *out_edge_cnt, double *elapsed_time, char *check_string);

#ifdef __cplusplus
};
#endif
#endif /* _GRID_CHALLENGE_API_H_ */
