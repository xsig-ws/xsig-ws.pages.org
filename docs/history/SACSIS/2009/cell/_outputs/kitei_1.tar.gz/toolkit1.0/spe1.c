/*----------------------------------------------------------------------*/
// Cell Speed Challenge 2008 規定課題プログラム
// チーム名: 東京工業大学小長谷研究室
// author: SATOSHIRO Haruki
//
/*----------------------------------------------------------------------*/
#include <spu_intrinsics.h>
#include <spelib.h>
#include <spe_stdio.h>
#include <stdlib.h>
#include <spu_mfcio.h>
#include <float.h>
#include <math.h>
#include "spe_util.h"
#include "define.h"

/**
 * 命名規則
 * * 変数名
 *   eaから始まる変数はDMA転送に使う実効アドレス(型は整数を表すeaddr_t)
 *   lsから始まる変数はDMA転送のバッファに使うもの, volatileで修飾されたものはデータの取得に使用する
 *   ループカウンタはi, j, k
 *     ループカウンタの後ろにはループの種類によってA(大文字), a(小文字), mが付く
 *     Aはブロックについて回すとき, aはブロック内の要素について回すとき, mは右辺ベクトルについて回すとき
 *     後置詞がないときはそれ以外のループ
 *   本来関数内だけで参照するべきだが高速化のためグローバル変数にしたものは先頭にgを付加
 *
 * * 関数名
 *   関数名の最後に inner が付くものは inner なしの関数の内側のループを出したもの
 *     *内側のループは計算,外側のループはデータの取得という形が多い.
 *   get, put が含まれる関数はDMA転送を行う
 *     *普通のget,put関数はコーディングの過程で不必要になったため削除
 *     iget, iputなどの i で始まる名前の関数は転送の終了を待たずに処理が戻ってくる
 *     iputb などの最後に b が付く名前の関数はバリア付き
 *   dma で始まる関数はその他のDMAに関する操作を行う
 */

/**
 * アルゴリズム
 *
 * LU分解を採用
 * 32x32のブロック形式
 * 最初に係数行列はブロックレイアウトに配置しなおす.
 * 行列の性質に関わらず1行ごとに部分ピボッティングを行う.
 * 対角要素はUに含める(除算が行方向に進むためSIMD化しやすい).
 * 
 */

/**
 * その他の注意
 * * 基本的に人が読むコードになっていない.
 *   SIMD命令や,ループアンローリング,インライン展開など
 *   可読性を減少させる方法を最大限に使って性能を向上させているため.
 *   * 最も重要な matrix_nmsub 関数だけ元のコードをコメントアウトして残している.
 *   他にもコンパイラの最適化を助けるためのコーディングをしている.
 *
 * 以上のことからアセンブリを読むくらいの覚悟をしたほうがいいと思います...
 *
 */

/* 変更可能なパラメータ */

// ピボット決定後に交換を行うかどうか(デバッグ用)
// 精度の問題があるので交換する必要あり
#define ENABLE_SWAP

// ゼロ行列の計算を飛ばすかどうか(デバッグ用)
// ゼロ行列を検出するためのコードを有効にする.
// なぜか有効にしたほうがパフォーマンスが良い.
#define SKIP_ZERO

// デクリメンタの読み込み(デバッグ用)
// 同期処理のバグ検出のためデクリメンタを読み込む
// あまりに長い時間ロックするときはメッセージを出力する.
// なぜか有効にしたほうがパフォーマンスが良い.
#define READ_DECREMENTER

// 解を求めた後係数行列を元の形式に戻す(デバッグ用)
// PPEプログラムのdisp_matrixで出力できるように係数行列を配置しなおす.
//#define FILL_A_AFTER_SOLEQS

// スピンロック中にデクリメンタがこの回数カウントしたときにメッセージを出力する.
// メッセージが表示されるのは大抵は同期ミスが発生したとき
#define PRINT_CYCLE 100000000

// もっとも計算量の多い行列の積和演算(matrix_nmsub関数)のプロファイリング用
//#define PROF_MATRIX_NMSUB

// 終了時に変数decの値を出力する
//#define PRINT_PROF

// 縦方向にキャッシュするブロック数
// これに収まりきらない係数行列を持つ問題は解くのが極端に遅くなる(大体2倍の時間がかかる)
// 4096x4096の行列でSPE7基合わせて128ブロックのキャッシュが必要
// * コード量が増大したため当初32ブロックだったキャッシュが減少しつつある.
#define COLCACHE_SIZE 20

/*----------------------------------------------------------------------*/
volatile static struct spe_ctrl       sc _GALIGN;

// eaddr_tの型を持つ変数はDMA転送の実行アドレスとして使う
typedef unsigned int eaddr_t;

#define BLOCK_SIZE 32 // 変更不可
// 最適化により32周分のループ展開をした部分あり

#define INNER_BLOCK_SIZE 4 //変更不可
#define INNER_BLOCK_COUNT (BLOCK_SIZE/INNER_BLOCK_SIZE)

// 一度に行うDMA転送の最大サイズ
// 一度にベクトルを転送できないときは遅くなる.
#define DMA_SIZE_MAX 16384
#define VEC_DMA_LINE (DMA_SIZE_MAX/(BLOCK_SIZE*sizeof(float)))

// コンパイラはキャストにも1サイクルかかるコードを生成することがあるので
// キャストして使う型は共用体にする
//
// qwordはインラインアセンブリ用
// * インラインアセンブリ用に用意はしたが,条件分岐を書くのが面倒(確実な方法がない?)なので2命令同時発行はコンパイラ任せ

typedef union {
    vector float v;
    qword q;
} uv_float;

typedef union {
    vector unsigned int v;
    qword q;
} uv_uint;

typedef union {
    vector unsigned short v;
    qword q;
} uv_ushort;

typedef union {
    vector float vf;
    vector unsigned int vui;
    qword q;
} uv_float_uint;

typedef union {
    vector unsigned int v;
    unsigned int i;
    qword q;
} u_vuint_uint;

typedef union {
    vector float v;
    float f;
    qword q;
} u_vfloat_float;

typedef union {
    vector unsigned short vus;
    vector unsigned int vui;
    unsigned int i;
    qword q;
} u_vushort_vuint_uint;

// 同期用
typedef struct {
    unsigned int sigfork;
    signed int line;
    union {
        float max;
        int pivot;
        unsigned int iszero;
    } p;
    unsigned int sigjoin;
} syncdata;

// 一括代入用にベクトルを共用体に含ませる
// 128バイト境界に並ぶようにパディングも行う
typedef union {
    syncdata s;
    vector unsigned int v;
    unsigned int pad[32];
} usyncdata;

#define SYNC_SIZE 8 // 変更不可
#define SYNC_SIGNAL 7

// idの控え
unsigned int speid;

// 同期用
// lssignal[speid]はマスタースレッドからのシグナルを受け取る
// その他の部分は対応するSPEからのシグナルを受け取る
volatile usyncdata lssignal[SYNC_SIZE] _GALIGN = {
    { { 0, -1, {0.0f}, 0, } },
    { { 0, -1, {0.0f}, 0, } },
    { { 0, -1, {0.0f}, 0, } },
    { { 0, -1, {0.0f}, 0, } },
    { { 0, -1, {0.0f}, 0, } },
    { { 0, -1, {0.0f}, 0, } },
    { { 0, -1, {0.0f}, 0, } },
    { { 0, -1, {0.0f}, 0, } }, };

// 縦方向の通信用
volatile float lsuline[2][BLOCK_SIZE] _GALIGN;
#define ULINE_TARGET 0 // 分解中の列
#define ULINE_SWAP   1 // 交換対象の列

// 縦方向の通信で取得した列の控え
float lsulinecp[BLOCK_SIZE] _GALIGN;

// シグナル送信用のバッファ
usyncdata lssyncbuf[SYNC_SIZE] _GALIGN;

// 同期処理の結果の控え
usyncdata lsresult[SYNC_SIZE] _GALIGN;

// 同期用アドレス
eaddr_t eals[SYNC_SIZE];
eaddr_t ealssignal[SYNC_SIZE];
eaddr_t ealsuline[SYNC_SIZE];

// リストエレメントの再定義
typedef struct sub_mfc_list_element {
    unsigned int notify    : 1;
    unsigned int reserved  : 16;
    unsigned int size      : 15;
    unsigned int eal       : 32;
} mfc_list_element_t;

// 一括代入のために共用体の中にベクトルを含ませる
typedef union {
    mfc_list_element_t e;
    vector unsigned int v;
} u_mfc_list_element_t;

volatile float lsrightelem[2][BLOCK_SIZE*sizeof(float)] _GALIGN;
mfc_list_element_t mlgetelem[2][BLOCK_SIZE] _GALIGN;

#define VECTOR_ARRAY_SIZE 10
volatile static float lsV[VECTOR_ARRAY_SIZE][BLOCK_SIZE] _GALIGN;
#define VECTOR_R 0
#define VECTOR_X 2
#define VECTOR_V 4

volatile static int lsperm[7][BLOCK_SIZE] _GALIGN;
#define PERM_INIT        0 // 4つ使用
#define PERM_TARGET      0
#define PERM_DECOM       0
#define PERM_RIGHT       0
#define PERM_L           2
#define PERM_PIVOT       2
#define PERM_SWAP_PIVOT  4
#define PERM_SWAP_TGTEMP 5
#define PERM_SWAP_PVTEMP 6

#define BLOCK_ARRAY_SIZE (11+COLCACHE_SIZE)

#define VECTOR_SIZE (BLOCK_ARRAY_SIZE/4*32)
#define VCACHE_SIZE (VECTOR_SIZE*4)

mfc_list_element_t mlget[BLOCK_ARRAY_SIZE][BLOCK_SIZE] _GALIGN;
mfc_list_element_t mlput[BLOCK_ARRAY_SIZE][BLOCK_SIZE] _GALIGN;
#define ML_RIGHT 0

volatile float lsblock[BLOCK_ARRAY_SIZE][BLOCK_SIZE][BLOCK_SIZE] _GALIGN;
#define BLOCK_DECOM     0
#define BLOCK_D         0
#define BLOCK_L         2
#define BLOCK_U         4
#define BLOCK_DIAG      6
#define BLOCK_TARGET    7
#define BLOCK_PIVOT     9
#define BLOCK_COLCACHE 11

int gcol;
int gcolcache_size;
vector unsigned int vcolcachevalid[COLCACHE_SIZE];

#define TAG_PERM_GET    8
#define TAG_PERM_PUT    9
#define TAG_BLOCK_GET  10
#define TAG_BLOCK_PUT  11
#define TAG_RIGHT      12
#define TAG_VECTOR_GET 13
#define TAG_VECTOR_PUT 14
#define TAG_SYNC       15
#define TAG_LINE_GET   16
#define TAG_LINE_PUT   17
#define TAG_PERM       18
#define TAG_DIAG       19
#define TAG_PVGET      20
#define TAG_SWAP       22 // 2個使用 

//リストDMA用
eaddr_t glinesize;
vector unsigned int gvinc;
vector unsigned int gveal0;
vector unsigned int gveal1;

#define SPE_MASTER 0
#define SPESIG_FORK 1
#define SPESIG_JOIN 1

// 行交換用
int gswap_tag;
int gswap_tbuf;
int gswap_pbuf;
int gswap_col;
int gswap_skip;
int gswap_nxtdecom;
int gswap_nA;
int gswap_iA;
int gswap_pvcnt;
eaddr_t gswap_eaA;

#if defined READ_DECREMENTER
unsigned int gstep = 0;
unsigned int gsync = 0;
unsigned int dec = 0;
unsigned int s, t;
#endif

#if defined PRINT_PROF
unsigned int sp, tp;
#define PROF_START_ONCE() do { sp = spu_read_decrementer(); } while(0)
#define PROF_STOP_ONCE() do { tp = spu_read_decrementer(); if(dec == 0) { dec = sp-tp; } } while(0)
#else
#define PROF_START_ONCE() do { ; } while(0)
#define PROF_STOP_ONCE() do { ; } while(0)
#endif

// splats用定数
const vector unsigned char gvsplats[8] = {
    { 0, 1, 2, 3 ,0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, },
    { 4, 5, 6, 7 ,4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, },
    { 8, 9, 10, 11 ,8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, },
    { 12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, },
    { 16, 17, 18, 19, 16, 17, 18, 19, 16, 17, 18, 19, 16, 17, 18, 19, },
    { 20, 21, 22, 23, 20, 21, 22, 23, 20, 21, 22, 23, 20, 21, 22, 23, },
    { 24, 25, 26, 27, 24, 25, 26, 27, 24, 25, 26, 27, 24, 25, 26, 27, },
    { 28, 29, 30, 31, 28, 29, 30, 31, 28, 29, 30, 31, 28, 29, 30, 31, },
};

// syncdata初期化用定数
const usyncdata gsyncinit = { { 0, -1, {0}, 0, }, };

/*----------------------------------------------------------------------*/

inline void set_linesize(eaddr_t linesize)
{
    vector unsigned int veal0 = { 0, linesize, 2*linesize, 3*linesize, };
    vector unsigned int veal1 = { 4*linesize, 5*linesize, 6*linesize, 7*linesize, };

    glinesize = linesize;
    gvinc = spu_splats(8*linesize);
    gveal0 = veal0;
    gveal1 = veal1;
}

#define line_assign(l, r) do {\
    *(vector float*)&(l)[ 0] = *(vector float*)&(r)[ 0]; \
    *(vector float*)&(l)[ 4] = *(vector float*)&(r)[ 4]; \
    *(vector float*)&(l)[ 8] = *(vector float*)&(r)[ 8]; \
    *(vector float*)&(l)[12] = *(vector float*)&(r)[12]; \
    *(vector float*)&(l)[16] = *(vector float*)&(r)[16]; \
    *(vector float*)&(l)[20] = *(vector float*)&(r)[20]; \
    *(vector float*)&(l)[24] = *(vector float*)&(r)[24]; \
    *(vector float*)&(l)[28] = *(vector float*)&(r)[28]; \
} while(0)

/////////////////////////////////////////////////////////////////////////////////////////////////
// 同期用関数
/////////////////////////////////////////////////////////////////////////////////////////////////

#define dma_wait(buf) do { mfc_write_tag_mask(1 << (buf)); mfc_read_tag_status_all(); } while(0)
//inline void dma_wait(int buf)
//{
//    mfc_write_tag_mask(1 << buf);
//    mfc_read_tag_status_all();
//}

#define dma_wait_mask(mask) do { mfc_write_tag_mask(mask); mfc_read_tag_status_all(); } while(0)

inline int is_master()
{
    return (speid == 0);
}

// iA番目の対角ブロックを担当するときは1, そうでなければ0を返す
inline int is_assigned(int iA)
{
    return (speid == iA%NUMBER_OF_SPES);
}

/** 
 * fork-joinモデルの実装
 * マスタースレッドはrun_spesとjoin_spesの間
 * スレーブスレッドはwait_for_signalとsend_signalの間が並列実行
 */
void run_spes(usyncdata sync)
{
    vector unsigned int vmask = { 0, 0xFFFFFFFF, 0xFFFFFFFF, 0, };
    vector unsigned int vsig = { SPESIG_FORK, 0, 0, 0, };

    sync.v = spu_and(sync.v, vmask);
    sync.v = spu_or(sync.v, vsig);

    dma_wait(TAG_SYNC);

    lssyncbuf[0].v = sync.v;

    // 他のSPEに転送
    if(NUMBER_OF_SPES >= 2) {
        mfc_putb(&lssyncbuf[0], ealssignal[1]+sizeof(usyncdata)*1, sizeof(syncdata), TAG_SYNC, 0, 0);
    }
    if(NUMBER_OF_SPES >= 3) {
        mfc_putb(&lssyncbuf[0], ealssignal[2]+sizeof(usyncdata)*2, sizeof(syncdata), TAG_SYNC, 0, 0);
    }
    if(NUMBER_OF_SPES >= 4) {
        mfc_putb(&lssyncbuf[0], ealssignal[3]+sizeof(usyncdata)*3, sizeof(syncdata), TAG_SYNC, 0, 0);
    }
    if(NUMBER_OF_SPES >= 5) {
        mfc_putb(&lssyncbuf[0], ealssignal[4]+sizeof(usyncdata)*4, sizeof(syncdata), TAG_SYNC, 0, 0);
    }
    if(NUMBER_OF_SPES >= 6) {
        mfc_putb(&lssyncbuf[0], ealssignal[5]+sizeof(usyncdata)*5, sizeof(syncdata), TAG_SYNC, 0, 0);
    }
    if(NUMBER_OF_SPES >= 7) {
        mfc_putb(&lssyncbuf[0], ealssignal[6]+sizeof(usyncdata)*6, sizeof(syncdata), TAG_SYNC, 0, 0);
    }

#if defined READ_DECREMENTER
    gsync++;
#endif
}

void join_spes()
{
    int i;
    syncdata sync = { -1, 0, {0.0f}, SPESIG_JOIN, };
    vector unsigned int vinit = { (unsigned int)(-1), -1, 0, 0, };
    usyncdata usync _LALIGN;

    usync.s = sync;

    dma_wait(TAG_SYNC);

    for(i = 1; i < NUMBER_OF_SPES; i++) {
#if defined READ_DECREMENTER
        s = spu_read_decrementer();
        while(lssignal[i].s.sigjoin != SPESIG_JOIN) {
            t = spu_read_decrementer();
            if(s-t > PRINT_CYCLE) {
                spe_printf("SPE(%d): too late!(join_spes) step = %d, sync = %d, sig(%d) = %d\n", speid, gstep, gsync, i, lssignal[i].s.sigjoin);
                s = t;
            }
        }
#else
        while(lssignal[i].s.sigjoin != SPESIG_JOIN) {
            ;
        }
#endif
        lsresult[i].v = lssignal[i].v;
    }

    lssignal[0].v = vinit;
    lssignal[1].v = vinit;
    lssignal[2].v = vinit;
    lssignal[3].v = vinit;
    lssignal[4].v = vinit;
    lssignal[5].v = vinit;
    lssignal[6].v = vinit;
    lssignal[7].v = vinit;
}

void wait_for_signal()
{
    dma_wait(TAG_SYNC);

#if defined READ_DECREMENTER
    gsync++;
    s = spu_read_decrementer();
    while(lssignal[speid].s.sigfork != SPESIG_FORK) {
        t = spu_read_decrementer();
        if(s-t > PRINT_CYCLE) {
            spe_printf("SPE(%d): too late!(wait_for_signal) step = %d, sync = %d, sig(%d) = %d\n", speid, gstep, gsync, speid, lssignal[speid].s.sigfork);
            s = t;
        }
    }
#else
    while(lssignal[speid].s.sigfork != SPESIG_FORK) {
        ;
    }
#endif
}

// 一連のデータ送信の前にTAG_SYNCの転送の終了を待つ必要あり
inline void send_signal_to(int spe, usyncdata signal)
{
    //dma_wait(TAG_SYNC);

    lssyncbuf[speid].v = signal.v;
    mfc_putf(&lssyncbuf[speid], ealssignal[spe] + sizeof(lssyncbuf[speid])*speid, sizeof(syncdata), TAG_SYNC, 0, 0);
}

// スレーブスレッドがsend_signal_toに続いてマスタースレッドを待たずにsend_signalを呼び出すと同期が乱れる恐れあり
void send_signal(usyncdata signal)
{
    vector unsigned int vinit;
    vector unsigned int vmask = { 0, 0xFFFFFFFF, 0xFFFFFFFF, 0, };
    vector unsigned int vsig = { 0, 0, 0, SPESIG_JOIN, };

    dma_wait(TAG_SYNC);

    vinit = gsyncinit.v;
    lssignal[0].v = vinit;
    lssignal[1].v = vinit;
    lssignal[2].v = vinit;
    lssignal[3].v = vinit;
    lssignal[4].v = vinit;
    lssignal[5].v = vinit;
    lssignal[6].v = vinit;
    lssignal[7].v = vinit;

    signal.v = spu_and(signal.v, vmask);
    signal.v = spu_or(signal.v, vsig);
    lssyncbuf[speid].v = signal.v;
    mfc_putf(&lssyncbuf[speid], ealssignal[SPE_MASTER] + sizeof(lssyncbuf[speid])*speid, sizeof(syncdata), TAG_SYNC, 0, 0);
}

// 8番目のバッファを使用してデータ送信
// 一連のデータ送信の前にTAG_SYNCの転送の終了を待つ必要あり
void send_signal_all(usyncdata signal)
{
    int i;
    vector unsigned int vmask = { 0, 0xFFFFFFFF, 0xFFFFFFFF, 0, };
    vector unsigned int vsig = { -1, 0, 0, 0, };

    signal.v = spu_and(signal.v, vmask);
    signal.v = spu_or(signal.v, vsig);

    //dma_wait(TAG_SYNC);

    lssyncbuf[SYNC_SIGNAL].v = signal.v;

    for(i = 0; i < NUMBER_OF_SPES; i++) {
        if(i != speid) {
            mfc_putf(&lssyncbuf[SYNC_SIGNAL], ealssignal[i]+sizeof(lssyncbuf[SYNC_SIGNAL])*SYNC_SIGNAL, sizeof(syncdata), TAG_SYNC, 0, 0);
        }
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////
// DMA転送用関数
/////////////////////////////////////////////////////////////////////////////////////////////////

inline void iget_perm(int buf, int tag, int iA, eaddr_t eaP)
{
    mfc_get(lsperm[buf],
            eaP+iA*BLOCK_SIZE*sizeof(float),
            sizeof(lsperm[buf]),
            tag, 0, 0);
}

inline void iput_perm(int buf, int tag, int iA, eaddr_t eaP)
{
    mfc_put(lsperm[buf], 
            eaP+iA*BLOCK_SIZE*sizeof(float), 
            sizeof(lsperm[buf]),
            tag, 0, 0);
}

inline void iputb_perm(int buf, int tag, int iA, eaddr_t eaP)
{
    mfc_putb(lsperm[buf], 
             eaP+iA*BLOCK_SIZE*sizeof(float), 
             sizeof(lsperm[buf]),
             tag, 0, 0);
}

inline eaddr_t cal_ea_block(int nA, int iA, int jA, eaddr_t eaA)
{
    //return (eaA + (iA*nA+jA)*BLOCK_SIZE*BLOCK_SIZE*sizeof(float));
    return (eaA + (jA*nA+iA)*BLOCK_SIZE*BLOCK_SIZE*sizeof(float));
}

inline void iget_line_p(volatile float *p, int tag, int nA, int line, int jA, eaddr_t eaA)
{
    unsigned int iA = line / BLOCK_SIZE;
    unsigned int lineA = line - iA*BLOCK_SIZE;
    eaddr_t eaLine = cal_ea_block(nA, iA, jA, eaA) + lineA*BLOCK_SIZE*sizeof(float);

    mfc_get(p, eaLine, BLOCK_SIZE*sizeof(float), tag, 0, 0);
}

inline void iput_line_p(volatile float *p, int tag, int nA, int line, int jA, eaddr_t eaA)
{
    unsigned int iA = line / BLOCK_SIZE;
    unsigned int lineA = line - iA*BLOCK_SIZE;
    eaddr_t eaLine = cal_ea_block(nA, iA, jA, eaA) + lineA*BLOCK_SIZE*sizeof(float);

    mfc_put(p, eaLine, BLOCK_SIZE*sizeof(float), tag, 0, 0);
}

// linesize = nA*BLOCK_SIZE*sizeof(float)
// lineoffset = jA*BLOCK_SIZE*sizeof(float)
// eaLineST = eaA + iA*BLOCK_SIZE*linesize + lineoffset
// リストエレメントをSIMDで計算
// eaLineSTは読み込むブロックの左上の要素のアドレス
void iget_block_ml_hs(int buf, eaddr_t eaLineST)
{
    //int i;
    vector unsigned int vln = spu_splats(eaLineST);
    const vector unsigned short cvml = { 0, BLOCK_SIZE*sizeof(float), 0, 0, 0, BLOCK_SIZE*sizeof(float), 0, 0, };
    vector unsigned short vml0, vml1, vml2, vml3;
    vector unsigned int veal0, veal1;
    const vector unsigned char vpattern0 = { 0, 1, 2, 3, 16, 17, 18, 19, 8, 9, 10, 11, 20, 21, 22, 23, };
    const vector unsigned char vpattern1 = { 0, 1, 2, 3, 24, 25, 26, 27, 8, 9, 10, 11, 28, 29, 30, 31, };

    veal0 = spu_add(vln, gveal0);
    veal1 = spu_add(vln, gveal1);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlget[buf][ 0] = vml0;
    *(vector unsigned short*)&mlget[buf][ 2] = vml1;
    *(vector unsigned short*)&mlget[buf][ 4] = vml2;
    *(vector unsigned short*)&mlget[buf][ 6] = vml3;

    veal0 = spu_add(veal0, gvinc);
    veal1 = spu_add(veal1, gvinc);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlget[buf][ 8] = vml0;
    *(vector unsigned short*)&mlget[buf][10] = vml1;
    *(vector unsigned short*)&mlget[buf][12] = vml2;
    *(vector unsigned short*)&mlget[buf][14] = vml3;

    veal0 = spu_add(veal0, gvinc);
    veal1 = spu_add(veal1, gvinc);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlget[buf][16] = vml0;
    *(vector unsigned short*)&mlget[buf][18] = vml1;
    *(vector unsigned short*)&mlget[buf][20] = vml2;
    *(vector unsigned short*)&mlget[buf][22] = vml3;

    veal0 = spu_add(veal0, gvinc);
    veal1 = spu_add(veal1, gvinc);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlget[buf][24] = vml0;
    *(vector unsigned short*)&mlget[buf][26] = vml1;
    *(vector unsigned short*)&mlget[buf][28] = vml2;
    *(vector unsigned short*)&mlget[buf][30] = vml3;

    /*for(i = 0; i < BLOCK_SIZE; i += 8) {
        vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
        vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
        vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
        vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

        *(vector unsigned short*)&mlget[buf][i  ] = vml0;
        *(vector unsigned short*)&mlget[buf][i+2] = vml1;
        *(vector unsigned short*)&mlget[buf][i+4] = vml2;
        *(vector unsigned short*)&mlget[buf][i+6] = vml3;

        veal0 = spu_add(veal0, gvinc);
        veal1 = spu_add(veal1, gvinc);
    }*/
}

/*#define iget_block_line(buf, tag, nA, iA, jA, eaA) do { \
    mfc_get(lsblock[buf], cal_ea_block(nA, iA, jA, eaA), sizeof(lsblock[buf]), tag, 0, 0); \
} while(0)*/
inline void iget_block_line(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    eaddr_t ea = cal_ea_block(nA, iA, jA, eaA);

    mfc_get(lsblock[buf], ea, sizeof(lsblock[buf]), tag, 0, 0);
}

inline void igetb_block_line(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    eaddr_t ea = cal_ea_block(nA, iA, jA, eaA);

    mfc_getb(lsblock[buf], ea, sizeof(lsblock[buf]), tag, 0, 0);
}

inline void iget_block_ml(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    eaddr_t lineoffset = jA*BLOCK_SIZE*sizeof(float);
    eaddr_t eaLineST = eaA + iA*BLOCK_SIZE*glinesize + lineoffset;

    iget_block_ml_hs(buf, eaLineST);

    mfc_getl(lsblock[buf], 0, mlget[buf], sizeof(mlget[buf]), tag, 0, 0);
}

//#define iget_block(buf, tag, nA, iA, jA, eaA) iget_block_line(buf, tag, nA, iA, jA, eaA)
inline void iget_block(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    //iget_block_ml(buf, tag, nA, iA, jA, eaA);
    iget_block_line(buf, tag, nA, iA, jA, eaA);
}

#if defined FILL_A_AFTER_SOLEQS
void iput_block_ml_hs(int buf, eaddr_t eaLineST)
{
    //int i;
    vector unsigned int vln = spu_splats(eaLineST);
    const vector unsigned short cvml = { 0, BLOCK_SIZE*sizeof(float), 0, 0, 0, BLOCK_SIZE*sizeof(float), 0, 0, };
    vector unsigned short vml0, vml1, vml2, vml3;
    vector unsigned int veal0, veal1;
    const vector unsigned char vpattern0 = { 0, 1, 2, 3, 16, 17, 18, 19, 8, 9, 10, 11, 20, 21, 22, 23, };
    const vector unsigned char vpattern1 = { 0, 1, 2, 3, 24, 25, 26, 27, 8, 9, 10, 11, 28, 29, 30, 31, };

    veal0 = spu_add(vln, gveal0);
    veal1 = spu_add(vln, gveal1);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlput[buf][ 0] = vml0;
    *(vector unsigned short*)&mlput[buf][ 2] = vml1;
    *(vector unsigned short*)&mlput[buf][ 4] = vml2;
    *(vector unsigned short*)&mlput[buf][ 6] = vml3;

    veal0 = spu_add(veal0, gvinc);
    veal1 = spu_add(veal1, gvinc);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlput[buf][ 8] = vml0;
    *(vector unsigned short*)&mlput[buf][10] = vml1;
    *(vector unsigned short*)&mlput[buf][12] = vml2;
    *(vector unsigned short*)&mlput[buf][14] = vml3;

    veal0 = spu_add(veal0, gvinc);
    veal1 = spu_add(veal1, gvinc);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlput[buf][16] = vml0;
    *(vector unsigned short*)&mlput[buf][18] = vml1;
    *(vector unsigned short*)&mlput[buf][20] = vml2;
    *(vector unsigned short*)&mlput[buf][22] = vml3;

    veal0 = spu_add(veal0, gvinc);
    veal1 = spu_add(veal1, gvinc);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlput[buf][24] = vml0;
    *(vector unsigned short*)&mlput[buf][26] = vml1;
    *(vector unsigned short*)&mlput[buf][28] = vml2;
    *(vector unsigned short*)&mlput[buf][30] = vml3;

    /*for(i = 0; i < BLOCK_SIZE; i += 8) {
        vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
        vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
        vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
        vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

        *(vector unsigned short*)&mlput[buf][i  ] = vml0;
        *(vector unsigned short*)&mlput[buf][i+2] = vml1;
        *(vector unsigned short*)&mlput[buf][i+4] = vml2;
        *(vector unsigned short*)&mlput[buf][i+6] = vml3;

        veal0 = spu_add(veal0, gvinc);
        veal1 = spu_add(veal1, gvinc);
    }*/
}

inline void iput_block_ml(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    eaddr_t lineoffset = jA*BLOCK_SIZE*sizeof(float);
    eaddr_t eaLineST = eaA + iA*BLOCK_SIZE*glinesize + lineoffset;

    iput_block_ml_hs(buf, eaLineST);

    mfc_putl(lsblock[buf], 0, mlput[buf], sizeof(mlput[buf]), tag, 0, 0);
}

inline void iputb_block_ml(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    eaddr_t lineoffset = jA*BLOCK_SIZE*sizeof(float);
    eaddr_t eaLineST = eaA + iA*BLOCK_SIZE*glinesize + lineoffset;

    iput_block_ml_hs(buf, eaLineST);

    mfc_putlb(lsblock[buf], 0, mlput[buf], sizeof(mlput[buf]), tag, 0, 0);
}
#endif

inline void iput_block_line(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    eaddr_t ea = cal_ea_block(nA, iA, jA, eaA);

    mfc_put(lsblock[buf], ea, sizeof(lsblock[buf]), tag, 0, 0);
}

inline void iputb_block_line(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    eaddr_t ea = cal_ea_block(nA, iA, jA, eaA);

    mfc_putb(lsblock[buf], ea, sizeof(lsblock[buf]), tag, 0, 0);
}

inline void iput_block(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    //iput_block_ml(buf, tag, nA, iA, jA, eaA);
    iput_block_line(buf, tag, nA, iA, jA, eaA);
}

//#define iputb_block(buf, tag, nA, iA, jA, eaA) iputb_block_line(buf, tag, nA, iA, jA, eaA)
inline void iputb_block(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    //iputb_block_ml(buf, tag, nA, iA, jA, eaA);
    iputb_block_line(buf, tag, nA, iA, jA, eaA);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
// 列方向キャッシュ
/////////////////////////////////////////////////////////////////////////////////////////////////

inline void colcache_init(int nA)
{
    int i;
    vector unsigned int vzero = spu_splats(0u);
    gcol = 0;
    gcolcache_size = (nA+NUMBER_OF_SPES-1)/NUMBER_OF_SPES;
    if(gcolcache_size > COLCACHE_SIZE) {
        gcolcache_size = COLCACHE_SIZE;
    }

    for(i = 0; i < gcolcache_size; i++) {
        vcolcachevalid[i] = vzero;
    }
}

inline void colcache_next(int nA, eaddr_t eaA)
{
    int i;
    vector unsigned int vzero = spu_splats(0u);

    for(i = 0; i < gcolcache_size; i++) {
        if(__builtin_expect(spu_extract(vcolcachevalid[i], 0), 1)) {
             iput_block(BLOCK_COLCACHE+i, TAG_SYNC, nA, i*NUMBER_OF_SPES+speid, gcol, eaA);
        }
        vcolcachevalid[i] = vzero;
    }

    gcol += 1;

    dma_wait(TAG_SYNC);
}

inline void colcache_sync(int nA, eaddr_t eaA)
{
    int i;
    vector unsigned int vzero = spu_splats(0u);

    for(i = 0; i < gcolcache_size; i++) {
        if(__builtin_expect(spu_extract(vcolcachevalid[i], 0), 1)) {
             iput_block(BLOCK_COLCACHE+i, TAG_SYNC, nA, i*NUMBER_OF_SPES+speid, gcol, eaA);
        }
        vcolcachevalid[i] = vzero;
    }
    dma_wait(TAG_SYNC);
}

// 前提条件: (iA%NUMBER_OF_SPES==speid)
// まずキャッシュからブロックを探す。
// 無ければメインメモリから転送し、可能ならばキャッシュする。
// 戻り値は実際にデータが格納されているバッファのインデックス
int colcache_iget_block(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    int index = iA/NUMBER_OF_SPES;
    vector unsigned int vvalid = spu_splats(1u);

    if(__builtin_expect((index < gcolcache_size), 1)) {
        // キャッシュ可
        if(spu_extract(vcolcachevalid[index], 0) == 0) {
            // キャッシュなし
            iget_block(BLOCK_COLCACHE+index, tag, nA, iA, jA, eaA);
            vcolcachevalid[index] = vvalid;
        }
        return BLOCK_COLCACHE+index;
    } else {
        // キャッシュ不可
        iget_block(buf, tag, nA, iA, jA, eaA);
        return buf;
    }
}

// 前提条件: (iA%NUMBER_OF_SPES==speid), 
//           以前に同じブロックに対してcolcache_iget_block関数を呼び出したことがある
// キャッシュに入っていればメインメモリまで転送する必要の無いもの
inline void colcache_iputb_block(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    int index = iA/NUMBER_OF_SPES;
    if(__builtin_expect((index >= gcolcache_size), 0)) {
        iputb_block(buf, tag, nA, iA, jA, eaA);
    }
}

// 前提条件: (iA%NUMBER_OF_SPES==speid), 列は現在分解中のもの
// 戻り値: ブロックのインデックス、キャッシュされていないときは-1
inline int colcache_get_index(int iA)
{
    int index = iA/NUMBER_OF_SPES;
    if(__builtin_expect((index < gcolcache_size), 1)) {
        if(__builtin_expect(spu_extract(vcolcachevalid[index], 0), 1)) {
            return BLOCK_COLCACHE+index;
        }
    }

    return -1;
}

inline void colcache_invalidate(int iA)
{
    vector unsigned int vzero = spu_splats(0u);

    int index = iA/NUMBER_OF_SPES;
    vcolcachevalid[index] = vzero;
}

/*inline void colcache_invalidate_all()
{
    int i;
    vector unsigned int vzero = spu_splats(0u);

    for(i = 0; i < gcolcache_size; i++) {
        vcolcachevalid[i] = vzero;
    }
}*/

/////////////////////////////////////////////////////////////////////////////////////////////////
// 行の交換
/////////////////////////////////////////////////////////////////////////////////////////////////

void swap_igetb_block(int buf, int tag, int nA, int perm, int count, int col, eaddr_t eaA)
{
    int i;
    unsigned int line;
    unsigned int iA;
    unsigned int lineA;
    eaddr_t eaLine;

    for(i = 0; i < count; i++) {
        line = lsperm[perm][i];

        iA = line / BLOCK_SIZE;
        lineA = line - iA*BLOCK_SIZE;
        eaLine = cal_ea_block(nA, iA, col, eaA) + lineA*BLOCK_SIZE*sizeof(float);

        mlget[buf][i].notify = 0;
        mlget[buf][i].reserved = 0;
        mlget[buf][i].size = BLOCK_SIZE*sizeof(float);
        mlget[buf][i].eal = eaLine;
    }

    mfc_getlb(lsblock[buf], 0, mlget[buf], sizeof(mfc_list_element_t)*count, tag, 0, 0);
}

void swap_iputb_block(int buf, int tag, int nA, int perm, int count, int col, eaddr_t eaA)
{
    int i;
    unsigned int line;
    unsigned int iA;
    unsigned int lineA;
    eaddr_t eaLine;

    for(i = 0; i <count; i++) {
        line = lsperm[perm][i];

        iA = line / BLOCK_SIZE;
        lineA = line - iA*BLOCK_SIZE;
        eaLine = cal_ea_block(nA, iA, col, eaA) + lineA*BLOCK_SIZE*sizeof(float);

        mlput[buf][i].notify = 0;
        mlput[buf][i].reserved = 0;
        mlput[buf][i].size = BLOCK_SIZE*sizeof(float);
        mlput[buf][i].eal = eaLine;
    }

    mfc_putlb(lsblock[buf], 0, mlput[buf], sizeof(mfc_list_element_t)*count, tag, 0, 0);
}

void swap_init_perm(int iA)
{
    vector unsigned int vcnt0 = { 0, 1, 2, 3, };
    vector unsigned int vcnt1 = { 4, 5, 6, 7, };
    vector unsigned int vcnt2 = { 8, 9, 10, 11, };
    vector unsigned int vcnt3 = { 12, 13, 14, 15, };
    vector unsigned int vcnt4 = { 16, 17, 18, 19, };
    vector unsigned int vcnt5 = { 20, 21, 22, 23, };
    vector unsigned int vcnt6 = { 24, 25, 26, 27, };
    vector unsigned int vcnt7 = { 28, 29, 30, 31, };
    vector unsigned int vperm0;
    vector unsigned int vperm1;
    vector unsigned int vperm2;
    vector unsigned int vperm3;
    vector unsigned int vperm4;
    vector unsigned int vperm5;
    vector unsigned int vperm6;
    vector unsigned int vperm7;
    unsigned int base = iA*BLOCK_SIZE;

    gswap_pvcnt = 0;

    vperm0 = spu_splats(base);
    vperm1 = spu_splats(base);
    vperm2 = spu_splats(base);
    vperm3 = spu_splats(base);
    vperm4 = spu_splats(base);
    vperm5 = spu_splats(base);
    vperm6 = spu_splats(base);
    vperm7 = spu_splats(base);

    vperm0 = spu_add(vperm0, vcnt0);
    vperm1 = spu_add(vperm1, vcnt1);
    vperm2 = spu_add(vperm2, vcnt2);
    vperm3 = spu_add(vperm3, vcnt3);
    vperm4 = spu_add(vperm4, vcnt4);
    vperm5 = spu_add(vperm5, vcnt5);
    vperm6 = spu_add(vperm6, vcnt6);
    vperm7 = spu_add(vperm7, vcnt7);

    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][ 0] = vperm0;
    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][ 4] = vperm1;
    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][ 8] = vperm2;
    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][12] = vperm3;
    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][16] = vperm4;
    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][20] = vperm5;
    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][24] = vperm6;
    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][28] = vperm7;

    /*int i;
    gswap_pvcnt = 0;
    for(i = 0; i < BLOCK_SIZE; i++) {
        lsperm[PERM_SWAP_TGTEMP][i] = i+iA*BLOCK_SIZE;
    }*/
}

void swap_set_perm(int target, int pivot)
{
    int i;
    int ta = target % BLOCK_SIZE;
    int pa;
    int temp;

    if(target/BLOCK_SIZE == pivot/BLOCK_SIZE) {
        pa = pivot % BLOCK_SIZE;
        temp = lsperm[PERM_SWAP_TGTEMP][ta];
        lsperm[PERM_SWAP_TGTEMP][ta] = lsperm[PERM_SWAP_TGTEMP][pa];
        lsperm[PERM_SWAP_TGTEMP][pa] = temp;        
    } else {
        for(i = 0; i < gswap_pvcnt; i++) {
            if(pivot == lsperm[PERM_SWAP_PIVOT][i]) {
                temp = lsperm[PERM_SWAP_PVTEMP][i];
                lsperm[PERM_SWAP_PVTEMP][i] = lsperm[PERM_SWAP_TGTEMP][ta];
                lsperm[PERM_SWAP_TGTEMP][ta] = temp;
                return;
            }
        }

        lsperm[PERM_SWAP_PIVOT][gswap_pvcnt] = pivot;
        lsperm[PERM_SWAP_PVTEMP][gswap_pvcnt] = lsperm[PERM_SWAP_TGTEMP][ta];
        lsperm[PERM_SWAP_TGTEMP][ta] = pivot;
        gswap_pvcnt++;
    }
}

void swap_begin(int nA, int iA, eaddr_t eaA)
{
    gswap_nA = nA;
    gswap_iA = iA;
    gswap_skip = iA;
    gswap_nxtdecom = iA+1;
    gswap_eaA = eaA;

    gswap_col = speid;
    if(gswap_col == gswap_skip || gswap_col == gswap_nxtdecom) {
        gswap_col += NUMBER_OF_SPES;
    }
#if NUMBER_OF_SPES == 1
    if(gswap_col == gswap_nxtdecom) {
        gswap_col += NUMBER_OF_SPES;
    }
#endif

    gswap_tag = TAG_SWAP;
    gswap_tbuf = BLOCK_TARGET + gswap_tag - TAG_SWAP;
    gswap_pbuf = BLOCK_PIVOT + gswap_tag - TAG_SWAP;

    // 次に分解する列は読み込みが発生するため先に交換する
    if(is_assigned(gswap_nxtdecom) && gswap_nxtdecom < nA) {
        swap_igetb_block(gswap_tbuf, gswap_tag, gswap_nA, PERM_SWAP_TGTEMP, BLOCK_SIZE, gswap_nxtdecom, gswap_eaA);
        swap_igetb_block(gswap_pbuf, gswap_tag, gswap_nA, PERM_SWAP_PVTEMP, gswap_pvcnt, gswap_nxtdecom, gswap_eaA);

        iputb_block(gswap_tbuf, gswap_tag, gswap_nA, gswap_iA, gswap_nxtdecom, gswap_eaA);
        swap_iputb_block(gswap_pbuf, gswap_tag, gswap_nA, PERM_SWAP_PIVOT, gswap_pvcnt, gswap_nxtdecom, gswap_eaA);
        dma_wait(gswap_tag);
    }
}

void swap_continue_sync()
{
    if(gswap_col >= gswap_nA) {
        return;
    }

    gswap_tag = ((gswap_tag+1) & 1) + TAG_SWAP;
    gswap_tbuf = BLOCK_TARGET + gswap_tag - TAG_SWAP;
    gswap_pbuf = BLOCK_PIVOT + gswap_tag - TAG_SWAP;

    dma_wait(TAG_SYNC);
    swap_igetb_block(gswap_tbuf, TAG_SYNC, gswap_nA, PERM_SWAP_TGTEMP, BLOCK_SIZE, gswap_col, gswap_eaA);
    swap_igetb_block(gswap_pbuf, TAG_SYNC, gswap_nA, PERM_SWAP_PVTEMP, gswap_pvcnt, gswap_col, gswap_eaA);

    iputb_block(gswap_tbuf, TAG_SYNC, gswap_nA, gswap_iA, gswap_col, gswap_eaA);
    swap_iputb_block(gswap_pbuf, TAG_SYNC, gswap_nA, PERM_SWAP_PIVOT, gswap_pvcnt, gswap_col, gswap_eaA);

    gswap_col += NUMBER_OF_SPES;
    if(gswap_col == gswap_skip || gswap_col == gswap_nxtdecom) {
        gswap_col += NUMBER_OF_SPES;
    }
#if NUMBER_OF_SPES == 1
    if(gswap_col == gswap_nxtdecom) {
        gswap_col += NUMBER_OF_SPES;
    }
#endif
}

void swap_continue()
{
    if(gswap_col >= gswap_nA) {
        return;
    }

    gswap_tag = ((gswap_tag+1) & 1) + TAG_SWAP;
    gswap_tbuf = BLOCK_TARGET + gswap_tag - TAG_SWAP;
    gswap_pbuf = BLOCK_PIVOT + gswap_tag - TAG_SWAP;

    dma_wait(gswap_tag);
    swap_igetb_block(gswap_tbuf, gswap_tag, gswap_nA, PERM_SWAP_TGTEMP, BLOCK_SIZE, gswap_col, gswap_eaA);
    swap_igetb_block(gswap_pbuf, gswap_tag, gswap_nA, PERM_SWAP_PVTEMP, gswap_pvcnt, gswap_col, gswap_eaA);

    iputb_block(gswap_tbuf, gswap_tag, gswap_nA, gswap_iA, gswap_col, gswap_eaA);
    swap_iputb_block(gswap_pbuf, gswap_tag, gswap_nA, PERM_SWAP_PIVOT, gswap_pvcnt, gswap_col, gswap_eaA);

    gswap_col += NUMBER_OF_SPES;
    if(gswap_col == gswap_skip || gswap_col == gswap_nxtdecom) {
        gswap_col += NUMBER_OF_SPES;
    }
#if NUMBER_OF_SPES == 1
    if(gswap_col == gswap_nxtdecom) {
        gswap_col += NUMBER_OF_SPES;
    }
#endif
}

#define swap_wait_all() do { dma_wait(TAG_SWAP); dma_wait(TAG_SWAP+1); } while(0)
//inline void swap_wait_all()
//{
//    dma_wait(TAG_SWAP);
//    dma_wait(TAG_SWAP+1);
//}

// 直前の交換の終了を待つ
#define swap_wait() do { dma_wait(gswap_tag); } while(0)
//inline void swap_wait()
//{
//    dma_wait(gswap_tag);
//}

#define swap_rest() do { dma_wait(TAG_SYNC); while(gswap_col < gswap_nA) swap_continue(); } while(0)
//inline void swap_rest()
//{
//    dma_wait(TAG_SYNC);
//    while(gswap_col < gswap_nA) {
//        swap_continue();
//    }
//}

void swap_diag(int dbuf, int perm, int target, int pivot, int nA, int iA, eaddr_t eaA, eaddr_t eaP)
{
    int index;
    int temp;
    int tA, pivotA;
    int ta, pivota;
    int ja;
    float ftemp;
    int spepivot;

    swap_set_perm(target, pivot);

    tA = target / BLOCK_SIZE;
    pivotA = pivot / BLOCK_SIZE;
    ta = target % BLOCK_SIZE;
    pivota = pivot % BLOCK_SIZE;

    //spe_printf("swap %d <-> %d\n", target, pivot);

    *(vector float*)&lsuline[ULINE_SWAP][ 0] = *(vector float*)&lsblock[dbuf][ta][ 0];
    *(vector float*)&lsuline[ULINE_SWAP][ 4] = *(vector float*)&lsblock[dbuf][ta][ 4];
    *(vector float*)&lsuline[ULINE_SWAP][ 8] = *(vector float*)&lsblock[dbuf][ta][ 8];
    *(vector float*)&lsuline[ULINE_SWAP][12] = *(vector float*)&lsblock[dbuf][ta][12];
    *(vector float*)&lsuline[ULINE_SWAP][16] = *(vector float*)&lsblock[dbuf][ta][16];
    *(vector float*)&lsuline[ULINE_SWAP][20] = *(vector float*)&lsblock[dbuf][ta][20];
    *(vector float*)&lsuline[ULINE_SWAP][24] = *(vector float*)&lsblock[dbuf][ta][24];
    *(vector float*)&lsuline[ULINE_SWAP][28] = *(vector float*)&lsblock[dbuf][ta][28];

    if(pivot == target) {
        return;
    }

    spepivot = pivotA % NUMBER_OF_SPES;
    if(spepivot == speid) {
        if(pivotA == tA) {
            temp = lsperm[perm][ta];
            lsperm[perm][ta] = lsperm[perm][pivota];
            lsperm[perm][pivota] = temp;

            for(ja = 0; ja < BLOCK_SIZE; ja++) {
                ftemp = lsblock[dbuf][ta][ja];
                lsblock[dbuf][ta][ja] = lsblock[dbuf][pivota][ja];
                lsblock[dbuf][pivota][ja] = ftemp;
            }
        } else {
            dma_wait(TAG_SYNC);
            iget_perm(PERM_PIVOT, TAG_PERM, pivotA, eaP);

            index = colcache_get_index(pivotA);
            if(index == -1) {
                iget_line_p(lsblock[dbuf][ta], TAG_SYNC, nA, pivot, iA, eaA);
                dma_wait(TAG_SYNC);
                iput_line_p(lsuline[ULINE_SWAP], TAG_SYNC, nA, pivot, iA, eaA);
            } else {
                for(ja = 0; ja < BLOCK_SIZE; ja++) {
                    lsblock[dbuf][ta][ja] = lsblock[index][pivota][ja];
                    lsblock[index][pivota][ja] = lsuline[ULINE_SWAP][ja];
                }
            }

            dma_wait(TAG_PERM);
            temp = lsperm[perm][ta];
            lsperm[perm][ta] = lsperm[PERM_PIVOT][pivota];
            lsperm[PERM_PIVOT][pivota] = temp;

            iput_perm(PERM_PIVOT, TAG_SYNC, pivotA, eaP);
        }
    } else {
        // ピボット候補の中から選んで取得する
        mfc_get(lsblock[dbuf][ta], ealsuline[spepivot], sizeof(lsblock[dbuf][ta]), TAG_PVGET, 0, 0);

        // 行の要素をspepivotに送る
        mfc_put(lsuline[ULINE_SWAP], ealsuline[spepivot]+BLOCK_SIZE*sizeof(float), sizeof(lsuline[ULINE_SWAP]), TAG_SYNC, 0, 0);

        iget_perm(PERM_PIVOT, TAG_PERM, pivotA, eaP);

        dma_wait(TAG_PERM);
        temp = lsperm[perm][ta];
        lsperm[perm][ta] = lsperm[PERM_PIVOT][pivota];
        lsperm[PERM_PIVOT][pivota] = temp;

        iputb_perm(PERM_PIVOT, TAG_PERM, pivotA, eaP);

        dma_wait(TAG_PVGET);
    }
}

void swap_down(int target, int pivot, int nA, int iA, eaddr_t eaA)
{
    int i;
    int index;
    int pivotA;
    int pivota;

    swap_set_perm(target, pivot);

    pivotA = pivot / BLOCK_SIZE;
    pivota = pivot % BLOCK_SIZE;
    if(pivotA%NUMBER_OF_SPES == speid) {
        index = colcache_get_index(pivotA);
        if(index == -1) {
            iput_line_p(lsuline[ULINE_SWAP], TAG_SYNC, nA, pivot, iA, eaA);
        } else {
            for(i = 0; i < BLOCK_SIZE; i++) {
                lsblock[index][pivota][i] = lsuline[ULINE_SWAP][i];
            }
        }
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////
// LU Decomposition
/////////////////////////////////////////////////////////////////////////////////////////////////

void pivot_selection_diag_vfirst(int *oapivot, float *oamax, int dbuf, int iv)
{
    float (*a)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[dbuf];
    int apivot = 0;
    float amax = 0.0f;
    int ia;
    float f;
    int pos = iv*INNER_BLOCK_SIZE;

    for(ia = pos; ia < BLOCK_SIZE; ia++) {
        f = fabs(a[ia][pos]);
        if(f > amax) {
            apivot = ia;
            amax = f;
        }
    }

    *oapivot = apivot;
    *oamax = amax;

    //spe_printf("vf diag pivot = %d, max = %.2f\n", apivot, amax);
}

void pivot_selection_down_vfirst_inner(int *oapivot, float *oamax, int dbuf, int iv)
{
    float (*a)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[dbuf];
    int apivot = 0;
    float amax = 0.0f;
    int ka;
    float f;
    int ivline;
    vector float va0, va1, va2, va3;
    vector float va4, va5, va6, va7;
    vector unsigned int vcmp0, vcmp1, vcmp2, vcmp3;
    vector unsigned int vka0, vka1, vka2, vka3; 
    vector unsigned int vka4, vka5, vka6, vka7;

    ivline = iv*4;

    for(ka = 0; ka < BLOCK_SIZE; ka += 8) {
        // ピボットを決める
        vka0 = spu_splats(0u);
        vka1 = spu_splats(1u);
        vka2 = spu_splats(2u);
        vka3 = spu_splats(3u);
        vka4 = spu_splats(4u);
        vka5 = spu_splats(5u);
        vka6 = spu_splats(6u);
        vka7 = spu_splats(7u);

        va0 = *(vector float*)&a[ka  ][ivline];
        va1 = *(vector float*)&a[ka+1][ivline];
        va2 = *(vector float*)&a[ka+2][ivline];
        va3 = *(vector float*)&a[ka+3][ivline];
        va4 = *(vector float*)&a[ka+4][ivline];
        va5 = *(vector float*)&a[ka+5][ivline];
        va6 = *(vector float*)&a[ka+6][ivline];
        va7 = *(vector float*)&a[ka+7][ivline];

        vcmp0 = spu_cmpabsgt(va0, va1);
        vcmp1 = spu_cmpabsgt(va2, va3);
        vcmp2 = spu_cmpabsgt(va4, va5);
        vcmp3 = spu_cmpabsgt(va6, va7);
        va0 = spu_sel(va1, va0, vcmp0);
        va2 = spu_sel(va3, va2, vcmp1);
        va4 = spu_sel(va5, va4, vcmp2);
        va6 = spu_sel(va7, va6, vcmp3);
        vka0 = spu_sel(vka1, vka0, vcmp0);
        vka2 = spu_sel(vka3, vka2, vcmp1);
        vka4 = spu_sel(vka5, vka4, vcmp2);
        vka6 = spu_sel(vka7, vka6, vcmp3);

        vcmp0 = spu_cmpabsgt(va0, va2);
        vcmp2 = spu_cmpabsgt(va4, va6);
        va1 = spu_sel(va2, va0, vcmp0);
        va3 = spu_sel(va6, va4, vcmp2);
        vka1 = spu_sel(vka2, vka0, vcmp0);
        vka3 = spu_sel(vka6, vka4, vcmp2);

        vcmp1 = spu_cmpabsgt(va1, va3);
        va0 = spu_sel(va3, va1, vcmp1);
        vka0 = spu_sel(vka3, vka1, vcmp1);

        f = fabs(spu_extract(va0, 0));
        if(f > amax) {
            apivot = spu_extract(vka0, 0) + ka;
            amax = f;
        }
    }

    *oapivot = apivot;
    *oamax = amax;

    //spe_printf("vf block pivot = %d, max = %.2f\n", apivot, amax);
}

void pivot_selection_down_vfirst(int *oApivot, float *oAmax, int nA, int iA, int iv, eaddr_t eaA)
{
    int jA;
    int Apivot = 0;
    float Amax = 0.0f;
    int apivot = 0;
    float amax = 0.0f;
    int ltag = 0;
    int lbuf;

    jA = (iA+1)/NUMBER_OF_SPES*NUMBER_OF_SPES+speid;
    if(jA < iA+1) {
        jA += NUMBER_OF_SPES;
    }
    //jA = (iA+1) + (NUMBER_OF_SPES + speid - ((iA+1)%NUMBER_OF_SPES)) % NUMBER_OF_SPES;

    for(; jA < nA; jA += NUMBER_OF_SPES) {
        lbuf = BLOCK_L;
        lbuf = colcache_iget_block(lbuf, ltag, nA, jA, iA, eaA);

        dma_wait(ltag);
        pivot_selection_down_vfirst_inner(&apivot, &amax, lbuf, iv);
        if(amax > Amax) {
            Apivot = apivot + jA*BLOCK_SIZE;
            Amax = amax;
            // ピボットの候補は退避
            line_assign(lsuline[ULINE_TARGET], lsblock[lbuf][apivot]);
        }
    }

    *oApivot = Apivot;
    *oAmax = Amax;
}

void send_U_and_pivot(int ubuf, int Apivot, int iA, int iv, int ia)
{
    int i;
    float (*u)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[ubuf];
    usyncdata sync = { { 0, 0, {0}, 0, }, };

    // 他のSPEにUの(iv*4+ia)行を送る
    dma_wait(TAG_SYNC);
    for(i = 0; i < NUMBER_OF_SPES; i++) {
        if(i != speid) {
            mfc_put(u[iv*4+ia], ealsuline[i], sizeof(u[iv*4+ia]), TAG_SYNC, 0, 0);
        }
    }

    sync.s.line = ia+iv*4+iA*BLOCK_SIZE;
    sync.s.p.pivot = Apivot;
    send_signal_all(sync);
}

void receive_U_and_pivot(int *opivot, int ubuf, int iA, int iv, int ia)
{
    int i;

    // 対角担当のSPEからUの(iv*4+ia)行を受け取る
#if defined READ_DECREMENTER
    s = spu_read_decrementer();
    while(lssignal[SYNC_SIGNAL].s.line < ia+iv*4+iA*BLOCK_SIZE) {
        t = spu_read_decrementer();
        if(s-t > PRINT_CYCLE) {
            spe_printf("SPE(%d): too late!(wait U line) step = %d, line(%d) = %d, expected %d\n", speid, gstep, SYNC_SIZE-1, lssignal[SYNC_SIGNAL].s.line, ia);
            s = t;
        }
    }
#else
    while(lssignal[SYNC_SIGNAL].s.line < ia+iv*4+iA*BLOCK_SIZE)  {
        ;
    }
#endif

    *opivot = lssignal[SYNC_SIGNAL].s.p.pivot;

    for(i = 0; i < BLOCK_SIZE; i++) {
        lsblock[ubuf][ia+iv*4][i] = lsuline[ULINE_TARGET][i];
    }
}

void cal_diag_right(int dbuf, int iv, int ia)
{
    int ja;
    int ivline;
    volatile float(*a)[BLOCK_SIZE] = lsblock[dbuf];
    vector float va, vas;
    vector signed int via;
    vector signed int vcnt = { 0, 1, 2, 3, };
    vector unsigned char vsplats0 = gvsplats[0];
    vector unsigned char vsplats1 = gvsplats[1];
    vector unsigned char vsplats2 = gvsplats[2];
    vector unsigned int vcmp;
    int diag;
    vector float vinva;
    vector float vlv0;
    vector float vl0, vl1, vl2;
    vector float vu0, vu1, vu2;

    // 他のSPEに送る行の更新
    // 右側の要素を計算する
    ivline = iv*4;
    diag = ivline+ia;
    via = spu_splats(ia);
    vinva = spu_splats(1.0f/a[diag][diag]);

    va = *(vector float*)&a[diag][ivline];
    vas = spu_mul(va, vinva);

    // diag+1列より左側の部分は元の値に戻す
    vcmp = spu_cmpgt(vcnt, via);
    va = spu_sel(va, vas, vcmp);
    *(vector float*)&a[diag][ivline] = va;

    if(ia == 0) {
        for(ja = ivline+4; ja < BLOCK_SIZE; ja += 4) {
            va = *(vector float*)&a[diag][ja];
            va = spu_mul(va, vinva);
            *(vector float*)&a[diag][ja] = va;
        }
    } else if(ia == 1) {
        vlv0 = *(vector float*)&a[ivline+1][ivline];
        vl0 = spu_shuffle(vlv0, vlv0, vsplats0);

        for(ja = ivline+4; ja < BLOCK_SIZE; ja += 4) {
            va = *(vector float*)&a[diag][ja];
            vu0 = *(vector float*)&a[ivline][ja];
            va = spu_nmsub(vl0, vu0, va);
            va = spu_mul(va, vinva);
            *(vector float*)&a[diag][ja] = va;
        }
    } else if(ia == 2) {
        vlv0 = *(vector float*)&a[ivline+2][ivline];
        vl0 = spu_shuffle(vlv0, vlv0, vsplats0);
        vl1 = spu_shuffle(vlv0, vlv0, vsplats1);

        for(ja = ivline+4; ja < BLOCK_SIZE; ja += 4) {
            va = *(vector float*)&a[diag][ja];
            vu0 = *(vector float*)&a[ivline  ][ja];
            vu1 = *(vector float*)&a[ivline+1][ja];
            va = spu_nmsub(vl0, vu0, va);
            va = spu_nmsub(vl1, vu1, va);
            va = spu_mul(va, vinva);
            *(vector float*)&a[diag][ja] = va;
        }
    } else {
        vlv0 = *(vector float*)&a[ivline+3][ivline];
        vl0 = spu_shuffle(vlv0, vlv0, vsplats0);
        vl1 = spu_shuffle(vlv0, vlv0, vsplats1);
        vl2 = spu_shuffle(vlv0, vlv0, vsplats2);

        for(ja = ivline+4; ja < BLOCK_SIZE; ja += 4) {
            va = *(vector float*)&a[diag][ja];
            vu0 = *(vector float*)&a[ivline  ][ja];
            vu1 = *(vector float*)&a[ivline+1][ja];
            vu2 = *(vector float*)&a[ivline+2][ja];
            va = spu_nmsub(vl0, vu0, va);
            va = spu_nmsub(vl1, vu1, va);
            va = spu_nmsub(vl2, vu2, va);
            va = spu_mul(va, vinva);
            *(vector float*)&a[diag][ja] = va;
        }
    }
}

void cal_diag_iline_and_pivot(int *oapivot, float *oamax, int dbuf, int iv, int ia)
{
    int ka;
    int vline;
    volatile float(*a)[BLOCK_SIZE] = lsblock[dbuf];
    int apivot = 0;
    float amax = 0.0f;
    float f;
    vector float vu0;
    vector float va0, va1, va2, va3;
    vector float vl0, vl1, vl2, vl3;
    vector float vas0, vas1, vas2, vas3;
    vector signed int via;
    vector signed int vcnt = { 0, 1, 2, 3, };
    vector unsigned char viasplats = gvsplats[0];
    vector unsigned char vsplats0 = gvsplats[0];
    vector unsigned char vsplats1 = gvsplats[1];
    vector unsigned char vsplats2 = gvsplats[2];
    vector unsigned char vsplats3 = gvsplats[3];
    vector unsigned char vtemp;
    vector unsigned int vcmp;
    vector unsigned int vcmp0, vcmp1, vcmp2, vcmp3;
    vector unsigned int vpvcmp0, vpvcmp1;
    vector unsigned int vka0, vka1, vka2, vka3;
    vector float vgt0, vgt1;
    vector float vmax;
    vector unsigned int vpivot;
    vector unsigned int vpv0, vpv1;
    int pvpos;

    vtemp = spu_splats((unsigned char)(ia*4));
    viasplats = spu_or(viasplats, vtemp);

    // 16バイト境界で読み込んだ後そのまま計算、余計な部分は元に戻す
    pvpos = ia+1;
    vline = iv*4;
    via = spu_splats(ia);
    vcmp = spu_cmpgt(vcnt, via);

    va0 = *(vector float*)&a[vline  ][vline];
    va1 = *(vector float*)&a[vline+1][vline];
    va2 = *(vector float*)&a[vline+2][vline];
    va3 = *(vector float*)&a[vline+3][vline];
    vl0 = spu_splats(a[vline  ][vline+ia]);
    vl1 = spu_splats(a[vline+1][vline+ia]);
    vl2 = spu_splats(a[vline+2][vline+ia]);
    vl3 = spu_splats(a[vline+3][vline+ia]);
    vu0 = *(vector float*)&a[vline+ia][vline];

    vas0 = spu_nmsub(vl0, vu0, va0);
    vas1 = spu_nmsub(vl1, vu0, va1);
    vas2 = spu_nmsub(vl2, vu0, va2);
    vas3 = spu_nmsub(vl3, vu0, va3);

    vcmp0 = spu_shuffle(vcmp, vcmp, vsplats0);
    vcmp1 = spu_shuffle(vcmp, vcmp, vsplats1);
    vcmp2 = spu_shuffle(vcmp, vcmp, vsplats2);
    vcmp3 = spu_shuffle(vcmp, vcmp, vsplats3);

    vcmp0 = spu_and(vcmp0, vcmp);
    vcmp1 = spu_and(vcmp1, vcmp);
    vcmp2 = spu_and(vcmp2, vcmp);
    vcmp3 = spu_and(vcmp3, vcmp);

    va0 = spu_sel(va0, vas0, vcmp0);
    va1 = spu_sel(va1, vas1, vcmp1);
    va2 = spu_sel(va2, vas2, vcmp2);
    va3 = spu_sel(va3, vas3, vcmp3);

    *(vector float*)&a[vline  ][vline] = va0;
    *(vector float*)&a[vline+1][vline] = va1;
    *(vector float*)&a[vline+2][vline] = va2;
    *(vector float*)&a[vline+3][vline] = va3;

    va0 = (vector float)spu_and(vcmp0, (vector unsigned int)va0);
    va1 = (vector float)spu_and(vcmp1, (vector unsigned int)va1);
    va2 = (vector float)spu_and(vcmp2, (vector unsigned int)va2);
    va3 = (vector float)spu_and(vcmp3, (vector unsigned int)va3);

    vpvcmp0 = spu_cmpabsgt(va0, va1);
    vpvcmp1 = spu_cmpabsgt(va2, va3);

    vka0 = spu_splats((unsigned int)(vline  ));
    vka1 = spu_splats((unsigned int)(vline+1));
    vka2 = spu_splats((unsigned int)(vline+2));
    vka3 = spu_splats((unsigned int)(vline+3));

    vgt0 = spu_sel(va1, va0, vpvcmp0);
    vpv0 = spu_sel(vka1, vka0, vpvcmp0);
    vgt1 = spu_sel(va3, va2, vpvcmp1);
    vpv1 = spu_sel(vka3, vka2, vpvcmp1);

    vpvcmp0 = spu_cmpabsgt(vgt0, vgt1);

    vmax = spu_sel(vgt1, vgt0, vpvcmp0);
    vpivot = spu_sel(vpv1, vpv0, vpvcmp0);

    apivot = spu_extract(vpivot, pvpos);
    amax = (float)fabs(spu_extract(vmax, pvpos));

    for(ka = vline+4; ka < BLOCK_SIZE; ka += 4) {
        va0 = *(vector float*)&a[ka  ][vline];
        va1 = *(vector float*)&a[ka+1][vline];
        va2 = *(vector float*)&a[ka+2][vline];
        va3 = *(vector float*)&a[ka+3][vline];
        vl0 = spu_shuffle(va0, va0, viasplats);
        vl1 = spu_shuffle(va1, va1, viasplats);
        vl2 = spu_shuffle(va2, va2, viasplats);
        vl3 = spu_shuffle(va3, va3, viasplats);
        vu0 = *(vector float*)&a[vline+ia][vline];

        vas0 = spu_nmsub(vl0, vu0, va0);
        vas1 = spu_nmsub(vl1, vu0, va1);
        vas2 = spu_nmsub(vl2, vu0, va2);
        vas3 = spu_nmsub(vl3, vu0, va3);

        // ia+1列より左側の部分は元の値に戻す
        va0 = spu_sel(va0, vas0, vcmp);
        va1 = spu_sel(va1, vas1, vcmp);
        va2 = spu_sel(va2, vas2, vcmp);
        va3 = spu_sel(va3, vas3, vcmp);
        *(vector float*)&a[ka  ][vline] = va0;
        *(vector float*)&a[ka+1][vline] = va1;
        *(vector float*)&a[ka+2][vline] = va2;
        *(vector float*)&a[ka+3][vline] = va3;

        vka0 = spu_splats(0u);
        vka1 = spu_splats(1u);
        vka2 = spu_splats(2u);
        vka3 = spu_splats(3u);

        vcmp0 = spu_cmpabsgt(vas0, vas1);
        vcmp1 = spu_cmpabsgt(vas2, vas3);
        vas0 = spu_sel(vas1, vas0, vcmp0);
        vas1 = spu_sel(vas3, vas2, vcmp1);
        vka0 = spu_sel(vka1, vka0, vcmp0);
        vka1 = spu_sel(vka3, vka2, vcmp1);

        vcmp0 = spu_cmpabsgt(vas0, vas1);
        vas0 = spu_sel(vas1, vas0, vcmp0);
        vka0 = spu_sel(vka1, vka0, vcmp0);

        f = (float)fabs(spu_extract(vas0, pvpos));
        if(f > amax) {
            apivot = spu_extract(vka0, pvpos) + ka;
            amax = f;
        }
    }

    *oapivot = apivot;
    *oamax = amax;

    //spe_printf("diag pivot = %d, max = %.2f\n", apivot, amax);
}

void cal_down_iline_and_pivot_inner(int *oapivot, float *oamax, int dbuf, int ubuf, int iv, int ia)
{
    int ivline;
    int pvpos;
    int posqw;
    float (*a)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[dbuf];
    float (*u)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[ubuf];
    vector float vu0;
    vector float va0, va1, va2, va3;
    vector float va4, va5, va6, va7;
    vector float va8, va9, va10, va11;
    vector float va12, va13, va14, va15;
    vector float va16, va17, va18, va19;
    vector float va20, va21, va22, va23;
    vector float va24, va25, va26, va27;
    vector float va28, va29, va30, va31;
    vector float vas0, vas1, vas2, vas3; // 使用レジスタ数を減少させるために他の関数でいうvl*にあたる役割も与える
    vector float vas4, vas5, vas6, vas7;
    vector float vas8, vas9, vas10, vas11;
    vector float vas12, vas13, vas14, vas15;
    vector float vas16, vas17, vas18, vas19;
    vector float vas20, vas21, vas22, vas23;
    vector float vas24, vas25, vas26, vas27;
    vector float vas28, vas29, vas30, vas31;
    vector signed int via;
    vector signed int vcnt = { 0, 1, 2, 3, };
    vector unsigned int vcmp;
    vector unsigned char viasplats = { 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, };
    vector unsigned char vtemp;
    vector unsigned int vcmp0, vcmp1, vcmp2, vcmp3;
    vector unsigned int vcmp4, vcmp5, vcmp6, vcmp7;
    vector unsigned int vcmp8, vcmp9, vcmp10, vcmp11;
    vector unsigned int vcmp12, vcmp13, vcmp14, vcmp15;
    vector unsigned int vka0, vka1, vka2, vka3;
    vector unsigned int vka4, vka5, vka6, vka7;
    vector unsigned int vka8, vka9, vka10, vka11;
    vector unsigned int vka12, vka13, vka14, vka15;
    vector unsigned int vka16, vka17, vka18, vka19;
    vector unsigned int vka20, vka21, vka22, vka23;
    vector unsigned int vka24, vka25, vka26, vka27;
    vector unsigned int vka28, vka29, vka30, vka31;

    vka0  = spu_splats(0u);
    vka1  = spu_splats(1u);
    vka2  = spu_splats(2u);
    vka3  = spu_splats(3u);
    vka4  = spu_splats(4u);
    vka5  = spu_splats(5u);
    vka6  = spu_splats(6u);
    vka7  = spu_splats(7u);
    vka8  = spu_splats(8u);
    vka9  = spu_splats(9u);
    vka10 = spu_splats(10u);
    vka11 = spu_splats(11u);
    vka12 = spu_splats(12u);
    vka13 = spu_splats(13u);
    vka14 = spu_splats(14u);
    vka15 = spu_splats(15u);
    vka16 = spu_splats(16u);
    vka17 = spu_splats(17u);
    vka18 = spu_splats(18u);
    vka19 = spu_splats(19u);
    vka20 = spu_splats(20u);
    vka21 = spu_splats(21u);
    vka22 = spu_splats(22u);
    vka23 = spu_splats(23u);
    vka24 = spu_splats(24u);
    vka25 = spu_splats(25u);
    vka26 = spu_splats(26u);
    vka27 = spu_splats(27u);
    vka28 = spu_splats(28u);
    vka29 = spu_splats(29u);
    vka30 = spu_splats(30u);
    vka31 = spu_splats(31u);

    ivline = iv*4;
    via = spu_splats(ia);
    vcmp = spu_cmpgt(vcnt, via);
    pvpos = ia+1;
    posqw = pvpos*4;
    vtemp = spu_splats((unsigned char)(ia*4));
    viasplats = spu_or(viasplats, vtemp);
 
    va0  = *(vector float*)&a[ 0][ivline];
    va1  = *(vector float*)&a[ 1][ivline];
    va2  = *(vector float*)&a[ 2][ivline];
    va3  = *(vector float*)&a[ 3][ivline];
    va4  = *(vector float*)&a[ 4][ivline];
    va5  = *(vector float*)&a[ 5][ivline];
    va6  = *(vector float*)&a[ 6][ivline];
    va7  = *(vector float*)&a[ 7][ivline];
    va8  = *(vector float*)&a[ 8][ivline];
    va9  = *(vector float*)&a[ 9][ivline];
    va10 = *(vector float*)&a[10][ivline];
    va11 = *(vector float*)&a[11][ivline];
    va12 = *(vector float*)&a[12][ivline];
    va13 = *(vector float*)&a[13][ivline];
    va14 = *(vector float*)&a[14][ivline];
    va15 = *(vector float*)&a[15][ivline];
    va16 = *(vector float*)&a[16][ivline];
    va17 = *(vector float*)&a[17][ivline];
    va18 = *(vector float*)&a[18][ivline];
    va19 = *(vector float*)&a[19][ivline];
    va20 = *(vector float*)&a[20][ivline];
    va21 = *(vector float*)&a[21][ivline];
    va22 = *(vector float*)&a[22][ivline];
    va23 = *(vector float*)&a[23][ivline];
    va24 = *(vector float*)&a[24][ivline];
    va25 = *(vector float*)&a[25][ivline];
    va26 = *(vector float*)&a[26][ivline];
    va27 = *(vector float*)&a[27][ivline];
    va28 = *(vector float*)&a[28][ivline];
    va29 = *(vector float*)&a[29][ivline];
    va30 = *(vector float*)&a[30][ivline];
    va31 = *(vector float*)&a[31][ivline];

    vas0  = spu_shuffle(va0,  va0,  viasplats);
    vas1  = spu_shuffle(va1,  va1,  viasplats);
    vas2  = spu_shuffle(va2,  va2,  viasplats);
    vas3  = spu_shuffle(va3,  va3,  viasplats);
    vas4  = spu_shuffle(va4,  va4,  viasplats);
    vas5  = spu_shuffle(va5,  va5,  viasplats);
    vas6  = spu_shuffle(va6,  va6,  viasplats);
    vas7  = spu_shuffle(va7,  va7,  viasplats);
    vas8  = spu_shuffle(va8,  va8,  viasplats);
    vas9  = spu_shuffle(va9,  va9,  viasplats);
    vas10 = spu_shuffle(va10, va10, viasplats);
    vas11 = spu_shuffle(va11, va11, viasplats);
    vas12 = spu_shuffle(va12, va12, viasplats);
    vas13 = spu_shuffle(va13, va13, viasplats);
    vas14 = spu_shuffle(va14, va14, viasplats);
    vas15 = spu_shuffle(va15, va15, viasplats);
    vas16 = spu_shuffle(va16, va16, viasplats);
    vas17 = spu_shuffle(va17, va17, viasplats);
    vas18 = spu_shuffle(va18, va18, viasplats);
    vas19 = spu_shuffle(va19, va19, viasplats);
    vas20 = spu_shuffle(va20, va20, viasplats);
    vas21 = spu_shuffle(va21, va21, viasplats);
    vas22 = spu_shuffle(va22, va22, viasplats);
    vas23 = spu_shuffle(va23, va23, viasplats);
    vas24 = spu_shuffle(va24, va24, viasplats);
    vas25 = spu_shuffle(va25, va25, viasplats);
    vas26 = spu_shuffle(va26, va26, viasplats);
    vas27 = spu_shuffle(va27, va27, viasplats);
    vas28 = spu_shuffle(va28, va28, viasplats);
    vas29 = spu_shuffle(va29, va29, viasplats);
    vas30 = spu_shuffle(va30, va30, viasplats);
    vas31 = spu_shuffle(va31, va31, viasplats);

    vu0 = *(vector float*)&u[ivline+ia][ivline];

    vas0  = spu_nmsub(vas0,  vu0, va0);
    vas1  = spu_nmsub(vas1,  vu0, va1);
    vas2  = spu_nmsub(vas2,  vu0, va2);
    vas3  = spu_nmsub(vas3,  vu0, va3);
    vas4  = spu_nmsub(vas4,  vu0, va4);
    vas5  = spu_nmsub(vas5,  vu0, va5);
    vas6  = spu_nmsub(vas6,  vu0, va6);
    vas7  = spu_nmsub(vas7,  vu0, va7);
    vas8  = spu_nmsub(vas8,  vu0, va8);
    vas9  = spu_nmsub(vas9,  vu0, va9);
    vas10 = spu_nmsub(vas10, vu0, va10);
    vas11 = spu_nmsub(vas11, vu0, va11);
    vas12 = spu_nmsub(vas12, vu0, va12);
    vas13 = spu_nmsub(vas13, vu0, va13);
    vas14 = spu_nmsub(vas14, vu0, va14);
    vas15 = spu_nmsub(vas15, vu0, va15);
    vas16 = spu_nmsub(vas16, vu0, va16);
    vas17 = spu_nmsub(vas17, vu0, va17);
    vas18 = spu_nmsub(vas18, vu0, va18);
    vas19 = spu_nmsub(vas19, vu0, va19);
    vas20 = spu_nmsub(vas20, vu0, va20);
    vas21 = spu_nmsub(vas21, vu0, va21);
    vas22 = spu_nmsub(vas22, vu0, va22);
    vas23 = spu_nmsub(vas23, vu0, va23);
    vas24 = spu_nmsub(vas24, vu0, va24);
    vas25 = spu_nmsub(vas25, vu0, va25);
    vas26 = spu_nmsub(vas26, vu0, va26);
    vas27 = spu_nmsub(vas27, vu0, va27);
    vas28 = spu_nmsub(vas28, vu0, va28);
    vas29 = spu_nmsub(vas29, vu0, va29);
    vas30 = spu_nmsub(vas30, vu0, va30);
    vas31 = spu_nmsub(vas31, vu0, va31);

    // ia+1列より左側の部分は元の値に戻す
    va0  = spu_sel(va0,  vas0,  vcmp);
    va1  = spu_sel(va1,  vas1,  vcmp);
    va2  = spu_sel(va2,  vas2,  vcmp);
    va3  = spu_sel(va3,  vas3,  vcmp);
    va4  = spu_sel(va4,  vas4,  vcmp);
    va5  = spu_sel(va5,  vas5,  vcmp);
    va6  = spu_sel(va6,  vas6,  vcmp);
    va7  = spu_sel(va7,  vas7,  vcmp);
    va8  = spu_sel(va8,  vas8,  vcmp);
    va9  = spu_sel(va9,  vas9,  vcmp);
    va10 = spu_sel(va10, vas10, vcmp);
    va11 = spu_sel(va11, vas11, vcmp);
    va12 = spu_sel(va12, vas12, vcmp);
    va13 = spu_sel(va13, vas13, vcmp);
    va14 = spu_sel(va14, vas14, vcmp);
    va15 = spu_sel(va15, vas15, vcmp);
    va16 = spu_sel(va16, vas16, vcmp);
    va17 = spu_sel(va17, vas17, vcmp);
    va18 = spu_sel(va18, vas18, vcmp);
    va19 = spu_sel(va19, vas19, vcmp);
    va20 = spu_sel(va20, vas20, vcmp);
    va21 = spu_sel(va21, vas21, vcmp);
    va22 = spu_sel(va22, vas22, vcmp);
    va23 = spu_sel(va23, vas23, vcmp);
    va24 = spu_sel(va24, vas24, vcmp);
    va25 = spu_sel(va25, vas25, vcmp);
    va26 = spu_sel(va26, vas26, vcmp);
    va27 = spu_sel(va27, vas27, vcmp);
    va28 = spu_sel(va28, vas28, vcmp);
    va29 = spu_sel(va29, vas29, vcmp);
    va30 = spu_sel(va30, vas30, vcmp);
    va31 = spu_sel(va31, vas31, vcmp);

    *(vector float*)&a[ 0][ivline] = va0;
    *(vector float*)&a[ 1][ivline] = va1;
    *(vector float*)&a[ 2][ivline] = va2;
    *(vector float*)&a[ 3][ivline] = va3;
    *(vector float*)&a[ 4][ivline] = va4;
    *(vector float*)&a[ 5][ivline] = va5;
    *(vector float*)&a[ 6][ivline] = va6;
    *(vector float*)&a[ 7][ivline] = va7;
    *(vector float*)&a[ 8][ivline] = va8;
    *(vector float*)&a[ 9][ivline] = va9;
    *(vector float*)&a[10][ivline] = va10;
    *(vector float*)&a[11][ivline] = va11;
    *(vector float*)&a[12][ivline] = va12;
    *(vector float*)&a[13][ivline] = va13;
    *(vector float*)&a[14][ivline] = va14;
    *(vector float*)&a[15][ivline] = va15;
    *(vector float*)&a[16][ivline] = va16;
    *(vector float*)&a[17][ivline] = va17;
    *(vector float*)&a[18][ivline] = va18;
    *(vector float*)&a[19][ivline] = va19;
    *(vector float*)&a[20][ivline] = va20;
    *(vector float*)&a[21][ivline] = va21;
    *(vector float*)&a[22][ivline] = va22;
    *(vector float*)&a[23][ivline] = va23;
    *(vector float*)&a[24][ivline] = va24;
    *(vector float*)&a[25][ivline] = va25;
    *(vector float*)&a[26][ivline] = va26;
    *(vector float*)&a[27][ivline] = va27;
    *(vector float*)&a[28][ivline] = va28;
    *(vector float*)&a[29][ivline] = va29;
    *(vector float*)&a[30][ivline] = va30;
    *(vector float*)&a[31][ivline] = va31;

    // ピボットを決める
    vcmp0 = spu_cmpabsgt(vas0, vas1);
    vcmp1 = spu_cmpabsgt(vas2, vas3);
    vcmp2 = spu_cmpabsgt(vas4, vas5);
    vcmp3 = spu_cmpabsgt(vas6, vas7);
    vcmp4 = spu_cmpabsgt(vas8, vas9);
    vcmp5 = spu_cmpabsgt(vas10, vas11);
    vcmp6 = spu_cmpabsgt(vas12, vas13);
    vcmp7 = spu_cmpabsgt(vas14, vas15);
    vcmp8 = spu_cmpabsgt(vas16, vas17);
    vcmp9 = spu_cmpabsgt(vas18, vas19);
    vcmp10 = spu_cmpabsgt(vas20, vas21);
    vcmp11 = spu_cmpabsgt(vas22, vas23);
    vcmp12 = spu_cmpabsgt(vas24, vas25);
    vcmp13 = spu_cmpabsgt(vas26, vas27);
    vcmp14 = spu_cmpabsgt(vas28, vas29);
    vcmp15 = spu_cmpabsgt(vas30, vas31);
    vas0 = spu_sel(vas1, vas0, vcmp0);
    vas1 = spu_sel(vas3, vas2, vcmp1);
    vas2 = spu_sel(vas5, vas4, vcmp2);
    vas3 = spu_sel(vas7, vas6, vcmp3);
    vas4 = spu_sel(vas9, vas8, vcmp4);
    vas5 = spu_sel(vas11, vas10, vcmp5);
    vas6 = spu_sel(vas13, vas12, vcmp6);
    vas7 = spu_sel(vas15, vas14, vcmp7);
    vas8 = spu_sel(vas17, vas16, vcmp8);
    vas9 = spu_sel(vas19, vas18, vcmp9);
    vas10 = spu_sel(vas21, vas20, vcmp10);
    vas11 = spu_sel(vas23, vas22, vcmp11);
    vas12 = spu_sel(vas25, vas24, vcmp12);
    vas13 = spu_sel(vas27, vas26, vcmp13);
    vas14 = spu_sel(vas29, vas28, vcmp14);
    vas15 = spu_sel(vas31, vas30, vcmp15);
    vka0 = spu_sel(vka1, vka0, vcmp0);
    vka1 = spu_sel(vka3, vka2, vcmp1);
    vka2 = spu_sel(vka5, vka4, vcmp2);
    vka3 = spu_sel(vka7, vka6, vcmp3);
    vka4 = spu_sel(vka9, vka8, vcmp4);
    vka5 = spu_sel(vka11, vka10, vcmp5);
    vka6 = spu_sel(vka13, vka12, vcmp6);
    vka7 = spu_sel(vka15, vka14, vcmp7);
    vka8 = spu_sel(vka17, vka16, vcmp8);
    vka9 = spu_sel(vka19, vka18, vcmp9);
    vka10 = spu_sel(vka21, vka20, vcmp10);
    vka11 = spu_sel(vka23, vka22, vcmp11);
    vka12 = spu_sel(vka25, vka24, vcmp12);
    vka13 = spu_sel(vka27, vka26, vcmp13);
    vka14 = spu_sel(vka29, vka28, vcmp14);
    vka15 = spu_sel(vka31, vka30, vcmp15);

    vcmp0 = spu_cmpabsgt(vas0, vas1);
    vcmp1 = spu_cmpabsgt(vas2, vas3);
    vcmp2 = spu_cmpabsgt(vas4, vas5);
    vcmp3 = spu_cmpabsgt(vas6, vas7);
    vcmp4 = spu_cmpabsgt(vas8, vas9);
    vcmp5 = spu_cmpabsgt(vas10, vas11);
    vcmp6 = spu_cmpabsgt(vas12, vas13);
    vcmp7 = spu_cmpabsgt(vas14, vas15);
    vas0 = spu_sel(vas1, vas0, vcmp0);
    vas1 = spu_sel(vas3, vas2, vcmp1);
    vas2 = spu_sel(vas5, vas4, vcmp2);
    vas3 = spu_sel(vas7, vas6, vcmp3);
    vas4 = spu_sel(vas9, vas8, vcmp4);
    vas5 = spu_sel(vas11, vas10, vcmp5);
    vas6 = spu_sel(vas13, vas12, vcmp6);
    vas7 = spu_sel(vas15, vas14, vcmp7);
    vka0 = spu_sel(vka1, vka0, vcmp0);
    vka1 = spu_sel(vka3, vka2, vcmp1);
    vka2 = spu_sel(vka5, vka4, vcmp2);
    vka3 = spu_sel(vka7, vka6, vcmp3);
    vka4 = spu_sel(vka9, vka8, vcmp4);
    vka5 = spu_sel(vka11, vka10, vcmp5);
    vka6 = spu_sel(vka13, vka12, vcmp6);
    vka7 = spu_sel(vka15, vka14, vcmp7);

    vcmp0 = spu_cmpabsgt(vas0, vas1);
    vcmp1 = spu_cmpabsgt(vas2, vas3);
    vcmp2 = spu_cmpabsgt(vas4, vas5);
    vcmp3 = spu_cmpabsgt(vas6, vas7);
    vas0 = spu_sel(vas1, vas0, vcmp0);
    vas1 = spu_sel(vas3, vas2, vcmp1);
    vas2 = spu_sel(vas5, vas4, vcmp2);
    vas3 = spu_sel(vas7, vas6, vcmp3);
    vka0 = spu_sel(vka1, vka0, vcmp0);
    vka1 = spu_sel(vka3, vka2, vcmp1);
    vka2 = spu_sel(vka5, vka4, vcmp2);
    vka3 = spu_sel(vka7, vka6, vcmp3);

    vcmp0 = spu_cmpabsgt(vas0, vas1);
    vcmp1 = spu_cmpabsgt(vas2, vas3);
    vas0 = spu_sel(vas1, vas0, vcmp0);
    vas1 = spu_sel(vas3, vas2, vcmp1);
    vka0 = spu_sel(vka1, vka0, vcmp0);
    vka1 = spu_sel(vka3, vka2, vcmp1);

    vcmp0 = spu_cmpabsgt(vas0, vas1);
    vas0 = spu_sel(vas1, vas0, vcmp0);
    vka0 = spu_sel(vka1, vka0, vcmp0);

    *oapivot = spu_extract(vka0, pvpos);
    *oamax = fabs(spu_extract(vas0, pvpos));

    //spe_printf("block pivot = %d, max = %.2f\n", apivot, amax);
}

void cal_down_iline_and_pivot(int *oApivot, float *oAmax, int ubuf, int nA, int iA, int iv, int ia, eaddr_t eaA)
{
    int jA;
    int Apivot = 0;
    float Amax = 0.0f;
    int apivot = 0;
    float amax = 0.0f;
    int ltag = 0;
    int lbuf;

    jA = (iA+1)/NUMBER_OF_SPES*NUMBER_OF_SPES+speid;
    if(jA < iA+1) {
        jA += NUMBER_OF_SPES;
    }
    //jA = (iA+1) + (NUMBER_OF_SPES + speid - ((iA+1)%NUMBER_OF_SPES)) % NUMBER_OF_SPES;

    for(; jA < nA; jA += NUMBER_OF_SPES) {
        lbuf = BLOCK_L;
        lbuf = colcache_iget_block(lbuf, ltag, nA, jA, iA, eaA);

        dma_wait(ltag);
        cal_down_iline_and_pivot_inner(&apivot, &amax, lbuf, ubuf, iv, ia);

        if(amax > Amax) {
            Apivot = apivot + jA*BLOCK_SIZE;
            Amax = amax;
            // ピボットの候補は退避
            line_assign(lsuline[ULINE_TARGET], lsblock[lbuf][apivot]); 
            //for(i = 0; i < BLOCK_SIZE; i++) {
            //    lsuline[ULINE_TARGET][i] = lsblock[lbuf][apivot][i];
            //}
        }

        colcache_iputb_block(lbuf, ltag, nA, jA, iA, eaA);
    }

    *oApivot = Apivot;
    *oAmax = Amax;
}

void receive_pivot(int *oApivot, int Apivot, float Amax)
{
    int i;
    //int b;

    // 他のSPEからのシグナルを待つ
    for(i = 0; i < NUMBER_OF_SPES; i++) {
        if(i != speid) {
#if defined READ_DECREMENTER
            s = spu_read_decrementer();
            while(lssignal[i].s.line == -1) {
                t = spu_read_decrementer();
                if(s-t > PRINT_CYCLE) {
                    spe_printf("SPE(%d): too late!(wait pivot) step = %d, sig(%d) = %d\n", speid, gstep, i, lssignal[i].s.line);
                    s = t;
                }
            }
#else
            while(lssignal[i].s.line == -1) {
                ;
            }
#endif
            lsresult[i].v = lssignal[i].v;
            lssignal[i].s.line = -1;

            if(lsresult[i].s.p.max > Amax) {
                Apivot = lsresult[i].s.line;
                Amax = lsresult[i].s.p.max;
            }
        }
    }

    for(i = 0; i < NUMBER_OF_SPES; i++) {
        //b = (lsresult[i].s.p.max > Amax && i != speid);
        //Apivot = (b) ? lsresult[i].s.line : Apivot;
        //Amax = (b) ? lsresult[i].s.p.max : Amax;

        if(lsresult[i].s.p.max > Amax && i != speid) {
            Apivot = lsresult[i].s.line;
            Amax = lsresult[i].s.p.max;
        }
    }

    *oApivot = Apivot;
}

void send_pivot(int diagspe, int Apivot, float Amax)
{
    usyncdata signal = gsyncinit;

    // 対角担当のSPEに情報を送る
    signal.s.line = Apivot;
    signal.s.p.max = Amax;
    dma_wait(TAG_SYNC);
    send_signal_to(diagspe, signal);
}

void cal_diag_down_right_and_pivot(int *oapivot, float *oamax, int dbuf, int iv)
{
    int ia, ja, ka;
    int ivline;
    float (*a)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[dbuf];
    vector float va0, va1, va2, va3;
    vector float vlv0, vlv1, vlv2, vlv3;
    vector float vl00, vl01, vl02, vl03;
    vector float vl10, vl11, vl12, vl13;
    vector float vl20, vl21, vl22, vl23;
    vector float vl30, vl31, vl32, vl33;
    vector float vu0, vu1, vu2, vu3;
    vector unsigned char vsplats0 = gvsplats[0];
    vector unsigned char vsplats1 = gvsplats[1];
    vector unsigned char vsplats2 = gvsplats[2];
    vector unsigned char vsplats3 = gvsplats[3];
    int apivot = 0;
    float amax = 0.0f;
    u_vfloat_float uvf;
    int pos = (iv+1)*INNER_BLOCK_SIZE;

    ivline = iv*4;

    for(ka = ivline+4; ka < BLOCK_SIZE; ka += 4) {
        vlv0 = *(vector float*)&a[ka  ][ivline];
        vlv1 = *(vector float*)&a[ka+1][ivline];
        vlv2 = *(vector float*)&a[ka+2][ivline];
        vlv3 = *(vector float*)&a[ka+3][ivline];

        vl00 = spu_shuffle(vlv0, vlv0, vsplats0);
        vl01 = spu_shuffle(vlv0, vlv0, vsplats1);
        vl02 = spu_shuffle(vlv0, vlv0, vsplats2);
        vl03 = spu_shuffle(vlv0, vlv0, vsplats3);

        vl10 = spu_shuffle(vlv1, vlv1, vsplats0);
        vl11 = spu_shuffle(vlv1, vlv1, vsplats1);
        vl12 = spu_shuffle(vlv1, vlv1, vsplats2);
        vl13 = spu_shuffle(vlv1, vlv1, vsplats3);

        vl20 = spu_shuffle(vlv2, vlv2, vsplats0);
        vl21 = spu_shuffle(vlv2, vlv2, vsplats1);
        vl22 = spu_shuffle(vlv2, vlv2, vsplats2);
        vl23 = spu_shuffle(vlv2, vlv2, vsplats3);

        vl30 = spu_shuffle(vlv3, vlv3, vsplats0);
        vl31 = spu_shuffle(vlv3, vlv3, vsplats1);
        vl32 = spu_shuffle(vlv3, vlv3, vsplats2);
        vl33 = spu_shuffle(vlv3, vlv3, vsplats3);

        for(ja = ivline+4; ja < BLOCK_SIZE; ja += 4) {
            va0 = *(vector float*)&a[ka  ][ja];
            va1 = *(vector float*)&a[ka+1][ja];
            va2 = *(vector float*)&a[ka+2][ja];
            va3 = *(vector float*)&a[ka+3][ja];

            vu0 = *(vector float*)&a[ivline  ][ja];
            vu1 = *(vector float*)&a[ivline+1][ja];
            vu2 = *(vector float*)&a[ivline+2][ja];
            vu3 = *(vector float*)&a[ivline+3][ja];

            va0 = spu_nmsub(vl00, vu0, va0);
            va0 = spu_nmsub(vl01, vu1, va0);
            va0 = spu_nmsub(vl02, vu2, va0);
            va0 = spu_nmsub(vl03, vu3, va0);

            va1 = spu_nmsub(vl10, vu0, va1);
            va1 = spu_nmsub(vl11, vu1, va1);
            va1 = spu_nmsub(vl12, vu2, va1);
            va1 = spu_nmsub(vl13, vu3, va1);

            va2 = spu_nmsub(vl20, vu0, va2);
            va2 = spu_nmsub(vl21, vu1, va2);
            va2 = spu_nmsub(vl22, vu2, va2);
            va2 = spu_nmsub(vl23, vu3, va2);

            va3 = spu_nmsub(vl30, vu0, va3);
            va3 = spu_nmsub(vl31, vu1, va3);
            va3 = spu_nmsub(vl32, vu2, va3);
            va3 = spu_nmsub(vl33, vu3, va3);

            *(vector float*)&a[ka  ][ja] = va0;
            *(vector float*)&a[ka+1][ja] = va1;
            *(vector float*)&a[ka+2][ja] = va2;
            *(vector float*)&a[ka+3][ja] = va3;
        }
    }

    for(ia = pos; ia < BLOCK_SIZE; ia++) {
        uvf.v = *(vector float*)&a[ia][pos];
        uvf.f = fabs(uvf.f);
        if(uvf.f > amax) {
            apivot = ia;
            amax = uvf.f;
        }
    }

    *oapivot = apivot;
    *oamax = amax;
}

void cal_down_right_inner(int dbuf, int ubuf, int iv)
{
    int ja, ka;
    int ivline;
    float (*a)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[dbuf];
    float (*u)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[ubuf];
    vector float va0, va1, va2, va3;
    vector float vlv0, vlv1, vlv2, vlv3;
    vector float vl00, vl10, vl20, vl30;
    vector float vl01, vl11, vl21, vl31;
    vector float vl02, vl12, vl22, vl32;
    vector float vl03, vl13, vl23, vl33;
    vector float vu0, vu1, vu2, vu3;
    vector unsigned char vsplats0 = gvsplats[0];
    vector unsigned char vsplats1 = gvsplats[1];
    vector unsigned char vsplats2 = gvsplats[2];
    vector unsigned char vsplats3 = gvsplats[3];

    ivline = iv*4;

    for(ka = 0; ka < BLOCK_SIZE; ka += 4) {
        vlv0 = *(vector float*)&a[ka  ][ivline];
        vl00 = spu_shuffle(vlv0, vlv0, vsplats0);
        vl01 = spu_shuffle(vlv0, vlv0, vsplats1);
        vl02 = spu_shuffle(vlv0, vlv0, vsplats2);
        vl03 = spu_shuffle(vlv0, vlv0, vsplats3);

        vlv1 = *(vector float*)&a[ka+1][ivline];
        vl10 = spu_shuffle(vlv1, vlv1, vsplats0);
        vl11 = spu_shuffle(vlv1, vlv1, vsplats1);
        vl12 = spu_shuffle(vlv1, vlv1, vsplats2);
        vl13 = spu_shuffle(vlv1, vlv1, vsplats3);

        vlv2 = *(vector float*)&a[ka+2][ivline];
        vl20 = spu_shuffle(vlv2, vlv2, vsplats0);
        vl21 = spu_shuffle(vlv2, vlv2, vsplats1);
        vl22 = spu_shuffle(vlv2, vlv2, vsplats2);
        vl23 = spu_shuffle(vlv2, vlv2, vsplats3);

        vlv3 = *(vector float*)&a[ka+3][ivline];
        vl30 = spu_shuffle(vlv3, vlv3, vsplats0);
        vl31 = spu_shuffle(vlv3, vlv3, vsplats1);
        vl32 = spu_shuffle(vlv3, vlv3, vsplats2);
        vl33 = spu_shuffle(vlv3, vlv3, vsplats3);

        for(ja = ivline+4; ja < BLOCK_SIZE; ja += 4) {
            va0 = *(vector float*)&a[ka  ][ja];
            va1 = *(vector float*)&a[ka+1][ja];
            va2 = *(vector float*)&a[ka+2][ja];
            va3 = *(vector float*)&a[ka+3][ja];
            vu0 = *(vector float*)&u[ivline  ][ja];
            vu1 = *(vector float*)&u[ivline+1][ja];
            vu2 = *(vector float*)&u[ivline+2][ja];
            vu3 = *(vector float*)&u[ivline+3][ja];

            va0 = spu_nmsub(vl00, vu0, va0);
            va0 = spu_nmsub(vl01, vu1, va0);
            va0 = spu_nmsub(vl02, vu2, va0);
            va0 = spu_nmsub(vl03, vu3, va0);

            va1 = spu_nmsub(vl10, vu0, va1);
            va1 = spu_nmsub(vl11, vu1, va1);
            va1 = spu_nmsub(vl12, vu2, va1);
            va1 = spu_nmsub(vl13, vu3, va1);

            va2 = spu_nmsub(vl20, vu0, va2);
            va2 = spu_nmsub(vl21, vu1, va2);
            va2 = spu_nmsub(vl22, vu2, va2);
            va2 = spu_nmsub(vl23, vu3, va2);

            va3 = spu_nmsub(vl30, vu0, va3);
            va3 = spu_nmsub(vl31, vu1, va3);
            va3 = spu_nmsub(vl32, vu2, va3);
            va3 = spu_nmsub(vl33, vu3, va3);

            *(vector float*)&a[ka  ][ja] = va0;
            *(vector float*)&a[ka+1][ja] = va1;
            *(vector float*)&a[ka+2][ja] = va2;
            *(vector float*)&a[ka+3][ja] = va3;
        }
    }
}

void cal_down_right(int ubuf, int nA, int iA, int iv, eaddr_t eaA)
{
    int jA;
    int ltag = 0;
    int lbuf;

    jA = (iA+1)/NUMBER_OF_SPES*NUMBER_OF_SPES+speid;
    if(jA < iA+1) {
        jA += NUMBER_OF_SPES;
    }

    for(; jA < nA; jA += NUMBER_OF_SPES) {
        lbuf = BLOCK_L;
        lbuf = colcache_iget_block(lbuf, ltag, nA, jA, iA, eaA);

        dma_wait(ltag);
        cal_down_right_inner(lbuf, ubuf, iv);

        colcache_iputb_block(lbuf, ltag, nA, jA, iA, eaA);
    }
}

void column_block_decomposition_diag(int nA, int iA, eaddr_t eaA, eaddr_t eaP)
{
    volatile float (*a)[BLOCK_SIZE];
    int iv, ia;
    int Apivot;
    float Amax;
    int apivot;
    float amax;
    int dbuf;
    int perm = PERM_TARGET;

    dbuf = colcache_iget_block(BLOCK_D, TAG_SYNC, nA, iA, iA, eaA);
    dma_wait(TAG_SYNC);
    a = lsblock[dbuf];

    iget_perm(perm, TAG_PERM, iA, eaP);

    swap_init_perm(iA);

    dma_wait(TAG_PERM);
    
    Apivot = 0;
    Amax = 0.0f;
    pivot_selection_diag_vfirst(&apivot, &amax, dbuf, 0);
    pivot_selection_down_vfirst(&Apivot, &Amax, nA, iA, 0, eaA);

    for(iv = 0; iv < INNER_BLOCK_COUNT; iv++) {

        if(amax > Amax) {
            Apivot = apivot + iA*BLOCK_SIZE;
            Amax = amax;
            
            line_assign(lsuline[ULINE_TARGET], lsblock[dbuf][apivot]);
        }

        receive_pivot(&Apivot, Apivot, Amax);

        for(ia = 0; ia < 3; ia++) {
            //column_block_decomposition_diag_inner(&Apivot, dbuf, perm, nA, iA, iv, ia, eaA, eaP);
#if defined ENABLE_SWAP
            //spe_printf("pivot(%d) = %d\n", iA*BLOCK_SIZE+iv*4+ia, Apivot);
            swap_diag(dbuf, perm, iA*BLOCK_SIZE+iv*4+ia, Apivot, nA, iA, eaA, eaP);
#endif

            cal_diag_right(dbuf, iv, ia);
            send_U_and_pivot(dbuf, Apivot, iA, iv, ia);

            Apivot = 0;
            Amax = 0.0f;
            cal_diag_iline_and_pivot(&apivot, &amax, dbuf, iv, ia);
            cal_down_iline_and_pivot(&Apivot, &Amax, dbuf, nA, iA, iv, ia, eaA);

            if(amax > Amax) {
                Apivot = apivot + iA*BLOCK_SIZE;
                Amax = amax;
                line_assign(lsuline[ULINE_TARGET], lsblock[dbuf][apivot]);
            }

            receive_pivot(&Apivot, Apivot, Amax);
        }

#if defined ENABLE_SWAP
        //spe_printf("pivot(%d) = %d\n", iA*BLOCK_SIZE+iv*4+ia, Apivot);
        swap_diag(dbuf, perm, iA*BLOCK_SIZE+iv*4+ia, Apivot, nA, iA, eaA, eaP);
#endif
        cal_diag_right(dbuf, iv, ia);
        send_U_and_pivot(dbuf, Apivot, iA, iv, ia);

        if(__builtin_expect((iv < INNER_BLOCK_COUNT-1), 1)) {
            cal_diag_down_right_and_pivot(&apivot, &amax, dbuf, iv);
            cal_down_right(dbuf, nA, iA, iv, eaA);
            //pivot_selection_diag_vfirst(&apivot, &amax, dbuf, iv+1);
            pivot_selection_down_vfirst(&Apivot, &Amax, nA, iA, iv+1, eaA);
        }
    }

#if defined ENABLE_SWAP
    swap_begin(nA, iA, eaA);
  #if NUMBER_OF_SPES > 1
    swap_continue_sync(); // 最初の更新領域を交換
  #else
    swap_continue_sync();
    swap_continue_sync();
    //swap_rest();
    //swap_wait_all();
  #endif
#endif

    iput_perm(perm, TAG_PERM, iA, eaP);
    colcache_iputb_block(dbuf, TAG_SYNC, nA, iA, iA, eaA);

    dma_wait(TAG_PERM);

    //spe_printf("SPE(%d): finished\n", speid);
}

void column_block_decomposition_down(int nA, int iA, eaddr_t eaA, eaddr_t eaP)
{
    int iv, ia;
    int Apivot;
    float Amax;
    int ubuf = BLOCK_U;
    int diagspe = iA % NUMBER_OF_SPES;

    swap_init_perm(iA);

    for(iv = 0; iv < INNER_BLOCK_COUNT; iv++) {
        pivot_selection_down_vfirst(&Apivot, &Amax, nA, iA, iv, eaA);

        send_pivot(diagspe, Apivot, Amax);

        for(ia = 0; ia < 3; ia++) {
            receive_U_and_pivot(&Apivot, ubuf, iA, iv, ia);

#if defined ENABLE_SWAP
            swap_down(iA*BLOCK_SIZE+iv*4+ia, Apivot, nA, iA, eaA);
#endif

            cal_down_iline_and_pivot(&Apivot, &Amax, ubuf, nA, iA, iv, ia, eaA);

            send_pivot(diagspe, Apivot, Amax);
        }

        receive_U_and_pivot(&Apivot, ubuf, iA, iv, ia);

#if defined ENABLE_SWAP
        swap_down(iA*BLOCK_SIZE+iv*4+ia, Apivot, nA, iA, eaA);
#endif

        if(__builtin_expect((iv < INNER_BLOCK_COUNT-1), 1)) {
            cal_down_right(ubuf, nA, iA, iv, eaA);
        }
    }

#if defined ENABLE_SWAP
    swap_begin(nA, iA, eaA);
  #if NUMBER_OF_SPES > 1
    swap_continue_sync();
  #else
    swap_continue_sync();
    swap_continue_sync();
    //swap_rest();
    //swap_wait_all();
  #endif
#endif
}

void column_block_decomposition_master(int nA, int iA, eaddr_t eaA, eaddr_t eaP)
{
    usyncdata signal;
    void (*pfcolumn_block_decomposition)(int, int, eaddr_t, eaddr_t);
    vector unsigned int vcmp;
    vector unsigned int vpfdiag = spu_splats((unsigned int)column_block_decomposition_diag);
    vector unsigned int vpfdown = spu_splats((unsigned int)column_block_decomposition_down);
    vector unsigned int vpf;
    vector unsigned int vspeid = spu_splats((unsigned int)speid);
    vector unsigned int vmod = spu_splats((unsigned int)(iA-iA/NUMBER_OF_SPES*NUMBER_OF_SPES));

    vcmp = spu_cmpeq(vspeid, vmod);
    vpf = spu_sel(vpfdown, vpfdiag, vcmp);
    pfcolumn_block_decomposition = (void (*)(int, int, eaddr_t, eaddr_t))spu_extract(vpf, 0);

    signal.v = gsyncinit.v;
    run_spes(signal);

    (*pfcolumn_block_decomposition)(nA, iA, eaA, eaP);

    join_spes();
}

void column_block_decomposition_slave(int nA, int iA, eaddr_t eaA, eaddr_t eaP)
{
    usyncdata signal;
    void (*pfcolumn_block_decomposition)(int, int, eaddr_t, eaddr_t);
    vector unsigned int vcmp;
    vector unsigned int vpfdiag = spu_splats((unsigned int)column_block_decomposition_diag);
    vector unsigned int vpfdown = spu_splats((unsigned int)column_block_decomposition_down);
    vector unsigned int vpf;
    vector unsigned int vspeid = spu_splats((unsigned int)speid);
    vector unsigned int vmod = spu_splats((unsigned int)(iA-iA/NUMBER_OF_SPES*NUMBER_OF_SPES));

    vcmp = spu_cmpeq(vspeid, vmod);
    vpf = spu_sel(vpfdown, vpfdiag, vcmp);
    pfcolumn_block_decomposition = (void (*)(int, int, eaddr_t, eaddr_t))spu_extract(vpf, 0);

    wait_for_signal();

    (*pfcolumn_block_decomposition)(nA, iA, eaA, eaP);

    signal.v = gsyncinit.v;
    send_signal(signal);
}

// 分解のついでにゼロ行列の判定を行う.ゼロ行列ならば戻り値は0以外
unsigned int decompose_U(int ubuf, int dbuf)
{
    int ia, ka;
    vector float vl00, vl01, vl02, vl03;
    vector float vl10, vl11, vl12, vl13;
    vector float vl20, vl21, vl22, vl23;
    vector float vl30, vl31, vl32, vl33;
    vector float vu00, vu10, vu20, vu30;
    vector float vu01, vu11, vu21, vu31;
    vector float vu02, vu12, vu22, vu32;
    vector float vu03, vu13, vu23, vu33;
    vector float vu04, vu14, vu24, vu34;
    vector float vu05, vu15, vu25, vu35;
    vector float vu06, vu16, vu26, vu36;
    vector float vu07, vu17, vu27, vu37;
    vector float va00, va10, va20, va30;
    vector float va01, va11, va21, va31;
    vector float va02, va12, va22, va32;
    vector float va03, va13, va23, va33;
    vector float va04, va14, va24, va34;
    vector float va05, va15, va25, va35;
    vector float va06, va16, va26, va36;
    vector float va07, va17, va27, va37;
    vector float vinva0, vinva1, vinva2, vinva3;
    vector float vlv0, vlv1, vlv2, vlv3;
    vector unsigned char vsplats0 = gvsplats[0];
    vector unsigned char vsplats1 = gvsplats[1];
    vector unsigned char vsplats2 = gvsplats[2];
    vector unsigned char vsplats3 = gvsplats[3];
    float (*u)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[ubuf];
    float (*l)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[dbuf];
    vector float val01, val02, val03, val12, val13, val23;
    vector unsigned int vallor = spu_splats(0u);
    uv_float_uint vor0, vor1, vor2, vor3;
    uv_float_uint vor4, vor5, vor6, vor7;
    vector unsigned int vcmp, vorx, vnot;

    for(ia = 0; ia < BLOCK_SIZE; ia += 4) {
        va00 = *(vector float*)&u[ia  ][ 0];
        va10 = *(vector float*)&u[ia+1][ 0];
        va20 = *(vector float*)&u[ia+2][ 0];
        va30 = *(vector float*)&u[ia+3][ 0];
        va01 = *(vector float*)&u[ia  ][ 4];
        va11 = *(vector float*)&u[ia+1][ 4];
        va21 = *(vector float*)&u[ia+2][ 4];
        va31 = *(vector float*)&u[ia+3][ 4];
        va02 = *(vector float*)&u[ia  ][ 8];
        va12 = *(vector float*)&u[ia+1][ 8];
        va22 = *(vector float*)&u[ia+2][ 8];
        va32 = *(vector float*)&u[ia+3][ 8];
        va03 = *(vector float*)&u[ia  ][12];
        va13 = *(vector float*)&u[ia+1][12];
        va23 = *(vector float*)&u[ia+2][12];
        va33 = *(vector float*)&u[ia+3][12];
        va04 = *(vector float*)&u[ia  ][16];
        va14 = *(vector float*)&u[ia+1][16];
        va24 = *(vector float*)&u[ia+2][16];
        va34 = *(vector float*)&u[ia+3][16];
        va05 = *(vector float*)&u[ia  ][20];
        va15 = *(vector float*)&u[ia+1][20];
        va25 = *(vector float*)&u[ia+2][20];
        va35 = *(vector float*)&u[ia+3][20];
        va06 = *(vector float*)&u[ia  ][24];
        va16 = *(vector float*)&u[ia+1][24];
        va26 = *(vector float*)&u[ia+2][24];
        va36 = *(vector float*)&u[ia+3][24];
        va07 = *(vector float*)&u[ia  ][28];
        va17 = *(vector float*)&u[ia+1][28];
        va27 = *(vector float*)&u[ia+2][28];
        va37 = *(vector float*)&u[ia+3][28];

        // ゼロ行列の判定
        vor0.vf = spu_or(va00, va10);
        vor1.vf = spu_or(va20, va30);
        vor2.vf = spu_or(va01, va11);
        vor3.vf = spu_or(va21, va31);
        vor4.vf = spu_or(va02, va12);
        vor5.vf = spu_or(va22, va32);
        vor6.vf = spu_or(va03, va13);
        vor7.vf = spu_or(va23, va33);
        vor0.vui = spu_or(vor0.vui, vor1.vui);
        vor1.vui = spu_or(vor2.vui, vor3.vui);
        vor2.vui = spu_or(vor4.vui, vor5.vui);
        vor3.vui = spu_or(vor6.vui, vor7.vui);
        vor0.vui = spu_or(vor0.vui, vor1.vui);
        vor1.vui = spu_or(vor2.vui, vor3.vui);
        vor0.vui = spu_or(vor0.vui, vor1.vui);
        vallor = spu_or(vor0.vui, vallor);

        vor0.vf = spu_or(va04, va14);
        vor1.vf = spu_or(va24, va34);
        vor2.vf = spu_or(va05, va15);
        vor3.vf = spu_or(va25, va35);
        vor4.vf = spu_or(va06, va16);
        vor5.vf = spu_or(va26, va36);
        vor6.vf = spu_or(va07, va17);
        vor7.vf = spu_or(va27, va37);
        vor0.vui = spu_or(vor0.vui, vor1.vui);
        vor1.vui = spu_or(vor2.vui, vor3.vui);
        vor2.vui = spu_or(vor4.vui, vor5.vui);
        vor3.vui = spu_or(vor6.vui, vor7.vui);
        vor0.vui = spu_or(vor0.vui, vor1.vui);
        vor1.vui = spu_or(vor2.vui, vor3.vui);
        vor0.vui = spu_or(vor0.vui, vor1.vui);
        vallor = spu_or(vor0.vui, vallor);

        vlv0 = *(vector float*)&l[ia  ][ia];
        vlv1 = *(vector float*)&l[ia+1][ia];
        vlv2 = *(vector float*)&l[ia+2][ia];
        vlv3 = *(vector float*)&l[ia+3][ia];

        vinva0 = spu_splats(1.0f/spu_extract(vlv0, 0));
        vinva1 = spu_splats(1.0f/spu_extract(vlv1, 1));
        vinva2 = spu_splats(1.0f/spu_extract(vlv2, 2));
        vinva3 = spu_splats(1.0f/spu_extract(vlv3, 3));

        val01 = spu_shuffle(vlv1, vlv1, vsplats0);
        val02 = spu_shuffle(vlv2, vlv2, vsplats0);
        val03 = spu_shuffle(vlv3, vlv3, vsplats0);

        val12 = spu_shuffle(vlv2, vlv2, vsplats1);
        val13 = spu_shuffle(vlv3, vlv3, vsplats1);

        val23 = spu_shuffle(vlv3, vlv3, vsplats2);

        vu00 = spu_mul(va00, vinva0);
        vu01 = spu_mul(va01, vinva0);
        vu02 = spu_mul(va02, vinva0);
        vu03 = spu_mul(va03, vinva0);
        vu04 = spu_mul(va04, vinva0);
        vu05 = spu_mul(va05, vinva0);
        vu06 = spu_mul(va06, vinva0);
        vu07 = spu_mul(va07, vinva0);
        vu10 = spu_nmsub(val01, vu00, va10);
        vu20 = spu_nmsub(val02, vu00, va20);
        vu30 = spu_nmsub(val03, vu00, va30);
        vu11 = spu_nmsub(val01, vu01, va11);
        vu21 = spu_nmsub(val02, vu01, va21);
        vu31 = spu_nmsub(val03, vu01, va31);
        vu12 = spu_nmsub(val01, vu02, va12);
        vu22 = spu_nmsub(val02, vu02, va22);
        vu32 = spu_nmsub(val03, vu02, va32);
        vu13 = spu_nmsub(val01, vu03, va13);
        vu23 = spu_nmsub(val02, vu03, va23);
        vu33 = spu_nmsub(val03, vu03, va33);
        vu14 = spu_nmsub(val01, vu04, va14);
        vu24 = spu_nmsub(val02, vu04, va24);
        vu34 = spu_nmsub(val03, vu04, va34);
        vu15 = spu_nmsub(val01, vu05, va15);
        vu25 = spu_nmsub(val02, vu05, va25);
        vu35 = spu_nmsub(val03, vu05, va35);
        vu16 = spu_nmsub(val01, vu06, va16);
        vu26 = spu_nmsub(val02, vu06, va26);
        vu36 = spu_nmsub(val03, vu06, va36);
        vu17 = spu_nmsub(val01, vu07, va17);
        vu27 = spu_nmsub(val02, vu07, va27);
        vu37 = spu_nmsub(val03, vu07, va37);

        vu10 = spu_mul(vu10, vinva1);
        vu11 = spu_mul(vu11, vinva1);
        vu12 = spu_mul(vu12, vinva1);
        vu13 = spu_mul(vu13, vinva1);
        vu14 = spu_mul(vu14, vinva1);
        vu15 = spu_mul(vu15, vinva1);
        vu16 = spu_mul(vu16, vinva1);
        vu17 = spu_mul(vu17, vinva1);
        vu20 = spu_nmsub(val12, vu10, vu20);
        vu30 = spu_nmsub(val13, vu10, vu30);
        vu21 = spu_nmsub(val12, vu11, vu21);
        vu31 = spu_nmsub(val13, vu11, vu31);
        vu22 = spu_nmsub(val12, vu12, vu22);
        vu32 = spu_nmsub(val13, vu12, vu32);
        vu23 = spu_nmsub(val12, vu13, vu23);
        vu33 = spu_nmsub(val13, vu13, vu33);
        vu24 = spu_nmsub(val12, vu14, vu24);
        vu34 = spu_nmsub(val13, vu14, vu34);
        vu25 = spu_nmsub(val12, vu15, vu25);
        vu35 = spu_nmsub(val13, vu15, vu35);
        vu26 = spu_nmsub(val12, vu16, vu26);
        vu36 = spu_nmsub(val13, vu16, vu36);
        vu27 = spu_nmsub(val12, vu17, vu27);
        vu37 = spu_nmsub(val13, vu17, vu37);

        vu20 = spu_mul(vu20, vinva2);
        vu21 = spu_mul(vu21, vinva2);
        vu22 = spu_mul(vu22, vinva2);
        vu23 = spu_mul(vu23, vinva2);
        vu24 = spu_mul(vu24, vinva2);
        vu25 = spu_mul(vu25, vinva2);
        vu26 = spu_mul(vu26, vinva2);
        vu27 = spu_mul(vu27, vinva2);
        vu30 = spu_nmsub(val23, vu20, vu30);
        vu31 = spu_nmsub(val23, vu21, vu31);
        vu32 = spu_nmsub(val23, vu22, vu32);
        vu33 = spu_nmsub(val23, vu23, vu33);
        vu34 = spu_nmsub(val23, vu24, vu34);
        vu35 = spu_nmsub(val23, vu25, vu35);
        vu36 = spu_nmsub(val23, vu26, vu36);
        vu37 = spu_nmsub(val23, vu27, vu37);

        vu30 = spu_mul(vu30, vinva3);
        vu31 = spu_mul(vu31, vinva3);
        vu32 = spu_mul(vu32, vinva3);
        vu33 = spu_mul(vu33, vinva3);
        vu34 = spu_mul(vu34, vinva3);
        vu35 = spu_mul(vu35, vinva3);
        vu36 = spu_mul(vu36, vinva3);
        vu37 = spu_mul(vu37, vinva3);

        *(vector float*)&u[ia  ][ 0] = vu00;
        *(vector float*)&u[ia+1][ 0] = vu10;
        *(vector float*)&u[ia+2][ 0] = vu20;
        *(vector float*)&u[ia+3][ 0] = vu30;
        *(vector float*)&u[ia  ][ 4] = vu01;
        *(vector float*)&u[ia+1][ 4] = vu11;
        *(vector float*)&u[ia+2][ 4] = vu21;
        *(vector float*)&u[ia+3][ 4] = vu31;
        *(vector float*)&u[ia  ][ 8] = vu02;
        *(vector float*)&u[ia+1][ 8] = vu12;
        *(vector float*)&u[ia+2][ 8] = vu22;
        *(vector float*)&u[ia+3][ 8] = vu32;
        *(vector float*)&u[ia  ][12] = vu03;
        *(vector float*)&u[ia+1][12] = vu13;
        *(vector float*)&u[ia+2][12] = vu23;
        *(vector float*)&u[ia+3][12] = vu33;
        *(vector float*)&u[ia  ][16] = vu04;
        *(vector float*)&u[ia+1][16] = vu14;
        *(vector float*)&u[ia+2][16] = vu24;
        *(vector float*)&u[ia+3][16] = vu34;
        *(vector float*)&u[ia  ][20] = vu05;
        *(vector float*)&u[ia+1][20] = vu15;
        *(vector float*)&u[ia+2][20] = vu25;
        *(vector float*)&u[ia+3][20] = vu35;
        *(vector float*)&u[ia  ][24] = vu06;
        *(vector float*)&u[ia+1][24] = vu16;
        *(vector float*)&u[ia+2][24] = vu26;
        *(vector float*)&u[ia+3][24] = vu36;
        *(vector float*)&u[ia  ][28] = vu07;
        *(vector float*)&u[ia+1][28] = vu17;
        *(vector float*)&u[ia+2][28] = vu27;
        *(vector float*)&u[ia+3][28] = vu37;

        for(ka = ia+4; ka < BLOCK_SIZE; ka += 4) {
            vlv0 = *(vector float*)&l[ka  ][ia];
            vlv1 = *(vector float*)&l[ka+1][ia];
            vlv2 = *(vector float*)&l[ka+2][ia];
            vlv3 = *(vector float*)&l[ka+3][ia];
            vl00 = spu_shuffle(vlv0, vlv0, vsplats0);
            vl01 = spu_shuffle(vlv0, vlv0, vsplats1);
            vl02 = spu_shuffle(vlv0, vlv0, vsplats2);
            vl03 = spu_shuffle(vlv0, vlv0, vsplats3);
            vl10 = spu_shuffle(vlv1, vlv1, vsplats0);
            vl11 = spu_shuffle(vlv1, vlv1, vsplats1);
            vl12 = spu_shuffle(vlv1, vlv1, vsplats2);
            vl13 = spu_shuffle(vlv1, vlv1, vsplats3);
            vl20 = spu_shuffle(vlv2, vlv2, vsplats0);
            vl21 = spu_shuffle(vlv2, vlv2, vsplats1);
            vl22 = spu_shuffle(vlv2, vlv2, vsplats2);
            vl23 = spu_shuffle(vlv2, vlv2, vsplats3);
            vl30 = spu_shuffle(vlv3, vlv3, vsplats0);
            vl31 = spu_shuffle(vlv3, vlv3, vsplats1);
            vl32 = spu_shuffle(vlv3, vlv3, vsplats2);
            vl33 = spu_shuffle(vlv3, vlv3, vsplats3);
            va00 = *(vector float*)&u[ka  ][ 0];
            va10 = *(vector float*)&u[ka+1][ 0];
            va20 = *(vector float*)&u[ka+2][ 0];
            va30 = *(vector float*)&u[ka+3][ 0];
            va01 = *(vector float*)&u[ka  ][ 4];
            va11 = *(vector float*)&u[ka+1][ 4];
            va21 = *(vector float*)&u[ka+2][ 4];
            va31 = *(vector float*)&u[ka+3][ 4];
            va02 = *(vector float*)&u[ka  ][ 8];
            va12 = *(vector float*)&u[ka+1][ 8];
            va22 = *(vector float*)&u[ka+2][ 8];
            va32 = *(vector float*)&u[ka+3][ 8];
            va03 = *(vector float*)&u[ka  ][12];
            va13 = *(vector float*)&u[ka+1][12];
            va23 = *(vector float*)&u[ka+2][12];
            va33 = *(vector float*)&u[ka+3][12];
            va04 = *(vector float*)&u[ka  ][16];
            va14 = *(vector float*)&u[ka+1][16];
            va24 = *(vector float*)&u[ka+2][16];
            va34 = *(vector float*)&u[ka+3][16];
            va05 = *(vector float*)&u[ka  ][20];
            va15 = *(vector float*)&u[ka+1][20];
            va25 = *(vector float*)&u[ka+2][20];
            va35 = *(vector float*)&u[ka+3][20];
            va06 = *(vector float*)&u[ka  ][24];
            va16 = *(vector float*)&u[ka+1][24];
            va26 = *(vector float*)&u[ka+2][24];
            va36 = *(vector float*)&u[ka+3][24];
            va07 = *(vector float*)&u[ka  ][28];
            va17 = *(vector float*)&u[ka+1][28];
            va27 = *(vector float*)&u[ka+2][28];
            va37 = *(vector float*)&u[ka+3][28];

            va00 = spu_nmsub(vl00, vu00, va00);
            va00 = spu_nmsub(vl01, vu10, va00);
            va00 = spu_nmsub(vl02, vu20, va00);
            va00 = spu_nmsub(vl03, vu30, va00);
            va10 = spu_nmsub(vl10, vu00, va10);
            va10 = spu_nmsub(vl11, vu10, va10);
            va10 = spu_nmsub(vl12, vu20, va10);
            va10 = spu_nmsub(vl13, vu30, va10);
            va20 = spu_nmsub(vl20, vu00, va20);
            va20 = spu_nmsub(vl21, vu10, va20);
            va20 = spu_nmsub(vl22, vu20, va20);
            va20 = spu_nmsub(vl23, vu30, va20);
            va30 = spu_nmsub(vl30, vu00, va30);
            va30 = spu_nmsub(vl31, vu10, va30);
            va30 = spu_nmsub(vl32, vu20, va30);
            va30 = spu_nmsub(vl33, vu30, va30);

            va01 = spu_nmsub(vl00, vu01, va01);
            va01 = spu_nmsub(vl01, vu11, va01);
            va01 = spu_nmsub(vl02, vu21, va01);
            va01 = spu_nmsub(vl03, vu31, va01);
            va11 = spu_nmsub(vl10, vu01, va11);
            va11 = spu_nmsub(vl11, vu11, va11);
            va11 = spu_nmsub(vl12, vu21, va11);
            va11 = spu_nmsub(vl13, vu31, va11);
            va21 = spu_nmsub(vl20, vu01, va21);
            va21 = spu_nmsub(vl21, vu11, va21);
            va21 = spu_nmsub(vl22, vu21, va21);
            va21 = spu_nmsub(vl23, vu31, va21);
            va31 = spu_nmsub(vl30, vu01, va31);
            va31 = spu_nmsub(vl31, vu11, va31);
            va31 = spu_nmsub(vl32, vu21, va31);
            va31 = spu_nmsub(vl33, vu31, va31);

            va02 = spu_nmsub(vl00, vu02, va02);
            va02 = spu_nmsub(vl01, vu12, va02);
            va02 = spu_nmsub(vl02, vu22, va02);
            va02 = spu_nmsub(vl03, vu32, va02);
            va12 = spu_nmsub(vl10, vu02, va12);
            va12 = spu_nmsub(vl11, vu12, va12);
            va12 = spu_nmsub(vl12, vu22, va12);
            va12 = spu_nmsub(vl13, vu32, va12);
            va22 = spu_nmsub(vl20, vu02, va22);
            va22 = spu_nmsub(vl21, vu12, va22);
            va22 = spu_nmsub(vl22, vu22, va22);
            va22 = spu_nmsub(vl23, vu32, va22);
            va32 = spu_nmsub(vl30, vu02, va32);
            va32 = spu_nmsub(vl31, vu12, va32);
            va32 = spu_nmsub(vl32, vu22, va32);
            va32 = spu_nmsub(vl33, vu32, va32);

            va03 = spu_nmsub(vl00, vu03, va03);
            va03 = spu_nmsub(vl01, vu13, va03);
            va03 = spu_nmsub(vl02, vu23, va03);
            va03 = spu_nmsub(vl03, vu33, va03);
            va13 = spu_nmsub(vl10, vu03, va13);
            va13 = spu_nmsub(vl11, vu13, va13);
            va13 = spu_nmsub(vl12, vu23, va13);
            va13 = spu_nmsub(vl13, vu33, va13);
            va23 = spu_nmsub(vl20, vu03, va23);
            va23 = spu_nmsub(vl21, vu13, va23);
            va23 = spu_nmsub(vl22, vu23, va23);
            va23 = spu_nmsub(vl23, vu33, va23);
            va33 = spu_nmsub(vl30, vu03, va33);
            va33 = spu_nmsub(vl31, vu13, va33);
            va33 = spu_nmsub(vl32, vu23, va33);
            va33 = spu_nmsub(vl33, vu33, va33);

            va04 = spu_nmsub(vl00, vu04, va04);
            va04 = spu_nmsub(vl01, vu14, va04);
            va04 = spu_nmsub(vl02, vu24, va04);
            va04 = spu_nmsub(vl03, vu34, va04);
            va14 = spu_nmsub(vl10, vu04, va14);
            va14 = spu_nmsub(vl11, vu14, va14);
            va14 = spu_nmsub(vl12, vu24, va14);
            va14 = spu_nmsub(vl13, vu34, va14);
            va24 = spu_nmsub(vl20, vu04, va24);
            va24 = spu_nmsub(vl21, vu14, va24);
            va24 = spu_nmsub(vl22, vu24, va24);
            va24 = spu_nmsub(vl23, vu34, va24);
            va34 = spu_nmsub(vl30, vu04, va34);
            va34 = spu_nmsub(vl31, vu14, va34);
            va34 = spu_nmsub(vl32, vu24, va34);
            va34 = spu_nmsub(vl33, vu34, va34);

            va05 = spu_nmsub(vl00, vu05, va05);
            va05 = spu_nmsub(vl01, vu15, va05);
            va05 = spu_nmsub(vl02, vu25, va05);
            va05 = spu_nmsub(vl03, vu35, va05);
            va15 = spu_nmsub(vl10, vu05, va15);
            va15 = spu_nmsub(vl11, vu15, va15);
            va15 = spu_nmsub(vl12, vu25, va15);
            va15 = spu_nmsub(vl13, vu35, va15);
            va25 = spu_nmsub(vl20, vu05, va25);
            va25 = spu_nmsub(vl21, vu15, va25);
            va25 = spu_nmsub(vl22, vu25, va25);
            va25 = spu_nmsub(vl23, vu35, va25);
            va35 = spu_nmsub(vl30, vu05, va35);
            va35 = spu_nmsub(vl31, vu15, va35);
            va35 = spu_nmsub(vl32, vu25, va35);
            va35 = spu_nmsub(vl33, vu35, va35);

            va06 = spu_nmsub(vl00, vu06, va06);
            va06 = spu_nmsub(vl01, vu16, va06);
            va06 = spu_nmsub(vl02, vu26, va06);
            va06 = spu_nmsub(vl03, vu36, va06);
            va16 = spu_nmsub(vl10, vu06, va16);
            va16 = spu_nmsub(vl11, vu16, va16);
            va16 = spu_nmsub(vl12, vu26, va16);
            va16 = spu_nmsub(vl13, vu36, va16);
            va26 = spu_nmsub(vl20, vu06, va26);
            va26 = spu_nmsub(vl21, vu16, va26);
            va26 = spu_nmsub(vl22, vu26, va26);
            va26 = spu_nmsub(vl23, vu36, va26);
            va36 = spu_nmsub(vl30, vu06, va36);
            va36 = spu_nmsub(vl31, vu16, va36);
            va36 = spu_nmsub(vl32, vu26, va36);
            va36 = spu_nmsub(vl33, vu36, va36);

            va07 = spu_nmsub(vl00, vu07, va07);
            va07 = spu_nmsub(vl01, vu17, va07);
            va07 = spu_nmsub(vl02, vu27, va07);
            va07 = spu_nmsub(vl03, vu37, va07);
            va17 = spu_nmsub(vl10, vu07, va17);
            va17 = spu_nmsub(vl11, vu17, va17);
            va17 = spu_nmsub(vl12, vu27, va17);
            va17 = spu_nmsub(vl13, vu37, va17);
            va27 = spu_nmsub(vl20, vu07, va27);
            va27 = spu_nmsub(vl21, vu17, va27);
            va27 = spu_nmsub(vl22, vu27, va27);
            va27 = spu_nmsub(vl23, vu37, va27);
            va37 = spu_nmsub(vl30, vu07, va37);
            va37 = spu_nmsub(vl31, vu17, va37);
            va37 = spu_nmsub(vl32, vu27, va37);
            va37 = spu_nmsub(vl33, vu37, va37);

            *(vector float*)&u[ka  ][ 0] = va00;
            *(vector float*)&u[ka+1][ 0] = va10;
            *(vector float*)&u[ka+2][ 0] = va20;
            *(vector float*)&u[ka+3][ 0] = va30;
            *(vector float*)&u[ka  ][ 4] = va01;
            *(vector float*)&u[ka+1][ 4] = va11;
            *(vector float*)&u[ka+2][ 4] = va21;
            *(vector float*)&u[ka+3][ 4] = va31;
            *(vector float*)&u[ka  ][ 8] = va02;
            *(vector float*)&u[ka+1][ 8] = va12;
            *(vector float*)&u[ka+2][ 8] = va22;
            *(vector float*)&u[ka+3][ 8] = va32;
            *(vector float*)&u[ka  ][12] = va03;
            *(vector float*)&u[ka+1][12] = va13;
            *(vector float*)&u[ka+2][12] = va23;
            *(vector float*)&u[ka+3][12] = va33;
            *(vector float*)&u[ka  ][16] = va04;
            *(vector float*)&u[ka+1][16] = va14;
            *(vector float*)&u[ka+2][16] = va24;
            *(vector float*)&u[ka+3][16] = va34;
            *(vector float*)&u[ka  ][20] = va05;
            *(vector float*)&u[ka+1][20] = va15;
            *(vector float*)&u[ka+2][20] = va25;
            *(vector float*)&u[ka+3][20] = va35;
            *(vector float*)&u[ka  ][24] = va06;
            *(vector float*)&u[ka+1][24] = va16;
            *(vector float*)&u[ka+2][24] = va26;
            *(vector float*)&u[ka+3][24] = va36;
            *(vector float*)&u[ka  ][28] = va07;
            *(vector float*)&u[ka+1][28] = va17;
            *(vector float*)&u[ka+2][28] = va27;
            *(vector float*)&u[ka+3][28] = va37;
        }
    }

    vcmp = spu_cmpeq(vallor, 0);
    vnot = spu_nor(vcmp, vcmp);
    vorx = spu_orx(vnot);
    vnot = spu_nor(vorx, vorx);

    return spu_extract(vnot, 0);
}

/**
 * matrix_nmsub関数について
 * 行列A,L,Uに対して A <- A - L * U の計算を行う.
 * LU分解中のほとんどの処理はこれ
 *
 * 本来3重ループであるが1つは完全に展開したため見た目は2重ループ
 *
 * 現在明らかになっている問題点
 * * 内側のループの最後では nop 命令と brnz 命令の2命令同時発行により1サイクルの無駄が生じている.
 *   本来は直前のサイクルで fnms と lnop を同時発行し, 次に fnms と brnz 命令を同時発行する方が良い.
 *   * nop 命令は fnms 命令と同じく even パイプラインを使うので,
 *     nop 命令を発行することはそれだけ fnms 命令の密度が低下することを意味する.
 *   * 現在の解決法
 *     odd パイプラインを使用するダミー命令を挟むことで2命令同時発行の数を調整し,
 *     nop 命令を使わずにすむようにした.
 *     ただし,使用するレジスタの数が増えるため効率が悪い.
 * * 外側のループの最初と最後に連続して行われる load, store 命令は積和演算と同時発行できていない.
 *   対策思いつかず…
 *
 * 計算結果は以下のコードと全く同じ
 * ただしこのコードの速さは最適化済みのものの100分の1程度
void matrix_nmsub(int abuf, int lbuf, int ubuf)
{
    int i, j, k;
    float (*a)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[abuf];
    float (*l)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[lbuf];
    float (*u)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[ubuf];

    for(i = 0; i < BLOCK_SIZE; i++) {
        for(j = 0; j < BLOCK_SIZE; j++) {
            for(k = 0; k < BLOCK_SIZE; k++) {
                a[i][j] = a[i][j] - l[i][k] * u[k][j];
            }
        }
    }
}
 */
void matrix_nmsub(int abuf, int lbuf, int ubuf)
{
    int ia;
    float (*a)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[abuf];
    vector unsigned char vsplats0 = gvsplats[0];
    vector unsigned char vsplats1 = gvsplats[1];
    vector unsigned char vsplats2 = gvsplats[2];
    vector unsigned char vsplats3 = gvsplats[3];
    vector float va00, va10, va20, va30;
    vector float va01, va11, va21, va31;
    vector float va02, va12, va22, va32;
    vector float va03, va13, va23, va33;
    vector float va04, va14, va24, va34;
    vector float va05, va15, va25, va35;
    vector float va06, va16, va26, va36;
    vector float va07, va17, va27, va37;
    vector float vlv0, vlv1, vlv2, vlv3;
    vector float vl00, vl01, vl02, vl03;
    vector float vl10, vl11, vl12, vl13;
    vector float vl20, vl21, vl22, vl23;
    vector float vl30, vl31, vl32, vl33;
    vector float vu00, vu10, vu20, vu30;
    vector float vu01, vu11, vu21, vu31;
    vector float vu02, vu12, vu22, vu32;
    vector float vu03, vu13, vu23, vu33;
    vector float vu04, vu14, vu24, vu34;
    vector float vu05, vu15, vu25, vu35;
    vector float vu06, vu16, vu26, vu36;
    vector float vu07, vu17, vu27, vu37;
    vector unsigned char vkcntshuffle = { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, };
    vector unsigned short vkcounterinit = { 0, 112, 96, 80, 64, 48, 32, 16, }; // 7回vkcntshuffleでシャッフルするとプリファードスロットに0が入る
                                                                               // そのままunsigned int型として扱うため0番要素は常に0
    // ベースアドレスは最初にすべて計算し、ループ中ではシャッフルで切り替える。
    vector unsigned int vbase_lka0 = { 0, 28*sizeof(float), 24*sizeof(float), 20*sizeof(float), };
    vector unsigned int vbase_lka1 = { 16*sizeof(float), 12*sizeof(float), 8*sizeof(float), 4*sizeof(float), };
    vector unsigned int vbase_uka0 = { 0, 28*BLOCK_SIZE*sizeof(float), 24*BLOCK_SIZE*sizeof(float), 20*BLOCK_SIZE*sizeof(float), };
    vector unsigned int vbase_uka1 = { 16*BLOCK_SIZE*sizeof(float), 12*BLOCK_SIZE*sizeof(float), 8*BLOCK_SIZE*sizeof(float), 4*BLOCK_SIZE*sizeof(float), };
    u_vuint_uint uvbase_lka;
    u_vuint_uint uvbase_uka;
    vector unsigned char vbase_splats;
    vector unsigned int vtemp;
    vector float vdummy = spu_splats(0.0f);
    volatile vector float vdummyaddr;
    u_vushort_vuint_uint uvkcounter;

#if defined PROF_MATRIX_NMSUB
    s = spu_read_decrementer();
#endif

    vtemp = spu_splats((unsigned int)lsblock[lbuf]);
    vbase_lka0 = spu_add(vbase_lka0, vtemp);
    vbase_lka1 = spu_add(vbase_lka1, vtemp);

    vtemp = spu_splats((unsigned int)lsblock[ubuf]);
    vbase_uka0 = spu_add(vbase_uka0, vtemp);
    vbase_uka1 = spu_add(vbase_uka1, vtemp);

    for(ia = 0; ia < BLOCK_SIZE; ia += 4) {
        uvkcounter.vus = vkcounterinit;

        va00 = *(vector float*)&a[ia  ][ 0];
        va10 = *(vector float*)&a[ia+1][ 0];
        va20 = *(vector float*)&a[ia+2][ 0];
        va30 = *(vector float*)&a[ia+3][ 0];
        va01 = *(vector float*)&a[ia  ][ 4];
        va11 = *(vector float*)&a[ia+1][ 4];
        va21 = *(vector float*)&a[ia+2][ 4];
        va31 = *(vector float*)&a[ia+3][ 4];
        va02 = *(vector float*)&a[ia  ][ 8];
        va12 = *(vector float*)&a[ia+1][ 8];
        va22 = *(vector float*)&a[ia+2][ 8];
        va32 = *(vector float*)&a[ia+3][ 8];
        va03 = *(vector float*)&a[ia  ][12];
        va13 = *(vector float*)&a[ia+1][12];
        va23 = *(vector float*)&a[ia+2][12];
        va33 = *(vector float*)&a[ia+3][12];
        va04 = *(vector float*)&a[ia  ][16];
        va14 = *(vector float*)&a[ia+1][16];
        va24 = *(vector float*)&a[ia+2][16];
        va34 = *(vector float*)&a[ia+3][16];
        va05 = *(vector float*)&a[ia  ][20];
        va15 = *(vector float*)&a[ia+1][20];
        va25 = *(vector float*)&a[ia+2][20];
        va35 = *(vector float*)&a[ia+3][20];
        va06 = *(vector float*)&a[ia  ][24];
        va16 = *(vector float*)&a[ia+1][24];
        va26 = *(vector float*)&a[ia+2][24];
        va36 = *(vector float*)&a[ia+3][24];
        va07 = *(vector float*)&a[ia  ][28];
        va17 = *(vector float*)&a[ia+1][28];
        va27 = *(vector float*)&a[ia+2][28];
        //va37 = *(vector float*)&a[ia+3][28];

        uvbase_lka.v = vbase_lka0;
        vlv0 = *(vector float*)(uvbase_lka.i      );
        vlv1 = *(vector float*)(uvbase_lka.i + 128);
        vlv2 = *(vector float*)(uvbase_lka.i + 256);
        vlv3 = *(vector float*)(uvbase_lka.i + 384);

        vl00 = spu_shuffle(vlv0, vlv0, vsplats0);
        vl01 = spu_shuffle(vlv0, vlv0, vsplats1);
        vl02 = spu_shuffle(vlv0, vlv0, vsplats2);
        vl03 = spu_shuffle(vlv0, vlv0, vsplats3);

        vl10 = spu_shuffle(vlv1, vlv1, vsplats0);
        vl11 = spu_shuffle(vlv1, vlv1, vsplats1);
        vl12 = spu_shuffle(vlv1, vlv1, vsplats2);
        vl13 = spu_shuffle(vlv1, vlv1, vsplats3);

        vl20 = spu_shuffle(vlv2, vlv2, vsplats0);
        vl21 = spu_shuffle(vlv2, vlv2, vsplats1);
        vl22 = spu_shuffle(vlv2, vlv2, vsplats2);
        vl23 = spu_shuffle(vlv2, vlv2, vsplats3);

        vl30 = spu_shuffle(vlv3, vlv3, vsplats0);
        vl31 = spu_shuffle(vlv3, vlv3, vsplats1);
        vl32 = spu_shuffle(vlv3, vlv3, vsplats2);
        vl33 = spu_shuffle(vlv3, vlv3, vsplats3);

        uvbase_uka.v = vbase_uka0;
        vu00 = *(vector float*)(uvbase_uka.i           );
        vu10 = *(vector float*)(uvbase_uka.i + 128     );
        vu20 = *(vector float*)(uvbase_uka.i + 256     );
        vu30 = *(vector float*)(uvbase_uka.i + 384     );
        vu01 = *(vector float*)(uvbase_uka.i       + 16);
        vu11 = *(vector float*)(uvbase_uka.i + 128 + 16);
        vu21 = *(vector float*)(uvbase_uka.i + 256 + 16);
        vu31 = *(vector float*)(uvbase_uka.i + 384 + 16);
        vu02 = *(vector float*)(uvbase_uka.i       + 32);
        vu12 = *(vector float*)(uvbase_uka.i + 128 + 32);
        vu22 = *(vector float*)(uvbase_uka.i + 256 + 32);
        vu32 = *(vector float*)(uvbase_uka.i + 384 + 32);
 
        va00 = spu_nmsub(vl00, vu00, va00);
        va00 = spu_nmsub(vl01, vu10, va00);
        va00 = spu_nmsub(vl02, vu20, va00);
        va00 = spu_nmsub(vl03, vu30, va00);
        va10 = spu_nmsub(vl10, vu00, va10);
        va10 = spu_nmsub(vl11, vu10, va10);
        va10 = spu_nmsub(vl12, vu20, va10);
        va10 = spu_nmsub(vl13, vu30, va10);
        va20 = spu_nmsub(vl20, vu00, va20);
        va20 = spu_nmsub(vl21, vu10, va20);
        va20 = spu_nmsub(vl22, vu20, va20);
        va20 = spu_nmsub(vl23, vu30, va20);
        va30 = spu_nmsub(vl30, vu00, va30);
        va30 = spu_nmsub(vl31, vu10, va30);
        va30 = spu_nmsub(vl32, vu20, va30);
        va30 = spu_nmsub(vl33, vu30, va30);

        va01 = spu_nmsub(vl00, vu01, va01);
        va01 = spu_nmsub(vl01, vu11, va01);
        va01 = spu_nmsub(vl02, vu21, va01);
        va01 = spu_nmsub(vl03, vu31, va01);
        va11 = spu_nmsub(vl10, vu01, va11);
        va11 = spu_nmsub(vl11, vu11, va11);
        va11 = spu_nmsub(vl12, vu21, va11);
        va11 = spu_nmsub(vl13, vu31, va11);
        va21 = spu_nmsub(vl20, vu01, va21);
        va21 = spu_nmsub(vl21, vu11, va21);
        va21 = spu_nmsub(vl22, vu21, va21);
        va21 = spu_nmsub(vl23, vu31, va21);
        va31 = spu_nmsub(vl30, vu01, va31);
        va31 = spu_nmsub(vl31, vu11, va31);
        va31 = spu_nmsub(vl32, vu21, va31);
        va31 = spu_nmsub(vl33, vu31, va31);

        va02 = spu_nmsub(vl00, vu02, va02);
        va02 = spu_nmsub(vl01, vu12, va02);
        va02 = spu_nmsub(vl02, vu22, va02);
        va02 = spu_nmsub(vl03, vu32, va02);
        va12 = spu_nmsub(vl10, vu02, va12);
        va12 = spu_nmsub(vl11, vu12, va12);
        va12 = spu_nmsub(vl12, vu22, va12);
        va12 = spu_nmsub(vl13, vu32, va12);
        va22 = spu_nmsub(vl20, vu02, va22);
        va22 = spu_nmsub(vl21, vu12, va22);
        va22 = spu_nmsub(vl22, vu22, va22);
        va22 = spu_nmsub(vl23, vu32, va22);
        va32 = spu_nmsub(vl30, vu02, va32);
        va32 = spu_nmsub(vl31, vu12, va32);
        va32 = spu_nmsub(vl32, vu22, va32);
        va32 = spu_nmsub(vl33, vu32, va32);

        vu03 = *(vector float*)(uvbase_uka.i       + 48);
        vu13 = *(vector float*)(uvbase_uka.i + 128 + 48);
        vu23 = *(vector float*)(uvbase_uka.i + 256 + 48);
        vu33 = *(vector float*)(uvbase_uka.i + 384 + 48);
        vu04 = *(vector float*)(uvbase_uka.i       + 64);
        vu14 = *(vector float*)(uvbase_uka.i + 128 + 64);
        vu24 = *(vector float*)(uvbase_uka.i + 256 + 64);
        vu34 = *(vector float*)(uvbase_uka.i + 384 + 64);

        // LU分解中で最も多く回すループ
        // 理論上128サイクルで1周回せるループをきっちり128サイクルで終わらせる.
        //
        // 積和演算はevenパイプラインを使用するので,
        // 本来evenパイプラインで行うカウンタやベースアドレスの更新はシャッフルで代用
        //
        // 最適化しやすいように,このループ中の1文はアセンブリ命令1つと対応させた.
        // ここで明示している命令以外にコンパイラが暗黙で生成する命令はない.
        do {
            vu05 = *(vector float*)(uvbase_uka.i       +  80);
            vu15 = *(vector float*)(uvbase_uka.i + 128 +  80);
            vu25 = *(vector float*)(uvbase_uka.i + 256 +  80);
            vu35 = *(vector float*)(uvbase_uka.i + 384 +  80);
            vu06 = *(vector float*)(uvbase_uka.i       +  96);
            vu16 = *(vector float*)(uvbase_uka.i + 128 +  96);
            vu26 = *(vector float*)(uvbase_uka.i + 256 +  96);
            vu36 = *(vector float*)(uvbase_uka.i + 384 +  96);
            vu07 = *(vector float*)(uvbase_uka.i       + 112);
            vu17 = *(vector float*)(uvbase_uka.i + 128 + 112);
            vu27 = *(vector float*)(uvbase_uka.i + 256 + 112);
            vu37 = *(vector float*)(uvbase_uka.i + 384 + 112);

            va03 = spu_nmsub(vl00, vu03, va03);
            va03 = spu_nmsub(vl01, vu13, va03);
            va03 = spu_nmsub(vl02, vu23, va03);
            va03 = spu_nmsub(vl03, vu33, va03);
            va13 = spu_nmsub(vl10, vu03, va13);
            va13 = spu_nmsub(vl11, vu13, va13);
            va13 = spu_nmsub(vl12, vu23, va13);
            va13 = spu_nmsub(vl13, vu33, va13);
            va23 = spu_nmsub(vl20, vu03, va23);
            va23 = spu_nmsub(vl21, vu13, va23);
            va23 = spu_nmsub(vl22, vu23, va23);
            va23 = spu_nmsub(vl23, vu33, va23);
            va33 = spu_nmsub(vl30, vu03, va33);
            va33 = spu_nmsub(vl31, vu13, va33);
            va33 = spu_nmsub(vl32, vu23, va33);
            va33 = spu_nmsub(vl33, vu33, va33);

            va04 = spu_nmsub(vl00, vu04, va04);
            va04 = spu_nmsub(vl01, vu14, va04);
            va04 = spu_nmsub(vl02, vu24, va04);
            va04 = spu_nmsub(vl03, vu34, va04);
            va14 = spu_nmsub(vl10, vu04, va14);
            va14 = spu_nmsub(vl11, vu14, va14);
            va14 = spu_nmsub(vl12, vu24, va14);
            va14 = spu_nmsub(vl13, vu34, va14);
            va24 = spu_nmsub(vl20, vu04, va24);
            va24 = spu_nmsub(vl21, vu14, va24);
            va24 = spu_nmsub(vl22, vu24, va24);
            va24 = spu_nmsub(vl23, vu34, va24);
            va34 = spu_nmsub(vl30, vu04, va34);
            va34 = spu_nmsub(vl31, vu14, va34);
            va34 = spu_nmsub(vl32, vu24, va34);
            va34 = spu_nmsub(vl33, vu34, va34);

            va05 = spu_nmsub(vl00, vu05, va05);
            va05 = spu_nmsub(vl01, vu15, va05);
            va05 = spu_nmsub(vl02, vu25, va05);
            va05 = spu_nmsub(vl03, vu35, va05);
            va15 = spu_nmsub(vl10, vu05, va15);
            va15 = spu_nmsub(vl11, vu15, va15);
            va15 = spu_nmsub(vl12, vu25, va15);
            va15 = spu_nmsub(vl13, vu35, va15);
            va25 = spu_nmsub(vl20, vu05, va25);
            va25 = spu_nmsub(vl21, vu15, va25);
            va25 = spu_nmsub(vl22, vu25, va25);
            va25 = spu_nmsub(vl23, vu35, va25);
            va35 = spu_nmsub(vl30, vu05, va35);
            va35 = spu_nmsub(vl31, vu15, va35);
            va35 = spu_nmsub(vl32, vu25, va35);
            va35 = spu_nmsub(vl33, vu35, va35);

            va06 = spu_nmsub(vl00, vu06, va06);
            va06 = spu_nmsub(vl01, vu16, va06);
            va06 = spu_nmsub(vl02, vu26, va06);
            va06 = spu_nmsub(vl03, vu36, va06);
            va16 = spu_nmsub(vl10, vu06, va16);
            va16 = spu_nmsub(vl11, vu16, va16);
            va16 = spu_nmsub(vl12, vu26, va16);
            va16 = spu_nmsub(vl13, vu36, va16);
            va26 = spu_nmsub(vl20, vu06, va26);
            va26 = spu_nmsub(vl21, vu16, va26);
            va26 = spu_nmsub(vl22, vu26, va26);
            va26 = spu_nmsub(vl23, vu36, va26);
            va36 = spu_nmsub(vl30, vu06, va36);
            va36 = spu_nmsub(vl31, vu16, va36);
            va36 = spu_nmsub(vl32, vu26, va36);
            va36 = spu_nmsub(vl33, vu36, va36);

            va37 = *(vector float*)&a[ia+3][28];

            va07 = spu_nmsub(vl00, vu07, va07);
            va07 = spu_nmsub(vl01, vu17, va07);
            va07 = spu_nmsub(vl02, vu27, va07);
            va07 = spu_nmsub(vl03, vu37, va07);
            va17 = spu_nmsub(vl10, vu07, va17);
            va17 = spu_nmsub(vl11, vu17, va17);
            va17 = spu_nmsub(vl12, vu27, va17);
            va17 = spu_nmsub(vl13, vu37, va17);
            va27 = spu_nmsub(vl20, vu07, va27);
            va27 = spu_nmsub(vl21, vu17, va27);
            va27 = spu_nmsub(vl22, vu27, va27);
            va27 = spu_nmsub(vl23, vu37, va27);
            va37 = spu_nmsub(vl30, vu07, va37);
            va37 = spu_nmsub(vl31, vu17, va37);
            va37 = spu_nmsub(vl32, vu27, va37);
            va37 = spu_nmsub(vl33, vu37, va37);

            *(vector float*)&a[ia+3][28] = va37;

            vbase_splats = *(vector unsigned char*)((unsigned int)gvsplats + uvkcounter.i);
            uvbase_lka.v = spu_shuffle(vbase_lka0, vbase_lka1, vbase_splats);
            vlv0 = *(vector float*)(uvbase_lka.i      );
            vlv1 = *(vector float*)(uvbase_lka.i + 128);
            vlv2 = *(vector float*)(uvbase_lka.i + 256);
            vlv3 = *(vector float*)(uvbase_lka.i + 384);

            vl00 = spu_shuffle(vlv0, vlv0, vsplats0);
            vl01 = spu_shuffle(vlv0, vlv0, vsplats1);
            vl02 = spu_shuffle(vlv0, vlv0, vsplats2);
            vl03 = spu_shuffle(vlv0, vlv0, vsplats3);

            vl10 = spu_shuffle(vlv1, vlv1, vsplats0);
            vl11 = spu_shuffle(vlv1, vlv1, vsplats1);
            vl12 = spu_shuffle(vlv1, vlv1, vsplats2);
            vl13 = spu_shuffle(vlv1, vlv1, vsplats3);

            vl20 = spu_shuffle(vlv2, vlv2, vsplats0);
            vl21 = spu_shuffle(vlv2, vlv2, vsplats1);
            vl22 = spu_shuffle(vlv2, vlv2, vsplats2);
            vl23 = spu_shuffle(vlv2, vlv2, vsplats3);

            vl30 = spu_shuffle(vlv3, vlv3, vsplats0);
            vl31 = spu_shuffle(vlv3, vlv3, vsplats1);
            vl32 = spu_shuffle(vlv3, vlv3, vsplats2);
            vl33 = spu_shuffle(vlv3, vlv3, vsplats3);

            uvbase_uka.v = spu_shuffle(vbase_uka0, vbase_uka1, vbase_splats);
            vu00 = *(vector float*)(uvbase_uka.i           );
            vu10 = *(vector float*)(uvbase_uka.i + 128     );
            vu20 = *(vector float*)(uvbase_uka.i + 256     );
            vu30 = *(vector float*)(uvbase_uka.i + 384     );
            vu01 = *(vector float*)(uvbase_uka.i       + 16);
            vu11 = *(vector float*)(uvbase_uka.i + 128 + 16);
            vu21 = *(vector float*)(uvbase_uka.i + 256 + 16);
            vu31 = *(vector float*)(uvbase_uka.i + 384 + 16);
            vu02 = *(vector float*)(uvbase_uka.i       + 32);
            vu12 = *(vector float*)(uvbase_uka.i + 128 + 32);
            vu22 = *(vector float*)(uvbase_uka.i + 256 + 32);
            vu32 = *(vector float*)(uvbase_uka.i + 384 + 32);

            va00 = spu_nmsub(vl00, vu00, va00);
            va00 = spu_nmsub(vl01, vu10, va00);
            va00 = spu_nmsub(vl02, vu20, va00);
            va00 = spu_nmsub(vl03, vu30, va00);
            va10 = spu_nmsub(vl10, vu00, va10);
            va10 = spu_nmsub(vl11, vu10, va10);
            va10 = spu_nmsub(vl12, vu20, va10);
            va10 = spu_nmsub(vl13, vu30, va10);
            va20 = spu_nmsub(vl20, vu00, va20);
            va20 = spu_nmsub(vl21, vu10, va20);
            va20 = spu_nmsub(vl22, vu20, va20);
            va20 = spu_nmsub(vl23, vu30, va20);
            va30 = spu_nmsub(vl30, vu00, va30);
            va30 = spu_nmsub(vl31, vu10, va30);
            va30 = spu_nmsub(vl32, vu20, va30);
            va30 = spu_nmsub(vl33, vu30, va30);

            va01 = spu_nmsub(vl00, vu01, va01);
            va01 = spu_nmsub(vl01, vu11, va01);
            va01 = spu_nmsub(vl02, vu21, va01);
            va01 = spu_nmsub(vl03, vu31, va01);
            va11 = spu_nmsub(vl10, vu01, va11);
            va11 = spu_nmsub(vl11, vu11, va11);
            va11 = spu_nmsub(vl12, vu21, va11);
            va11 = spu_nmsub(vl13, vu31, va11);
            va21 = spu_nmsub(vl20, vu01, va21);
            va21 = spu_nmsub(vl21, vu11, va21);
            va21 = spu_nmsub(vl22, vu21, va21);
            va21 = spu_nmsub(vl23, vu31, va21);
            va31 = spu_nmsub(vl30, vu01, va31);
            va31 = spu_nmsub(vl31, vu11, va31);
            va31 = spu_nmsub(vl32, vu21, va31);
            va31 = spu_nmsub(vl33, vu31, va31);

            va02 = spu_nmsub(vl00, vu02, va02);
            va02 = spu_nmsub(vl01, vu12, va02);
            va02 = spu_nmsub(vl02, vu22, va02);
            va02 = spu_nmsub(vl03, vu32, va02);
            va12 = spu_nmsub(vl10, vu02, va12);
            va12 = spu_nmsub(vl11, vu12, va12);
            va12 = spu_nmsub(vl12, vu22, va12);
            va12 = spu_nmsub(vl13, vu32, va12);
            va22 = spu_nmsub(vl20, vu02, va22);
            va22 = spu_nmsub(vl21, vu12, va22);
            va22 = spu_nmsub(vl22, vu22, va22);
            va22 = spu_nmsub(vl23, vu32, va22);
            va32 = spu_nmsub(vl30, vu02, va32);
            va32 = spu_nmsub(vl31, vu12, va32);
            va32 = spu_nmsub(vl32, vu22, va32);
            va32 = spu_nmsub(vl33, vu32, va32);

            vu03 = *(vector float*)(uvbase_uka.i       +  48);
            vu13 = *(vector float*)(uvbase_uka.i + 128 +  48);
            vu23 = *(vector float*)(uvbase_uka.i + 256 +  48);
            vu33 = *(vector float*)(uvbase_uka.i + 384 +  48);
            vu04 = *(vector float*)(uvbase_uka.i       +  64);
            vu14 = *(vector float*)(uvbase_uka.i + 128 +  64);
            vu24 = *(vector float*)(uvbase_uka.i + 256 +  64);
            vu34 = *(vector float*)(uvbase_uka.i + 384 +  64);

            uvkcounter.vus = spu_shuffle(uvkcounter.vus, uvkcounter.vus, vkcntshuffle);

            // コンパイラの最適化を補助するダミー命令
            // odd 命令を使わせることで2命令同時発行の数を調整し,
            // 最後に nop 命令を使って2命令同時発行してしまうのを防ぐ.
            vdummy = spu_shuffle(vdummy, va32, vkcntshuffle);
            vdummy = spu_shuffle(vdummy, va33, vkcntshuffle);
        } while(uvkcounter.i);

        vu05 = *(vector float*)(uvbase_uka.i       +  80);
        vu15 = *(vector float*)(uvbase_uka.i + 128 +  80);
        vu25 = *(vector float*)(uvbase_uka.i + 256 +  80);
        vu35 = *(vector float*)(uvbase_uka.i + 384 +  80);
        vu06 = *(vector float*)(uvbase_uka.i       +  96);
        vu16 = *(vector float*)(uvbase_uka.i + 128 +  96);
        vu26 = *(vector float*)(uvbase_uka.i + 256 +  96);
        vu36 = *(vector float*)(uvbase_uka.i + 384 +  96);
        vu07 = *(vector float*)(uvbase_uka.i       + 112);
        vu17 = *(vector float*)(uvbase_uka.i + 128 + 112);
        vu27 = *(vector float*)(uvbase_uka.i + 256 + 112);
        vu37 = *(vector float*)(uvbase_uka.i + 384 + 112);

        va03 = spu_nmsub(vl00, vu03, va03);
        va03 = spu_nmsub(vl01, vu13, va03);
        va03 = spu_nmsub(vl02, vu23, va03);
        va03 = spu_nmsub(vl03, vu33, va03);
        va13 = spu_nmsub(vl10, vu03, va13);
        va13 = spu_nmsub(vl11, vu13, va13);
        va13 = spu_nmsub(vl12, vu23, va13);
        va13 = spu_nmsub(vl13, vu33, va13);
        va23 = spu_nmsub(vl20, vu03, va23);
        va23 = spu_nmsub(vl21, vu13, va23);
        va23 = spu_nmsub(vl22, vu23, va23);
        va23 = spu_nmsub(vl23, vu33, va23);
        va33 = spu_nmsub(vl30, vu03, va33);
        va33 = spu_nmsub(vl31, vu13, va33);
        va33 = spu_nmsub(vl32, vu23, va33);
        va33 = spu_nmsub(vl33, vu33, va33);

        va04 = spu_nmsub(vl00, vu04, va04);
        va04 = spu_nmsub(vl01, vu14, va04);
        va04 = spu_nmsub(vl02, vu24, va04);
        va04 = spu_nmsub(vl03, vu34, va04);
        va14 = spu_nmsub(vl10, vu04, va14);
        va14 = spu_nmsub(vl11, vu14, va14);
        va14 = spu_nmsub(vl12, vu24, va14);
        va14 = spu_nmsub(vl13, vu34, va14);
        va24 = spu_nmsub(vl20, vu04, va24);
        va24 = spu_nmsub(vl21, vu14, va24);
        va24 = spu_nmsub(vl22, vu24, va24);
        va24 = spu_nmsub(vl23, vu34, va24);
        va34 = spu_nmsub(vl30, vu04, va34);
        va34 = spu_nmsub(vl31, vu14, va34);
        va34 = spu_nmsub(vl32, vu24, va34);
        va34 = spu_nmsub(vl33, vu34, va34);

        va05 = spu_nmsub(vl00, vu05, va05);
        va05 = spu_nmsub(vl01, vu15, va05);
        va05 = spu_nmsub(vl02, vu25, va05);
        va05 = spu_nmsub(vl03, vu35, va05);
        va15 = spu_nmsub(vl10, vu05, va15);
        va15 = spu_nmsub(vl11, vu15, va15);
        va15 = spu_nmsub(vl12, vu25, va15);
        va15 = spu_nmsub(vl13, vu35, va15);
        va25 = spu_nmsub(vl20, vu05, va25);
        va25 = spu_nmsub(vl21, vu15, va25);
        va25 = spu_nmsub(vl22, vu25, va25);
        va25 = spu_nmsub(vl23, vu35, va25);
        va35 = spu_nmsub(vl30, vu05, va35);
        va35 = spu_nmsub(vl31, vu15, va35);
        va35 = spu_nmsub(vl32, vu25, va35);
        va35 = spu_nmsub(vl33, vu35, va35);

        va06 = spu_nmsub(vl00, vu06, va06);
        va06 = spu_nmsub(vl01, vu16, va06);
        va06 = spu_nmsub(vl02, vu26, va06);
        va06 = spu_nmsub(vl03, vu36, va06);
        va16 = spu_nmsub(vl10, vu06, va16);
        va16 = spu_nmsub(vl11, vu16, va16);
        va16 = spu_nmsub(vl12, vu26, va16);
        va16 = spu_nmsub(vl13, vu36, va16);
        va26 = spu_nmsub(vl20, vu06, va26);
        va26 = spu_nmsub(vl21, vu16, va26);
        va26 = spu_nmsub(vl22, vu26, va26);
        va26 = spu_nmsub(vl23, vu36, va26);
        va36 = spu_nmsub(vl30, vu06, va36);
        va36 = spu_nmsub(vl31, vu16, va36);
        va36 = spu_nmsub(vl32, vu26, va36);
        va36 = spu_nmsub(vl33, vu36, va36);

        va37 = *(vector float*)&a[ia+3][28];

        va07 = spu_nmsub(vl00, vu07, va07);
        va07 = spu_nmsub(vl01, vu17, va07);
        va07 = spu_nmsub(vl02, vu27, va07);
        va07 = spu_nmsub(vl03, vu37, va07);
        va17 = spu_nmsub(vl10, vu07, va17);
        va17 = spu_nmsub(vl11, vu17, va17);
        va17 = spu_nmsub(vl12, vu27, va17);
        va17 = spu_nmsub(vl13, vu37, va17);
        va27 = spu_nmsub(vl20, vu07, va27);
        va27 = spu_nmsub(vl21, vu17, va27);
        va27 = spu_nmsub(vl22, vu27, va27);
        va27 = spu_nmsub(vl23, vu37, va27);
        va37 = spu_nmsub(vl30, vu07, va37);
        va37 = spu_nmsub(vl31, vu17, va37);
        va37 = spu_nmsub(vl32, vu27, va37);
        va37 = spu_nmsub(vl33, vu37, va37);

        *(vector float*)&a[ia  ][ 0] = va00;
        *(vector float*)&a[ia+1][ 0] = va10;
        *(vector float*)&a[ia+2][ 0] = va20;
        *(vector float*)&a[ia+3][ 0] = va30;
        *(vector float*)&a[ia  ][ 4] = va01;
        *(vector float*)&a[ia+1][ 4] = va11;
        *(vector float*)&a[ia+2][ 4] = va21;
        *(vector float*)&a[ia+3][ 4] = va31;
        *(vector float*)&a[ia  ][ 8] = va02;
        *(vector float*)&a[ia+1][ 8] = va12;
        *(vector float*)&a[ia+2][ 8] = va22;
        *(vector float*)&a[ia+3][ 8] = va32;
        *(vector float*)&a[ia  ][12] = va03;
        *(vector float*)&a[ia+1][12] = va13;
        *(vector float*)&a[ia+2][12] = va23;
        *(vector float*)&a[ia+3][12] = va33;
        *(vector float*)&a[ia  ][16] = va04;
        *(vector float*)&a[ia+1][16] = va14;
        *(vector float*)&a[ia+2][16] = va24;
        *(vector float*)&a[ia+3][16] = va34;
        *(vector float*)&a[ia  ][20] = va05;
        *(vector float*)&a[ia+1][20] = va15;
        *(vector float*)&a[ia+2][20] = va25;
        *(vector float*)&a[ia+3][20] = va35;
        *(vector float*)&a[ia  ][24] = va06;
        *(vector float*)&a[ia+1][24] = va16;
        *(vector float*)&a[ia+2][24] = va26;
        *(vector float*)&a[ia+3][24] = va36;
        *(vector float*)&a[ia  ][28] = va07;
        *(vector float*)&a[ia+1][28] = va17;
        *(vector float*)&a[ia+2][28] = va27;
        *(vector float*)&a[ia+3][28] = va37;

        vtemp = spu_splats((unsigned int)(4*BLOCK_SIZE*sizeof(float)));
        vbase_lka0 = spu_add(vbase_lka0, vtemp);
        vbase_lka1 = spu_add(vbase_lka1, vtemp);
    }

    // ダミー命令
    // 1cycleの遅延あり
    // 途中のダミー命令が最適化により除去されるのを防ぐ.
    vdummyaddr = vdummy;

#if defined PROF_MATRIX_NMSUB
    t = spu_read_decrementer();
    if(dec == 0) {
        dec = s - t;
    }
#endif
}

void init_perm(int nA, eaddr_t eaP)
{
    int i;
    int iA;
    int count = 0;
    int buf;

    for(iA = speid; iA < nA; iA += NUMBER_OF_SPES, count++) {
        buf = count&3;
        dma_wait(buf);

        for(i = 0; i < BLOCK_SIZE; i++) {
            lsperm[buf][i] = iA*BLOCK_SIZE+i;
        }
        iput_perm(buf, buf, iA, eaP);
    }
    mfc_barrier(TAG_SYNC);
}

void init_perm_master(int nA, eaddr_t eaP)
{
    usyncdata sync = gsyncinit;

    run_spes(sync);
    init_perm(nA, eaP);
    join_spes();
}

void init_perm_slave(int nA, eaddr_t eaP)
{
    usyncdata signal = gsyncinit;

    wait_for_signal();
    init_perm(nA, eaP);
    send_signal(signal);
}

#define prepare_first_diag_block(nA, iA, eaA) do { \
    if(speid < iA) { \
        iget_block(BLOCK_DIAG, TAG_DIAG, nA, speid, speid, eaA); \
    } \
} while(0)

void update_column(int nA, int iA, eaddr_t eaA)
{
    int jA, kA;
    int cur_utag, nxt_utag;
    int cur_ubuf, nxt_ubuf;
    int diagbuf;
    int cur_ltag, nxt_ltag = 0;
    int cur_dtag, nxt_dtag = 0;
    int cur_lbuf, nxt_lbuf = 0;
    int cur_dbuf, nxt_dbuf = 0;
    int cur_kA, nxt_kA = 0;
    usyncdata signal = gsyncinit;
    int diagA;
    int uready = 0;
    int diagspe;
    unsigned int iszero = 0;

    jA = 0;

    nxt_utag = 4;
    nxt_ubuf = BLOCK_U-4+nxt_utag;

    diagbuf = BLOCK_DIAG;

    // 最初に使う対角ブロックを取得する
    diagA = speid;
    prepare_first_diag_block(nA, iA, eaA);
    //if(diagA < iA) {
    //    iget_block(diagbuf, TAG_DIAG, nA, diagA, diagA, eaA);
    //}

    // 最初のUの計算
    if(speid == 0) {
//#if defined ENABLE_SWAP
//        swap_continue(); // 更新が行の交換に追いつかないようにする
//#endif
        cur_ubuf = colcache_iget_block(BLOCK_U, TAG_SYNC, nA, jA, iA, eaA);
        dma_wait(TAG_DIAG);
        dma_wait(TAG_SYNC);

        iszero = decompose_U(cur_ubuf, diagbuf);

        iputb_block(cur_ubuf, TAG_SYNC, nA, jA, iA, eaA);
        mfc_sync(TAG_SYNC);
        signal.s.line = jA;
        signal.s.p.iszero = (iszero) ? jA:0;
        send_signal_all(signal);

        diagA += NUMBER_OF_SPES;
        if(diagA < iA) {
            iget_block(diagbuf, TAG_DIAG, nA, diagA, diagA, eaA);
        }
    }

    // Lと分解するブロックの先読み
    kA = (jA+1)/NUMBER_OF_SPES*NUMBER_OF_SPES+speid;
    if(kA < jA+1) {
        kA += NUMBER_OF_SPES;
    }
    if(kA < nA) {
        nxt_kA = kA;
        nxt_ltag = 0;
        nxt_dtag = 2;
        nxt_lbuf = BLOCK_L+nxt_ltag;
        nxt_dbuf = BLOCK_D-2+nxt_dtag;

        iget_block(nxt_lbuf, nxt_ltag, nA, nxt_kA, jA, eaA);
        nxt_dbuf = colcache_iget_block(nxt_dbuf, nxt_dtag, nA, nxt_kA, iA, eaA);
    }

    for(jA = 0; jA < iA; jA++) {
#if defined ENABLE_SWAP
        swap_continue_sync(); // 更新が行の交換に追いつかないようにする
#endif

        cur_utag = nxt_utag;
        cur_ubuf = nxt_ubuf;

        diagspe = jA % NUMBER_OF_SPES;
        
        if(diagspe == speid) {
            cur_ubuf = colcache_iget_block(cur_ubuf, cur_utag, nA, jA, iA, eaA);
        } else if (kA < nA) {
            if(!uready) {
#if defined READ_DECREMENTER
                s = spu_read_decrementer();
                while(lssignal[SYNC_SIGNAL].s.line < jA) {
                    t = spu_read_decrementer();
                    if(s-t > PRINT_CYCLE) {
                        spe_printf("SPE(%d): too late!(wait U) step = %d, line(%d) = %d\n", speid, gstep, SYNC_SIGNAL, lssignal[SYNC_SIGNAL].s.line);
                        s = t;
                    }
                }
#else
                while(lssignal[SYNC_SIGNAL].s.line < jA)  {
                    ;
                }
#endif
                iget_block(cur_ubuf, cur_utag, nA, jA, iA, eaA);
                dma_wait(cur_utag);
            }
            iszero = lssignal[SYNC_SIGNAL].s.p.iszero;
        }

        nxt_utag = ((nxt_utag+1) & 1) + 4;
        nxt_ubuf = BLOCK_U-4+nxt_utag;
        uready = 0;

#if defined SKIP_ZERO
        if(__builtin_expect((iszero && kA < nA), 0)) { 
            // Uがゼロ行列のとき
            cur_kA = nxt_kA;
            cur_ltag = nxt_ltag;
            cur_dtag = nxt_dtag;
            cur_lbuf = nxt_lbuf;
            cur_dbuf = nxt_dbuf;
            nxt_kA = kA;
            nxt_ltag = ((nxt_ltag+1) & 1);
            nxt_dtag = ((nxt_dtag+1) & 1) + 2;
            nxt_lbuf = BLOCK_L+nxt_ltag;
            nxt_dbuf = BLOCK_D-2+nxt_dtag;

            dma_wait_mask((1 << cur_ltag) | (1 << cur_dtag) | (1 << cur_utag));
            //dma_wait(cur_ltag);
            //dma_wait(cur_dtag);
            //dma_wait(cur_utag);

            if((jA+1)%NUMBER_OF_SPES == speid) {
                dma_wait(TAG_DIAG);
                iszero = decompose_U(cur_dbuf, diagbuf);

                dma_wait(TAG_SYNC);
                iputb_block(cur_dbuf, TAG_SYNC, nA, cur_kA, iA, eaA);
                mfc_sync(TAG_SYNC);
                signal.s.line = jA+1;
                signal.s.p.iszero = (iszero) ? (jA+1):0;
                send_signal_all(signal);

                diagA += NUMBER_OF_SPES;
                if(diagA < iA) {
                    iget_block(diagbuf, TAG_DIAG, nA, diagA, diagA, eaA);
                }
            }

            // Lと分解するブロックの先読み
            kA = (jA+2)/NUMBER_OF_SPES*NUMBER_OF_SPES+speid;
            if(kA < jA+2) {
                kA += NUMBER_OF_SPES;
            }
            if(kA < nA) {
                nxt_kA = kA;
                nxt_ltag = ((nxt_ltag+1) & 1);
                nxt_lbuf = BLOCK_L+nxt_ltag;

                iget_block(nxt_lbuf, nxt_ltag, nA, nxt_kA, jA+1, eaA);

                // 最後に読み込んだブロックが次に使われるときは転送なし
                if(nxt_kA == cur_kA) {
                    nxt_dtag = cur_dtag;
                    nxt_dbuf = cur_dbuf;
                } else {
                    nxt_dtag = ((nxt_dtag+1) & 1) + 2;
                    nxt_dbuf = BLOCK_D-2+nxt_dtag;
                    nxt_dbuf = colcache_iget_block(nxt_dbuf, nxt_dtag, nA, nxt_kA, iA, eaA);
                }
            }
        } else
#endif
        if(kA < nA) {
            kA += NUMBER_OF_SPES;
            if(kA < nA) {
                cur_kA = nxt_kA;
                nxt_kA = kA;
                cur_ltag = nxt_ltag;
                nxt_ltag = ((nxt_ltag+1) & 1);
                cur_dtag = nxt_dtag;
                nxt_dtag = ((nxt_dtag+1) & 1) + 2;
                cur_lbuf = nxt_lbuf;
                nxt_lbuf = BLOCK_L+nxt_ltag;
                cur_dbuf = nxt_dbuf;
                nxt_dbuf = BLOCK_D-2+nxt_dtag;

                iget_block(nxt_lbuf, nxt_ltag, nA, nxt_kA, jA, eaA);
                nxt_dbuf = colcache_iget_block(nxt_dbuf, nxt_dtag, nA, nxt_kA, iA, eaA);

                dma_wait_mask((1 << cur_ltag) | (1 << cur_dtag) | (1 << cur_utag));
                //dma_wait(cur_ltag);
                //dma_wait(cur_dtag);
                //dma_wait(cur_utag);

                matrix_nmsub(cur_dbuf, cur_lbuf, cur_ubuf);

                if(cur_kA == jA+1 && jA+1 < iA) {
                    dma_wait(TAG_DIAG);
                    iszero = decompose_U(cur_dbuf, diagbuf);

                    dma_wait(TAG_SYNC);
                    iputb_block(cur_dbuf, TAG_SYNC, nA, cur_kA, iA, eaA);
                    mfc_sync(TAG_SYNC);
                    signal.s.line = jA+1;
                    signal.s.p.iszero = (iszero) ? (jA+1):0;
                    send_signal_all(signal);

                    diagA += NUMBER_OF_SPES;
                    if(diagA < iA) {
                        iget_block(diagbuf, TAG_DIAG, nA, diagA, diagA, eaA);
                    }
                } else {
                    colcache_iputb_block(cur_dbuf, cur_dtag, nA, cur_kA, iA, eaA);
                    dma_wait(cur_dtag); // 必要な理由が不明、そのうち解析する予定
                }
                kA += NUMBER_OF_SPES;
            }

            for(; kA < nA; kA += NUMBER_OF_SPES) {
                cur_kA = nxt_kA;
                nxt_kA = kA;
                cur_ltag = nxt_ltag;
                nxt_ltag = ((nxt_ltag+1) & 1);
                cur_dtag = nxt_dtag;
                nxt_dtag = ((nxt_dtag+1) & 1) + 2;
                cur_lbuf = nxt_lbuf;
                nxt_lbuf = BLOCK_L+nxt_ltag;
                cur_dbuf = nxt_dbuf;
                nxt_dbuf = BLOCK_D-2+nxt_dtag;

                iget_block(nxt_lbuf, nxt_ltag, nA, nxt_kA, jA, eaA);
                nxt_dbuf = colcache_iget_block(nxt_dbuf, nxt_dtag, nA, nxt_kA, iA, eaA);
 
                dma_wait_mask((1 << cur_ltag) | (1 << cur_dtag) | (1 << cur_utag));
                //dma_wait(cur_ltag);
                //dma_wait(cur_dtag);
                //dma_wait(cur_utag);

                matrix_nmsub(cur_dbuf, cur_lbuf, cur_ubuf);

                colcache_iputb_block(cur_dbuf, cur_dtag, nA, cur_kA, iA, eaA);
                dma_wait(cur_dtag); // 必要な理由が不明、そのうち解析する予定
            }

            cur_kA = nxt_kA;
            cur_ltag = nxt_ltag;
            cur_dtag = nxt_dtag;
            cur_lbuf = nxt_lbuf;
            cur_dbuf = nxt_dbuf;

            if(jA+1 < iA) {
                // Lと分解するブロックの先読み
                kA = (jA+2)/NUMBER_OF_SPES*NUMBER_OF_SPES+speid;
                if(kA < jA+2) {
                    kA += NUMBER_OF_SPES;
                }
                if(kA < nA) {
                    nxt_kA = kA;
                    nxt_ltag = ((nxt_ltag+1) & 1);
                    nxt_lbuf = BLOCK_L+nxt_ltag;

                    iget_block(nxt_lbuf, nxt_ltag, nA, nxt_kA, jA+1, eaA);

                    // 最後に読み込んだブロックが次に使われるときは転送なし
                    if(nxt_kA == cur_kA) {
                        nxt_dtag = cur_dtag;
                        nxt_dbuf = cur_dbuf;
                    } else {
                        nxt_dtag = ((nxt_dtag+1) & 1) + 2;
                        nxt_dbuf = BLOCK_D-2+nxt_dtag;
                        nxt_dbuf = colcache_iget_block(nxt_dbuf, nxt_dtag, nA, nxt_kA, iA, eaA);
                    }
                }
            }

            if(lssignal[SYNC_SIGNAL].s.line >= jA+1 && jA+1 < iA) {
                uready = 1;
                iget_block(nxt_ubuf, nxt_utag, nA, jA+1, iA, eaA);
            }

            //dma_wait_mask((1 << cur_ltag) | (1 << cur_dtag) | (1 << cur_utag));
            dma_wait(cur_ltag);
            dma_wait(cur_dtag);
            dma_wait(cur_utag);
            matrix_nmsub(cur_dbuf, cur_lbuf, cur_ubuf);

            if(cur_kA == jA+1 && jA+1 < iA) {
                dma_wait(TAG_DIAG);
                iszero = decompose_U(cur_dbuf, diagbuf);

                dma_wait(TAG_SYNC);
                iputb_block(cur_dbuf, TAG_SYNC, nA, cur_kA, iA, eaA);
                mfc_sync(TAG_SYNC);
                signal.s.line = jA+1;
                signal.s.p.iszero = (iszero) ? (jA+1):0;
                send_signal_all(signal);

                diagA += NUMBER_OF_SPES;
                if(diagA < iA) {
                    iget_block(diagbuf, TAG_DIAG, nA, diagA, diagA, eaA);
                }
            } else {
                colcache_iputb_block(cur_dbuf, cur_dtag, nA, cur_kA, iA, eaA);
                dma_wait(cur_dtag); // 必要な理由が不明、そのうち解析する予定。
                // キャッシュが当たる限りはパフォーマンスにほとんど影響しない
            }
        }
    }
}

void update_column_master(int nA, int iA, eaddr_t eaA)
{
    usyncdata signal = gsyncinit;

    run_spes(signal);

    update_column(nA, iA, eaA);

    join_spes();
}

void update_column_slave(int nA, int iA, eaddr_t eaA)
{
    usyncdata signal = gsyncinit;

    wait_for_signal();

    update_column(nA, iA, eaA);

    send_signal(signal);
}

void blocked_lu_decomposition(int n, int m, eaddr_t eaA, eaddr_t eaP)
{
    int iA;
    int nA = n / BLOCK_SIZE;
    void (*pfcolumn_block_decomposition)(int, int, eaddr_t, eaddr_t);
    void (*pfupdate_column)(int, int, eaddr_t);
    void (*pfinit_perm)(int, eaddr_t);
    int b = is_master();

    iA = 0;

    colcache_init(nA);

    pfinit_perm = (b) ? init_perm_master
                        : init_perm_slave;
    pfcolumn_block_decomposition = (b) ? column_block_decomposition_master
                                         : column_block_decomposition_slave;
    pfupdate_column = (b) ? update_column_master
                            : update_column_slave;

    (*pfinit_perm)(nA, eaP);

    (*pfcolumn_block_decomposition)(nA, iA, eaA, eaP);

    for(iA = 1; iA < nA; iA++) {
        colcache_next(nA, eaA);

#if defined READ_DECREMENTER
        gstep = iA;
#endif

        (*pfupdate_column)(nA, iA, eaA);

#if defined ENABLE_SWAP
        swap_rest();
        swap_wait_all();
#endif
   
        (*pfcolumn_block_decomposition)(nA, iA, eaA, eaP);
    }

    colcache_sync(nA, eaA);

#if defined ENABLE_SWAP
    swap_rest();
    swap_wait_all();
#endif
}

//////////////////////////////////////////////////////////////////////////////
// forward & backward substitution
//////////////////////////////////////////////////////////////////////////////

inline void iget_vector(int buf, int tag, int iV, eaddr_t eaV)
{
    mfc_get(lsV[buf], eaV + iV*BLOCK_SIZE*sizeof(float), sizeof(lsV[buf]), tag, 0, 0);
}

inline void get_vector(int buf, int iV, eaddr_t eaV)
{
    mfc_get(lsV[buf], eaV + iV*BLOCK_SIZE*sizeof(float), sizeof(lsV[buf]), TAG_VECTOR_GET, 0, 0);
    mfc_write_tag_mask(1 << TAG_VECTOR_GET);
    mfc_read_tag_status_all();
}

inline void iput_vector(int buf, int tag, int iV, eaddr_t eaV)
{
    mfc_put(lsV[buf], eaV + iV*BLOCK_SIZE*sizeof(float), sizeof(lsV[buf]), tag, 0, 0);
}

inline void iputb_vector(int buf, int tag, int iV, eaddr_t eaV)
{
    mfc_putb(lsV[buf], eaV + iV*BLOCK_SIZE*sizeof(float), sizeof(lsV[buf]), tag, 0, 0);
}

inline void put_vector(int buf, int iV, eaddr_t eaV)
{
    mfc_put(lsV[buf], eaV + iV*BLOCK_SIZE*sizeof(float), sizeof(lsV[buf]), TAG_VECTOR_PUT, 0, 0);
    mfc_write_tag_mask(1 << TAG_VECTOR_PUT);
    mfc_read_tag_status_all();
}

void iget_right_vector_elem(int buf, int tag, int perm, eaddr_t eaB)
{
    int i;

    for(i = 0; i < BLOCK_SIZE; i++) {
        mlgetelem[buf][i].notify = 0;
        mlgetelem[buf][i].reserved = 0;
        mlgetelem[buf][i].size = sizeof(float)*4;
        mlgetelem[buf][i].eal = eaB + (lsperm[perm][i]/4)*4*sizeof(float);
    }

    mfc_getl(lsrightelem[buf], 0, mlgetelem[buf], sizeof(mlgetelem[buf]), tag, 0, 0);
}

void iget_vector_all(int buf, int tag, int nA, eaddr_t eaV)
{
    int i;
    unsigned int size;
    float (*v)[VECTOR_SIZE*BLOCK_SIZE] = (float(*)[VECTOR_SIZE*BLOCK_SIZE])lsblock;

    for(i = 0; i < nA; i += VEC_DMA_LINE) {
        if(nA < i+VEC_DMA_LINE) {
            size = (nA-i)*BLOCK_SIZE*sizeof(float);
        } else {
            size = DMA_SIZE_MAX;
        }
        mfc_get(&v[buf][i*BLOCK_SIZE], eaV + i*BLOCK_SIZE*sizeof(float), size, tag, 0, 0);
    }
}

void iget_perm_all(int buf, int tag, int nA, eaddr_t eaP)
{
    int i;
    unsigned int size;
    int (*v)[VECTOR_SIZE*BLOCK_SIZE] = (int(*)[VECTOR_SIZE*BLOCK_SIZE])lsblock;

    for(i = 0; i < nA; i+= VEC_DMA_LINE) {
        if(nA < i+VEC_DMA_LINE) {
            size = (nA-i)*BLOCK_SIZE*sizeof(float);
        } else {
            size = DMA_SIZE_MAX;
        }
        mfc_get(&v[buf][i*BLOCK_SIZE], eaP + i*BLOCK_SIZE*sizeof(float), size, tag, 0, 0);
    }
}

void iputb_vector_all(int buf, int tag, int nA, eaddr_t eaV)
{
    int i;
    unsigned int size;
    float (*v)[VECTOR_SIZE*BLOCK_SIZE] = (float(*)[VECTOR_SIZE*BLOCK_SIZE])lsblock;

    for(i = 0; i < nA; i += VEC_DMA_LINE) {
        if(nA < i+VEC_DMA_LINE) {
            size = (nA-i)*BLOCK_SIZE*sizeof(float);
        } else {
            size = DMA_SIZE_MAX;
        }
        mfc_putb(&v[buf][i*BLOCK_SIZE], eaV + i*BLOCK_SIZE*sizeof(float), size, tag, 0, 0);
    }
}

void perm_vector(int rbuf, int ebuf, int perm)
{
    int i;
    for(i = 0; i < BLOCK_SIZE; i++) {
        lsV[rbuf][i] = lsrightelem[ebuf][i*4+lsperm[perm][i]%4];
    }
}

// 任意の大きさの右辺ベクトルを置換する
// かなり遅い
void perm_right_vector_large(int nA, int m, eaddr_t eaB, eaddr_t eaX, eaddr_t eaP)
{
    int iA, im;
    int nxt_eaB;
    int cur_eaX, nxt_eaX;
    int cur_vtag, nxt_vtag;
    int cur_vbuf, nxt_vbuf;

    cur_vtag = 0;

    for(iA = speid; iA < nA; iA += NUMBER_OF_SPES) {
        iget_perm(PERM_RIGHT, TAG_PERM, iA, eaP);
        dma_wait(TAG_PERM);

        nxt_eaB = eaB;
        nxt_eaX = eaX;
        nxt_vtag = 0; 
        nxt_vbuf = VECTOR_V+nxt_vtag;
        iget_right_vector_elem(nxt_vbuf, nxt_vtag, PERM_RIGHT, nxt_eaB);

        for(im = 0; im < m; im++) {
            nxt_eaB = eaB + im*nA*BLOCK_SIZE*sizeof(float);
            cur_eaX = nxt_eaX;
            nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
            cur_vtag = nxt_vtag;
            nxt_vtag = ((nxt_vtag+1) & 1);
            cur_vbuf = nxt_vbuf;
            nxt_vbuf = VECTOR_V+nxt_vtag;

            iget_right_vector_elem(nxt_vbuf, nxt_vtag, PERM_RIGHT, nxt_eaB);

            dma_wait(cur_vtag);
            perm_vector(cur_vbuf, cur_vbuf, PERM_RIGHT);

            iputb_vector(cur_vbuf, cur_vtag, iA, cur_eaX);
        }

        dma_wait(nxt_vtag);
        perm_vector(nxt_vbuf, nxt_vbuf, PERM_RIGHT);

        iputb_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

        dma_wait(cur_vtag);
        dma_wait(nxt_vtag);
    }
}

void perm_vector_all(int outbuf, int refbuf, int permbuf, int nA)
{
    int *o = (int *)((unsigned int)(lsblock) + outbuf*VECTOR_SIZE*BLOCK_SIZE*sizeof(float));
    int *r = (int *)((unsigned int)(lsblock) + refbuf*VECTOR_SIZE*BLOCK_SIZE*sizeof(float));
    int *p = (int *)((unsigned int)(lsblock) + permbuf*VECTOR_SIZE*BLOCK_SIZE*sizeof(float));
    int i;

    // 面倒なのでSIMD化なし
    for(i = 0; i < nA*BLOCK_SIZE; i += 4) {
        o[i  ] = r[p[i  ]];
        o[i+1] = r[p[i+1]];
        o[i+2] = r[p[i+2]];
        o[i+3] = r[p[i+3]];
    }
}

// ローカルストアに入りきる大きさの右辺ベクトルを置換する
// 8000個程度のfloatを処理可能
void perm_right_vector_small(int nA, int m, eaddr_t eaB, eaddr_t eaX, eaddr_t eaP)
{
    // ブロック用に確保した領域を流用
    // 0: 置換行列
    // 1-3: 入力、計算、出力の役割を順番に交代

    int im;
    int in_tag, ref_tag, out_tag;
    int in_buf, ref_buf, out_buf;
    int temp;
    int perm = 3;
    eaddr_t in_eaB;
    eaddr_t out_eaX;

    im = speid;
    if(im >= m) {
        return;
    }

    in_eaB = eaB + im*nA*BLOCK_SIZE*sizeof(float);
    in_tag = 0;
    ref_tag = 1;
    out_tag = 2;
    in_buf = 2;
    ref_buf = 1;
    out_buf = 0;

    // 置換行列をすべてローカルストア内に取得
    iget_perm_all(perm, TAG_PERM, nA, eaP);
    dma_wait(TAG_PERM);

    iget_vector_all(in_buf, in_tag, nA, in_eaB);

    im += NUMBER_OF_SPES;
    for(; im < m; im += NUMBER_OF_SPES) {
        in_eaB = eaB + im*nA*BLOCK_SIZE*sizeof(float);
        out_eaX = eaX + (im-NUMBER_OF_SPES)*nA*BLOCK_SIZE*sizeof(float);
        temp = out_tag;
        out_tag = ref_tag;
        ref_tag = in_tag;
        in_tag = temp;
        temp = out_buf;
        out_buf = ref_buf;
        ref_buf = in_buf;
        in_buf = temp;

        iget_vector_all(in_buf, in_tag, nA, in_eaB);

        dma_wait(ref_tag);
        perm_vector_all(out_buf, ref_buf, perm, nA);

        iputb_vector_all(out_buf, out_tag, nA, out_eaX);
    }

    out_eaX = eaX + (im-NUMBER_OF_SPES)*nA*BLOCK_SIZE*sizeof(float);
    temp = out_tag;
    out_tag = ref_tag;
    ref_tag = in_tag;
    in_tag = temp;
    temp = out_buf;
    out_buf = ref_buf;
    ref_buf = in_buf;
    in_buf = temp;

    dma_wait(ref_tag);
    perm_vector_all(out_buf, ref_buf, perm, nA);

    iputb_vector_all(out_buf, out_tag, nA, out_eaX);
    dma_wait(in_tag);
    dma_wait(out_tag);
}

void perm_right_vector(int nA, int m, eaddr_t eaB, eaddr_t eaX, eaddr_t eaP)
{
    if(nA < VECTOR_SIZE) {
        perm_right_vector_small(nA, m, eaB, eaX, eaP);
    } else {
        perm_right_vector_large(nA, m, eaB, eaX, eaP);
    }
}

void sub_diag_down_turn(int target, int block)
{
    volatile float *x = lsV[target];
    volatile float (*a)[BLOCK_SIZE] = lsblock[block];
    int ia, ja;
    vector float vv, vx;
    vector float vv0, vv1, vv2, vv3;
    vector float va0, va1, va2, va3;
    vector unsigned char vsplats0 = gvsplats[0];
    vector unsigned char vsplats1 = gvsplats[1];
    vector unsigned char vsplats2 = gvsplats[2];
    vector unsigned char vsplats3 = gvsplats[3];

    for(ia = 0; ia < BLOCK_SIZE; ia += 4) {
        x[ia  ] /= a[ia  ][ia  ];
        x[ia+1] -= x[ia  ] * a[ia  ][ia+1];
        x[ia+2] -= x[ia  ] * a[ia  ][ia+2];
        x[ia+3] -= x[ia  ] * a[ia  ][ia+3];

        x[ia+1] /= a[ia+1][ia+1];
        x[ia+2] -= x[ia+1] * a[ia+1][ia+2];
        x[ia+3] -= x[ia+1] * a[ia+1][ia+3];

        x[ia+2] /= a[ia+2][ia+2];
        x[ia+3] -= x[ia+2] * a[ia+2][ia+3];

        x[ia+3] /= a[ia+3][ia+3];

        vv = *(vector float*)&x[ia];
        vv0 = spu_shuffle(vv, vv, vsplats0);
        vv1 = spu_shuffle(vv, vv, vsplats1);
        vv2 = spu_shuffle(vv, vv, vsplats2);
        vv3 = spu_shuffle(vv, vv, vsplats3);

        for(ja = ia+4; ja < BLOCK_SIZE; ja += 4) {
            vx = *(vector float*)&x[ja];
            va0 = *(vector float*)&a[ja  ][ia];
            va1 = *(vector float*)&a[ja+1][ia];
            va2 = *(vector float*)&a[ja+2][ia];
            va3 = *(vector float*)&a[ja+3][ia];

            vx = spu_nmsub(vv0, va0, vx);
            vx = spu_nmsub(vv1, va1, vx);
            vx = spu_nmsub(vv2, va2, vx);
            vx = spu_nmsub(vv3, va3, vx);

            *(vector float*)&x[ja] = vx;
        }
    }
}

// 4x4の小行列内で転置する
// ついでにゼロ行列の判定を行い、ゼロ行列ならば0以外の値を返す
unsigned int matrix_inner_turn(int buf)
{
    volatile float (*a)[BLOCK_SIZE] = lsblock[buf];
    int ia, ja;
    vector float vs0, vs1, vs2, vs3;
    vector float vt0, vt1, vt2, vt3;
    vector float vd0, vd1, vd2, vd3;
    vector unsigned char vturn00 = { 0, 1, 2, 3, 4, 5, 6, 7, 16, 17, 18, 19, 20, 21, 22, 23, };
    vector unsigned char vturn01 = { 8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29, 30, 31, };
    vector unsigned char vturn10 = { 0, 1, 2, 3, 16, 17, 18, 19, 8, 9, 10, 11, 24, 25, 26, 27, };
    vector unsigned char vturn11 = { 4, 5, 6, 7, 20, 21, 22, 23, 12, 13, 14, 15, 28, 29, 30, 31, };
    uv_float_uint vor0, vor1;
    vector unsigned int vallor = spu_splats(0u);
    vector unsigned int vcmp;
    vector unsigned int vorx;
    vector unsigned int vnot;

    for(ia = 0; ia < BLOCK_SIZE; ia += 4) {
        for(ja = 0; ja < BLOCK_SIZE; ja += 4) {
            vs0 = *(vector float*)&a[ia  ][ja];
            vs1 = *(vector float*)&a[ia+1][ja];
            vs2 = *(vector float*)&a[ia+2][ja];
            vs3 = *(vector float*)&a[ia+3][ja];

            vor0.vf = spu_or(vs0, vs1);
            vor1.vf = spu_or(vs2, vs3);
            vor0.vui = spu_or(vor0.vui, vor1.vui);
            vallor = spu_or(vor0.vui, vallor);

            vt0 = spu_shuffle(vs0, vs2, vturn00);
            vt1 = spu_shuffle(vs1, vs3, vturn00);
            vt2 = spu_shuffle(vs0, vs2, vturn01);
            vt3 = spu_shuffle(vs1, vs3, vturn01);

            vd0 = spu_shuffle(vt0, vt1, vturn10);
            vd1 = spu_shuffle(vt0, vt1, vturn11);
            vd2 = spu_shuffle(vt2, vt3, vturn10);
            vd3 = spu_shuffle(vt2, vt3, vturn11);

            *(vector float*)&a[ia  ][ja] = vd0;
            *(vector float*)&a[ia+1][ja] = vd1;
            *(vector float*)&a[ia+2][ja] = vd2;
            *(vector float*)&a[ia+3][ja] = vd3;
        }
    }

    vcmp = spu_cmpeq(vallor, 0);
    vnot = spu_nor(vcmp, vcmp);
    vorx = spu_orx(vnot);
    vnot = spu_nor(vorx, vorx);

    return spu_extract(vnot, 0);
}

// blockは4x4の小行列内で転置済み
void sub_inner_turn(int target, int block, int diag)
{
    int ja;
    volatile float (*a)[BLOCK_SIZE] = lsblock[block];
    volatile float *t = lsV[target];
    volatile float *d = lsV[diag];
    uv_float vat0, vat1, vat2, vat3;
    uv_float vat4, vat5, vat6, vat7;
    uv_float vat8, vat9, vat10, vat11;
    uv_float vat12, vat13, vat14, vat15;
    uv_float vat16, vat17, vat18, vat19;
    uv_float vat20, vat21, vat22, vat23;
    uv_float vat24, vat25, vat26, vat27;
    uv_float vat28, vat29, vat30, vat31;
    uv_float vt0, vt1, vt2, vt3;
    uv_float vt4, vt5, vt6, vt7;
    uv_float vdv0;
    uv_float vd0, vd1, vd2, vd3;
    vector unsigned char vsplats0 = gvsplats[0];
    vector unsigned char vsplats1 = gvsplats[1];
    vector unsigned char vsplats2 = gvsplats[2];
    vector unsigned char vsplats3 = gvsplats[3];
    uv_uint vaddr;
    vector unsigned int vaddr_inc = { 16, 16, 16, 16, }; // sizeof(float)*4

    vt0.v = *(vector float*)&t[ 0];
    vt1.v = *(vector float*)&t[ 4];
    vt2.v = *(vector float*)&t[ 8];
    vt3.v = *(vector float*)&t[12];
    vt4.v = *(vector float*)&t[16];
    vt5.v = *(vector float*)&t[20];
    vt6.v = *(vector float*)&t[24];
    vt7.v = *(vector float*)&t[28];

    ja = 0;
    vdv0.v = *(vector float*)&d[ja];
    vd0.v = spu_shuffle(vdv0.v, vdv0.v, vsplats0);
    vd1.v = spu_shuffle(vdv0.v, vdv0.v, vsplats1);
    vd2.v = spu_shuffle(vdv0.v, vdv0.v, vsplats2);
    vd3.v = spu_shuffle(vdv0.v, vdv0.v, vsplats3);
    vat0.v  = *(vector float*)&a[ 0][ja];
    vat1.v  = *(vector float*)&a[ 1][ja];
    vat2.v  = *(vector float*)&a[ 2][ja];
    vat3.v  = *(vector float*)&a[ 3][ja];
    vat4.v  = *(vector float*)&a[ 4][ja];
    vat5.v  = *(vector float*)&a[ 5][ja];
    vat6.v  = *(vector float*)&a[ 6][ja];
    vat7.v  = *(vector float*)&a[ 7][ja];
    vat8.v  = *(vector float*)&a[ 8][ja];
    vat9.v  = *(vector float*)&a[ 9][ja];
    vat10.v = *(vector float*)&a[10][ja];
    vat11.v = *(vector float*)&a[11][ja];
    vat12.v = *(vector float*)&a[12][ja];
    vat13.v = *(vector float*)&a[13][ja];
    vat14.v = *(vector float*)&a[14][ja];
    vat15.v = *(vector float*)&a[15][ja];
    vat16.v = *(vector float*)&a[16][ja];
    vat17.v = *(vector float*)&a[17][ja];
    vat18.v = *(vector float*)&a[18][ja];
    vat19.v = *(vector float*)&a[19][ja];
    vat20.v = *(vector float*)&a[20][ja];
    vat21.v = *(vector float*)&a[21][ja];
    vat22.v = *(vector float*)&a[22][ja];
    vat23.v = *(vector float*)&a[23][ja];
    vat24.v = *(vector float*)&a[24][ja];
    vat25.v = *(vector float*)&a[25][ja];
    vat26.v = *(vector float*)&a[26][ja];
    vat27.v = *(vector float*)&a[27][ja];
    vat28.v = *(vector float*)&a[28][ja];
    vat29.v = *(vector float*)&a[29][ja];
    vat30.v = *(vector float*)&a[30][ja];
    vat31.v = *(vector float*)&a[31][ja];

    vaddr.v = spu_splats((unsigned int)(a));
    vaddr.v = spu_add(vaddr.v, vaddr_inc);

    for(ja = 4; ja < BLOCK_SIZE; ja += 4) {
        vt0.v = spu_nmsub(vd0.v, vat0.v, vt0.v);
        vt0.v = spu_nmsub(vd1.v, vat1.v, vt0.v);
        vt0.v = spu_nmsub(vd2.v, vat2.v, vt0.v);
        vt0.v = spu_nmsub(vd3.v, vat3.v, vt0.v);

        vt1.v = spu_nmsub(vd0.v, vat4.v, vt1.v);
        vt1.v = spu_nmsub(vd1.v, vat5.v, vt1.v);
        vt1.v = spu_nmsub(vd2.v, vat6.v, vt1.v);
        vt1.v = spu_nmsub(vd3.v, vat7.v, vt1.v);

        vt2.v = spu_nmsub(vd0.v, vat8.v, vt2.v);
        vt2.v = spu_nmsub(vd1.v, vat9.v, vt2.v);
        vt2.v = spu_nmsub(vd2.v, vat10.v, vt2.v);
        vt2.v = spu_nmsub(vd3.v, vat11.v, vt2.v);

        vt3.v = spu_nmsub(vd0.v, vat12.v, vt3.v);
        vt3.v = spu_nmsub(vd1.v, vat13.v, vt3.v);
        vt3.v = spu_nmsub(vd2.v, vat14.v, vt3.v);
        vt3.v = spu_nmsub(vd3.v, vat15.v, vt3.v);

        vt4.v = spu_nmsub(vd0.v, vat16.v, vt4.v);
        vt4.v = spu_nmsub(vd1.v, vat17.v, vt4.v);
        vt4.v = spu_nmsub(vd2.v, vat18.v, vt4.v);
        vt4.v = spu_nmsub(vd3.v, vat19.v, vt4.v);

        vt5.v = spu_nmsub(vd0.v, vat20.v, vt5.v);
        vt5.v = spu_nmsub(vd1.v, vat21.v, vt5.v);
        vt5.v = spu_nmsub(vd2.v, vat22.v, vt5.v);
        vt5.v = spu_nmsub(vd3.v, vat23.v, vt5.v);

        vt6.v = spu_nmsub(vd0.v, vat24.v, vt6.v);
        vt6.v = spu_nmsub(vd1.v, vat25.v, vt6.v);
        vt6.v = spu_nmsub(vd2.v, vat26.v, vt6.v);
        vt6.v = spu_nmsub(vd3.v, vat27.v, vt6.v);

        vt7.v = spu_nmsub(vd0.v, vat28.v, vt7.v);
        vt7.v = spu_nmsub(vd1.v, vat29.v, vt7.v);
        vt7.v = spu_nmsub(vd2.v, vat30.v, vt7.v);
        vt7.v = spu_nmsub(vd3.v, vat31.v, vt7.v);

        vat0.q  = si_lqd(vaddr.q, 0);
        vat1.q  = si_lqd(vaddr.q, 128);
        vat2.q  = si_lqd(vaddr.q, 256);
        vat3.q  = si_lqd(vaddr.q, 384);
        vat4.q  = si_lqd(vaddr.q, 512);
        vat5.q  = si_lqd(vaddr.q, 640);
        vat6.q  = si_lqd(vaddr.q, 768);
        vat7.q  = si_lqd(vaddr.q, 896);
        vat8.q  = si_lqd(vaddr.q, 1024);
        vat9.q  = si_lqd(vaddr.q, 1152);
        vat10.q = si_lqd(vaddr.q, 1280);
        vat11.q = si_lqd(vaddr.q, 1408);
        vat12.q = si_lqd(vaddr.q, 1536);
        vat13.q = si_lqd(vaddr.q, 1664);
        vat14.q = si_lqd(vaddr.q, 1792);
        vat15.q = si_lqd(vaddr.q, 1920);
        vat16.q = si_lqd(vaddr.q, 2048);
        vat17.q = si_lqd(vaddr.q, 2176);
        vat18.q = si_lqd(vaddr.q, 2304);
        vat19.q = si_lqd(vaddr.q, 2432);
        vat20.q = si_lqd(vaddr.q, 2560);
        vat21.q = si_lqd(vaddr.q, 2688);
        vat22.q = si_lqd(vaddr.q, 2816);
        vat23.q = si_lqd(vaddr.q, 2944);
        vat24.q = si_lqd(vaddr.q, 3072);
        vat25.q = si_lqd(vaddr.q, 3200);
        vat26.q = si_lqd(vaddr.q, 3328);
        vat27.q = si_lqd(vaddr.q, 3456);
        vat28.q = si_lqd(vaddr.q, 3584);
        vat29.q = si_lqd(vaddr.q, 3712);
        vat30.q = si_lqd(vaddr.q, 3840);
        vat31.q = si_lqd(vaddr.q, 3968);
        vdv0.v = *(vector float*)&d[ja];
        vd0.v = spu_shuffle(vdv0.v, vdv0.v, vsplats0);
        vd1.v = spu_shuffle(vdv0.v, vdv0.v, vsplats1);
        vd2.v = spu_shuffle(vdv0.v, vdv0.v, vsplats2);
        vd3.v = spu_shuffle(vdv0.v, vdv0.v, vsplats3);
        vaddr.v = spu_add(vaddr.v, vaddr_inc);
    }

    vt0.v = spu_nmsub(vd0.v, vat0.v, vt0.v);
    vt0.v = spu_nmsub(vd1.v, vat1.v, vt0.v);
    vt0.v = spu_nmsub(vd2.v, vat2.v, vt0.v);
    vt0.v = spu_nmsub(vd3.v, vat3.v, vt0.v);

    vt1.v = spu_nmsub(vd0.v, vat4.v, vt1.v);
    vt1.v = spu_nmsub(vd1.v, vat5.v, vt1.v);
    vt1.v = spu_nmsub(vd2.v, vat6.v, vt1.v);
    vt1.v = spu_nmsub(vd3.v, vat7.v, vt1.v);

    vt2.v = spu_nmsub(vd0.v, vat8.v, vt2.v);
    vt2.v = spu_nmsub(vd1.v, vat9.v, vt2.v);
    vt2.v = spu_nmsub(vd2.v, vat10.v, vt2.v);
    vt2.v = spu_nmsub(vd3.v, vat11.v, vt2.v);

    vt3.v = spu_nmsub(vd0.v, vat12.v, vt3.v);
    vt3.v = spu_nmsub(vd1.v, vat13.v, vt3.v);
    vt3.v = spu_nmsub(vd2.v, vat14.v, vt3.v);
    vt3.v = spu_nmsub(vd3.v, vat15.v, vt3.v);

    vt4.v = spu_nmsub(vd0.v, vat16.v, vt4.v);
    vt4.v = spu_nmsub(vd1.v, vat17.v, vt4.v);
    vt4.v = spu_nmsub(vd2.v, vat18.v, vt4.v);
    vt4.v = spu_nmsub(vd3.v, vat19.v, vt4.v);

    vt5.v = spu_nmsub(vd0.v, vat20.v, vt5.v);
    vt5.v = spu_nmsub(vd1.v, vat21.v, vt5.v);
    vt5.v = spu_nmsub(vd2.v, vat22.v, vt5.v);
    vt5.v = spu_nmsub(vd3.v, vat23.v, vt5.v);

    vt6.v = spu_nmsub(vd0.v, vat24.v, vt6.v);
    vt6.v = spu_nmsub(vd1.v, vat25.v, vt6.v);
    vt6.v = spu_nmsub(vd2.v, vat26.v, vt6.v);
    vt6.v = spu_nmsub(vd3.v, vat27.v, vt6.v);

    vt7.v = spu_nmsub(vd0.v, vat28.v, vt7.v);
    vt7.v = spu_nmsub(vd1.v, vat29.v, vt7.v);
    vt7.v = spu_nmsub(vd2.v, vat30.v, vt7.v);
    vt7.v = spu_nmsub(vd3.v, vat31.v, vt7.v);

    *(vector float*)&t[ 0] = vt0.v;
    *(vector float*)&t[ 4] = vt1.v;
    *(vector float*)&t[ 8] = vt2.v;
    *(vector float*)&t[12] = vt3.v;
    *(vector float*)&t[16] = vt4.v;
    *(vector float*)&t[20] = vt5.v;
    *(vector float*)&t[24] = vt6.v;
    *(vector float*)&t[28] = vt7.v;
}

// 前進消去,後退消去は係数行列がローカルストアに残るようにしているが,
// 右辺ベクトルがローカルストアに残るようにした方が早いはず.
// そうしないのは単にプログラミングが面倒だから.
//
// 制御の流れもLU分解のupdate_column関数と同じにしたほうが早いはず.
// これも面倒なので放置.

// 各SPEが少なくとも1本は担当することが前提
void forward_substitution_1spe(int nA, int m, eaddr_t eaA, eaddr_t eaX)
{
    int iA, jA;
    int im;
    eaddr_t cur_eaX, nxt_eaX;
    int cur_dtag, nxt_dtag;
    int cur_utag, nxt_utag;
    int cur_vtag, nxt_vtag;
    int cur_dbuf, nxt_dbuf;
    int cur_ubuf, nxt_ubuf;
    int cur_vbuf, nxt_vbuf;
    int cur_xbuf, nxt_xbuf;
    unsigned int iszero;

    nxt_dtag = 0;
    nxt_utag = 2;
    nxt_vtag = 4;
    nxt_dbuf = BLOCK_D+nxt_dtag;
    nxt_ubuf = BLOCK_U-2+nxt_utag;
    nxt_vbuf = VECTOR_V-4+nxt_vtag;
    nxt_xbuf = VECTOR_X-4+nxt_vtag;

    for(iA = 0; iA < nA; iA++) {
        cur_dtag = 0;
        cur_dbuf = BLOCK_D+nxt_dtag;
        iget_block(cur_dbuf, cur_dtag, nA, iA, iA, eaA);

        im = speid;
        cur_vtag = 5;
        nxt_eaX = eaX+im*nA*BLOCK_SIZE*sizeof(float);
        nxt_vtag = 4;
        nxt_vbuf = VECTOR_V-4+nxt_vtag;
        iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

        dma_wait(cur_dtag);
        (void)matrix_inner_turn(cur_dbuf);

        im += NUMBER_OF_SPES;
        for(; im < m; im += NUMBER_OF_SPES) {
            cur_eaX = nxt_eaX;
            nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
            cur_vtag = nxt_vtag;
            nxt_vtag = ((nxt_vtag+1) & 1) + 4;
            cur_vbuf = nxt_vbuf;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;

            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

            dma_wait(cur_vbuf);
            sub_diag_down_turn(cur_vbuf, cur_dbuf);

            iputb_vector(cur_vbuf, cur_vtag, iA, cur_eaX);
        }

        dma_wait(nxt_vtag);
        sub_diag_down_turn(nxt_vbuf, cur_dbuf);

        iputb_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
       
        for(jA = iA+1; jA < nA; jA++) {
            cur_utag = 2;
            cur_ubuf = BLOCK_U-2+cur_utag;
            iget_block(cur_ubuf, cur_utag, nA, jA, iA, eaA);
            dma_wait(cur_utag);

            iszero = matrix_inner_turn(cur_ubuf);
#if defined SKIP_ZERO
            if(__builtin_expect(iszero, 0)) {
                continue;
            }
#endif

            im = speid;
            nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
            nxt_vtag = ((nxt_vtag+1) & 1) + 4;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;
            nxt_xbuf = VECTOR_X-4+nxt_vtag;
            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
            iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

            im += NUMBER_OF_SPES;
            for(; im < m; im += NUMBER_OF_SPES) {
                cur_eaX = nxt_eaX;
                nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
                cur_vtag = nxt_vtag;
                nxt_vtag = ((nxt_vtag+1) & 1) + 4;
                cur_vbuf = nxt_vbuf;
                nxt_vbuf = VECTOR_V-4+nxt_vtag;
                cur_xbuf = nxt_xbuf;
                nxt_xbuf = VECTOR_X-4+nxt_vtag;

                iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
                iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

                dma_wait(cur_vtag);
                sub_inner_turn(cur_xbuf, cur_ubuf, cur_vbuf);

                iputb_vector(cur_xbuf, cur_vtag, jA, cur_eaX);
            }

            dma_wait(nxt_vtag);
            sub_inner_turn(nxt_xbuf, cur_ubuf, nxt_vbuf);

            iputb_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);
            dma_wait(nxt_vtag);
        }
    }

    mfc_barrier(TAG_SYNC);
}

void forward_substitution_nspe(int nA, int m, eaddr_t eaA, eaddr_t eaX)
{
    int iA, jA;
    int im;
    eaddr_t cur_eaX, nxt_eaX;
    int cur_dtag, nxt_dtag;
    int cur_utag, nxt_utag;
    int cur_vtag, nxt_vtag;
    int cur_dbuf, nxt_dbuf;
    int cur_ubuf, nxt_ubuf;
    int cur_vbuf, nxt_vbuf;
    int cur_xbuf, nxt_xbuf;
    usyncdata signal = { { 0, 0, {0}, 0, }, };
    unsigned int iszero;

    nxt_dtag = 0;
    nxt_utag = 2;
    nxt_vtag = 4;
    nxt_dbuf = BLOCK_D+nxt_dtag;
    nxt_ubuf = BLOCK_U-2+nxt_utag;
    nxt_vbuf = VECTOR_V-4+nxt_vtag;
    nxt_xbuf = VECTOR_X-4+nxt_vtag;

    for(iA = 0; iA < nA; iA++) {
        if(is_assigned(iA)) {
            cur_dtag = 0;
            cur_dbuf = BLOCK_D+nxt_dtag;
            iget_block(cur_dbuf, cur_dtag, nA, iA, iA, eaA);

            cur_vtag = 5;
            nxt_eaX = eaX;
            nxt_vtag = 4;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;
            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

            dma_wait(cur_dtag);
            (void)matrix_inner_turn(cur_dbuf);

            for(im = 1; im < m; im++) {
                cur_eaX = nxt_eaX;
                nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
                cur_vtag = nxt_vtag;
                nxt_vtag = ((nxt_vtag+1) & 1) + 4;
                cur_vbuf = nxt_vbuf;
                nxt_vbuf = VECTOR_V-4+nxt_vtag;

                iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

                dma_wait(cur_vbuf);
                sub_diag_down_turn(cur_vbuf, cur_dbuf);

                iputb_vector(cur_vbuf, cur_vtag, iA, cur_eaX);
            }

            dma_wait(nxt_vtag);
            sub_diag_down_turn(nxt_vbuf, cur_dbuf);

            iputb_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

            mfc_barrier(TAG_SYNC);

            signal.s.line = iA;
            send_signal_all(signal);
        } else {
#if defined READ_DECREMENTER
            s = spu_read_decrementer();
            while(lssignal[SYNC_SIGNAL].s.line < iA) {
                t = spu_read_decrementer();
                if(s-t > PRINT_CYCLE) {
                    spe_printf("SPE(%d): too late!(wait diag up vector) line(%d) = %d\n", speid, SYNC_SIGNAL, lssignal[SYNC_SIGNAL].s.line);
                    s = t;
                }
            }
#else
            while(lssignal[SYNC_SIGNAL].s.line < iA)  {
                ;
            }
#endif
        }

        jA = (iA+1)/NUMBER_OF_SPES*NUMBER_OF_SPES+speid;
        if(jA < iA+1) {
            jA += NUMBER_OF_SPES;
        }
        for(; jA < nA; jA += NUMBER_OF_SPES) {
            cur_utag = 2;
            cur_ubuf = BLOCK_U-2+cur_utag;
            iget_block(cur_ubuf, cur_utag, nA, jA, iA, eaA);
            dma_wait(cur_utag);

            iszero = matrix_inner_turn(cur_ubuf);
#if defined SKIP_ZERO
            if(__builtin_expect(iszero, 0)) {
                continue;
            }
#endif

            nxt_eaX = eaX;
            nxt_vtag = ((nxt_vtag+1) & 1) + 4;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;
            nxt_xbuf = VECTOR_X-4+nxt_vtag;
            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
            iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

            for(im = 1; im < m; im++) {
                cur_eaX = nxt_eaX;
                nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
                cur_vtag = nxt_vtag;
                nxt_vtag = ((nxt_vtag+1) & 1) + 4;
                cur_vbuf = nxt_vbuf;
                nxt_vbuf = VECTOR_V-4+nxt_vtag;
                cur_xbuf = nxt_xbuf;
                nxt_xbuf = VECTOR_X-4+nxt_vtag;

                iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
                iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

                dma_wait(cur_vtag);
                sub_inner_turn(cur_xbuf, cur_ubuf, cur_vbuf);

                iputb_vector(cur_xbuf, cur_vtag, jA, cur_eaX);
            }

            dma_wait(nxt_vtag);
            sub_inner_turn(nxt_xbuf, cur_ubuf, nxt_vbuf);

            iputb_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);
            dma_wait(nxt_vtag);
        }
    }

    mfc_barrier(TAG_SYNC);
}

void sub_diag_up_turn(int target, int ublock)
{
    volatile float *x = lsV[target];
    volatile float (*a)[BLOCK_SIZE] = lsblock[ublock];
    int ia, ja;
    vector float vv, vx;
    vector float vv0, vv1, vv2, vv3;
    vector float va0, va1, va2, va3;
    vector unsigned char vsplats0 = gvsplats[0];
    vector unsigned char vsplats1 = gvsplats[1];
    vector unsigned char vsplats2 = gvsplats[2];
    vector unsigned char vsplats3 = gvsplats[3];

    for(ia = BLOCK_SIZE-4; ia >= 0; ia -= 4) {
        x[ia+2] -= x[ia+3] * a[ia+3][ia+2];
        x[ia+1] -= x[ia+3] * a[ia+3][ia+1];
        x[ia  ] -= x[ia+3] * a[ia+3][ia  ];

        x[ia+1] -= x[ia+2] * a[ia+2][ia+1];
        x[ia  ] -= x[ia+2] * a[ia+2][ia  ];

        x[ia  ] -= x[ia+1] * a[ia+1][ia  ];

        vv = *(vector float*)&x[ia];
        vv0 = spu_shuffle(vv, vv, vsplats0);
        vv1 = spu_shuffle(vv, vv, vsplats1);
        vv2 = spu_shuffle(vv, vv, vsplats2);
        vv3 = spu_shuffle(vv, vv, vsplats3);
        for(ja = ia-4; ja >= 0; ja -= 4) {
            vx = *(vector float*)&x[ja];
            va0 = *(vector float*)&a[ja  ][ia];
            va1 = *(vector float*)&a[ja+1][ia];
            va2 = *(vector float*)&a[ja+2][ia];
            va3 = *(vector float*)&a[ja+3][ia];

            vx = spu_nmsub(vv0, va0, vx);
            vx = spu_nmsub(vv1, va1, vx);
            vx = spu_nmsub(vv2, va2, vx);
            vx = spu_nmsub(vv3, va3, vx);

            *(vector float*)&x[ja] = vx;
        }
    }
}

// 各SPEが少なくとも1本は担当することが前提
void backward_substitution_1spe(int nA, int m, eaddr_t eaA, eaddr_t eaX)
{
    int iA, jA;
    int im;
    eaddr_t cur_eaX, nxt_eaX;
    int cur_dtag, nxt_dtag;
    int cur_utag, nxt_utag;
    int cur_vtag, nxt_vtag;
    int cur_dbuf, nxt_dbuf;
    int cur_ubuf, nxt_ubuf;
    int cur_vbuf, nxt_vbuf;
    int cur_xbuf, nxt_xbuf;
    usyncdata signal = { { 0, 0, {0}, 0, }, };
    unsigned int iszero;

    nxt_dtag = 0;
    nxt_utag = 2;
    nxt_vtag = 4;
    nxt_dbuf = BLOCK_D+nxt_dtag;
    nxt_ubuf = BLOCK_U-2+nxt_utag;
    nxt_vbuf = VECTOR_V-4+nxt_vtag;
    nxt_xbuf = VECTOR_X-4+nxt_vtag;

    for(iA = nA-1; iA >= 0; iA--) {
        cur_dtag = 0;
        cur_dbuf = BLOCK_D+nxt_dtag;
        iget_block(cur_dbuf, cur_dtag, nA, iA, iA, eaA);

        im = speid;
        nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
        nxt_vtag = 4;
        nxt_vbuf = VECTOR_V-4+nxt_vtag;
        iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

        dma_wait(cur_dtag);
        (void)matrix_inner_turn(cur_dbuf);

        im += NUMBER_OF_SPES;
        for(; im < m; im += NUMBER_OF_SPES) {
            cur_eaX = nxt_eaX;
            nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
            cur_vtag = nxt_vtag;
            nxt_vtag = ((nxt_vtag+1) & 1) + 4;
            cur_vbuf = nxt_vbuf;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;

            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

            dma_wait(cur_vbuf);
            sub_diag_up_turn(cur_vbuf, cur_dbuf);

            iputb_vector(cur_vbuf, cur_vtag, iA, cur_eaX);
        }
        dma_wait(nxt_vtag);
        sub_diag_up_turn(nxt_vbuf, cur_dbuf);

        iputb_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

        mfc_barrier(TAG_SYNC);

        signal.s.line = nA-1-iA;
        send_signal_all(signal);

        for(jA = 0; jA < iA; jA++) {
            cur_utag = 2;
            cur_ubuf = BLOCK_U-2+cur_utag;
            iget_block(cur_ubuf, cur_utag, nA, jA, iA, eaA);
            dma_wait(cur_utag);

            iszero = matrix_inner_turn(cur_ubuf);
#if defined SKIP_ZERO
            if(__builtin_expect(iszero, 0)) {
                continue;
            }
#endif

            im = speid;
            nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
            nxt_vtag = ((nxt_vtag+1) & 1) + 4;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;
            nxt_xbuf = VECTOR_X-4+nxt_vtag;
            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
            iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

            im += NUMBER_OF_SPES;
            for(; im < m; im += NUMBER_OF_SPES) {
                cur_eaX = nxt_eaX;
                nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
                cur_vtag = nxt_vtag;
                nxt_vtag = ((nxt_vtag+1) & 1) + 4;
                cur_vbuf = nxt_vbuf;
                nxt_vbuf = VECTOR_V-4+nxt_vtag;
                cur_xbuf = nxt_xbuf;
                nxt_xbuf = VECTOR_X-4+nxt_vtag;

                iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
                iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

                dma_wait(cur_vtag);
                sub_inner_turn(cur_xbuf, cur_ubuf, cur_vbuf);

                iputb_vector(cur_xbuf, cur_vtag, jA, cur_eaX);
            }

            dma_wait(nxt_vtag);
            sub_inner_turn(nxt_xbuf, cur_ubuf, nxt_vbuf);

            iputb_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

            dma_wait(nxt_vtag);
        }
    }

    mfc_barrier(TAG_SYNC);
}

void backward_substitution_nspe(int nA, int m, eaddr_t eaA, eaddr_t eaX)
{
    int iA, jA;
    int im;
    eaddr_t cur_eaX, nxt_eaX;
    int cur_dtag, nxt_dtag;
    int cur_utag, nxt_utag;
    int cur_vtag, nxt_vtag;
    int cur_dbuf, nxt_dbuf;
    int cur_ubuf, nxt_ubuf;
    int cur_vbuf, nxt_vbuf;
    int cur_xbuf, nxt_xbuf;
    usyncdata signal = { { 0, 0, {0}, 0, }, };
    unsigned int iszero;

    nxt_dtag = 0;
    nxt_utag = 2;
    nxt_vtag = 4;
    nxt_dbuf = BLOCK_D+nxt_dtag;
    nxt_ubuf = BLOCK_U-2+nxt_utag;
    nxt_vbuf = VECTOR_V-4+nxt_vtag;
    nxt_xbuf = VECTOR_X-4+nxt_vtag;

    for(iA = nA-1; iA >= 0; iA--) {
        if(is_assigned(iA)) {
            cur_dtag = 0;
            cur_dbuf = BLOCK_D+nxt_dtag;
            iget_block(cur_dbuf, cur_dtag, nA, iA, iA, eaA);

            nxt_eaX = eaX;
            nxt_vtag = 4;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;
            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

            dma_wait(cur_dtag);
            (void)matrix_inner_turn(cur_dbuf);

            for(im = 1; im < m; im++) {
                cur_eaX = nxt_eaX;
                nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
                cur_vtag = nxt_vtag;
                nxt_vtag = ((nxt_vtag+1) & 1) + 4;
                cur_vbuf = nxt_vbuf;
                nxt_vbuf = VECTOR_V-4+nxt_vtag;

                iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

                dma_wait(cur_vbuf);
                sub_diag_up_turn(cur_vbuf, cur_dbuf);

                iputb_vector(cur_vbuf, cur_vtag, iA, cur_eaX);
            }

            dma_wait(nxt_vtag);
            sub_diag_up_turn(nxt_vbuf, cur_dbuf);

            iputb_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

            mfc_barrier(TAG_SYNC);

            signal.s.line = nA-1-iA;
            send_signal_all(signal);
        } else {
#if defined READ_DECREMENTER
            s = spu_read_decrementer();
            while(lssignal[SYNC_SIGNAL].s.line < nA-1-iA) {
                t = spu_read_decrementer();
                if(s-t > PRINT_CYCLE) {
                    spe_printf("SPE(%d): too late!(wait diag down vector) line(%d) = %d\n", speid, SYNC_SIGNAL, lssignal[SYNC_SIGNAL].s.line);
                    s = t;
                }
            }
#else
            while(lssignal[SYNC_SIGNAL].s.line < nA-1-iA)  {
                ;
            }
#endif
        }

        for(jA = speid; jA < iA; jA += NUMBER_OF_SPES) {
            cur_utag = 2;
            cur_ubuf = BLOCK_U-2+cur_utag;
            iget_block(cur_ubuf, cur_utag, nA, jA, iA, eaA);
            dma_wait(cur_utag);

            iszero = matrix_inner_turn(cur_ubuf);
#if defined SKIP_ZERO
            if(__builtin_expect(iszero, 0)) {
                continue;
            }
#endif

            nxt_eaX = eaX;
            nxt_vtag = ((nxt_vtag+1) & 1) + 4;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;
            nxt_xbuf = VECTOR_X-4+nxt_vtag;
            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
            iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

            for(im = 1; im < m; im++) {
                cur_eaX = nxt_eaX;
                nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
                cur_vtag = nxt_vtag;
                nxt_vtag = ((nxt_vtag+1) & 1) + 4;
                cur_vbuf = nxt_vbuf;
                nxt_vbuf = VECTOR_V-4+nxt_vtag;
                cur_xbuf = nxt_xbuf;
                nxt_xbuf = VECTOR_X-4+nxt_vtag;

                iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
                iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

                dma_wait(cur_vtag);
                sub_inner_turn(cur_xbuf, cur_ubuf, cur_vbuf);

                iputb_vector(cur_xbuf, cur_vtag, jA, cur_eaX);
            }

            dma_wait(nxt_vtag);
            sub_inner_turn(nxt_xbuf, cur_ubuf, nxt_vbuf);

            iputb_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

            dma_wait(nxt_vtag);
        }
    }

    mfc_barrier(TAG_SYNC);
}

void solve_1spe_master(int nA, int m, eaddr_t eaA, eaddr_t eaP, eaddr_t eaB, eaddr_t eaX)
{
    usyncdata signal = { { 0, 0, {0}, 0, }, };

    perm_right_vector(nA, m, eaB, eaX, eaP);

    run_spes(signal);
    forward_substitution_1spe(nA, m, eaA, eaX);
    backward_substitution_1spe(nA, m, eaA, eaX);
    join_spes();
}

void solve_nspe_master(int nA, int m, eaddr_t eaA, eaddr_t eaP, eaddr_t eaB, eaddr_t eaX)
{
    usyncdata signal = { { 0, 0, {0}, 0, }, };

    perm_right_vector(nA, m, eaB, eaX, eaP);

    run_spes(signal);
    forward_substitution_nspe(nA, m, eaA, eaX);
    join_spes();

    run_spes(signal);
    backward_substitution_nspe(nA, m, eaA, eaX);
    join_spes();
}

void solve_1spe_slave(int nA, int m, eaddr_t eaA, eaddr_t eaP, eaddr_t eaB, eaddr_t eaX)
{
    usyncdata signal = { { 0, 0, {0}, 0, }, };

    perm_right_vector(nA, m, eaB, eaX, eaP);

    wait_for_signal();
    forward_substitution_1spe(nA, m, eaA, eaX);
    backward_substitution_1spe(nA, m, eaA, eaX);
    send_signal(signal);
}

void solve_nspe_slave(int nA, int m, eaddr_t eaA, eaddr_t eaP, eaddr_t eaB, eaddr_t eaX)
{
    usyncdata signal = { { 0, 0, {0}, 0, }, };

    perm_right_vector(nA, m, eaB, eaX, eaP);

    wait_for_signal();
    forward_substitution_nspe(nA, m, eaA, eaX);
    send_signal(signal);

    wait_for_signal();
    backward_substitution_nspe(nA, m, eaA, eaX);
    send_signal(signal);
}

void spe_soleqs(struct spe_ctrl* sc){
    int i;
    int n = sc->n;
    int m = sc->m;
    int nA = n / BLOCK_SIZE;
    eaddr_t eaA = (eaddr_t)sc->buf;
    eaddr_t eaB = (eaddr_t)sc->buf+sizeof(float)*(n*n);
    eaddr_t eaX = (eaddr_t)sc->buf+sizeof(float)*(n*n+n*m);
    eaddr_t eaD = (eaddr_t)sc->buf+sizeof(float)*(n*n+n*m+n*m);
    eaddr_t eaP = (eaddr_t)sc->buf+sizeof(float)*(n*n+n*m+n*m+n*n);
    int cur_buf, nxt_buf;
    int cur_iA, nxt_iA;
    int cur_jA, nxt_jA;
    speid = sc->id;
    vector unsigned int vinit = { 0, 0, 0, 0, };
    void (*pfsolve)(int, int, eaddr_t, eaddr_t, eaddr_t, eaddr_t);
    int mperspe;

    set_linesize(nA*BLOCK_SIZE*sizeof(float));

    for(i = 0; i < NUMBER_OF_SPES; i++) {
        lsresult[i].v = vinit;

        eals[i] = sc->ls_addr[i];
        ealssignal[i] = sc->ls_addr[i] + (eaddr_t)&lssignal;
        ealsuline[i] = sc->ls_addr[i] + (eaddr_t)&lsuline;
    }

    i = speid;
    nxt_buf = 0;
    nxt_iA = i / nA;
    nxt_jA = i % nA;

    mperspe = m / NUMBER_OF_SPES;
    if(mperspe < 16) {
        if(is_master()) {
            pfsolve = solve_nspe_master;
        } else {
            pfsolve = solve_nspe_slave;
        }
    } else {
        if(is_master()) {
            pfsolve = solve_1spe_master;
        } else {
            pfsolve = solve_1spe_slave;
        }
    }

    // 係数行列の要素を配置しなおす.
    // 配置換えの理由
    // 1, 32x32のブロックの要素がメモリ上ではバラバラになっている.
    // 2, 列方向アクセスが多いが列方向にはメモリ上で連続していない.
    // 3, 1,2によりメモリアクセスが極端に遅い.
    //
    // 配置換えの内容
    // 32x32のブロックの要素がメモリ上で連続するようにに配置(ブロックレイアウト).
    // i行j列のブロックは(j*nA+i)番目に配置する.
    // ブロック内の要素は元の配置のまま.
    if(i < nA*nA) {
        iget_block_ml(nxt_buf, nxt_buf, nA, nxt_iA, nxt_jA, eaA);

        i += NUMBER_OF_SPES;
        for(; i < nA*nA; i += NUMBER_OF_SPES) {
            cur_buf = nxt_buf;
            nxt_buf = (nxt_buf+1) & 3;
            cur_iA = nxt_iA;
            nxt_iA = i / nA;
            cur_jA = nxt_jA;
            nxt_jA = i % nA;

            iget_block_ml(nxt_buf, nxt_buf, nA, nxt_iA, nxt_jA, eaA);
            dma_wait(cur_buf);
            iputb_block_line(cur_buf, cur_buf, nA, cur_iA, cur_jA, eaD);
        }

        iputb_block_line(nxt_buf, nxt_buf, nA, nxt_iA, nxt_jA, eaD);
        mfc_barrier(TAG_SYNC);
    }

    blocked_lu_decomposition(n, m, eaD, eaP);

    (*pfsolve)(nA, m, eaD, eaP, eaB, eaX);

#if defined FILL_A_AFTER_SOLEQS
    if(speid == 0) {
        nxt_buf = 0;
        nxt_iA = 0;
        nxt_jA = 0;

        iget_block_line(nxt_buf, nxt_buf, nA, nxt_iA, nxt_jA, eaD);

        for(i = 1; i < nA*nA; i++) {
            cur_buf = nxt_buf;
            nxt_buf = (nxt_buf+1) & 1;
            cur_iA = nxt_iA;
            nxt_iA = i / nA;
            cur_jA = nxt_jA;
            nxt_jA = i % nA;

            iget_block_line(nxt_buf, nxt_buf, nA, nxt_iA, nxt_jA, eaD);
            dma_wait(cur_buf);
            iputb_block_ml(cur_buf, cur_buf, nA, cur_iA, cur_jA, eaA);
        }

        iputb_block_ml(nxt_buf, nxt_buf, nA, nxt_iA, nxt_jA, eaA);
        dma_wait(nxt_buf);
    }
#endif

    mfc_barrier(TAG_SYNC);
    dma_wait(TAG_SYNC);

#if defined PROF_MATRIX_NMSUB || defined PRINT_PROF
    if(speid == 0) {
        spe_printf("dec = %d, %lf sec, %f cycle\n", dec, dec/(100.0*1024.0*1024.0), (dec/(100.0*1024.0*1024.0))*3.2e9);
    }
#endif
}

