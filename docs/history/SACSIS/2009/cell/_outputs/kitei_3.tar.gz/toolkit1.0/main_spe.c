/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2008-02-05                */
/*----------------------------------------------------------------------*/
#include <stdlib.h>
#include <float.h>
#include <spu_intrinsics.h>
#include <spelib.h>
#include <spe_stdio.h>
#include <spu_mfcio.h>
#include "spe_util.h"
#include "define.h"
#include "spe.h"

#define DEC_INIT_VAL 0x77359400

/*-----------------------------------------------------------------------*/

volatile static struct argument arg _GALIGN;
volatile static struct spe_ctrl sc _GALIGN;

volatile static struct spe_sync_block spe_sync _GALIGN;
volatile static struct spe_sync_block sync_addr _GALIGN;
unsigned int sync_ls[NUMBER_OF_SPES];
unsigned int dec_cnt;

void spe_soleqs(struct spe_ctrl* sc);

/*----------------------------------------------------------------------*/
void dmaget(void* d, unsigned long long addr, unsigned int size){
    /***** DMA Data Transfer, Memory -> LS *****/
    mfc_get(d, addr, size, DMA_TAG, 0, 0);
    mfc_write_tag_mask(DMA_TAG_MASK(DMA_TAG));
    mfc_write_tag_update_all();
    mfc_read_tag_status();
}

/*----------------------------------------------------------------------*/
void dmaput(void* d, unsigned long long addr, unsigned int size){
    /***** DMA Data Transfer, LS -> Memory *****/
    mfc_put(d, addr, size, DMA_TAG, 0, 0);
    mfc_write_tag_mask(DMA_TAG_MASK(DMA_TAG));
    mfc_write_tag_update_all();
    mfc_read_tag_status();
}

/*----------------------------------------------------------------------*/
void spe_pre_part_mult(unsigned int addr, int p, int q, int n, int m){
    unsigned int a,b,x;
    int i,j,k;
    volatile static float buf1[32] _GALIGN;
    volatile static float buf2[32] _GALIGN;
    volatile static float buf3[32] _GALIGN;

    vector float ma = {0.0, 0.0, 0.0, 0.0};

    a = addr;
    b = a + n * n * sizeof(float);
    x = b + n * m * sizeof(float);

    for(k=0;k<32;k++){
        for(i=0;i<4;i++)
            ma = spu_insert(0.0, ma, i);

        for(i=0;i<n/32;i++){
            dmaget((void*)buf1, a+n*sizeof(float)*(p+k)+i*128, 128);
            dmaget((void*)buf2, x+n*sizeof(float)*q    +i*128, 128);
            for(j=0;j<8;j++){
                ma = spu_madd(*(vector float*)&buf1[j*4], *(vector float*)&buf2[j*4], ma);
            }
        }

        buf3[k] = (float)spu_extract(ma,0);
        for(i=1;i<4;i++){
            buf3[k] += (float)spu_extract(ma,i);
        }
    }
    dmaput((void*)buf3, b+n*sizeof(float)*q+p*sizeof(float), 128);
}


void spe_pre_multiplication(int id, unsigned int addr, int n, int m){
    int i,j;

    for(i=0;i<n;i=i+32){
        for(j=id;j<m;j=j+NUMBER_OF_SPES){
            spe_pre_part_mult(addr, i, j, n, m);
        }
    }
}

/*----------------------------------------------------------------------*/

void spe_time_start(struct spe_ctrl* sc, unsigned long long argv){
    int i;

    dmaget((void*)&arg, argv, SPE_DMA_ALIGN);

    sc->flag = 0;
    while(sc->flag!=1){
        dmaget((void*)sc, arg.sc_addr, SPE_DMA_ALIGN);
    }

    spe_pre_multiplication(sc->id, (unsigned int)sc->buf, sc->n, sc->m);

    sync_addr.d[0] = 0;
    sync_addr.d[1] = 0;
    sync_addr.d[2] = 0;
    dmaput((void*)&sync_addr, sc->sync_addr + sc->id * SPE_DMA_ALIGN, SPE_DMA_ALIGN);

    sc->flag = 2;
    dmaput((void*)sc, arg.sc_addr, SPE_DMA_ALIGN);
    while(sc->flag!=3){
        dmaget((void*)sc, arg.sc_addr, SPE_DMA_ALIGN);
    }
    spu_write_decrementer(DEC_INIT_VAL);
    
    sync_addr.d[0] = (unsigned int)&spe_sync;
    sync_addr.d[1] = (unsigned int)0X3FFFFFFF;
    dmaput((void*)&sync_addr, sc->sync_addr + sc->id * SPE_DMA_ALIGN, SPE_DMA_ALIGN);

    spe_sync.d[0] = 0;

    if(sc->id == 0){
        sync_ls[0] = (unsigned int)&spe_sync + sc->ls_addr[0];
        spe_sync.d[0] = 1;
        spe_sync.d[1] = sync_ls[0];

        for(i=1;i<NUMBER_OF_SPES;i++){
            do{
                dmaget((void*)&sync_addr, sc->sync_addr + i * SPE_DMA_ALIGN, SPE_DMA_ALIGN);
            }while(sync_addr.d[1] != (unsigned int)0X3FFFFFFF);
            sync_ls[i] = sync_addr.d[0] + sc->ls_addr[i];
            dmaput((void*)&spe_sync, sync_ls[i], SPE_DMA_ALIGN);
        }
    }
    else{
        while(1){
            if(spe_sync.d[0] == 1){
                break;
            }
        }
    }

    dec_cnt = spu_read_decrementer();
};

/*----------------------------------------------------------------------*/

void spe_time_end(struct spe_ctrl* sc){
    int i;
    unsigned int cnt, stime, etime;

    cnt = spu_read_decrementer();

    spe_sync.d[0] = (unsigned int)0X1FFFFFFF;
    spe_sync.d[1] = dec_cnt;
    spe_sync.d[2] = cnt;
    stime = dec_cnt;
    etime = cnt;

    if(sc->id == 0){
        for(i=1;i<NUMBER_OF_SPES;i++){
            do{
                dmaget((void*)&spe_sync, sync_ls[i], SPE_DMA_ALIGN);
            }while(spe_sync.d[0] != (unsigned int)0X1FFFFFFF);

            if(stime < spe_sync.d[1]){
                stime = spe_sync.d[1];
            }
            if(etime > spe_sync.d[2]){
                etime = spe_sync.d[2];
            }

            spe_sync.d[0] = (unsigned int)0X2FFFFFFF;
            dmaput((void*)&spe_sync, sync_ls[i], SPE_DMA_ALIGN);
        }

        sc->dec_cnt = stime - etime;
        dmaput((void*)sc, arg.sc_addr, SPE_DMA_ALIGN);
    }
    else{
        while(spe_sync.d[0] != (unsigned int)0X2FFFFFFF) ;
    }
};

/*----------------------------------------------------------------------*/

/*----------------------------------------------------------------------*/
/* SPE main program                                                     */
/*----------------------------------------------------------------------*/

int main(int speid, unsigned long long argv)
{
    spe_time_start((struct spe_ctrl*)&sc, argv);
/*-----------------------*/
  // modify codes in function "spe_soleqs".
    spe_soleqs((struct spe_ctrl*)&sc);
/*-----------------------*/
    spe_time_end((struct spe_ctrl*)&sc);

    return 0;
}
/*----------------------------------------------------------------------*/
