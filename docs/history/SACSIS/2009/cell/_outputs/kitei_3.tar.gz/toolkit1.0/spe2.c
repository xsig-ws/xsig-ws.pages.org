/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2008-02-05                */
/*----------------------------------------------------------------------*/
#include "define.h"
#include "my_spe_common.h"

volatile static float dat[NUM_BLOCK_BUF*BSZxBSZ] _GALIGN;
volatile static float *tb[NUM_BLOCK_BUF] = { 
    dat,            dat+   BSZxBSZ, dat+ 2*BSZxBSZ, dat+ 3*BSZxBSZ, dat+ 4*BSZxBSZ, 
    dat+ 5*BSZxBSZ, dat+ 6*BSZxBSZ, dat+ 7*BSZxBSZ, dat+ 8*BSZxBSZ, dat+ 9*BSZxBSZ,
    dat+10*BSZxBSZ, dat+11*BSZxBSZ, dat+12*BSZxBSZ, dat+13*BSZxBSZ, dat+14*BSZxBSZ,
    dat+15*BSZxBSZ, dat+16*BSZxBSZ, dat+17*BSZxBSZ, dat+18*BSZxBSZ, dat+19*BSZxBSZ,
    dat+20*BSZxBSZ, dat+21*BSZxBSZ, dat+22*BSZxBSZ, dat+23*BSZxBSZ, dat+24*BSZxBSZ,
    dat+25*BSZxBSZ, dat+26*BSZxBSZ, dat+27*BSZxBSZ, dat+28*BSZxBSZ, dat+29*BSZxBSZ,
    dat+30*BSZxBSZ, dat+31*BSZxBSZ, dat+32*BSZxBSZ, dat+33*BSZxBSZ };
volatile float *ll = dat;

unsigned int ppe_ls[NUMBER_OF_SPES];
volatile static struct spe_sync sd[NUMBER_OF_SPES] _GALIGN;
volatile static struct spe_ctrl sc _GALIGN;
unsigned int onerow_sz; /* size of one row (n * sizeof(float) */

int swap_tail = 0;
int swap_info_i[4097];
int swap_info_m[4097];

/*----------------------------------------------------------------------*/
inline void sync_dist(int id, unsigned int key) 
{
    while (sd[id].start_flag != key);
}

inline void sync_collect(int id, unsigned int key)
{
    sd[id].end_flag = key;
    mfc_put(&sd[id], ppe_ls[0]+128*id, 128, TAG0, 0, 0);
    DMA_WAIT(1);
}

static unsigned int _list_swap_1[2*NUM_BLOCK_BUF] = {
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0 };
static unsigned int _list_swap_2[2*NUM_BLOCK_BUF] = {
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0 };
static my_mfc_list_elem_t *mfc_list_swap_1 = (my_mfc_list_elem_t *) (void *) _list_swap_1;
static my_mfc_list_elem_t *mfc_list_swap_2 = (my_mfc_list_elem_t *) (void *) _list_swap_2;
volatile static float sbuf1[BSZ*NUM_BLOCK_BUF] _GALIGN;
volatile static float sbuf2[BSZ*NUM_BLOCK_BUF] _GALIGN;
inline void swap_row(int id, unsigned int addr, unsigned int r1, unsigned int r2, int n, int N)
{
    int i, idx;
    unsigned int tmp1 = r1 / BSZ * BSZ;
    unsigned int tmp2 = r2 / BSZ * BSZ;
    unsigned int base1 = addr + sizeof(float)*(tmp1*n+(r1-tmp1)*BSZ);
    unsigned int base2 = addr + sizeof(float)*(tmp2*n+(r2-tmp2)*BSZ);

    idx = 0;
    for (i = id; i < N; i+= NUMBER_OF_SPES) {
        mfc_list_swap_1[idx].eal = base1 + BLK_DATA_SZ*i;
        mfc_list_swap_2[idx].eal = base2 + BLK_DATA_SZ*i;
        idx++;
    }

    if (__builtin_expect(idx > 0, 1)) {
        mfc_getl(sbuf1, 0, mfc_list_swap_1, idx*sizeof(my_mfc_list_elem_t), TAG0, 0, 0);
        mfc_getl(sbuf2, 0, mfc_list_swap_2, idx*sizeof(my_mfc_list_elem_t), TAG0, 0, 0);
        DMA_WAIT(1);
        mfc_putl(sbuf1, 0, mfc_list_swap_2, idx*sizeof(my_mfc_list_elem_t), TAG0, 0, 0);
        mfc_putl(sbuf2, 0, mfc_list_swap_1, idx*sizeof(my_mfc_list_elem_t), TAG0, 0, 0);
        DMA_WAIT(1);
    }
}

#define swap_buf() {             \
    tmp = in; in = op; op = tmp; \
}
inline void solve(unsigned int ppe_aa, unsigned int ppe_b, 
                  unsigned int ppe_x,  unsigned int start_col, int num_col, int n, int N)
{
    int i, j, I, J, idx;
    volatile static float *x[8] = { 
        dat+ 2*BSZxBSZ, dat+ 6*BSZxBSZ, dat+10*BSZxBSZ, dat+14*BSZxBSZ,
        dat+18*BSZxBSZ, dat+22*BSZxBSZ, dat+26*BSZxBSZ, dat+27*BSZxBSZ };
    volatile static float *tmp;
    volatile static float *in = dat;
    volatile static float *op = dat+BSZxBSZ;
    unsigned int in_addr;
    int Nm1=N-1, Nm2=N-2;
    int Nm1xBSZ = Nm1 * BSZ;
    int Nm2xBSZ = Nm2 * BSZ;

    idx = start_col;
    for (j = 0; j < num_col; j++) {
        mfc_get(x[j], ppe_b+idx*onerow_sz, onerow_sz, TAG0, 0, 0);
        DMA_WAIT(1);
        idx += NUMBER_OF_SPES;
    }
    /* swap column */
    for (i = 0; i < n; i++) {
        int swapidx_i = swap_info_i[i];
        int swapidx_m = swap_info_m[i];
        for (j = 0; j < num_col; j++) {
            float t = x[j][swapidx_i];
            x[j][swapidx_i] = x[j][swapidx_m];
            x[j][swapidx_m] = t; 
        }
    }


    /**********************************************************************/
    /* forward substitution                                               */
    /**********************************************************************/
    in_addr = ppe_aa;
    mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
    DMA_WAIT(1);
    swap_buf();

    in_addr = ppe_aa + BSZxFLOATSZ*n;
    mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
    for (j = 0; j < num_col; j++) 
        forward_substitution_32x32((float*)x[j], (float*)op);
    DMA_WAIT(1);
    swap_buf();

    in_addr = in_addr + BLK_DATA_SZ;
    mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
    for (j = 0; j < num_col; j++) 
        solve_kernel_32x32((float*)&x[j][BSZ], (float*)x[j], (float*)op);
    DMA_WAIT(1);
    swap_buf();

    in_addr = ppe_aa + 2*BSZxFLOATSZ*n;
    mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
    for (j = 0; j < num_col; j++) 
        forward_substitution_32x32((float*)&x[j][BSZ], (float*)op);

    for (I = 2; I < N; I++) {
        int IxBSZ = I * BSZ;
        int Jm1xBSZ;
        DMA_WAIT(1);
        for (J = 1; J < I; J++) {
            Jm1xBSZ = (J-1) * BSZ;
            swap_buf();
            in_addr = ppe_aa + (IxBSZ*n+J*BSZxBSZ)*sizeof(float);
            mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
            for (j = 0; j < num_col; j++) 
                solve_kernel_32x32((float*)&x[j][IxBSZ], (float*)&x[j][Jm1xBSZ], (float*)op);
            DMA_WAIT(1);
        }
        swap_buf();

        in_addr = ppe_aa + (IxBSZ*n+I*BSZxBSZ)*sizeof(float);
        mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
        Jm1xBSZ = (J-1) * BSZ;
        for (j = 0; j < num_col; j++) 
            solve_kernel_32x32((float*)&x[j][IxBSZ], (float*)&x[j][Jm1xBSZ], (float*)op);
        DMA_WAIT(1);
        swap_buf();

        if ((I+1) < N) {
            in_addr = ppe_aa + (I+1)*BSZxFLOATSZ*n;
            mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
        } else {
            in_addr = ppe_aa + ((N-1)*BSZ*n+(N-1)*BSZxBSZ)*sizeof(float);
            mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
        }

        for (j = 0; j < num_col; j++) 
            forward_substitution_32x32((float*)&x[j][IxBSZ], (float*)op);
    }

    /**********************************************************************/
    /* backward substitution                                               */
    /**********************************************************************/
    DMA_WAIT(1);
    swap_buf();

    in_addr = ppe_aa + (Nm2*BSZ*n+Nm1*BSZxBSZ)*sizeof(float);
    mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
    for (j = 0; j < num_col; j++) 
        backward_substitution_32x32((float*)&x[j][Nm1xBSZ], (float*)op);
    DMA_WAIT(1);
    swap_buf();

    in_addr = ppe_aa + (Nm2*BSZ*n+Nm2*BSZxBSZ)*sizeof(float);
    mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
    for (j = 0; j < num_col; j++) 
        solve_kernel_32x32((float*)&x[j][Nm2xBSZ], (float*)&x[j][Nm1xBSZ], (float*)op);
    DMA_WAIT(1);
    swap_buf();

    in_addr = ppe_aa + ((N-3)*BSZ*n+Nm1*BSZxBSZ)*sizeof(float);
    mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
    for (j = 0; j < num_col; j++) 
        backward_substitution_32x32((float*)&x[j][Nm2xBSZ], (float*)op);

    for (I = N-3; I >= 0; I--) {
        int IxBSZ = I * BSZ;
        int Jp1xBSZ;
        DMA_WAIT(1);
        for (J = Nm2; J > I; J--) {
            Jp1xBSZ = (J+1) * BSZ;
            swap_buf();
            in_addr = ppe_aa + (I*BSZ*n+J*BSZxBSZ)*sizeof(float);
            mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
            for (j = 0; j < num_col; j++) 
                solve_kernel_32x32((float*)&x[j][IxBSZ], (float*)&x[j][Jp1xBSZ], (float*)op);
            DMA_WAIT(1);
        }
        swap_buf();

        in_addr = ppe_aa + (I*BSZ*n+I*BSZxBSZ)*sizeof(float);
        mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
        Jp1xBSZ = (J+1) * BSZ;
        for (j = 0; j < num_col; j++) 
            solve_kernel_32x32((float*)&x[j][IxBSZ], (float*)&x[j][Jp1xBSZ], (float*)op);
        DMA_WAIT(1);
        swap_buf();

        if ((I-1) >= 0) {
            in_addr = ppe_aa + ((I-1)*BSZ*n+Nm1*BSZxBSZ)*sizeof(float);
            mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
        }

        for (j = 0; j < num_col; j++) 
            backward_substitution_32x32((float*)&x[j][IxBSZ], (float*)op);
    }

    idx = start_col;
    for (j = 0; j < num_col; j++) {
        mfc_put(x[j], ppe_x+idx*onerow_sz, onerow_sz, TAG0, 0, 0);
        DMA_WAIT(1);
        idx += NUMBER_OF_SPES;
    }
}

inline void solve_onecol(unsigned int ppe_aa, unsigned int ppe_b, 
                         unsigned int ppe_x,  unsigned int idx, int n, int N)
{
    int i, I, J;
    volatile static float *x = dat+2*BSZxBSZ;
    volatile static float *tmp;
    volatile static float *in = dat;
    volatile static float *op = dat+BSZxBSZ;
    unsigned int in_addr;
    int Nm1=N-1, Nm2=N-2;
    int Nm1xBSZ = Nm1 * BSZ;
    int Nm2xBSZ = Nm2 * BSZ;

    mfc_get(x, ppe_b+idx*onerow_sz, onerow_sz, TAG0, 0, 0);
    DMA_WAIT(1);
    /* swap column */
    for (i = 0; i < n; i++) {
        int swapidx_i = swap_info_i[i];
        int swapidx_m = swap_info_m[i];
        float t = x[swapidx_i];
        x[swapidx_i] = x[swapidx_m];
        x[swapidx_m] = t; 
    }

    /**********************************************************************/
    /* forward substitution                                               */
    /**********************************************************************/
    in_addr = ppe_aa;
    mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
    DMA_WAIT(1);
    swap_buf();

    in_addr = ppe_aa + BSZxFLOATSZ*n;
    mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
    forward_substitution_32x32((float*)x, (float*)op);
    DMA_WAIT(1);
    swap_buf();

    in_addr = in_addr + BLK_DATA_SZ;
    mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
    solve_nosimd_32x32((float*)&x[BSZ], (float*)x, (float*)op);
    DMA_WAIT(1);
    swap_buf();

    in_addr = ppe_aa + 2*BSZxFLOATSZ*n;
    mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
    forward_substitution_32x32((float*)&x[BSZ], (float*)op);

    for (I = 2; I < N; I++) {
        int IxBSZ = I * BSZ;
        int Jm1xBSZ;
        DMA_WAIT(1);
        for (J = 1; J < I; J++) {
            Jm1xBSZ = (J-1) * BSZ;
            swap_buf();
            in_addr = ppe_aa + (IxBSZ*n+J*BSZxBSZ)*sizeof(float);
            mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
            solve_nosimd_32x32((float*)&x[IxBSZ], (float*)&x[Jm1xBSZ], (float*)op);
            DMA_WAIT(1);
        }
        swap_buf();

        in_addr = ppe_aa + (IxBSZ*n+I*BSZxBSZ)*sizeof(float);
        mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
        Jm1xBSZ = (J-1) * BSZ;
        solve_nosimd_32x32((float*)&x[IxBSZ], (float*)&x[Jm1xBSZ], (float*)op);
        DMA_WAIT(1);
        swap_buf();

        if ((I+1) < N) {
            in_addr = ppe_aa + (I+1)*BSZxFLOATSZ*n;
            mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
        } else {
            in_addr = ppe_aa + ((N-1)*BSZ*n+(N-1)*BSZxBSZ)*sizeof(float);
            mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
        }

        forward_substitution_32x32((float*)&x[IxBSZ], (float*)op);
    }

    /**********************************************************************/
    /* backward substitution                                               */
    /**********************************************************************/
    DMA_WAIT(1);
    swap_buf();

    in_addr = ppe_aa + (Nm2*BSZ*n+Nm1*BSZxBSZ)*sizeof(float);
    mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
    backward_substitution_32x32((float*)&x[Nm1xBSZ], (float*)op);
    DMA_WAIT(1);
    swap_buf();

    in_addr = ppe_aa + (Nm2*BSZ*n+Nm2*BSZxBSZ)*sizeof(float);
    mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
    solve_nosimd_32x32((float*)&x[Nm2xBSZ], (float*)&x[Nm1xBSZ], (float*)op);
    DMA_WAIT(1);
    swap_buf();

    in_addr = ppe_aa + ((N-3)*BSZ*n+Nm1*BSZxBSZ)*sizeof(float);
    mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
    backward_substitution_32x32((float*)&x[Nm2xBSZ], (float*)op);

    for (I = N-3; I >= 0; I--) {
        int IxBSZ = I * BSZ;
        int Jp1xBSZ;
        DMA_WAIT(1);
        for (J = Nm2; J > I; J--) {
            Jp1xBSZ = (J+1) * BSZ;
            swap_buf();
            in_addr = ppe_aa + (I*BSZ*n+J*BSZxBSZ)*sizeof(float);
            mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
            solve_nosimd_32x32((float*)&x[IxBSZ], (float*)&x[Jp1xBSZ], (float*)op);
            DMA_WAIT(1);
        }
        swap_buf();

        in_addr = ppe_aa + (I*BSZ*n+I*BSZxBSZ)*sizeof(float);
        mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
        Jp1xBSZ = (J+1) * BSZ;
        solve_nosimd_32x32((float*)&x[IxBSZ], (float*)&x[Jp1xBSZ], (float*)op);
        DMA_WAIT(1);
        swap_buf();

        if ((I-1) >= 0) {
            in_addr = ppe_aa + ((I-1)*BSZ*n+Nm1*BSZxBSZ)*sizeof(float);
            mfc_get(in, in_addr, BLK_DATA_SZ, TAG0, 0, 0);
        }

        backward_substitution_32x32((float*)&x[IxBSZ], (float*)op);
    }

    mfc_put(x, ppe_x+idx*onerow_sz, onerow_sz, TAG0, 0, 0);
    DMA_WAIT(1);
}

inline void solve_small(unsigned int ppe_aa, unsigned int ppe_b, 
                        unsigned int ppe_x,  unsigned int idx, int n, int N)
{
    int i, I, J;
    volatile static float *x = dat+2*BSZxBSZ;
    volatile static float *lu1 = dat;
    volatile static float *lu2 = dat+BSZxBSZ;

    mfc_get(x, ppe_b+idx*onerow_sz, onerow_sz, TAG0, 0, 0);
    DMA_WAIT(1);
    /* swap column */
    for (i = 0; i < n; i++) {
        int swapidx_i = swap_info_i[i];
        int swapidx_m = swap_info_m[i];
        float t = x[swapidx_i];
        x[swapidx_i] = x[swapidx_m];
        x[swapidx_m] = t; 
    }

    /* forward substitution */
    for (I = 0; I < N; I++) {
        for (J = 0; J < I; J++) {
            mfc_get(lu1, ppe_aa+(I*BSZ*n+J*BSZxBSZ)*sizeof(float), BSZxBSZ*sizeof(float), 0, 0, 0);
            DMA_WAIT(1);
            solve_kernel_32x32((float*)&x[I*BSZ], (float*)&x[J*BSZ], (float*)lu1);
        }
        mfc_get(lu2, ppe_aa+(I*BSZ*n+I*BSZxBSZ)*sizeof(float), BSZxBSZ*sizeof(float), 0, 0, 0);
        DMA_WAIT(1);
        forward_substitution_32x32((float*)&x[I*BSZ], (float*)lu2);
    }

    /* backward substitution */
    for (I = N-1; I >= 0; I--) {
        for (J = N-1; J > I; J--) {
            mfc_get(lu1, ppe_aa+(I*BSZ*n+J*BSZxBSZ)*sizeof(float), BSZxBSZ*sizeof(float), 0, 0, 0);
            DMA_WAIT(1);
            solve_kernel_32x32((float*)&x[I*BSZ], (float*)&x[J*BSZ], (float*)lu1);
        }

        mfc_get(lu2, ppe_aa+(I*BSZ*n+I*BSZxBSZ)*sizeof(float), BSZxBSZ*sizeof(float), 0, 0, 0);
        DMA_WAIT(1);
        backward_substitution_32x32((float*)&x[I*BSZ], (float*)lu2);
    }

    mfc_put(x, ppe_x+idx*onerow_sz, onerow_sz, TAG0, 0, 0);
    DMA_WAIT(1);
}

#define __next__(VAR1, VAR2) { \
    v0 = spu_add(v0, vadd);    \
    v1 = spu_add(v1, vadd);    \
    vlist[VAR1] = v0;          \
    vlist[VAR2] = v1;          \
}

inline void fill_dma_list(int base, vector unsigned int *vlist) {                                                                        
    vector unsigned int vadd = (vector unsigned int) { 0, 4*onerow_sz, 0, 4*onerow_sz };                             
    vector unsigned int v0 = (vector unsigned int) { BSZxFLOATSZ, base,             BSZxFLOATSZ, base+onerow_sz };               
    vector unsigned int v1 = (vector unsigned int) { BSZxFLOATSZ, base+2*onerow_sz, BSZxFLOATSZ, base+3*onerow_sz }; 
                                                                                                
    vlist[0] = v0;                                                                              
    vlist[1] = v1;                                                                             
    __next__( 2, 3);                                                                          
    __next__( 4, 5);                                                                         
    __next__( 6, 7);                                                                        
    __next__( 8, 9);                                                                       
    __next__(10,11);                                                                      
    __next__(12,13);                                                                     
    __next__(14,15);                                                                             
}

inline void get_block(unsigned int dis, unsigned int src, int I, int J)
{
    unsigned int base = src + I*BSZ*onerow_sz + J*BSZxFLOATSZ; 
    vector unsigned int vlist[BSZ/2]; 
    fill_dma_list(base, vlist);
    mfc_getl((void*)dis, 0, (unsigned int)vlist, BSZ/2*sizeof(vector unsigned int), TAG0, 0, 0);
    DMA_WAIT(1);
}

#define piv_max(j) {                                 \
    t2 = fabs(tb[idx][j*BSZ+ss]);                    \
    if (t2 > tmax) {                                 \
        tmax = t2;                                   \
        *maxj = (K+(idx*NUMBER_OF_SPES)+id)*BSZ + j; \
    }                                                \
} 
inline void pivoting(int id, int s, int ss, int K, int KxBSZ, int num_blk, int *maxj)
{
    int idx;
    float tmax, t2;
    tmax = -1.0;

    for (idx = 0; idx < num_blk; idx++) {
        piv_max( 0); piv_max( 1); piv_max( 2); piv_max( 3); piv_max( 4);
        piv_max( 5); piv_max( 6); piv_max( 7); piv_max( 8); piv_max( 9);
        piv_max(10); piv_max(11); piv_max(12); piv_max(13); piv_max(14);
        piv_max(15); piv_max(16); piv_max(17); piv_max(18); piv_max(19);
        piv_max(20); piv_max(21); piv_max(22); piv_max(23); piv_max(24);
        piv_max(25); piv_max(26); piv_max(27); piv_max(28); piv_max(29);
        piv_max(30); piv_max(31);
    }

    sd[id].pivot_flag = SYNC_1;
    sd[id].pivot_idx  = *maxj;
    sd[id].pivot_max  = tmax;
    mfc_put(&sd[id], ppe_ls[0]+128*id, 128, TAG0, 0, 0);
    DMA_WAIT(1);

    while (sd[id].pivot_flag != SYNC_2);
    *maxj = sd[id].pivot_max;
}

inline void pivoting_and_swap(int id, int i, int ii, int iixBSZ, int num_blk, 
                              int K, int KxBSZ, int KxBSZxFLOATSZ, 
                              unsigned int ppe_aa, unsigned int ppe_b, int n, int m, int N) 
{
    int maxj=i, no, idx;
    unsigned int itemp, iaddr, mtemp, maddr;
    unsigned int base = ppe_aa + K*BLK_DATA_SZ;

    /* pivot selection */
    pivoting(id, i, ii, K, KxBSZ, num_blk, &maxj);

    if (maxj != i) {
        swap_row(id, ppe_aa, i, maxj, n, N);
        sync_collect(id, SYNC_3);
        swap_info_i[swap_tail] = i;
        swap_info_m[swap_tail++] = maxj;

        no = (maxj-KxBSZ) / BSZ;
        idx = no / NUMBER_OF_SPES;
        sync_dist(id, SYNC_4);

        if ((no%NUMBER_OF_SPES) == id) {
            unsigned int maxj_idx = (maxj-((K+no)*BSZ)) * BSZ;
            itemp = i/BSZ * BSZ;
            iaddr = base + sizeof(float)*(itemp*n+(i-itemp)*BSZ);
            mfc_put(&tb[idx][maxj_idx], iaddr, BSZ*sizeof(float), TAG0, 0, 0);
            mtemp = maxj/BSZ * BSZ;
            maddr = base + sizeof(float)*(mtemp*n+(maxj-mtemp)*BSZ);
            DMA_WAIT(1);
            sync_collect(id, SYNC_5);
            mfc_get(&tb[idx][maxj_idx], maddr, BSZ*sizeof(float), TAG0, 0, 0);
            DMA_WAIT(1)
        } 
    } 
    sync_dist(id, SYNC_S+i);
}

inline void lu_factorization(int id, int K, unsigned int ppe_aa, unsigned int ppe_b, int n, int m, int N)
{
    int i, ii, iixBSZ, idx, num_blk, KK, pos4;
    volatile float pivrow[BSZ] _GALIGN;
    unsigned int taddr, Kbase, iaddr, itemp;
    int KxBSZ = K * BSZ;
    int KxBSZxFLOATSZ = K * BSZxFLOATSZ;
    Kbase = ppe_aa + K*BLK_DATA_SZ;

    idx = 0;
    for (KK = K+id; KK < N; KK += NUMBER_OF_SPES) {
        taddr = Kbase + KK*n*BSZxFLOATSZ;
        mfc_get(tb[idx], taddr, BLK_DATA_SZ, TAG0, 0, 0);
        idx++;
    }
    num_blk = idx;
    DMA_WAIT(1);

    for (i = K*BSZ; i < (K+1)*BSZ-4; i++) {
        ii = i - K*BSZ;
        iixBSZ = ii * BSZ;

        pivoting_and_swap(id, i, ii, iixBSZ, num_blk, K, KxBSZ, KxBSZxFLOATSZ, ppe_aa, ppe_b, n, m, N);
        itemp = i/BSZ * BSZ;
        iaddr = Kbase + sizeof(float)*(itemp*n+(i-itemp)*BSZ);
        mfc_get(pivrow, iaddr, BSZxFLOATSZ, TAG0, 0, 0);
        pos4 = 4*(ii/4+1);
        DMA_WAIT(1);

        /* right looking */
        for (idx = 0; idx < num_blk; idx++) {
            column_update_simd32(tb[idx], pivrow, ii, pos4);
        }
    }

    do {
        ii = i - KxBSZ;
        iixBSZ = ii * BSZ;

        pivoting_and_swap(id, i, ii, iixBSZ, num_blk, K, KxBSZ, KxBSZxFLOATSZ, ppe_aa, ppe_b, n, m, N);

        itemp = i/BSZ * BSZ;
        iaddr = Kbase + sizeof(float)*(itemp*n+(i-itemp)*BSZ);
        mfc_get(pivrow, iaddr, BSZxFLOATSZ, TAG0, 0, 0);
        DMA_WAIT(1);

        for (idx = 0; idx < num_blk; idx++) {
            column_update_small(tb[idx], pivrow, ii, BSZ);
        }
        i++;
    } while (i < (K+1)*BSZ-1);

    ii = BSZ-1;
    iixBSZ = (BSZ-1) * BSZ;
    pivoting_and_swap(id, i, ii, iixBSZ, num_blk, K, KxBSZ, KxBSZxFLOATSZ, ppe_aa, ppe_b, n, m, N);

    itemp = i/BSZ * BSZ;
    iaddr = Kbase + sizeof(float)*(itemp*n+(i-itemp)*BSZ);
    mfc_get(pivrow, iaddr, BSZxFLOATSZ, TAG0, 0, 0);
    DMA_WAIT(1);

    KK = K + id;
    for (idx = 0; idx < num_blk; idx++) {
        column_update_small(tb[idx], pivrow, ii, BSZ);
        taddr = Kbase + BSZxFLOATSZ*KK*n;
        mfc_put(tb[idx], taddr, BLK_DATA_SZ, TAG0, 0, 0);
        KK += NUMBER_OF_SPES;
    }
    DMA_WAIT(1);
}

#define swap_Lik_buf() { \
    tmp_fptr = in_Lik; in_Lik = op_Lik; op_Lik = tmp_fptr; \
}
#define shift_Aij_buf() { \
    tmp_fptr = in_Aij; in_Aij = out_Aij;                 \
    out_Aij = op_Aij; op_Aij = tmp_fptr;                 \
    out_Aij_area = op_Aij_area; op_Aij_area = in_Aij_area; \
}

volatile static float *op_Ukj  = dat+2*BSZxBSZ;
volatile static float *in_Lik  = dat+4*BSZxBSZ;
volatile static float *op_Lik  = dat+5*BSZxBSZ;
volatile static float *in_Aij  = dat+6*BSZxBSZ;
volatile static float *op_Aij  = dat+7*BSZxBSZ;
volatile static float *out_Aij = dat+8*BSZxBSZ;

static unsigned int Ukj_area;
static unsigned int in_Lik_area;
static unsigned int in_Aij_area;
static unsigned int op_Aij_area;
static unsigned int out_Aij_area;

inline void other_update(int id, int K, unsigned int ppe_aa, int n, int N)
{
    volatile int I, J;
    volatile float *tmp_fptr;
    int BSZxn = BSZ * n;
    int KxBSZxBSZ = K * BSZxBSZ;
    int KxBSZxn = K * BSZxn;
    int JxBSZxBSZ, IxBSZxn;

    mfc_get(ll, ppe_aa+(K*BSZ*n+K*BSZxBSZ)*sizeof(float), BSZxBSZ*sizeof(float), TAG1, 0, 0);

    if (__builtin_expect(K+id >= N-2, 0)) {
        //inverse_l(K, ppe_aa, n);
        for (J = K+1+id; J < N; J+= NUMBER_OF_SPES) {
            JxBSZxBSZ = J * BSZxBSZ;
            Ukj_area = ppe_aa + (KxBSZxn+JxBSZxBSZ)*sizeof(float);
            mfc_get(op_Ukj, Ukj_area, BLK_DATA_SZ, TAG0, 0, 0);
            DMA_WAIT(3);
            forward_sub_row_32x32((float*)op_Ukj, (float*)ll);
            mfc_put(op_Ukj, Ukj_area, BLK_DATA_SZ, TAG0, 0, 0);
            DMA_WAIT(1);

            for (I = K+1; I < N; I++) {
                IxBSZxn = I * BSZxn;
                in_Lik_area = ppe_aa + (IxBSZxn+KxBSZxBSZ)*sizeof(float);
                mfc_get(in_Lik, in_Lik_area, BLK_DATA_SZ, TAG0, 0, 0);
                in_Aij_area = ppe_aa + (IxBSZxn+JxBSZxBSZ)*sizeof(float);
                mfc_get(in_Aij, in_Aij_area, BLK_DATA_SZ, TAG0, 0, 0);
                DMA_WAIT(1);
                matmulsub_SIMD32(in_Lik, op_Ukj, in_Aij);
                mfc_put(in_Aij, in_Aij_area, BLK_DATA_SZ, TAG0, 0, 0);
                DMA_WAIT(1);
            }
        }
        return;
    }

    J = K + 1 + id;
    JxBSZxBSZ = J * BSZxBSZ;
    Ukj_area = ppe_aa + (KxBSZxn+JxBSZxBSZ)*sizeof(float);
    mfc_get(op_Ukj, Ukj_area, BLK_DATA_SZ, TAG1, 0, 0);

    while (J < N) {
        I = K + 1;
        IxBSZxn = I * BSZxn;
        in_Lik_area = ppe_aa + (IxBSZxn+KxBSZxBSZ)*sizeof(float);
        DMA_WAIT(2);
        mfc_get(in_Lik, in_Lik_area, BLK_DATA_SZ, TAG0, 0, 0);
        in_Aij_area = ppe_aa + (IxBSZxn+JxBSZxBSZ)*sizeof(float);
        mfc_get(in_Aij, in_Aij_area, BLK_DATA_SZ, TAG0, 0, 0);
        forward_sub_row_32x32((float*)op_Ukj, (float*)ll);

        mfc_put(op_Ukj, Ukj_area, BLK_DATA_SZ, TAG1, 0, 0);
        DMA_WAIT(1);

        I++;
        swap_Lik_buf();
        shift_Aij_buf();
        IxBSZxn = I * BSZxn;
        in_Lik_area = ppe_aa + (IxBSZxn+KxBSZxBSZ)*sizeof(float);
        mfc_get(in_Lik, in_Lik_area, BLK_DATA_SZ, TAG0, 0, 0);
        in_Aij_area = ppe_aa + (IxBSZxn+JxBSZxBSZ)*sizeof(float);
        mfc_get(in_Aij, in_Aij_area, BLK_DATA_SZ, TAG0, 0, 0);
        matmulsub_SIMD32(op_Lik, op_Ukj, op_Aij);
        DMA_WAIT(3);

        I++;
        while (I < N) {
            swap_Lik_buf();
            shift_Aij_buf();
            mfc_put(out_Aij, out_Aij_area, BLK_DATA_SZ, TAG0, 0, 0);
            IxBSZxn = I * BSZxn;
            in_Lik_area = ppe_aa + (IxBSZxn+KxBSZxBSZ)*sizeof(float);
            mfc_get(in_Lik, in_Lik_area, BLK_DATA_SZ, TAG0, 0, 0);
            in_Aij_area = ppe_aa + (IxBSZxn+JxBSZxBSZ)*sizeof(float);
            mfc_get(in_Aij, in_Aij_area, BLK_DATA_SZ, TAG0, 0, 0);
            matmulsub_SIMD32(op_Lik, op_Ukj, op_Aij);
            I++;
            DMA_WAIT(1);
        }

        mfc_put(op_Aij, op_Aij_area, BLK_DATA_SZ, TAG0, 0, 0);
        matmulsub_SIMD32(in_Lik, op_Ukj, in_Aij);
        DMA_WAIT(1);
        mfc_put(in_Aij, in_Aij_area, BLK_DATA_SZ, TAG0, 0, 0);
        J += NUMBER_OF_SPES;
        if (J < N) {
            JxBSZxBSZ = J * BSZxBSZ;
            Ukj_area = ppe_aa + (KxBSZxn+JxBSZxBSZ)*sizeof(float);
            mfc_get(op_Ukj, Ukj_area, BLK_DATA_SZ, TAG1, 0, 0);
        }
        DMA_WAIT(1);
    }
}

void spe_soleqs(struct spe_ctrl* sc){
    int i, j;
    volatile int m, n, N;
    int I, J, K;
    int id;
    unsigned int ppe_a, ppe_b, ppe_x, ppe_c;
    unsigned int ppe_s, ppe_aa;
    volatile static struct spe_sync ss _GALIGN;
    
    ss.flag = 0;

    n  = sc->n;
    m  = sc->m;
    id = sc->id;
    ppe_a = sc->buf;
    ppe_b = ppe_a + n * n * sizeof(float);
    ppe_x = ppe_b + n * m * sizeof(float);
    ppe_c = ppe_x + n * m * sizeof(float);
    ppe_s = ppe_c + n * m * sizeof(float);
    ppe_aa = ppe_s + 128*NUMBER_OF_SPES;
    N = n / BSZ;
    onerow_sz = n * sizeof(float);
    
    /* for syncronization */
    ss.flag = 0XFFFFFFFF;
    ss.addr = (unsigned int)sc->ls_addr[id] + (unsigned int)&sd[0];
    dmaput((void*)&ss, (ppe_s+128*id) , 128);

    /* Get addresses for each sharing memory of SPE */
    ss.flag = 0;
    for(i=0;i<NUMBER_OF_SPES;i++){
        do{
            dmaget((void*)&ss, (ppe_s+128*i), 128);
        }while(ss.flag != 0XFFFFFFFF);
        ppe_ls[i] = ss.addr;
        ss.flag = 0;
    }

    /* change layout from row-major layout to BDL */
    for (I = id; I < N; I += NUMBER_OF_SPES) {
        unsigned int addr = ppe_aa + (I*BSZ*n)*sizeof(float);
        for (J = 0; J < N; J++) {
            get_block((unsigned int)dat, ppe_a, I, J);
            mfc_put(dat, addr, BLK_DATA_SZ, TAG0, 0, 0);
            addr += BLK_DATA_SZ;
            DMA_WAIT(1);
        }
    }
    sync_dist(id, SYNC_0);

    for (K = 0; K < N-1; K++) {
        lu_factorization(id, K, ppe_aa, ppe_b, n, m, N);
        sync_collect(id, SYNC_6);
        sync_dist(id, SYNC_7);
        other_update(id, K, ppe_aa, n, N);
        sync_dist(id, SYNC_8);
        sync_collect(id, SYNC_9);
    }
    lu_factorization(id, N-1, ppe_aa, ppe_b, n, m, N);
    sync_dist(id, SYNC_A);
    sync_collect(id, SYNC_B);

    /* Forward Substitution and Backward Substitution */
    if (__builtin_expect(N >= 3, 1)) {
        if (m > NUMBER_OF_SPES) {
            for(i = id; i < m; ) {
                i += NUMBER_OF_SPES;
                for (j = 1; j < 8 && i < m; j++) {
                    i += NUMBER_OF_SPES;
                }
                solve(ppe_aa, ppe_b, ppe_x, i-j*NUMBER_OF_SPES, j, n, N);
            }
        } else {
            if (id < m) {
                solve_onecol(ppe_aa, ppe_b, ppe_x, id, n, N);
            }
        }
    } else {
        for(i = id; i < m; i += NUMBER_OF_SPES) {
            solve_small(ppe_aa, ppe_b, ppe_x, i, n, N);
        }
    }
}

