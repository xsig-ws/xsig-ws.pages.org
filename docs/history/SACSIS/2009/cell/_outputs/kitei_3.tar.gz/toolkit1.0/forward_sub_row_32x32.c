#include <spu_intrinsics.h>
#define BSZ 32

void forward_sub_row_32x32(float *u, float *l)
{
    int i, j, ixBSZ, jxBSZ;
    vector float vu0a, vu1a, vu2a, vu3a, vu4a, vu5a, vu6a, vu7a;
    vector float vu0b, vu1b, vu2b, vu3b, vu4b, vu5b, vu6b, vu7b;
    vector float vl;

    for (i = 1; i < BSZ-1; i++) {
        /* odd */
        ixBSZ = i * BSZ;
        vu0a = *((vector float *) (u+ixBSZ   ));
        vu1a = *((vector float *) (u+ixBSZ+ 4));
        vu2a = *((vector float *) (u+ixBSZ+ 8));
        vu3a = *((vector float *) (u+ixBSZ+12));
        vu4a = *((vector float *) (u+ixBSZ+16));
        vu5a = *((vector float *) (u+ixBSZ+20));
        vu6a = *((vector float *) (u+ixBSZ+24));
        vu7a = *((vector float *) (u+ixBSZ+28));
        for (j = 0; j < i; j++) {
            jxBSZ = j * BSZ;
            vl = (vector float) spu_splats(*(l+ixBSZ+j));
            vu0b = *((vector float *) (u+jxBSZ   ));
            vu1b = *((vector float *) (u+jxBSZ+ 4));
            vu2b = *((vector float *) (u+jxBSZ+ 8));
            vu3b = *((vector float *) (u+jxBSZ+12));
            vu4b = *((vector float *) (u+jxBSZ+16));
            vu5b = *((vector float *) (u+jxBSZ+20));
            vu6b = *((vector float *) (u+jxBSZ+24));
            vu7b = *((vector float *) (u+jxBSZ+28));
            vu0a = spu_nmsub(vl, vu0b, vu0a);
            vu1a = spu_nmsub(vl, vu1b, vu1a);
            vu2a = spu_nmsub(vl, vu2b, vu2a);
            vu3a = spu_nmsub(vl, vu3b, vu3a);
            vu4a = spu_nmsub(vl, vu4b, vu4a);
            vu5a = spu_nmsub(vl, vu5b, vu5a);
            vu6a = spu_nmsub(vl, vu6b, vu6a);
            vu7a = spu_nmsub(vl, vu7b, vu7a);
        }
        i++;
        *((vector float *) (u+ixBSZ   )) = vu0a;
        *((vector float *) (u+ixBSZ+ 4)) = vu1a;
        *((vector float *) (u+ixBSZ+ 8)) = vu2a;
        *((vector float *) (u+ixBSZ+12)) = vu3a;
        *((vector float *) (u+ixBSZ+16)) = vu4a;
        *((vector float *) (u+ixBSZ+20)) = vu5a;
        *((vector float *) (u+ixBSZ+24)) = vu6a;
        *((vector float *) (u+ixBSZ+28)) = vu7a;

        /* even */
        ixBSZ = i * BSZ;
        vu0a = *((vector float *) (u+ixBSZ   ));
        vu1a = *((vector float *) (u+ixBSZ+ 4));
        vu2a = *((vector float *) (u+ixBSZ+ 8));
        vu3a = *((vector float *) (u+ixBSZ+12));
        vu4a = *((vector float *) (u+ixBSZ+16));
        vu5a = *((vector float *) (u+ixBSZ+20));
        vu6a = *((vector float *) (u+ixBSZ+24));
        vu7a = *((vector float *) (u+ixBSZ+28));
        for (j = 0; j < i; j++) {
            jxBSZ = j * BSZ;
            vl = (vector float) spu_splats(*(l+ixBSZ+j));
            vu0b = *((vector float *) (u+jxBSZ   ));
            vu1b = *((vector float *) (u+jxBSZ+ 4));
            vu2b = *((vector float *) (u+jxBSZ+ 8));
            vu3b = *((vector float *) (u+jxBSZ+12));
            vu4b = *((vector float *) (u+jxBSZ+16));
            vu5b = *((vector float *) (u+jxBSZ+20));
            vu6b = *((vector float *) (u+jxBSZ+24));
            vu7b = *((vector float *) (u+jxBSZ+28));
            j++;
            vu0a = spu_nmsub(vl, vu0b, vu0a);
            vu1a = spu_nmsub(vl, vu1b, vu1a);
            vu2a = spu_nmsub(vl, vu2b, vu2a);
            vu3a = spu_nmsub(vl, vu3b, vu3a);
            vu4a = spu_nmsub(vl, vu4b, vu4a);
            vu5a = spu_nmsub(vl, vu5b, vu5a);
            vu6a = spu_nmsub(vl, vu6b, vu6a);
            vu7a = spu_nmsub(vl, vu7b, vu7a);

            jxBSZ = j * BSZ;
            vl = (vector float) spu_splats(*(l+ixBSZ+j));
            vu0b = *((vector float *) (u+jxBSZ   ));
            vu1b = *((vector float *) (u+jxBSZ+ 4));
            vu2b = *((vector float *) (u+jxBSZ+ 8));
            vu3b = *((vector float *) (u+jxBSZ+12));
            vu4b = *((vector float *) (u+jxBSZ+16));
            vu5b = *((vector float *) (u+jxBSZ+20));
            vu6b = *((vector float *) (u+jxBSZ+24));
            vu7b = *((vector float *) (u+jxBSZ+28));
            vu0a = spu_nmsub(vl, vu0b, vu0a);
            vu1a = spu_nmsub(vl, vu1b, vu1a);
            vu2a = spu_nmsub(vl, vu2b, vu2a);
            vu3a = spu_nmsub(vl, vu3b, vu3a);
            vu4a = spu_nmsub(vl, vu4b, vu4a);
            vu5a = spu_nmsub(vl, vu5b, vu5a);
            vu6a = spu_nmsub(vl, vu6b, vu6a);
            vu7a = spu_nmsub(vl, vu7b, vu7a);
        }
        *((vector float *) (u+ixBSZ   )) = vu0a;
        *((vector float *) (u+ixBSZ+ 4)) = vu1a;
        *((vector float *) (u+ixBSZ+ 8)) = vu2a;
        *((vector float *) (u+ixBSZ+12)) = vu3a;
        *((vector float *) (u+ixBSZ+16)) = vu4a;
        *((vector float *) (u+ixBSZ+20)) = vu5a;
        *((vector float *) (u+ixBSZ+24)) = vu6a;
        *((vector float *) (u+ixBSZ+28)) = vu7a;
    }

    /* last(31) */
    vu0a = *((vector float *) (u+31*BSZ   ));
    vu1a = *((vector float *) (u+31*BSZ+ 4));
    vu2a = *((vector float *) (u+31*BSZ+ 8));
    vu3a = *((vector float *) (u+31*BSZ+12));
    vu4a = *((vector float *) (u+31*BSZ+16));
    vu5a = *((vector float *) (u+31*BSZ+20));
    vu6a = *((vector float *) (u+31*BSZ+24));
    vu7a = *((vector float *) (u+31*BSZ+28));
    for (j = 0; j < 30; j++) {
        jxBSZ = j * BSZ;
        vl = (vector float) spu_splats(*(l+31*BSZ+j));
        vu0b = *((vector float *) (u+jxBSZ   ));
        vu1b = *((vector float *) (u+jxBSZ+ 4));
        vu2b = *((vector float *) (u+jxBSZ+ 8));
        vu3b = *((vector float *) (u+jxBSZ+12));
        vu4b = *((vector float *) (u+jxBSZ+16));
        vu5b = *((vector float *) (u+jxBSZ+20));
        vu6b = *((vector float *) (u+jxBSZ+24));
        vu7b = *((vector float *) (u+jxBSZ+28));
        j++;
        vu0a = spu_nmsub(vl, vu0b, vu0a);
        vu1a = spu_nmsub(vl, vu1b, vu1a);
        vu2a = spu_nmsub(vl, vu2b, vu2a);
        vu3a = spu_nmsub(vl, vu3b, vu3a);
        vu4a = spu_nmsub(vl, vu4b, vu4a);
        vu5a = spu_nmsub(vl, vu5b, vu5a);
        vu6a = spu_nmsub(vl, vu6b, vu6a);
        vu7a = spu_nmsub(vl, vu7b, vu7a);

        jxBSZ = j * BSZ;
        vl = (vector float) spu_splats(*(l+31*BSZ+j));
        vu0b = *((vector float *) (u+jxBSZ   ));
        vu1b = *((vector float *) (u+jxBSZ+ 4));
        vu2b = *((vector float *) (u+jxBSZ+ 8));
        vu3b = *((vector float *) (u+jxBSZ+12));
        vu4b = *((vector float *) (u+jxBSZ+16));
        vu5b = *((vector float *) (u+jxBSZ+20));
        vu6b = *((vector float *) (u+jxBSZ+24));
        vu7b = *((vector float *) (u+jxBSZ+28));
        j++;
        vu0a = spu_nmsub(vl, vu0b, vu0a);
        vu1a = spu_nmsub(vl, vu1b, vu1a);
        vu2a = spu_nmsub(vl, vu2b, vu2a);
        vu3a = spu_nmsub(vl, vu3b, vu3a);
        vu4a = spu_nmsub(vl, vu4b, vu4a);
        vu5a = spu_nmsub(vl, vu5b, vu5a);
        vu6a = spu_nmsub(vl, vu6b, vu6a);
        vu7a = spu_nmsub(vl, vu7b, vu7a);
        
        jxBSZ = j * BSZ;
        vl = (vector float) spu_splats(*(l+31*BSZ+j));
        vu0b = *((vector float *) (u+jxBSZ   ));
        vu1b = *((vector float *) (u+jxBSZ+ 4));
        vu2b = *((vector float *) (u+jxBSZ+ 8));
        vu3b = *((vector float *) (u+jxBSZ+12));
        vu4b = *((vector float *) (u+jxBSZ+16));
        vu5b = *((vector float *) (u+jxBSZ+20));
        vu6b = *((vector float *) (u+jxBSZ+24));
        vu7b = *((vector float *) (u+jxBSZ+28));
        vu0a = spu_nmsub(vl, vu0b, vu0a);
        vu1a = spu_nmsub(vl, vu1b, vu1a);
        vu2a = spu_nmsub(vl, vu2b, vu2a);
        vu3a = spu_nmsub(vl, vu3b, vu3a);
        vu4a = spu_nmsub(vl, vu4b, vu4a);
        vu5a = spu_nmsub(vl, vu5b, vu5a);
        vu6a = spu_nmsub(vl, vu6b, vu6a);
        vu7a = spu_nmsub(vl, vu7b, vu7a);
    }

    vl = (vector float) spu_splats(*(l+31*BSZ+30));
    vu0b = *((vector float *) (u+30*BSZ   ));
    vu1b = *((vector float *) (u+30*BSZ+ 4));
    vu2b = *((vector float *) (u+30*BSZ+ 8));
    vu3b = *((vector float *) (u+30*BSZ+12));
    vu4b = *((vector float *) (u+30*BSZ+16));
    vu5b = *((vector float *) (u+30*BSZ+20));
    vu6b = *((vector float *) (u+30*BSZ+24));
    vu7b = *((vector float *) (u+30*BSZ+28));
    vu0a = spu_nmsub(vl, vu0b, vu0a);
    vu1a = spu_nmsub(vl, vu1b, vu1a);
    vu2a = spu_nmsub(vl, vu2b, vu2a);
    vu3a = spu_nmsub(vl, vu3b, vu3a);
    vu4a = spu_nmsub(vl, vu4b, vu4a);
    vu5a = spu_nmsub(vl, vu5b, vu5a);
    vu6a = spu_nmsub(vl, vu6b, vu6a);
    vu7a = spu_nmsub(vl, vu7b, vu7a);

    *((vector float *) (u+31*BSZ   )) = vu0a;
    *((vector float *) (u+31*BSZ+ 4)) = vu1a;
    *((vector float *) (u+31*BSZ+ 8)) = vu2a;
    *((vector float *) (u+31*BSZ+12)) = vu3a;
    *((vector float *) (u+31*BSZ+16)) = vu4a;
    *((vector float *) (u+31*BSZ+20)) = vu5a;
    *((vector float *) (u+31*BSZ+24)) = vu6a;
    *((vector float *) (u+31*BSZ+28)) = vu7a;
}

