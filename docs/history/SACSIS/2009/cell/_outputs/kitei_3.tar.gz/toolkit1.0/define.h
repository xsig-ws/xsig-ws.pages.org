/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2008-02-05                */
/*----------------------------------------------------------------------*/
#define NUMBER_OF_SPES 7
#define USER_MEM   (20 * 1024 * 1024)         // user working memory

/*----------------------------------------------------------------------*/
#define DMA_TAG 0
#define SPE_STDIO_BUF_SIZE 1024 // 512
#define SPE_DMA_ALIGN (128)

/*----------------------------------------------------------------------*/
struct argument{
    int id;               //
    unsigned int sc_addr; //
    float padding[30];    // just for padding
};

/*----------------------------------------------------------------------*/
struct spe_ctrl{
    unsigned int flag;        //
    unsigned int id;          //
    unsigned int spe_num;     //
    unsigned int buf;         //
    unsigned int buf_ctrl;    // 

    unsigned int n;           // matrix size
    unsigned int m;           // number of solution vector
    unsigned int dec_cnt;
    unsigned int sync_addr;
    unsigned int ls_addr[NUMBER_OF_SPES];    // 7 * 4 = 28 Byte
    unsigned int padding[23-NUMBER_OF_SPES]; // just for padding
};
/*----------------------------------------------------------------------*/

struct spe_sync_block{
    unsigned int d[32];
};

/*----------------------------------------------------------------------*/
