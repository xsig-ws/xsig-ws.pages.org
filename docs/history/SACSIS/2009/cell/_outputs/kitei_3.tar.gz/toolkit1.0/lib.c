/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2008-01-11                */
/*----------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include "define.h"
#include <math.h>

typedef union fs{
    float f;
    unsigned char c[4];
}FS;

typedef union ds{
    double d;
    unsigned char c[8];
}DS;

/*----------------------------------------------------------------------*/
double my_clock()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec + (double)tv.tv_usec*1e-6;
};

double calculate_flops(int n, int m, double t){
  double flops;

  flops = 0.0;
  flops += (2.0/3.0) * (double)n * (double)n * (double)n;
  flops += (3.0/2.0) * (double)n * (double)n;
  flops += (5.0/6.0) * (double)n; // LU decomposition
  flops += ((double)n * (double)n + (double)n) * (double)m;  // forward substitution
  flops += ((double)n * (double)n + 2.0 * (double)n) * (double)m;  // backward substitution
  flops /= (t * 1000000.0);

  return flops;
}

void matrix_multiplication(int n, int m, float* a, float* x, float* b)
{
    int i,j,k;

    for(k=0;k<m;k++){
        for(i=0;i<n;i++){
            b[k*n+i] = 0.0;
            for(j=0;j<n;j++){
                b[k*n+i] += a[n*i+j]*x[k*n+j];
            }
        }
    }
}


void get_matrix(int n, int m, float* a, unsigned int s)
{
    int i,j;
    int d, hd;

    // generate by random values
    // srand((unsigned int)time(NULL));
    if (s == 1) {
        /* Dense Unsymmetrical Random Matrix  n = *, m = ** */
        for(j=0;j<n;j++){
            for(i=0;i<n;i++){
                a[n*j+i] = ((float)rand()/(float)RAND_MAX);
            }
        }
    }
    else if (s == 2) {
        /* Dense Unsymmetrical Random Matrix  n = *, m = 1  */

        for(j=0;j<n;j++){
            for(i=0;i<n;i++){
                a[n*j+i] = ((float)rand()/(float)RAND_MAX);
            }
        }

    }
    else if (s == 3) {
        /* Unsymmetrical Tridiagonal matrix,  n = *, m = 1 */
        for(i=0;i<2;i++){
            a[i] = ((float)rand()/(float)RAND_MAX);
        }
        for(j=1;j<n-1;j++){
            for(i=j-1;i<j+2;i++){
                a[n*j+i] = ((float)rand()/(float)RAND_MAX);
            }
        }
        for(i=j-1;i<n;i++){
            a[n*(n-1)+i] = ((float)rand()/(float)RAND_MAX);
        }
    }
    else if (s == 4) {
        /* Unsymmetric Band Matrix,  n = *, m = ** */
        d = n / 4 + 1;
        hd = (d-1) / 2;
        for(j=0;j<hd;j++){
            for(i=0;i<j+hd+1;i++){
                a[n*j+i] = ((float)rand()/(float)RAND_MAX);
            }
        }
        for(j=hd;j<n-hd;j++){
            for(i=j-hd;i<j+hd+1;i++){
                a[n*j+i] = ((float)rand()/(float)RAND_MAX);
            }
        }
        for(j=n-hd;j<n;j++){
            for(i=j-hd;i<n;i++){
                a[n*j+i] = ((float)rand()/(float)RAND_MAX);
            }
        }

    }
    else if (s == 5){
        /* Dense Symmetric Positive Definite Matrix,  n = *, m = **  */
        for(j=0;j<n;j++){
            for(i=0;i<n;i++){
                a[n*j+i] = ((float)rand()/(float)RAND_MAX);
            }
        }
        for(j=0;j<n;j++){
            a[n*j+j] = a[n*j+j] + (float)n;
        }
    }
    else{
        for(j=0;j<m;j++){
            for(i=0;i<n;i++){
                a[n*j+i] = ((float)rand()/(float)RAND_MAX);
            }
        }
    }
}



void generate_solvec(int n, int m, float* x, unsigned int s)
{
    int i;

    if(s == 0){
        for(i=0;i<n*m;i++) x[i] = 1.0;
    }
    else{
        for(i=0;i<n*m;i++) x[i] = ((float)rand()/(float)RAND_MAX);
    }

}

void get_prob(int n, int m, int s, float* buf){
    float* x;
    float* b;

    b = (float*)((unsigned int)buf+sizeof(float)*n*n);
    x = (float*)((unsigned int)buf+sizeof(float)*(n*n+n*m));

    srand(s);
    get_matrix(n,n,(float*)buf,s);

    srand(s*s);
    generate_solvec(n, m, x, s);
}

double check(int n, int m, float* buf, double etime, unsigned int s)
{
    int i,j;
    float* c;
    float* x;
    float ftxmax;
    float famax;
    float fta;

    float feps;
    DS ds;
    DS dsa;
    unsigned int ca[5][2];
    double da;
    
    x = (float*)((unsigned int)buf+sizeof(float)*(n*n+n*m));
    c = (float*)((unsigned int)x+sizeof(float)*n*m);

    srand(s);
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            buf[i*n+j] = 0.0;
        }
    }
    get_matrix(n,n,(float*)buf,s);

    srand(s*s);
    generate_solvec(n, m, c, s);

    feps = 1.0;
    for(i=0;i<23;i++) feps *= 0.5;

    famax = 0.0;
    for(i=0;i<n;i++){
        fta = 0.0;
        for(j=0;j<n;j++)
            fta += fabs(buf[n*j+i]);
        if(famax < fta) famax = fta;
    }

    ftxmax = (double)fabs(c[0] - x[0]);
    for(i=1;i<n*m;i++){
        if((double)fabs(c[i] - x[i]) > ftxmax){
            ftxmax = (double)fabs(c[i] - x[i]);
        }
    }
    ds.d = (double)ftxmax/((double)feps*(double)famax*(double)n);

    ca[0][0] = 0X1F94FD54;
    ca[0][1] = 0X3F925829;

    ca[1][0] = 0X9C584156;
    ca[1][1] = 0X3F9FF6E9;

    ca[2][0] = 0X6C8193F3;
    ca[2][1] = 0X3FD7575B;

    ca[3][0] = 0X0FAFB916;
    ca[3][1] = 0X3F99FADC;

    ca[4][0] = 0X755C1D79;
    ca[4][1] = 0X3F290D62;

    if(s>=1 && s<=5){
        for(i=0;i<8;i++){
            dsa.c[i] = (unsigned char)(ca[s-1][1-(i/4)] >> (8*(3-i%4)));
        }
    }
    else{
        dsa.d = 1.0/3.0;
    }

    da = ds.d / dsa.d;
    
    // for x86
    /*
      printf("check[%2d] : %1.5f (%02X%02X%02X%02X)\n",k,fs.f,

              *(unsigned char*)&fs.c[3],
              *(unsigned char*)&fs.c[2],
              *(unsigned char*)&fs.c[1],
              *(unsigned char*)&fs.c[0]);
    */
    // for ppc
    /*
    printf("check : %1.5f (%02X%02X%02X%02X)\n",
           fs.f,
           *(unsigned char*)&fs.c[0],
           *(unsigned char*)&fs.c[1],
           *(unsigned char*)&fs.c[2],
           *(unsigned char*)&fs.c[3]);
    */
    
    printf("[spe_] %8.6f (sec) check %1.2f  < 3.0 (current error:%1.2e / error:%1.2e)\n", etime, da, ds.d, dsa.d);
    printf("check : %1.5f (%02X%02X%02X%02X%02X%02X%02X%02X)\n",
           ds.d,
           *(unsigned char*)&ds.c[0],
           *(unsigned char*)&ds.c[1],
           *(unsigned char*)&ds.c[2],
           *(unsigned char*)&ds.c[3],
           *(unsigned char*)&ds.c[4],
           *(unsigned char*)&ds.c[5],
           *(unsigned char*)&ds.c[6],
           *(unsigned char*)&ds.c[7]
        );

    return da;
}

void disp_matrix(int n, int m, float* a)
{
    int i, j;

    // for standard output
    for(j=0;j<m;j++){
        for(i=0;i<n;i++){
            printf("%1.2f ",a[j*n+i]);
        }
        printf("\n");
    }
}
