#include <spu_intrinsics.h>
#define BSZ 32

#define vxI_8rows_spu_madd() {                  \
    vxJ++;                                      \
    vxI0 = spu_madd(*vop0, *vxJ, vxI0); vop0++; \
    vxI1 = spu_madd(*vop1, *vxJ, vxI1); vop1++; \
    vxI2 = spu_madd(*vop2, *vxJ, vxI2); vop2++; \
    vxI3 = spu_madd(*vop3, *vxJ, vxI3); vop3++; \
    vxI4 = spu_madd(*vop4, *vxJ, vxI4); vop4++; \
    vxI5 = spu_madd(*vop5, *vxJ, vxI5); vop5++; \
    vxI6 = spu_madd(*vop6, *vxJ, vxI6); vop6++; \
    vxI7 = spu_madd(*vop7, *vxJ, vxI7); vop7++; \
}

void solve_kernel_32x32(float *xI, float *xJ, float *op)
{
    vector float *vxJ, *vxx0, *vxx1;
    vector float *vop0, *vop1, *vop2, *vop3, *vop4, *vop5, *vop6, *vop7;
    vector float vxI0, vxI1, vxI2, vxI3, vxI4, vxI5, vxI6, vxI7;
    vector float vt0, vt1;

    /* 0-7 */
    vxJ = (vector float *) xJ;
    vop0 = (vector float *) (op      );
    vop1 = (vector float *) (op+1*BSZ);
    vop2 = (vector float *) (op+2*BSZ);
    vop3 = (vector float *) (op+3*BSZ);
    vop4 = (vector float *) (op+4*BSZ);
    vop5 = (vector float *) (op+5*BSZ);
    vop6 = (vector float *) (op+6*BSZ);
    vop7 = (vector float *) (op+7*BSZ);

    vxI0 = spu_mul(*vop0, *vxJ); vop0++;
    vxI1 = spu_mul(*vop1, *vxJ); vop1++;
    vxI2 = spu_mul(*vop2, *vxJ); vop2++;
    vxI3 = spu_mul(*vop3, *vxJ); vop3++;
    vxI4 = spu_mul(*vop4, *vxJ); vop4++;
    vxI5 = spu_mul(*vop5, *vxJ); vop5++;
    vxI6 = spu_mul(*vop6, *vxJ); vop6++;
    vxI7 = spu_mul(*vop7, *vxJ); vop7++;

    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();

    vxJ++;
    vxI0 = spu_madd(*vop0, *vxJ, vxI0);
    vxI1 = spu_madd(*vop1, *vxJ, vxI1);
    vxI2 = spu_madd(*vop2, *vxJ, vxI2);
    vxI3 = spu_madd(*vop3, *vxJ, vxI3);
    vxI4 = spu_madd(*vop4, *vxJ, vxI4);
    vxI5 = spu_madd(*vop5, *vxJ, vxI5);
    vxI6 = spu_madd(*vop6, *vxJ, vxI6);
    vxI7 = spu_madd(*vop7, *vxJ, vxI7);

    vxx0 = (vector float *) (xI    );
    vxx1 = (vector float *) (xI + 4);
    vt0 = (vector float) { 
            spu_extract(vxI0, 0) + spu_extract(vxI0, 1) + spu_extract(vxI0, 2) + spu_extract(vxI0, 3),
            spu_extract(vxI1, 0) + spu_extract(vxI1, 1) + spu_extract(vxI1, 2) + spu_extract(vxI1, 3),
            spu_extract(vxI2, 0) + spu_extract(vxI2, 1) + spu_extract(vxI2, 2) + spu_extract(vxI2, 3),
            spu_extract(vxI3, 0) + spu_extract(vxI3, 1) + spu_extract(vxI3, 2) + spu_extract(vxI3, 3) };
    vt1 = (vector float) {
            spu_extract(vxI4, 0) + spu_extract(vxI4, 1) + spu_extract(vxI4, 2) + spu_extract(vxI4, 3),
            spu_extract(vxI5, 0) + spu_extract(vxI5, 1) + spu_extract(vxI5, 2) + spu_extract(vxI5, 3),
            spu_extract(vxI6, 0) + spu_extract(vxI6, 1) + spu_extract(vxI6, 2) + spu_extract(vxI6, 3),
            spu_extract(vxI7, 0) + spu_extract(vxI7, 1) + spu_extract(vxI7, 2) + spu_extract(vxI7, 3) };
    *vxx0 = spu_sub(*vxx0, vt0);
    *vxx1 = spu_sub(*vxx1, vt1);

    /* 8-15 */
    vxJ = (vector float *) xJ;
    vop0 = (vector float *) (op+ 8*BSZ);
    vop1 = (vector float *) (op+ 9*BSZ);
    vop2 = (vector float *) (op+10*BSZ);
    vop3 = (vector float *) (op+11*BSZ);
    vop4 = (vector float *) (op+12*BSZ);
    vop5 = (vector float *) (op+13*BSZ);
    vop6 = (vector float *) (op+14*BSZ);
    vop7 = (vector float *) (op+15*BSZ);

    vxI0 = spu_mul(*vop0, *vxJ); vop0++;
    vxI1 = spu_mul(*vop1, *vxJ); vop1++;
    vxI2 = spu_mul(*vop2, *vxJ); vop2++;
    vxI3 = spu_mul(*vop3, *vxJ); vop3++;
    vxI4 = spu_mul(*vop4, *vxJ); vop4++;
    vxI5 = spu_mul(*vop5, *vxJ); vop5++;
    vxI6 = spu_mul(*vop6, *vxJ); vop6++;
    vxI7 = spu_mul(*vop7, *vxJ); vop7++;

    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();

    vxJ++;
    vxI0 = spu_madd(*vop0, *vxJ, vxI0);
    vxI1 = spu_madd(*vop1, *vxJ, vxI1);
    vxI2 = spu_madd(*vop2, *vxJ, vxI2);
    vxI3 = spu_madd(*vop3, *vxJ, vxI3);
    vxI4 = spu_madd(*vop4, *vxJ, vxI4);
    vxI5 = spu_madd(*vop5, *vxJ, vxI5);
    vxI6 = spu_madd(*vop6, *vxJ, vxI6);
    vxI7 = spu_madd(*vop7, *vxJ, vxI7);

    vxx0 = (vector float *) (xI +  8);
    vxx1 = (vector float *) (xI + 12);
    vt0 = (vector float) { 
            spu_extract(vxI0, 0) + spu_extract(vxI0, 1) + spu_extract(vxI0, 2) + spu_extract(vxI0, 3),
            spu_extract(vxI1, 0) + spu_extract(vxI1, 1) + spu_extract(vxI1, 2) + spu_extract(vxI1, 3),
            spu_extract(vxI2, 0) + spu_extract(vxI2, 1) + spu_extract(vxI2, 2) + spu_extract(vxI2, 3),
            spu_extract(vxI3, 0) + spu_extract(vxI3, 1) + spu_extract(vxI3, 2) + spu_extract(vxI3, 3) };
    vt1 = (vector float) {
            spu_extract(vxI4, 0) + spu_extract(vxI4, 1) + spu_extract(vxI4, 2) + spu_extract(vxI4, 3),
            spu_extract(vxI5, 0) + spu_extract(vxI5, 1) + spu_extract(vxI5, 2) + spu_extract(vxI5, 3),
            spu_extract(vxI6, 0) + spu_extract(vxI6, 1) + spu_extract(vxI6, 2) + spu_extract(vxI6, 3),
            spu_extract(vxI7, 0) + spu_extract(vxI7, 1) + spu_extract(vxI7, 2) + spu_extract(vxI7, 3) };
    *vxx0 = spu_sub(*vxx0, vt0);
    *vxx1 = spu_sub(*vxx1, vt1);

    /* 16-23 */
    vxJ = (vector float *) xJ;
    vop0 = (vector float *) (op+16*BSZ);
    vop1 = (vector float *) (op+17*BSZ);
    vop2 = (vector float *) (op+18*BSZ);
    vop3 = (vector float *) (op+19*BSZ);
    vop4 = (vector float *) (op+20*BSZ);
    vop5 = (vector float *) (op+21*BSZ);
    vop6 = (vector float *) (op+22*BSZ);
    vop7 = (vector float *) (op+23*BSZ);

    vxI0 = spu_mul(*vop0, *vxJ); vop0++;
    vxI1 = spu_mul(*vop1, *vxJ); vop1++;
    vxI2 = spu_mul(*vop2, *vxJ); vop2++;
    vxI3 = spu_mul(*vop3, *vxJ); vop3++;
    vxI4 = spu_mul(*vop4, *vxJ); vop4++;
    vxI5 = spu_mul(*vop5, *vxJ); vop5++;
    vxI6 = spu_mul(*vop6, *vxJ); vop6++;
    vxI7 = spu_mul(*vop7, *vxJ); vop7++;

    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();

    vxJ++;
    vxI0 = spu_madd(*vop0, *vxJ, vxI0);
    vxI1 = spu_madd(*vop1, *vxJ, vxI1);
    vxI2 = spu_madd(*vop2, *vxJ, vxI2);
    vxI3 = spu_madd(*vop3, *vxJ, vxI3);
    vxI4 = spu_madd(*vop4, *vxJ, vxI4);
    vxI5 = spu_madd(*vop5, *vxJ, vxI5);
    vxI6 = spu_madd(*vop6, *vxJ, vxI6);
    vxI7 = spu_madd(*vop7, *vxJ, vxI7);

    vxx0 = (vector float *) (xI + 16);
    vxx1 = (vector float *) (xI + 20);
    vt0 = (vector float) { 
            spu_extract(vxI0, 0) + spu_extract(vxI0, 1) + spu_extract(vxI0, 2) + spu_extract(vxI0, 3),
            spu_extract(vxI1, 0) + spu_extract(vxI1, 1) + spu_extract(vxI1, 2) + spu_extract(vxI1, 3),
            spu_extract(vxI2, 0) + spu_extract(vxI2, 1) + spu_extract(vxI2, 2) + spu_extract(vxI2, 3),
            spu_extract(vxI3, 0) + spu_extract(vxI3, 1) + spu_extract(vxI3, 2) + spu_extract(vxI3, 3) };
    vt1 = (vector float) {
            spu_extract(vxI4, 0) + spu_extract(vxI4, 1) + spu_extract(vxI4, 2) + spu_extract(vxI4, 3),
            spu_extract(vxI5, 0) + spu_extract(vxI5, 1) + spu_extract(vxI5, 2) + spu_extract(vxI5, 3),
            spu_extract(vxI6, 0) + spu_extract(vxI6, 1) + spu_extract(vxI6, 2) + spu_extract(vxI6, 3),
            spu_extract(vxI7, 0) + spu_extract(vxI7, 1) + spu_extract(vxI7, 2) + spu_extract(vxI7, 3) };
    *vxx0 = spu_sub(*vxx0, vt0);
    *vxx1 = spu_sub(*vxx1, vt1);

    /* 24-31 */
    vxJ = (vector float *) xJ;
    vop0 = (vector float *) (op+24*BSZ);
    vop1 = (vector float *) (op+25*BSZ);
    vop2 = (vector float *) (op+26*BSZ);
    vop3 = (vector float *) (op+27*BSZ);
    vop4 = (vector float *) (op+28*BSZ);
    vop5 = (vector float *) (op+29*BSZ);
    vop6 = (vector float *) (op+30*BSZ);
    vop7 = (vector float *) (op+31*BSZ);

    vxI0 = spu_mul(*vop0, *vxJ); vop0++;
    vxI1 = spu_mul(*vop1, *vxJ); vop1++;
    vxI2 = spu_mul(*vop2, *vxJ); vop2++;
    vxI3 = spu_mul(*vop3, *vxJ); vop3++;
    vxI4 = spu_mul(*vop4, *vxJ); vop4++;
    vxI5 = spu_mul(*vop5, *vxJ); vop5++;
    vxI6 = spu_mul(*vop6, *vxJ); vop6++;
    vxI7 = spu_mul(*vop7, *vxJ); vop7++;

    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();
    vxI_8rows_spu_madd();

    vxJ++;
    vxI0 = spu_madd(*vop0, *vxJ, vxI0);
    vxI1 = spu_madd(*vop1, *vxJ, vxI1);
    vxI2 = spu_madd(*vop2, *vxJ, vxI2);
    vxI3 = spu_madd(*vop3, *vxJ, vxI3);
    vxI4 = spu_madd(*vop4, *vxJ, vxI4);
    vxI5 = spu_madd(*vop5, *vxJ, vxI5);
    vxI6 = spu_madd(*vop6, *vxJ, vxI6);
    vxI7 = spu_madd(*vop7, *vxJ, vxI7);

    vxx0 = (vector float *) (xI + 24);
    vxx1 = (vector float *) (xI + 28);
    vt0 = (vector float) { 
            spu_extract(vxI0, 0) + spu_extract(vxI0, 1) + spu_extract(vxI0, 2) + spu_extract(vxI0, 3),
            spu_extract(vxI1, 0) + spu_extract(vxI1, 1) + spu_extract(vxI1, 2) + spu_extract(vxI1, 3),
            spu_extract(vxI2, 0) + spu_extract(vxI2, 1) + spu_extract(vxI2, 2) + spu_extract(vxI2, 3),
            spu_extract(vxI3, 0) + spu_extract(vxI3, 1) + spu_extract(vxI3, 2) + spu_extract(vxI3, 3) };
    vt1 = (vector float) {
            spu_extract(vxI4, 0) + spu_extract(vxI4, 1) + spu_extract(vxI4, 2) + spu_extract(vxI4, 3),
            spu_extract(vxI5, 0) + spu_extract(vxI5, 1) + spu_extract(vxI5, 2) + spu_extract(vxI5, 3),
            spu_extract(vxI6, 0) + spu_extract(vxI6, 1) + spu_extract(vxI6, 2) + spu_extract(vxI6, 3),
            spu_extract(vxI7, 0) + spu_extract(vxI7, 1) + spu_extract(vxI7, 2) + spu_extract(vxI7, 3) };
    *vxx0 = spu_sub(*vxx0, vt0);
    *vxx1 = spu_sub(*vxx1, vt1);
}

void forward_substitution_32x32(float *x, float *op)
{
    float xi0a, xi1a, xi2a, xi3a, xi4a, xi5a, xi6a, xi7a;
    float xi0b, xi1b, xi2b, xi3b, xi4b, xi5b, xi6b, xi7b;
    float *pop1, *pop2, *pop3, *pop4, *pop5, *pop6, *pop7;
    vector float *vx_c0, *vx_c1, *vx_c2, *vx_c3, *vx_c4, *vx_c5, *vx_c6;
    vector float *vop0, *vop1, *vop2, *vop3, *vop4, *vop5, *vop6, *vop7;
    vector float vxi0, vxi1, vxi2, vxi3, vxi4, vxi5, vxi6, vxi7;

    /* 0-7 */
    pop1 = (op +    BSZ);
    pop2 = (op +  2*BSZ);
    pop3 = (op +  3*BSZ);
    pop4 = (op +  4*BSZ);
    pop5 = (op +  5*BSZ);
    pop6 = (op +  6*BSZ);
    pop7 = (op +  7*BSZ);
    xi0a = *x;
    xi1a = *(x +  1);
    xi2a = *(x +  2);
    xi3a = *(x +  3);
    xi4a = *(x +  4);
    xi5a = *(x +  5);
    xi6a = *(x +  6);
    xi7a = *(x +  7);
    xi1a -= *pop1 * xi0a;
    xi2a -= *pop2 * xi0a; pop2++;
    xi3a -= *pop3 * xi0a; pop3++;
    xi4a -= *pop4 * xi0a; pop4++;
    xi5a -= *pop5 * xi0a; pop5++;
    xi6a -= *pop6 * xi0a; pop6++;
    xi7a -= *pop7 * xi0a; pop7++;
    xi2a -= *pop2 * xi1a;
    xi3a -= *pop3 * xi1a; pop3++;
    xi4a -= *pop4 * xi1a; pop4++;
    xi5a -= *pop5 * xi1a; pop5++;
    xi6a -= *pop6 * xi1a; pop6++;
    xi7a -= *pop7 * xi1a; pop7++;
    vx_c0 = (vector float *) x;
    xi3a -= *pop3 * xi2a;
    xi4a -= *pop4 * xi2a; pop4++;
    xi5a -= *pop5 * xi2a; pop5++;
    xi6a -= *pop6 * xi2a; pop6++;
    xi7a -= *pop7 * xi2a; pop7++;
    vx_c1 = (vector float *) (x +  4);
    xi4a -= *pop4 * xi3a; 
    xi5a -= *pop5 * xi3a; pop5++;
    xi6a -= *pop6 * xi3a; pop6++;
    xi7a -= *pop7 * xi3a; pop7++;
    *vx_c0 = (vector float) { xi0a, xi1a, xi2a, xi3a };
    xi5a -= *pop5 * xi4a;
    xi6a -= *pop6 * xi4a; pop6++;
    xi7a -= *pop7 * xi4a; pop7++;
    xi6a -= *pop6 * xi5a; 
    xi7a -= *pop7 * xi5a; pop7++;
    xi7a -= *pop7 * xi6a; 

    /* 8-15 */
    vop0 = (vector float *) (op +  8*BSZ);
    vop1 = (vector float *) (op +  9*BSZ);
    vop2 = (vector float *) (op + 10*BSZ);
    vop3 = (vector float *) (op + 11*BSZ);
    vop4 = (vector float *) (op + 12*BSZ);
    vop5 = (vector float *) (op + 13*BSZ);
    vop6 = (vector float *) (op + 14*BSZ);
    vop7 = (vector float *) (op + 15*BSZ);
    *vx_c1 = (vector float) { xi4a, xi5a, xi6a, xi7a };
    xi0b = *(x +  8);
    xi1b = *(x +  9);
    xi2b = *(x + 10);
    xi3b = *(x + 11);
    xi4b = *(x + 12);
    xi5b = *(x + 13);
    xi6b = *(x + 14);
    xi7b = *(x + 15);
    vxi0 = spu_mul(*vop0, *vx_c0); vop0++;
    vxi1 = spu_mul(*vop1, *vx_c0); vop1++;
    vxi2 = spu_mul(*vop2, *vx_c0); vop2++;
    vxi3 = spu_mul(*vop3, *vx_c0); vop3++;
    vxi4 = spu_mul(*vop4, *vx_c0); vop4++;
    vxi5 = spu_mul(*vop5, *vx_c0); vop5++;
    vxi6 = spu_mul(*vop6, *vx_c0); vop6++;
    vxi7 = spu_mul(*vop7, *vx_c0); vop7++;
    vxi0 = spu_madd(*vop0, *vx_c1, vxi0); 
    vxi1 = spu_madd(*vop1, *vx_c1, vxi1); pop1 = (op +  9*BSZ+ 8);
    vxi2 = spu_madd(*vop2, *vx_c1, vxi2); pop2 = (op + 10*BSZ+ 8); 
    vxi3 = spu_madd(*vop3, *vx_c1, vxi3); pop3 = (op + 11*BSZ+ 8);
    vxi4 = spu_madd(*vop4, *vx_c1, vxi4); vop4++;
    vxi5 = spu_madd(*vop5, *vx_c1, vxi5); vop5++;
    vxi6 = spu_madd(*vop6, *vx_c1, vxi6); vop6++;
    vxi7 = spu_madd(*vop7, *vx_c1, vxi7); vop7++;
    xi0b -= (double)spu_extract(vxi0, 0) + spu_extract(vxi0, 1) + spu_extract(vxi0, 2) + spu_extract(vxi0, 3);
    xi1b -= (double)spu_extract(vxi1, 0) + spu_extract(vxi1, 1) + spu_extract(vxi1, 2) + spu_extract(vxi1, 3);
    xi2b -= (double)spu_extract(vxi2, 0) + spu_extract(vxi2, 1) + spu_extract(vxi2, 2) + spu_extract(vxi2, 3);
    xi3b -= (double)spu_extract(vxi3, 0) + spu_extract(vxi3, 1) + spu_extract(vxi3, 2) + spu_extract(vxi3, 3);
    vx_c2 = (vector float *) (x + 8);
    xi1b -= *pop1 * xi0b;
    xi2b -= *pop2 * xi0b; pop2++;
    xi3b -= *pop3 * xi0b; pop3++;
    xi2b -= *pop2 * xi1b;
    xi3b -= *pop3 * xi1b; pop3++;
    xi3b -= *pop3 * xi2b;
    *vx_c2 = (vector float) { xi0b, xi1b, xi2b, xi3b };
    vxi4 = spu_madd(*vop4, *vx_c2, vxi4);
    vxi5 = spu_madd(*vop5, *vx_c2, vxi5); pop5 = (op + 13*BSZ+12);
    vxi6 = spu_madd(*vop6, *vx_c2, vxi6); pop6 = (op + 14*BSZ+12);
    vxi7 = spu_madd(*vop7, *vx_c2, vxi7); pop7 = (op + 15*BSZ+12);
    xi4b -= (double)spu_extract(vxi4, 0) + spu_extract(vxi4, 1) + spu_extract(vxi4, 2) + spu_extract(vxi4, 3);
    xi5b -= (double)spu_extract(vxi5, 0) + spu_extract(vxi5, 1) + spu_extract(vxi5, 2) + spu_extract(vxi5, 3);
    xi6b -= (double)spu_extract(vxi6, 0) + spu_extract(vxi6, 1) + spu_extract(vxi6, 2) + spu_extract(vxi6, 3);
    xi7b -= (double)spu_extract(vxi7, 0) + spu_extract(vxi7, 1) + spu_extract(vxi7, 2) + spu_extract(vxi7, 3);
    vx_c3 = (vector float *) (x + 12);
    xi5b -= *pop5 * xi4b;
    xi6b -= *pop6 * xi4b; pop6++;
    xi7b -= *pop7 * xi4b; pop7++;
    xi6b -= *pop6 * xi5b;
    xi7b -= *pop7 * xi5b; pop7++;
    xi7b -= *pop7 * xi6b;

    /* 16-13 */
    vop0 = (vector float *) (op + 16*BSZ);
    vop1 = (vector float *) (op + 17*BSZ);
    vop2 = (vector float *) (op + 18*BSZ);
    vop3 = (vector float *) (op + 19*BSZ);
    vop4 = (vector float *) (op + 20*BSZ);
    vop5 = (vector float *) (op + 21*BSZ);
    vop6 = (vector float *) (op + 22*BSZ);
    vop7 = (vector float *) (op + 23*BSZ);
    *vx_c3 = (vector float) { xi4b, xi5b, xi6b, xi7b };
    xi0a = *(x + 16);
    xi1a = *(x + 17);
    xi2a = *(x + 18);
    xi3a = *(x + 19);
    xi4a = *(x + 20);
    xi5a = *(x + 21);
    xi6a = *(x + 22);
    xi7a = *(x + 23);
    vxi0 = spu_mul(*vop0, *vx_c0); vop0++;
    vxi1 = spu_mul(*vop1, *vx_c0); vop1++;
    vxi2 = spu_mul(*vop2, *vx_c0); vop2++;
    vxi3 = spu_mul(*vop3, *vx_c0); vop3++;
    vxi4 = spu_mul(*vop4, *vx_c0); vop4++;
    vxi5 = spu_mul(*vop5, *vx_c0); vop5++;
    vxi6 = spu_mul(*vop6, *vx_c0); vop6++;
    vxi7 = spu_mul(*vop7, *vx_c0); vop7++;
    vxi0 = spu_madd(*vop0, *vx_c1, vxi0); vop0++;
    vxi1 = spu_madd(*vop1, *vx_c1, vxi1); vop1++;
    vxi2 = spu_madd(*vop2, *vx_c1, vxi2); vop2++;
    vxi3 = spu_madd(*vop3, *vx_c1, vxi3); vop3++;
    vxi4 = spu_madd(*vop4, *vx_c1, vxi4); vop4++;
    vxi5 = spu_madd(*vop5, *vx_c1, vxi5); vop5++;
    vxi6 = spu_madd(*vop6, *vx_c1, vxi6); vop6++;
    vxi7 = spu_madd(*vop7, *vx_c1, vxi7); vop7++;
    vxi0 = spu_madd(*vop0, *vx_c2, vxi0); vop0++;
    vxi1 = spu_madd(*vop1, *vx_c2, vxi1); vop1++;
    vxi2 = spu_madd(*vop2, *vx_c2, vxi2); vop2++;
    vxi3 = spu_madd(*vop3, *vx_c2, vxi3); vop3++;
    vxi4 = spu_madd(*vop4, *vx_c2, vxi4); vop4++;
    vxi5 = spu_madd(*vop5, *vx_c2, vxi5); vop5++;
    vxi6 = spu_madd(*vop6, *vx_c2, vxi6); vop6++;
    vxi7 = spu_madd(*vop7, *vx_c2, vxi7); vop7++;
    vxi0 = spu_madd(*vop0, *vx_c3, vxi0);
    vxi1 = spu_madd(*vop1, *vx_c3, vxi1); pop1 = (op + 17*BSZ+16);
    vxi2 = spu_madd(*vop2, *vx_c3, vxi2); pop2 = (op + 18*BSZ+16);
    vxi3 = spu_madd(*vop3, *vx_c3, vxi3); pop3 = (op + 19*BSZ+16);
    vxi4 = spu_madd(*vop4, *vx_c3, vxi4); vop4++;
    vxi5 = spu_madd(*vop5, *vx_c3, vxi5); vop5++;
    vxi6 = spu_madd(*vop6, *vx_c3, vxi6); vop6++;
    vxi7 = spu_madd(*vop7, *vx_c3, vxi7); vop7++;
    xi0a -= (double)spu_extract(vxi0, 0) + spu_extract(vxi0, 1) + spu_extract(vxi0, 2) + spu_extract(vxi0, 3);
    xi1a -= (double)spu_extract(vxi1, 0) + spu_extract(vxi1, 1) + spu_extract(vxi1, 2) + spu_extract(vxi1, 3);
    xi2a -= (double)spu_extract(vxi2, 0) + spu_extract(vxi2, 1) + spu_extract(vxi2, 2) + spu_extract(vxi2, 3);
    xi3a -= (double)spu_extract(vxi3, 0) + spu_extract(vxi3, 1) + spu_extract(vxi3, 2) + spu_extract(vxi3, 3);
    vx_c4 = (vector float *) (x + 16);
    xi1a -= *pop1 * xi0a;
    xi2a -= *pop2 * xi0a; pop2++;
    xi3a -= *pop3 * xi0a; pop3++;
    xi2a -= *pop2 * xi1a;
    xi3a -= *pop3 * xi1a; pop3++;
    xi3a -= *pop3 * xi2a;
    *vx_c4 = (vector float) { xi0a, xi1a, xi2a, xi3a };
    vxi4 = spu_madd(*vop4, *vx_c4, vxi4);
    vxi5 = spu_madd(*vop5, *vx_c4, vxi5); pop5 = (op + 21*BSZ+20);
    vxi6 = spu_madd(*vop6, *vx_c4, vxi6); pop6 = (op + 22*BSZ+20);
    vxi7 = spu_madd(*vop7, *vx_c4, vxi7); pop7 = (op + 23*BSZ+20);
    xi4a -= (double)spu_extract(vxi4, 0) + spu_extract(vxi4, 1) + spu_extract(vxi4, 2) + spu_extract(vxi4, 3);
    xi5a -= (double)spu_extract(vxi5, 0) + spu_extract(vxi5, 1) + spu_extract(vxi5, 2) + spu_extract(vxi5, 3);
    xi6a -= (double)spu_extract(vxi6, 0) + spu_extract(vxi6, 1) + spu_extract(vxi6, 2) + spu_extract(vxi6, 3);
    xi7a -= (double)spu_extract(vxi7, 0) + spu_extract(vxi7, 1) + spu_extract(vxi7, 2) + spu_extract(vxi7, 3);
    vx_c5 = (vector float *) (x + 20);
    xi5a -= *pop5 * xi4a;
    xi6a -= *pop6 * xi4a; pop6++;
    xi7a -= *pop7 * xi4a; pop7++;
    xi6a -= *pop6 * xi5a;
    xi7a -= *pop7 * xi5a; pop7++;
    xi7a -= *pop7 * xi6a;
    *vx_c5 = (vector float) { xi4a, xi5a, xi6a, xi7a };

    /* 24-31 */
    vop0 = (vector float *) (op + 24*BSZ);
    vop1 = (vector float *) (op + 25*BSZ);
    vop2 = (vector float *) (op + 26*BSZ);
    vop3 = (vector float *) (op + 27*BSZ);
    vop4 = (vector float *) (op + 28*BSZ);
    vop5 = (vector float *) (op + 29*BSZ);
    vop6 = (vector float *) (op + 30*BSZ);
    vop7 = (vector float *) (op + 31*BSZ);
    xi0a = *(x + 24);
    xi1a = *(x + 25);
    xi2a = *(x + 26);
    xi3a = *(x + 27);
    xi4a = *(x + 28);
    xi5a = *(x + 29);
    xi6a = *(x + 30);
    xi7a = *(x + 31);
    vxi0 = spu_mul(*vop0, *vx_c0); vop0++;
    vxi1 = spu_mul(*vop1, *vx_c0); vop1++;
    vxi2 = spu_mul(*vop2, *vx_c0); vop2++;
    vxi3 = spu_mul(*vop3, *vx_c0); vop3++;
    vxi4 = spu_mul(*vop4, *vx_c0); vop4++;
    vxi5 = spu_mul(*vop5, *vx_c0); vop5++;
    vxi6 = spu_mul(*vop6, *vx_c0); vop6++;
    vxi7 = spu_mul(*vop7, *vx_c0); vop7++;
    vxi0 = spu_madd(*vop0, *vx_c1, vxi0); vop0++;
    vxi1 = spu_madd(*vop1, *vx_c1, vxi1); vop1++;
    vxi2 = spu_madd(*vop2, *vx_c1, vxi2); vop2++;
    vxi3 = spu_madd(*vop3, *vx_c1, vxi3); vop3++;
    vxi4 = spu_madd(*vop4, *vx_c1, vxi4); vop4++;
    vxi5 = spu_madd(*vop5, *vx_c1, vxi5); vop5++;
    vxi6 = spu_madd(*vop6, *vx_c1, vxi6); vop6++;
    vxi7 = spu_madd(*vop7, *vx_c1, vxi7); vop7++;
    vxi0 = spu_madd(*vop0, *vx_c2, vxi0); vop0++;
    vxi1 = spu_madd(*vop1, *vx_c2, vxi1); vop1++;
    vxi2 = spu_madd(*vop2, *vx_c2, vxi2); vop2++;
    vxi3 = spu_madd(*vop3, *vx_c2, vxi3); vop3++;
    vxi4 = spu_madd(*vop4, *vx_c2, vxi4); vop4++;
    vxi5 = spu_madd(*vop5, *vx_c2, vxi5); vop5++;
    vxi6 = spu_madd(*vop6, *vx_c2, vxi6); vop6++;
    vxi7 = spu_madd(*vop7, *vx_c2, vxi7); vop7++;
    vxi0 = spu_madd(*vop0, *vx_c3, vxi0); vop0++;
    vxi1 = spu_madd(*vop1, *vx_c3, vxi1); vop1++;
    vxi2 = spu_madd(*vop2, *vx_c3, vxi2); vop2++;
    vxi3 = spu_madd(*vop3, *vx_c3, vxi3); vop3++;
    vxi4 = spu_madd(*vop4, *vx_c3, vxi4); vop4++;
    vxi5 = spu_madd(*vop5, *vx_c3, vxi5); vop5++;
    vxi6 = spu_madd(*vop6, *vx_c3, vxi6); vop6++;
    vxi7 = spu_madd(*vop7, *vx_c3, vxi7); vop7++;
    vxi0 = spu_madd(*vop0, *vx_c4, vxi0); vop0++;
    vxi1 = spu_madd(*vop1, *vx_c4, vxi1); vop1++;
    vxi2 = spu_madd(*vop2, *vx_c4, vxi2); vop2++;
    vxi3 = spu_madd(*vop3, *vx_c4, vxi3); vop3++;
    vxi4 = spu_madd(*vop4, *vx_c4, vxi4); vop4++;
    vxi5 = spu_madd(*vop5, *vx_c4, vxi5); vop5++;
    vxi6 = spu_madd(*vop6, *vx_c4, vxi6); vop6++;
    vxi7 = spu_madd(*vop7, *vx_c4, vxi7); vop7++;
    vxi0 = spu_madd(*vop0, *vx_c5, vxi0);
    vxi1 = spu_madd(*vop1, *vx_c5, vxi1); pop1 = (op + 25*BSZ+24);
    vxi2 = spu_madd(*vop2, *vx_c5, vxi2); pop2 = (op + 26*BSZ+24);
    vxi3 = spu_madd(*vop3, *vx_c5, vxi3); pop3 = (op + 27*BSZ+24);
    vxi4 = spu_madd(*vop4, *vx_c5, vxi4); vop4++;
    vxi5 = spu_madd(*vop5, *vx_c5, vxi5); vop5++;
    vxi6 = spu_madd(*vop6, *vx_c5, vxi6); vop6++;
    vxi7 = spu_madd(*vop7, *vx_c5, vxi7); vop7++;
    xi0a -= (double)spu_extract(vxi0, 0) + spu_extract(vxi0, 1) + spu_extract(vxi0, 2) + spu_extract(vxi0, 3);
    xi1a -= (double)spu_extract(vxi1, 0) + spu_extract(vxi1, 1) + spu_extract(vxi1, 2) + spu_extract(vxi1, 3);
    xi2a -= (double)spu_extract(vxi2, 0) + spu_extract(vxi2, 1) + spu_extract(vxi2, 2) + spu_extract(vxi2, 3);
    xi3a -= (double)spu_extract(vxi3, 0) + spu_extract(vxi3, 1) + spu_extract(vxi3, 2) + spu_extract(vxi3, 3);
    vx_c6 = (vector float *) (x + 24);
    xi1a -= *pop1 * xi0a;
    xi2a -= *pop2 * xi0a; pop2++;
    xi3a -= *pop3 * xi0a; pop3++;
    xi2a -= *pop2 * xi1a;
    xi3a -= *pop3 * xi1a; pop3++;
    xi3a -= *pop3 * xi2a; 
    *vx_c6 = (vector float) { xi0a, xi1a, xi2a, xi3a };
    vxi4 = spu_madd(*vop4, *vx_c6, vxi4);
    vxi5 = spu_madd(*vop5, *vx_c6, vxi5); pop5 = (op + 29*BSZ+28);
    vxi6 = spu_madd(*vop6, *vx_c6, vxi6); pop6 = (op + 30*BSZ+28);
    vxi7 = spu_madd(*vop7, *vx_c6, vxi7); pop7 = (op + 31*BSZ+28);
    xi4a -= (double)spu_extract(vxi4, 0) + spu_extract(vxi4, 1) + spu_extract(vxi4, 2) + spu_extract(vxi4, 3);
    xi5a -= (double)spu_extract(vxi5, 0) + spu_extract(vxi5, 1) + spu_extract(vxi5, 2) + spu_extract(vxi5, 3);
    xi6a -= (double)spu_extract(vxi6, 0) + spu_extract(vxi6, 1) + spu_extract(vxi6, 2) + spu_extract(vxi6, 3);
    xi7a -= (double)spu_extract(vxi7, 0) + spu_extract(vxi7, 1) + spu_extract(vxi7, 2) + spu_extract(vxi7, 3);
    xi5a -= *pop5 * xi4a;
    xi6a -= *pop6 * xi4a; pop6++;
    xi7a -= *pop7 * xi4a; pop7++;
    xi6a -= *pop6 * xi5a;
    xi7a -= *pop7 * xi5a; pop7++;
    xi7a -= *pop7 * xi6a;
    *((vector float *)(x+28)) = (vector float) { xi4a, xi5a, xi6a, xi7a };
}

void backward_substitution_32x32(float *x, float *op)
{
    float xi0a, xi1a, xi2a, xi3a, xi4a, xi5a, xi6a, xi7a;
    float xi0b, xi1b, xi2b, xi3b, xi4b, xi5b, xi6b, xi7b;
    float *pop0, *pop1, *pop2, *pop3, *pop4, *pop5, *pop6, *pop7;
    vector float *vx_c0, *vx_c1, *vx_c2, *vx_c3, *vx_c4, *vx_c5, *vx_c6;
    vector float *vop0, *vop1, *vop2, *vop3, *vop4, *vop5, *vop6, *vop7;
    vector float vxi0, vxi1, vxi2, vxi3, vxi4, vxi5, vxi6, vxi7;

    /* 31-24 */
    pop0 = (op + 31*BSZ+31);
    pop1 = (op + 30*BSZ+31);
    pop2 = (op + 29*BSZ+31);
    pop3 = (op + 28*BSZ+31);
    pop4 = (op + 27*BSZ+31);
    pop5 = (op + 26*BSZ+31);
    pop6 = (op + 25*BSZ+31);
    pop7 = (op + 24*BSZ+31);
    xi0a = *(x + 31);
    xi1a = *(x + 30);
    xi2a = *(x + 29);
    xi3a = *(x + 28);
    xi4a = *(x + 27);
    xi5a = *(x + 26);
    xi6a = *(x + 25);
    xi7a = *(x + 24);
    xi0a /= *pop0;
    xi1a -= *pop1 * xi0a; pop1--;
    xi2a -= *pop2 * xi0a; pop2--;
    xi3a -= *pop3 * xi0a; pop3--;
    xi4a -= *pop4 * xi0a; pop4--;
    xi5a -= *pop5 * xi0a; pop5--;
    xi6a -= *pop6 * xi0a; pop6--;
    xi7a -= *pop7 * xi0a; pop7--;
    xi1a /= *pop1;
    xi2a -= *pop2 * xi1a; pop2--;
    xi3a -= *pop3 * xi1a; pop3--;
    xi4a -= *pop4 * xi1a; pop4--;
    xi5a -= *pop5 * xi1a; pop5--;
    xi6a -= *pop6 * xi1a; pop6--;
    xi7a -= *pop7 * xi1a; pop7--;
    vx_c0 = (vector float *) (x + 28);
    xi2a /= *pop2;
    xi3a -= *pop3 * xi2a; pop3--;
    xi4a -= *pop4 * xi2a; pop4--;
    xi5a -= *pop5 * xi2a; pop5--;
    xi6a -= *pop6 * xi2a; pop6--;
    xi7a -= *pop7 * xi2a; pop7--;
    xi3a /= *pop3;
    xi4a -= *pop4 * xi3a; pop4--;
    xi5a -= *pop5 * xi3a; pop5--;
    xi6a -= *pop6 * xi3a; pop6--;
    xi7a -= *pop7 * xi3a; pop7--;
    *vx_c0 = (vector float) { xi3a, xi2a, xi1a, xi0a };
    xi4a /= *pop4;
    xi5a -= *pop5 * xi4a; pop5--;
    xi6a -= *pop6 * xi4a; pop6--;
    xi7a -= *pop7 * xi4a; pop7--;
    xi5a /= *pop5;
    xi6a -= *pop6 * xi5a; pop6--;
    xi7a -= *pop7 * xi5a; pop7--;
    vx_c1 = (vector float *) (x + 24);
    xi6a /= *pop6;
    xi7a -= *pop7 * xi6a; pop7--;
    xi7a /= *pop7;
    *vx_c1 = (vector float) { xi7a, xi6a, xi5a, xi4a };

    /* 23-16 */        
    vop0 = (vector float *) (op + 23*BSZ+28); 
    vop1 = (vector float *) (op + 22*BSZ+28); 
    vop2 = (vector float *) (op + 21*BSZ+28); 
    vop3 = (vector float *) (op + 20*BSZ+28); 
    vop4 = (vector float *) (op + 19*BSZ+28); 
    vop5 = (vector float *) (op + 18*BSZ+28); 
    vop6 = (vector float *) (op + 17*BSZ+28); 
    vop7 = (vector float *) (op + 16*BSZ+28); 
    xi0b = *(x + 23);
    xi1b = *(x + 22);
    xi2b = *(x + 21);
    xi3b = *(x + 20);
    xi4b = *(x + 19);
    xi5b = *(x + 18);
    xi6b = *(x + 17);
    xi7b = *(x + 16);
    vxi0 = spu_mul(*vop0, *vx_c0); vop0--;
    vxi1 = spu_mul(*vop1, *vx_c0); vop1--;
    vxi2 = spu_mul(*vop2, *vx_c0); vop2--;
    vxi3 = spu_mul(*vop3, *vx_c0); vop3--;
    vxi4 = spu_mul(*vop4, *vx_c0); vop4--;
    vxi5 = spu_mul(*vop5, *vx_c0); vop5--;
    vxi6 = spu_mul(*vop6, *vx_c0); vop6--;
    vxi7 = spu_mul(*vop7, *vx_c0); vop7--;
    vxi0 = spu_madd(*vop0, *vx_c1, vxi0); pop0 = (op + 23*BSZ+23);
    vxi1 = spu_madd(*vop1, *vx_c1, vxi1); pop1 = (op + 22*BSZ+23);
    vxi2 = spu_madd(*vop2, *vx_c1, vxi2); pop2 = (op + 21*BSZ+23);
    vxi3 = spu_madd(*vop3, *vx_c1, vxi3); pop3 = (op + 20*BSZ+23);
    vxi4 = spu_madd(*vop4, *vx_c1, vxi4); vop4--;
    vxi5 = spu_madd(*vop5, *vx_c1, vxi5); vop5--;
    vxi6 = spu_madd(*vop6, *vx_c1, vxi6); vop6--;
    vxi7 = spu_madd(*vop7, *vx_c1, vxi7); vop7--;
    xi0b -= spu_extract(vxi0, 0) + spu_extract(vxi0, 1) + spu_extract(vxi0, 2) + spu_extract(vxi0, 3);
    xi1b -= spu_extract(vxi1, 0) + spu_extract(vxi1, 1) + spu_extract(vxi1, 2) + spu_extract(vxi1, 3);
    xi2b -= spu_extract(vxi2, 0) + spu_extract(vxi2, 1) + spu_extract(vxi2, 2) + spu_extract(vxi2, 3);
    xi3b -= spu_extract(vxi3, 0) + spu_extract(vxi3, 1) + spu_extract(vxi3, 2) + spu_extract(vxi3, 3);
    xi0b /= *pop0;
    xi1b -= *pop1 * xi0b; pop1--;
    xi2b -= *pop2 * xi0b; pop2--;
    xi3b -= *pop3 * xi0b; pop3--;
    xi1b /= *pop1;
    xi2b -= *pop2 * xi1b; pop2--;
    xi3b -= *pop3 * xi1b; pop3--;
    vx_c2 = (vector float *) (x + 20);
    xi2b /= *pop2;
    xi3b -= *pop3 * xi2b; pop3--;
    xi3b /= *pop3;
    *vx_c2 = (vector float) { xi3b, xi2b, xi1b, xi0b };
    vxi4 = spu_madd(*vop4, *vx_c2, vxi4); pop4 = (op + 19*BSZ+19);
    vxi5 = spu_madd(*vop5, *vx_c2, vxi5); pop5 = (op + 18*BSZ+19);
    vxi6 = spu_madd(*vop6, *vx_c2, vxi6); pop6 = (op + 17*BSZ+19);
    vxi7 = spu_madd(*vop7, *vx_c2, vxi7); pop7 = (op + 16*BSZ+19);
    xi4b -= spu_extract(vxi4, 0) + spu_extract(vxi4, 1) + spu_extract(vxi4, 2) + spu_extract(vxi4, 3);
    xi5b -= spu_extract(vxi5, 0) + spu_extract(vxi5, 1) + spu_extract(vxi5, 2) + spu_extract(vxi5, 3);
    xi6b -= spu_extract(vxi6, 0) + spu_extract(vxi6, 1) + spu_extract(vxi6, 2) + spu_extract(vxi6, 3);
    xi7b -= spu_extract(vxi7, 0) + spu_extract(vxi7, 1) + spu_extract(vxi7, 2) + spu_extract(vxi7, 3);
    xi4b /= *pop4;
    xi5b -= *pop5 * xi4b; pop5--;
    xi6b -= *pop6 * xi4b; pop6--;
    xi7b -= *pop7 * xi4b; pop7--;
    xi5b /= *pop5;
    xi6b -= *pop6 * xi5b; pop6--;
    xi7b -= *pop7 * xi5b; pop7--;
    vx_c3 = (vector float *) (x + 16);
    xi6b /= *pop6;
    xi7b -= *pop7 * xi6b; pop7--;
    xi7b /= *pop7;
    *vx_c3 = (vector float) { xi7b, xi6b, xi5b, xi4b };
        
    /* 15-8 */
    vop0 = (vector float *) (op + 15*BSZ+28); 
    vop1 = (vector float *) (op + 14*BSZ+28); 
    vop2 = (vector float *) (op + 13*BSZ+28); 
    vop3 = (vector float *) (op + 12*BSZ+28); 
    vop4 = (vector float *) (op + 11*BSZ+28); 
    vop5 = (vector float *) (op + 10*BSZ+28); 
    vop6 = (vector float *) (op +  9*BSZ+28); 
    vop7 = (vector float *) (op +  8*BSZ+28); 
    xi0a = *(x + 15);
    xi1a = *(x + 14);
    xi2a = *(x + 13);
    xi3a = *(x + 12);
    xi4a = *(x + 11);
    xi5a = *(x + 10);
    xi6a = *(x +  9);
    xi7a = *(x +  8);
    vxi0 = spu_mul(*vop0, *vx_c0); vop0--;
    vxi1 = spu_mul(*vop1, *vx_c0); vop1--;
    vxi2 = spu_mul(*vop2, *vx_c0); vop2--;
    vxi3 = spu_mul(*vop3, *vx_c0); vop3--;
    vxi4 = spu_mul(*vop4, *vx_c0); vop4--;
    vxi5 = spu_mul(*vop5, *vx_c0); vop5--;
    vxi6 = spu_mul(*vop6, *vx_c0); vop6--;
    vxi7 = spu_mul(*vop7, *vx_c0); vop7--;
    vxi0 = spu_madd(*vop0, *vx_c1, vxi0); vop0--;
    vxi1 = spu_madd(*vop1, *vx_c1, vxi1); vop1--;
    vxi2 = spu_madd(*vop2, *vx_c1, vxi2); vop2--;
    vxi3 = spu_madd(*vop3, *vx_c1, vxi3); vop3--;
    vxi4 = spu_madd(*vop4, *vx_c1, vxi4); vop4--;
    vxi5 = spu_madd(*vop5, *vx_c1, vxi5); vop5--;
    vxi6 = spu_madd(*vop6, *vx_c1, vxi6); vop6--;
    vxi7 = spu_madd(*vop7, *vx_c1, vxi7); vop7--;
    vxi0 = spu_madd(*vop0, *vx_c2, vxi0); vop0--;
    vxi1 = spu_madd(*vop1, *vx_c2, vxi1); vop1--;
    vxi2 = spu_madd(*vop2, *vx_c2, vxi2); vop2--;
    vxi3 = spu_madd(*vop3, *vx_c2, vxi3); vop3--;
    vxi4 = spu_madd(*vop4, *vx_c2, vxi4); vop4--;
    vxi5 = spu_madd(*vop5, *vx_c2, vxi5); vop5--;
    vxi6 = spu_madd(*vop6, *vx_c2, vxi6); vop6--;
    vxi7 = spu_madd(*vop7, *vx_c2, vxi7); vop7--;
    vxi0 = spu_madd(*vop0, *vx_c3, vxi0); pop0 = (op + 15*BSZ+15);
    vxi1 = spu_madd(*vop1, *vx_c3, vxi1); pop1 = (op + 14*BSZ+15);
    vxi2 = spu_madd(*vop2, *vx_c3, vxi2); pop2 = (op + 13*BSZ+15);
    vxi3 = spu_madd(*vop3, *vx_c3, vxi3); pop3 = (op + 12*BSZ+15);
    vxi4 = spu_madd(*vop4, *vx_c3, vxi4); vop4--;
    vxi5 = spu_madd(*vop5, *vx_c3, vxi5); vop5--;
    vxi6 = spu_madd(*vop6, *vx_c3, vxi6); vop6--;
    vxi7 = spu_madd(*vop7, *vx_c3, vxi7); vop7--;
    xi0a -= spu_extract(vxi0, 0) + spu_extract(vxi0, 1) + spu_extract(vxi0, 2) + spu_extract(vxi0, 3);
    xi1a -= spu_extract(vxi1, 0) + spu_extract(vxi1, 1) + spu_extract(vxi1, 2) + spu_extract(vxi1, 3);
    xi2a -= spu_extract(vxi2, 0) + spu_extract(vxi2, 1) + spu_extract(vxi2, 2) + spu_extract(vxi2, 3);
    xi3a -= spu_extract(vxi3, 0) + spu_extract(vxi3, 1) + spu_extract(vxi3, 2) + spu_extract(vxi3, 3);
    xi0a /= *pop0;
    xi1a -= *pop1 * xi0a; pop1--;
    xi2a -= *pop2 * xi0a; pop2--;
    xi3a -= *pop3 * xi0a; pop3--;
    xi1a /= *pop1;
    xi2a -= *pop2 * xi1a; pop2--;
    xi3a -= *pop3 * xi1a; pop3--;
    vx_c4 = (vector float *) (x + 12);
    xi2a /= *pop2;
    xi3a -= *pop3 * xi2a; pop3--;
    xi3a /= *pop3;
    *vx_c4 = (vector float) { xi3a, xi2a, xi1a, xi0a };
    vxi4 = spu_madd(*vop4, *vx_c4, vxi4); pop4 = (op + 11*BSZ+11);
    vxi5 = spu_madd(*vop5, *vx_c4, vxi5); pop5 = (op + 10*BSZ+11);
    vxi6 = spu_madd(*vop6, *vx_c4, vxi6); pop6 = (op +  9*BSZ+11);
    vxi7 = spu_madd(*vop7, *vx_c4, vxi7); pop7 = (op +  8*BSZ+11);
    xi4a -= spu_extract(vxi4, 0) + spu_extract(vxi4, 1) + spu_extract(vxi4, 2) + spu_extract(vxi4, 3);
    xi5a -= spu_extract(vxi5, 0) + spu_extract(vxi5, 1) + spu_extract(vxi5, 2) + spu_extract(vxi5, 3);
    xi6a -= spu_extract(vxi6, 0) + spu_extract(vxi6, 1) + spu_extract(vxi6, 2) + spu_extract(vxi6, 3);
    xi7a -= spu_extract(vxi7, 0) + spu_extract(vxi7, 1) + spu_extract(vxi7, 2) + spu_extract(vxi7, 3);
    xi4a /= *pop4;
    xi5a -= *pop5 * xi4a; pop5--;
    xi6a -= *pop6 * xi4a; pop6--;
    xi7a -= *pop7 * xi4a; pop7--;
    xi5a /= *pop5;
    xi6a -= *pop6 * xi5a; pop6--;
    xi7a -= *pop7 * xi5a; pop7--;
    vx_c5 = (vector float *) (x +  8);
    xi6a /= *pop6;
    xi7a -= *pop7 * xi6a; pop7--;
    xi7a /= *pop7;

    /* 7-0 */
    vop0 = (vector float *) (op +  7*BSZ+28); 
    vop1 = (vector float *) (op +  6*BSZ+28); 
    vop2 = (vector float *) (op +  5*BSZ+28); 
    vop3 = (vector float *) (op +  4*BSZ+28); 
    vop4 = (vector float *) (op +  3*BSZ+28); 
    vop5 = (vector float *) (op +  2*BSZ+28); 
    vop6 = (vector float *) (op +    BSZ+28); 
    vop7 = (vector float *) (op         +28); 
    *vx_c5 = (vector float) { xi7a, xi6a, xi5a, xi4a };
    xi0a = *(x +  7);
    xi1a = *(x +  6);
    xi2a = *(x +  5);
    xi3a = *(x +  4);
    xi4a = *(x +  3);
    xi5a = *(x +  2);
    xi6a = *(x +  1);
    xi7a = *(x     );
    vxi0 = spu_mul(*vop0, *vx_c0); vop0--;
    vxi1 = spu_mul(*vop1, *vx_c0); vop1--;
    vxi2 = spu_mul(*vop2, *vx_c0); vop2--;
    vxi3 = spu_mul(*vop3, *vx_c0); vop3--;
    vxi4 = spu_mul(*vop4, *vx_c0); vop4--;
    vxi5 = spu_mul(*vop5, *vx_c0); vop5--;
    vxi6 = spu_mul(*vop6, *vx_c0); vop6--;
    vxi7 = spu_mul(*vop7, *vx_c0); vop7--;
    vxi0 = spu_madd(*vop0, *vx_c1, vxi0); vop0--;
    vxi1 = spu_madd(*vop1, *vx_c1, vxi1); vop1--;
    vxi2 = spu_madd(*vop2, *vx_c1, vxi2); vop2--;
    vxi3 = spu_madd(*vop3, *vx_c1, vxi3); vop3--;
    vxi4 = spu_madd(*vop4, *vx_c1, vxi4); vop4--;
    vxi5 = spu_madd(*vop5, *vx_c1, vxi5); vop5--;
    vxi6 = spu_madd(*vop6, *vx_c1, vxi6); vop6--;
    vxi7 = spu_madd(*vop7, *vx_c1, vxi7); vop7--;
    vxi0 = spu_madd(*vop0, *vx_c2, vxi0); vop0--;
    vxi1 = spu_madd(*vop1, *vx_c2, vxi1); vop1--;
    vxi2 = spu_madd(*vop2, *vx_c2, vxi2); vop2--;
    vxi3 = spu_madd(*vop3, *vx_c2, vxi3); vop3--;
    vxi4 = spu_madd(*vop4, *vx_c2, vxi4); vop4--;
    vxi5 = spu_madd(*vop5, *vx_c2, vxi5); vop5--;
    vxi6 = spu_madd(*vop6, *vx_c2, vxi6); vop6--;
    vxi7 = spu_madd(*vop7, *vx_c2, vxi7); vop7--;
    vxi0 = spu_madd(*vop0, *vx_c3, vxi0); vop0--;
    vxi1 = spu_madd(*vop1, *vx_c3, vxi1); vop1--;
    vxi2 = spu_madd(*vop2, *vx_c3, vxi2); vop2--;
    vxi3 = spu_madd(*vop3, *vx_c3, vxi3); vop3--;
    vxi4 = spu_madd(*vop4, *vx_c3, vxi4); vop4--;
    vxi5 = spu_madd(*vop5, *vx_c3, vxi5); vop5--;
    vxi6 = spu_madd(*vop6, *vx_c3, vxi6); vop6--;
    vxi7 = spu_madd(*vop7, *vx_c3, vxi7); vop7--;
    vxi0 = spu_madd(*vop0, *vx_c4, vxi0); vop0--;
    vxi1 = spu_madd(*vop1, *vx_c4, vxi1); vop1--;
    vxi2 = spu_madd(*vop2, *vx_c4, vxi2); vop2--;
    vxi3 = spu_madd(*vop3, *vx_c4, vxi3); vop3--;
    vxi4 = spu_madd(*vop4, *vx_c4, vxi4); vop4--;
    vxi5 = spu_madd(*vop5, *vx_c4, vxi5); vop5--;
    vxi6 = spu_madd(*vop6, *vx_c4, vxi6); vop6--;
    vxi7 = spu_madd(*vop7, *vx_c4, vxi7); vop7--;
    vxi0 = spu_madd(*vop0, *vx_c5, vxi0); pop0 = (op +  7*BSZ+ 7);
    vxi1 = spu_madd(*vop1, *vx_c5, vxi1); pop1 = (op +  6*BSZ+ 7);
    vxi2 = spu_madd(*vop2, *vx_c5, vxi2); pop2 = (op +  5*BSZ+ 7);
    vxi3 = spu_madd(*vop3, *vx_c5, vxi3); pop3 = (op +  4*BSZ+ 7);
    vxi4 = spu_madd(*vop4, *vx_c5, vxi4); vop4--;
    vxi5 = spu_madd(*vop5, *vx_c5, vxi5); vop5--;
    vxi6 = spu_madd(*vop6, *vx_c5, vxi6); vop6--;
    vxi7 = spu_madd(*vop7, *vx_c5, vxi7); vop7--;
    xi0a -= spu_extract(vxi0, 0) + spu_extract(vxi0, 1) + spu_extract(vxi0, 2) + spu_extract(vxi0, 3);
    xi1a -= spu_extract(vxi1, 0) + spu_extract(vxi1, 1) + spu_extract(vxi1, 2) + spu_extract(vxi1, 3);
    xi2a -= spu_extract(vxi2, 0) + spu_extract(vxi2, 1) + spu_extract(vxi2, 2) + spu_extract(vxi2, 3);
    xi3a -= spu_extract(vxi3, 0) + spu_extract(vxi3, 1) + spu_extract(vxi3, 2) + spu_extract(vxi3, 3);
    xi0a /= *pop0;
    xi1a -= *pop1 * xi0a; pop1--;
    xi2a -= *pop2 * xi0a; pop2--;
    xi3a -= *pop3 * xi0a; pop3--;
    xi1a /= *pop1;
    xi2a -= *pop2 * xi1a; pop2--;
    xi3a -= *pop3 * xi1a; pop3--;
    vx_c6 = (vector float *) (x +  4);
    xi2a /= *pop2;
    xi3a -= *pop3 * xi2a; pop3--;
    xi3a /= *pop3;
    *vx_c6 = (vector float) { xi3a, xi2a, xi1a, xi0a };
    vxi4 = spu_madd(*vop4, *vx_c6, vxi4); pop4 = (op +  3*BSZ+ 3);
    vxi5 = spu_madd(*vop5, *vx_c6, vxi5); pop5 = (op +  2*BSZ+ 3);
    vxi6 = spu_madd(*vop6, *vx_c6, vxi6); pop6 = (op +    BSZ+ 3);
    vxi7 = spu_madd(*vop7, *vx_c6, vxi7); pop7 = (op +       + 3);
    xi4a -= spu_extract(vxi4, 0) + spu_extract(vxi4, 1) + spu_extract(vxi4, 2) + spu_extract(vxi4, 3);
    xi5a -= spu_extract(vxi5, 0) + spu_extract(vxi5, 1) + spu_extract(vxi5, 2) + spu_extract(vxi5, 3);
    xi6a -= spu_extract(vxi6, 0) + spu_extract(vxi6, 1) + spu_extract(vxi6, 2) + spu_extract(vxi6, 3);
    xi7a -= spu_extract(vxi7, 0) + spu_extract(vxi7, 1) + spu_extract(vxi7, 2) + spu_extract(vxi7, 3);
    xi4a /= *pop4;
    xi5a -= *pop5 * xi4a; pop5--;
    xi6a -= *pop6 * xi4a; pop6--;
    xi7a -= *pop7 * xi4a; pop7--;
    xi5a /= *pop5;
    xi6a -= *pop6 * xi5a; pop6--;
    xi7a -= *pop7 * xi5a; pop7--;
    xi6a /= *pop6;
    xi7a -= *pop7 * xi6a; pop7--;
    xi7a /= *pop7;
    *((vector float *)(x)) = (vector float) { xi7a, xi6a, xi5a, xi4a }; 
}

#define xx_8rows_msub() {       \
    xx0 -= *pop0 * *px; pop0++; \
    xx1 -= *pop1 * *px; pop1++; \
    xx2 -= *pop2 * *px; pop2++; \
    xx3 -= *pop3 * *px; pop3++; \
    xx4 -= *pop4 * *px; pop4++; \
    xx5 -= *pop5 * *px; pop5++; \
    xx6 -= *pop6 * *px; pop6++; \
    xx7 -= *pop7 * *px; pop7++; \
    px++;                       \
}

void solve_nosimd_32x32(float *xI, float *xJ, float *op)
{
    int j;
    float *px; 
    float *pop0, *pop1, *pop2, *pop3, *pop4, *pop5,  *pop6, *pop7;
    float xx0, xx1, xx2, xx3, xx4, xx5, xx6, xx7;

    pop0 = op;
    pop1 = op +    BSZ;
    pop2 = op +  2*BSZ;
    pop3 = op +  3*BSZ;
    pop4 = op +  4*BSZ;
    pop5 = op +  5*BSZ;
    pop6 = op +  6*BSZ;
    pop7 = op +  7*BSZ;

    xx0 = *(xI     );
    xx1 = *(xI +  1);
    xx2 = *(xI +  2);
    xx3 = *(xI +  3);
    xx4 = *(xI +  4);
    xx5 = *(xI +  5);
    xx6 = *(xI +  6);
    xx7 = *(xI +  7);

    px = xJ;

    for (j = 0; j < BSZ; j += 8) {
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
    }

    *(xI     ) = xx0;
    *(xI +  1) = xx1;
    *(xI +  2) = xx2;
    *(xI +  3) = xx3;
    *(xI +  4) = xx4;
    *(xI +  5) = xx5;
    *(xI +  6) = xx6;
    *(xI +  7) = xx7;


    pop0 = op +  8*BSZ;
    pop1 = op +  9*BSZ;
    pop2 = op + 10*BSZ;
    pop3 = op + 11*BSZ;
    pop4 = op + 12*BSZ;
    pop5 = op + 13*BSZ;
    pop6 = op + 14*BSZ;
    pop7 = op + 15*BSZ;

    xx0 = *(xI +  8);
    xx1 = *(xI +  9);
    xx2 = *(xI + 10);
    xx3 = *(xI + 11);
    xx4 = *(xI + 12);
    xx5 = *(xI + 13);
    xx6 = *(xI + 14);
    xx7 = *(xI + 15);

    px = xJ;

    for (j = 0; j < BSZ; j += 8) {
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
    }

    *(xI +  8) = xx0;
    *(xI +  9) = xx1;
    *(xI + 10) = xx2;
    *(xI + 11) = xx3;
    *(xI + 12) = xx4;
    *(xI + 13) = xx5;
    *(xI + 14) = xx6;
    *(xI + 15) = xx7;
    

    pop0 = op + 16*BSZ;
    pop1 = op + 17*BSZ;
    pop2 = op + 18*BSZ;
    pop3 = op + 19*BSZ;
    pop4 = op + 20*BSZ;
    pop5 = op + 21*BSZ;
    pop6 = op + 22*BSZ;
    pop7 = op + 23*BSZ;

    xx0 = *(xI + 16);
    xx1 = *(xI + 17);
    xx2 = *(xI + 18);
    xx3 = *(xI + 19);
    xx4 = *(xI + 20);
    xx5 = *(xI + 21);
    xx6 = *(xI + 22);
    xx7 = *(xI + 23);

    px = xJ;

    for (j = 0; j < BSZ; j += 8) {
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
    }

    *(xI + 16) = xx0;
    *(xI + 17) = xx1;
    *(xI + 18) = xx2;
    *(xI + 19) = xx3;
    *(xI + 20) = xx4;
    *(xI + 21) = xx5;
    *(xI + 22) = xx6;
    *(xI + 23) = xx7;
    

    pop0 = op + 24*BSZ;
    pop1 = op + 25*BSZ;
    pop2 = op + 26*BSZ;
    pop3 = op + 27*BSZ;
    pop4 = op + 28*BSZ;
    pop5 = op + 29*BSZ;
    pop6 = op + 30*BSZ;
    pop7 = op + 31*BSZ;

    xx0 = *(xI + 24);
    xx1 = *(xI + 25);
    xx2 = *(xI + 26);
    xx3 = *(xI + 27);
    xx4 = *(xI + 28);
    xx5 = *(xI + 29);
    xx6 = *(xI + 30);
    xx7 = *(xI + 31);

    px = xJ;

    for (j = 0; j < BSZ; j += 8) {
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
        xx_8rows_msub();
    }

    *(xI + 24) = xx0;
    *(xI + 25) = xx1;
    *(xI + 26) = xx2;
    *(xI + 27) = xx3;
    *(xI + 28) = xx4;
    *(xI + 29) = xx5;
    *(xI + 30) = xx6;
    *(xI + 31) = xx7;
}


