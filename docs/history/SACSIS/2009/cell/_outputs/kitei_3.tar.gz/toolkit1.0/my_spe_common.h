#ifndef _MY_SPE_COMMON_H
#define _MY_SPE_COMMON_H
#include <spu_intrinsics.h>
#include <spelib.h>
//#include <spe_stdio.h>
//#include <stdio.h>
#include <stdlib.h>
#include <spu_mfcio.h>
#include <float.h>
#include <math.h>
#include "spe_util.h"

#define BSZ           32 /* block size */
#define BSZxBSZ     1024 /* BSZ*BSZ */
#define BLK_DATA_SZ 4096 /* BSZxBSZ*sizeof(float) */
#define BSZxFLOATSZ  128 /* BSZ*sizeof(float) */
#define NUM_BLOCK_BUF 34
/*----------------------------------------------------------------------*/
struct spe_sync{
    unsigned int flag;
    unsigned int start_flag;
    unsigned int end_flag;
    unsigned int addr; // address for sd
    unsigned int pivot_flag;
    unsigned int pivot_idx;
    float        pivot_max;
    unsigned int data[25];
};

typedef unsigned long long int  uint64_t;
typedef struct my_mfc_list_element {
    uint64_t notify       :  1;   /** Stall-and-notify bit  */
    uint64_t reserved     : 16;
    uint64_t size         : 15;   /** Transfer size */
    uint64_t eal          : 32;   /** Lower word of effective address */
} my_mfc_list_elem_t;

enum dma_tags { TAG0=0, TAG1=1 };
enum sync_tags { SYNC_0=4096, SYNC_1, SYNC_2, SYNC_3, SYNC_4, SYNC_5, SYNC_6,
                 SYNC_7, SYNC_8, SYNC_9, SYNC_A, SYNC_B, SYNC_C, SYNC_S };

#define DMA_WAIT(TAG_MASK) {      \
    mfc_write_tag_mask(TAG_MASK); \
    mfc_write_tag_update_all();   \
    mfc_read_tag_status();        \
}

/* SIMD functions */
vector unsigned int SIMDadd = (vector unsigned int) { 0, 64, 0, 0 };
extern void matmulsub_SIMD32(volatile float *a, volatile float *b, volatile float *c);
extern void column_update_simd32(volatile float *tb, volatile float *pivrow, int ii, int pos4);
extern void column_update_small(volatile float *tb, volatile float *pivrow, int ii, int end);
extern void forward_sub_row_32x32(float *u, float *l);
extern void solve_kernel_32x32(float *xI, float *xJ, float *op);
extern void forward_substitution_32x32(float *x, float *op);
extern void backward_substitution_32x32(float *x, float *op);
extern void solve_nosimd_32x32(float *xI, float *xJ, float *op);

extern void dmaget(void* d, unsigned long long addr, unsigned int size);
extern void dmaput(void* d, unsigned long long addr, unsigned int size);

#endif /* _MY_SPE_COMMON_H */

