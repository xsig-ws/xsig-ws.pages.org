#ifndef _MY_SPE_COMMON_H
#define _MY_SPE_COMMON_H
#include <spu_intrinsics.h>
#include <spelib.h>
#include <spe_stdio.h>
#include <stdlib.h>
#include <spu_mfcio.h>
#include <float.h>
#include <math.h>
#include "spe_util.h"

#define BSZ           32 /* block size */
#define BSZxBSZ     1024 /* BSZ*BSZ */
#define BSZxFLOATSZ  128 /* BSZ*sizeof(float) */
#define NUM_BLOCK_BUF 25
/*----------------------------------------------------------------------*/
struct spe_sync{
    unsigned int flag;
    unsigned int start_flag;
    unsigned int end_flag;
    unsigned int addr; // address for sd
    unsigned int pivot_flag;
    unsigned int pivot_idx;
    float        pivot_max;
    unsigned int data[25];
};

typedef unsigned long long int  uint64_t;
typedef struct my_mfc_list_element {
    uint64_t notify       :  1;   /** Stall-and-notify bit  */
    uint64_t reserved     : 16;
    uint64_t size         : 15;   /** Transfer size */
    uint64_t eal          : 32;   /** Lower word of effective address */
} my_mfc_list_elem_t;

enum tags { TAG0=0, TAG1=1 };
enum sync_tags { SYNC_0=4096, SYNC_1, SYNC_2, SYNC_3, SYNC_4, SYNC_5,
                 SYNC_6, SYNC_7, SYNC_8, SYNC_9, SYNC_A, SYNC_B, SYNC_C };

void disp_matrix(int n, int m, volatile float *a)
{
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            spe_printf("%7.3f ", a[i*n+j]);
        }
        spe_printf("\n");
    }
}

#define DMA_WAIT(TAG_MASK) {      \
    mfc_write_tag_mask(TAG_MASK); \
    mfc_write_tag_update_all();   \
    mfc_read_tag_status();        \
}

#endif /* _MY_SPE_COMMON_H */

