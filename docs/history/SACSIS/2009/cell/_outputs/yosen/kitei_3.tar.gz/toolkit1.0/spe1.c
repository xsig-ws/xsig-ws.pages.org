/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008                                            */
/*----------------------------------------------------------------------*/
#include "define.h"
#include "my_spe_common.h"

int n, m, N;
unsigned int ppe_ls[NUMBER_OF_SPES];
volatile static struct spe_sync sd[NUMBER_OF_SPES] _GALIGN;

volatile static float dat[NUM_BLOCK_BUF*BSZxBSZ] _GALIGN;
volatile static float *tb[NUM_BLOCK_BUF] = { 
    dat,            dat+   BSZxBSZ, dat+ 2*BSZxBSZ, dat+ 3*BSZxBSZ, dat+ 4*BSZxBSZ, 
    dat+ 5*BSZxBSZ, dat+ 6*BSZxBSZ, dat+ 7*BSZxBSZ, dat+ 8*BSZxBSZ, dat+ 9*BSZxBSZ,
    dat+10*BSZxBSZ, dat+11*BSZxBSZ, dat+12*BSZxBSZ, dat+13*BSZxBSZ, dat+14*BSZxBSZ,
    dat+15*BSZxBSZ, dat+16*BSZxBSZ, dat+17*BSZxBSZ, dat+18*BSZxBSZ, dat+19*BSZxBSZ,
    dat+20*BSZxBSZ, dat+21*BSZxBSZ, dat+22*BSZxBSZ, dat+23*BSZxBSZ, dat+24*BSZxBSZ };
volatile static float l_inv[BSZxBSZ] _GALIGN;
volatile float *ll = dat;

/* SIMD functions */
vector unsigned int SIMDadd = (vector unsigned int) { 0, 64, 0, 0 };
extern void ld_matmul_SIMD32(volatile float *a, volatile float *b, volatile float *c);
extern void matmulsub_SIMD32(volatile float *a, volatile float *b, volatile float *c);
extern inline void column_update_simd32(volatile float *tb, volatile float *pivrow, int ii, int pos4);
extern inline void column_update_small(volatile float *tb, volatile float *pivrow, int ii, int end);
extern inline void solve_kernel_32x32(float *xI, float *xJ, float *op);
extern inline void forward_substitution_32x32(float *x, float *op);
extern inline void backward_substitution_32x32(float *x, float *op);

volatile static my_mfc_list_elem_t mfc_list[BSZ];
unsigned int onerow_sz; /* size of one row (n * sizeof(flaot) */


/*----------------------------------------------------------------------*/
extern void dmaget(void* d, unsigned long long addr, unsigned int size);
extern void dmaput(void* d, unsigned long long addr, unsigned int size);

volatile static my_mfc_list_elem_t sync_mfclist[NUMBER_OF_SPES-1];
volatile static struct spe_sync sss[NUMBER_OF_SPES-1] _GALIGN; 
#define sync_dist(key) {                                                \
    int j;                                                              \
    for(j = 1; j < NUMBER_OF_SPES; j++)                                 \
        sss[j-1].start_flag = key;                                      \
    mfc_putl((void*)sss, 0, (unsigned int)sync_mfclist,                 \
            (NUMBER_OF_SPES-1)*sizeof(my_mfc_list_elem_t), TAG0, 0, 0); \
    DMA_WAIT(1<<TAG0);                                                  \
}

#define sync_collect(key) {               \
    int j;                                \
    for(j = 1; j < NUMBER_OF_SPES; j++) { \
        while(sd[j].end_flag != key) ;    \
    }                                     \
}

#define __next__(VAR1, VAR2) { \
    v0 = spu_add(v0, vadd);    \
    v1 = spu_add(v1, vadd);    \
    vlist[VAR1] = v0;          \
    vlist[VAR2] = v1;          \
}

inline void fill_dma_list(int base, vector unsigned int *vlist) {                                                                        
    vector unsigned int vadd = (vector unsigned int) { 0, 4*onerow_sz, 0, 4*onerow_sz };                             
    vector unsigned int v0 = (vector unsigned int) { BSZxFLOATSZ, base,             BSZxFLOATSZ, base+onerow_sz };               
    vector unsigned int v1 = (vector unsigned int) { BSZxFLOATSZ, base+2*onerow_sz, BSZxFLOATSZ, base+3*onerow_sz }; 
                                                                                                
    vlist[0] = v0;                                                                              
    vlist[1] = v1;                                                                             
    __next__( 2, 3);                                                                          
    __next__( 4, 5);                                                                         
    __next__( 6, 7);                                                                        
    __next__( 8, 9);                                                                       
    __next__(10,11);                                                                      
    __next__(12,13);                                                                     
    __next__(14,15);                                                                             
}

inline void get_block(unsigned int dis, unsigned int src, int I, int J)
{
    unsigned int base = src + I*BSZ*onerow_sz + J*BSZxFLOATSZ; 
    vector unsigned int vlist[BSZ/2]; 
    fill_dma_list(base, vlist);
    mfc_getl((void*)dis, 0, (unsigned int)vlist, BSZ/2*sizeof(vector unsigned int), TAG0, 0, 0);
    DMA_WAIT(1);
}

inline void put_block(unsigned int src, unsigned int dis, int I, int J)
{
    unsigned int base = dis + I*BSZ*onerow_sz + J*BSZxFLOATSZ; 
    vector unsigned int vlist[BSZ/2]; 
    fill_dma_list(base, vlist);
    mfc_putl((void*)src, 0, (unsigned int)vlist, BSZ/2*sizeof(vector unsigned int), TAG0, 0, 0);
    DMA_WAIT(1);
}

inline void get_block_with_list(unsigned int dis, unsigned int src, int I, int J, int tag, unsigned int *_list)
{
    unsigned int base = src + I*BSZ*onerow_sz + J*BSZxFLOATSZ; 
    vector unsigned int *vlist = (vector unsigned int *) _list;
    fill_dma_list(base, vlist);
    mfc_getl((void*)dis, 0, (unsigned int)vlist, BSZ/2*sizeof(vector unsigned int), tag, 0, 0);
}

inline void put_block_with_list(unsigned int src, int tag, unsigned int *_list)
{
    mfc_putl((void*)src, 0, (unsigned int)_list, BSZ/2*sizeof(vector unsigned int), tag, 0, 0);
}

static unsigned int _list_swap_1[2*NUM_BLOCK_BUF] = {
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0 };
static unsigned int _list_swap_2[2*NUM_BLOCK_BUF] = {
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0,
    BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0, BSZxFLOATSZ, 0 };
static my_mfc_list_elem_t *mfc_list_swap_1 = (my_mfc_list_elem_t *) _list_swap_1;
static my_mfc_list_elem_t *mfc_list_swap_2 = (my_mfc_list_elem_t *) _list_swap_2;
inline void swap_row(unsigned int addr, unsigned int r1, unsigned int r2)
{
    int i, idx;
    volatile static float buf1[2048] _GALIGN;
    volatile static float buf2[2048] _GALIGN;

    idx = 0;
    for(i = 0; i < N; i += NUMBER_OF_SPES){
        mfc_list_swap_1[idx].eal = addr + sizeof(float) * n * r1 + BSZxFLOATSZ * i;
        mfc_list_swap_2[idx].eal = addr + sizeof(float) * n * r2 + BSZxFLOATSZ * i;
        idx++;
    }

    if (__builtin_expect(idx > 0, 1)) {
        mfc_getl(buf1, 0, mfc_list_swap_1, idx*sizeof(my_mfc_list_elem_t), TAG0, 0, 0);
        mfc_getl(buf2, 0, mfc_list_swap_2, idx*sizeof(my_mfc_list_elem_t), TAG0, 0, 0);
        DMA_WAIT(1);
        mfc_putl(buf1, 0, mfc_list_swap_2, idx*sizeof(my_mfc_list_elem_t), TAG0, 0, 0);
        mfc_putl(buf2, 0, mfc_list_swap_1, idx*sizeof(my_mfc_list_elem_t), TAG0, 0, 0);
        DMA_WAIT(1);
    }
}

inline void swap_col(unsigned int addr, unsigned int r1, unsigned int r2)
{
    int col;
    volatile static float buf1[32] _GALIGN;
    volatile static float buf2[32] _GALIGN;
    float t1;
    unsigned int paddr1, paddr2;

    for(col = 0; col < m; col += NUMBER_OF_SPES){
        paddr1 = addr + n * col * sizeof(float) + (r1 / 32) * 128;
        paddr2 = addr + n * col * sizeof(float) + (r2 / 32) * 128;
        mfc_get(buf1, paddr1, 128, TAG0, 0, 0);
        mfc_get(buf2, paddr2, 128, TAG0, 0, 0);
        DMA_WAIT(1);
        t1 = buf1[r1%32]; buf1[r1%32] = buf2[r2%32];
        mfc_put(buf1, paddr1, 128, TAG0, 0, 0);
        DMA_WAIT(1);
        mfc_get(buf1, paddr2, 128, TAG0, 0, 0);
        DMA_WAIT(1);
        buf1[r2%32] = t1;
        mfc_put(buf1, paddr2, 128, TAG0, 0, 0);
        DMA_WAIT(1);
    }
}

inline void solve_small(unsigned int ppe_a, unsigned int ppe_b, 
                        unsigned int ppe_x, unsigned int idx)
{
    int I, J;
    volatile static float *x   = dat+ 6*BSZxBSZ;
    volatile static float *lu1 = dat+13*BSZxBSZ;
    volatile static float *lu2 = dat+19*BSZxBSZ;

    dmaget((void*)x, ppe_b+idx*onerow_sz, onerow_sz);

    /* forward substitution */
    for (I = 0; I < N; I++) {
        for (J = 0; J < I; J++) {
            get_block((unsigned int)lu1, ppe_a, I, J);
            solve_kernel_32x32((float*)&x[I*BSZ], (float*)&x[J*BSZ], (float*)lu1);
        }
        get_block((unsigned int)lu2, ppe_a, I, I);
        forward_substitution_32x32((float*)&x[I*BSZ], (float*)lu2);
    }

    /* backward substitution */
    for (I = N-1; I >= 0; I--) {
        for (J = N-1; J > I; J--) {
            get_block((unsigned int)lu1, ppe_a, I, J);
            solve_kernel_32x32((float*)&x[I*BSZ], (float*)&x[J*BSZ], (float*)lu1);
        }

        get_block((unsigned int)lu2, ppe_a, I, I);
        backward_substitution_32x32((float*)&x[I*BSZ], (float*)lu2);
    }

    dmaput((void*)x, ppe_x+idx*onerow_sz, onerow_sz);
}

#define swap_buf() {             \
    tmp = in; in = op; op = tmp; \
}
inline void solve(unsigned int ppe_a, unsigned int ppe_b, 
                  unsigned int ppe_x, unsigned int idx)
{
    int I, J;
    unsigned int dmalist[2*BSZ];
    volatile float *tmp;
    volatile static float x[4096] _GALIGN;
    volatile static float *in = dat+3*BSZxBSZ;
    volatile static float *op = dat+5*BSZxBSZ;
    int Nm1=N-1, Nm2=N-2;
    int Nm1xBSZ = Nm1 * BSZ;
    int Nm2xBSZ = Nm2 * BSZ;

    mfc_get(x, ppe_b+idx*onerow_sz, onerow_sz, TAG0, 0, 0);
    DMA_WAIT(1);

    /**********************************************************************/
    /* forward substitution                                               */
    /**********************************************************************/
    get_block_with_list((unsigned int)in, ppe_a, 0, 0, TAG0, dmalist);
    DMA_WAIT(1);
    swap_buf();

    get_block_with_list((unsigned int)in, ppe_a, 1, 0, TAG0, dmalist);
    forward_substitution_32x32((float*)x, (float*)op);
    DMA_WAIT(1);
    swap_buf();

    get_block_with_list((unsigned int)in, ppe_a, 1, 1, TAG0, dmalist);
    solve_kernel_32x32((float*)&x[BSZ], (float*)x, (float*)op);
    DMA_WAIT(1);
    swap_buf();

    get_block_with_list((unsigned int)in, ppe_a, 2, 0, TAG0, dmalist);
    forward_substitution_32x32((float*)&x[BSZ], (float*)op);

    for (I = 2; I < N; I++) {
        int IxBSZ = I * BSZ;
        int Jm1xBSZ;
        DMA_WAIT(1);
        for (J = 1; J < I; J++) {
            Jm1xBSZ = (J-1) * BSZ;
            swap_buf();
            get_block_with_list((unsigned int)in, ppe_a, I, J, TAG0, dmalist);
            solve_kernel_32x32((float*)&x[IxBSZ], (float*)&x[Jm1xBSZ], (float*)op);
            DMA_WAIT(1);
        }
        swap_buf();

        get_block_with_list((unsigned int)in, ppe_a, I, I, TAG0, dmalist);
        Jm1xBSZ = (J-1) * BSZ;
        solve_kernel_32x32((float*)&x[IxBSZ], (float*)&x[Jm1xBSZ], (float*)op);
        DMA_WAIT(1);
        swap_buf();

        if ((I+1) < N) {
            get_block_with_list((unsigned int)in, ppe_a, I+1, 0, TAG0, dmalist);
        } else {
            get_block_with_list((unsigned int)in, ppe_a, N-1, N-1, TAG0, dmalist);
        }

        forward_substitution_32x32((float*)&x[IxBSZ], (float*)op);
    }


    /**********************************************************************/
    /* backward substitution                                               */
    /**********************************************************************/
    DMA_WAIT(1);
    swap_buf();

    get_block_with_list((unsigned int)in, ppe_a, Nm2, Nm1, TAG0, dmalist);
    backward_substitution_32x32((float*)&x[Nm1xBSZ], (float*)op);
    DMA_WAIT(1);
    swap_buf();

    get_block_with_list((unsigned int)in, ppe_a, Nm2, Nm2, TAG0, dmalist);
    solve_kernel_32x32((float*)&x[Nm2xBSZ], (float*)&x[Nm1xBSZ], (float*)op);
    DMA_WAIT(1);
    swap_buf();

    get_block_with_list((unsigned int)in, ppe_a, N-3, Nm1, TAG0, dmalist);
    backward_substitution_32x32((float*)&x[Nm2xBSZ], (float*)op);

    for (I = N-3; I >= 0; I--) {
        int IxBSZ = I * BSZ;
        int Jp1xBSZ;
        DMA_WAIT(1);
        for (J = Nm2; J > I; J--) {
            Jp1xBSZ = (J+1) * BSZ;
            swap_buf();
            get_block_with_list((unsigned int)in, ppe_a, I, J, TAG0, dmalist);
            solve_kernel_32x32((float*)&x[IxBSZ], (float*)&x[Jp1xBSZ], (float*)op);
            DMA_WAIT(1);
        }
        swap_buf();

        get_block_with_list((unsigned int)in, ppe_a, I, I, TAG0, dmalist);
        Jp1xBSZ = (J+1) * BSZ;
        solve_kernel_32x32((float*)&x[IxBSZ], (float*)&x[Jp1xBSZ], (float*)op);
        DMA_WAIT(1);
        swap_buf();

        if ((I-1) >= 0) {
            get_block_with_list((unsigned int)in, ppe_a, I-1, Nm1, TAG0, dmalist);
        }

        backward_substitution_32x32((float*)&x[IxBSZ], (float*)op);
    }

    mfc_put(x, ppe_x+idx*onerow_sz, onerow_sz, TAG0, 0, 0);
    DMA_WAIT(1);
}

inline void pivoting(unsigned int addr, int s, int K, int num_blk, int *maxj)
{
    int ii, i, j, idx;
    float tmax, t2;
    int KxBSZ = K * BSZ;
    tmax = -1.0;

    ii = s - KxBSZ;
    *maxj = s;
    for (j = ii; j < BSZ; j++) {
        t2 = fabs(tb[0][j*BSZ+ii]);
        if (t2 > tmax) {
            tmax = t2;
            *maxj = KxBSZ + j;
        }
    }

    for (idx = 1; idx < num_blk; idx++) {
        for (j = 0; j < BSZ; j++) {
            t2 = fabs(tb[idx][j*BSZ+ii]);
            if (t2 > tmax) {
                tmax = t2;
                *maxj = (K+(idx*NUMBER_OF_SPES))*BSZ + j;
            }
        }
    }

    for (i = 1; i < NUMBER_OF_SPES; i++) {
        while (sd[i].pivot_flag != SYNC_0);

        if (sd[i].pivot_max > tmax) {
            *maxj = sd[i].pivot_idx;
            tmax  = sd[i].pivot_max;
        }
    }

    for (i = 0; i < NUMBER_OF_SPES-1; i++) {
        sd[i].pivot_flag = SYNC_1;
        sd[i].pivot_max  = *maxj;
    }
    mfc_putl((void*)sd, 0, (unsigned int)sync_mfclist, 
             (NUMBER_OF_SPES-1)*sizeof(my_mfc_list_elem_t), TAG0, 0, 0);
    DMA_WAIT(1);
}

inline void pivoting_and_swap(int i, int ii, int iixBSZ, int num_blk, 
                              int K, int KxBSZ, int KxBSZxFLOATSZ, 
                              unsigned int ppe_a, unsigned int ppe_b) 
{
    int maxj, idx, no;
    static float *buf0 = (float *) dat;

    /* pivot selection */
    pivoting(ppe_a, i, K, num_blk, &maxj);
    iixBSZ = ii * BSZ;

    if (maxj != i) {
        swap_row(ppe_a, i, maxj);
        swap_col(ppe_b, i, maxj);
        sync_collect(SYNC_2);

        no = (maxj-KxBSZ) / BSZ;
        idx = no / NUMBER_OF_SPES;
        mfc_put(&buf0[ii*BSZ], ppe_a+maxj*onerow_sz+KxBSZxFLOATSZ, BSZxFLOATSZ, TAG0, 0, 0);
        DMA_WAIT(1);
        sync_dist(SYNC_3);

        if (no % NUMBER_OF_SPES == 0) {
            unsigned int maxj_idx = (maxj-((K+no)*BSZ)) * BSZ;
            mfc_put(&tb[idx][maxj_idx], ppe_a+i*onerow_sz+KxBSZxFLOATSZ, BSZxFLOATSZ, TAG0, 0, 0);
            DMA_WAIT(1);
            sync_collect(SYNC_4);
            mfc_get(&tb[idx][maxj_idx], ppe_a+maxj*onerow_sz+KxBSZxFLOATSZ, BSZxFLOATSZ, TAG0, 0, 0);
            DMA_WAIT(1);
        } else {
            sync_collect(SYNC_4);
        }
        mfc_get(&buf0[iixBSZ], ppe_a+i*onerow_sz+KxBSZxFLOATSZ, BSZxFLOATSZ, TAG0, 0, 0);
        DMA_WAIT(1);
    } else {
        mfc_put(&buf0[iixBSZ], ppe_a+i*onerow_sz+KxBSZxFLOATSZ, BSZxFLOATSZ, TAG0, 0, 0);
        DMA_WAIT(1);
    }
    sync_dist(SYNC_5+i);

}

inline void lu_block(int K, unsigned int ppe_a, unsigned int ppe_b)
{
    int i, j, k, idx, num_blk, KK, pos4;
    float *pivrow, *pb0, bii0;
    vector float *vpiv;
    vector float *vtb0, vtbii0;
    unsigned int dmalist[NUM_BLOCK_BUF][2*BSZ];
    int KxBSZxFLOATSZ = K * BSZxFLOATSZ;
    int KxBSZ = K * BSZ;
    int ii, iixBSZ;
    static float *buf0 = (float *) dat;

    idx = 0;
    for (KK = K; KK < N; KK += NUMBER_OF_SPES) {
        get_block_with_list((unsigned int)tb[idx], ppe_a, KK, K, TAG0, dmalist[idx]);
        idx++;
    }
    DMA_WAIT(1);
    num_blk = idx;

    for (i = KxBSZ; i < (K+1)*BSZ-4; i++) {
        ii = i - KxBSZ;
        iixBSZ = ii * BSZ;
        pivoting_and_swap(i, ii, iixBSZ, num_blk, K, KxBSZ, KxBSZxFLOATSZ, ppe_a, ppe_b);

        pivrow = (float *) &buf0[iixBSZ];
        pos4 = 4*(ii/4+1);

        for (j = ii+1; j < BSZ; j++) {
            int jxBSZ = j * BSZ;
            pb0 = (float *) (buf0+jxBSZ+ii);
            bii0 = *pb0 /= *(pivrow+ii);
            vtb0 = (vector float *) (buf0+jxBSZ+pos4);
            vtbii0 = spu_splats(bii0);
            vpiv = (vector float *) (pivrow+pos4);

            for (k = ii+1; k < pos4; k++) {
                pb0++;
                *pb0 -= pivrow[k] * bii0;
            }
            for ( ; k < BSZ; k += 4) {
                *vtb0 = spu_nmsub(*vpiv, vtbii0, *vtb0);
                vtb0++; vpiv++;
            }
        }

        for (idx = 1; idx < num_blk; idx++) {
            column_update_simd32(tb[idx], pivrow, ii, pos4);
        }
    }

    for ( ; i < (K+1)*BSZ; i++) {
        ii = i - KxBSZ;
        iixBSZ = ii * BSZ;
        pivoting_and_swap(i, ii, iixBSZ, num_blk, K, KxBSZ, KxBSZxFLOATSZ, ppe_a, ppe_b);

        pivrow = (float *) &buf0[iixBSZ];

        for (j = ii+1; j < BSZ; j++) {
            int jxBSZ = j * BSZ;
            pb0 = (float *) (buf0+jxBSZ+ii);
            bii0 = *pb0 /= *(pivrow+ii);

            for (k = ii+1; k < BSZ; k++) {
                pb0++;
                *pb0 -= pivrow[k] * bii0;
            }
        }

        for (idx = 1; idx < num_blk; idx++) {
            column_update_small(tb[idx], pivrow, ii, BSZ);
        }
    }

    idx = 0;
    for (KK = K; KK < N; KK += NUMBER_OF_SPES) {
        put_block_with_list((unsigned int)tb[idx], TAG0, dmalist[idx]);
        idx++;
    }

    DMA_WAIT(1);
}

inline void inverse_l(void)
{
    int i, j, k;
    double l_inv_d[BSZxBSZ], ll_kval;
    double *l_ix, *l_kx;

    for (k = 0; k < BSZ; k++) {
        int kxBSZ = k * BSZ;
        *(l_inv_d+kxBSZ+k) = 1.0;
        for (i = k+1; i < BSZ; i++) {
            int ixBSZ = i * BSZ;
            l_kx = (l_inv_d + kxBSZ);
            ll_kval = (double)(*(ll+ixBSZ+k));
            l_ix = (l_inv_d + ixBSZ);
            for (j = 0; j < k; j++) {
                *l_ix -= ll_kval * *l_kx;
                l_ix++; l_kx++;
            }
            *l_ix = - (double)(*(ll+ixBSZ+k));
        }
    }
    for (i = 0; i < BSZ; i++) {
        int ixBSZ = i * BSZ;
        for (j = 0; j <= i; j++) {
            l_inv[ixBSZ+j] = l_inv_d[ixBSZ+j];
        }
    }
}

#define swap_ll_buf() {                                \
    tmp_fptr = in_ll; in_ll = op_ll; op_ll = tmp_fptr; \
    tmp_uiptr = in_list_ll; in_list_ll = op_list_ll;   \
    op_list_ll = tmp_uiptr;                            \
}

#define shift_aa_buf() {                              \
    tmp_fptr = in_aa; in_aa = out_aa;                 \
    out_aa = op_aa; op_aa = tmp_fptr;                 \
    tmp_uiptr = in_list_aa; in_list_aa = out_list_aa; \
    out_list_aa = op_list_aa; op_list_aa = tmp_uiptr; \
}

unsigned int dmalist_uu[2*BSZ];
unsigned int dmalist_ll[2][2*BSZ];
unsigned int dmalist_aa[3][2*BSZ];
inline void row_and_other_update(int K, unsigned int ppe_a)
{
    int I, J;
    unsigned int *tmp_uiptr;
    static unsigned int *in_list_aa  = dmalist_aa[0];
    static unsigned int *op_list_aa  = dmalist_aa[1];
    static unsigned int *out_list_aa = dmalist_aa[2];
    static unsigned int *in_list_ll  = dmalist_ll[0];
    static unsigned int *op_list_ll  = dmalist_ll[1];
    volatile float *tmp_fptr;
    volatile static float *in_uu  = dat+2*BSZxBSZ;
    volatile static float *out_uu = dat+3*BSZxBSZ;
    volatile static float *in_ll  = dat+4*BSZxBSZ;
    volatile static float *op_ll  = dat+5*BSZxBSZ;
    volatile static float *in_aa  = dat+6*BSZxBSZ;
    volatile static float *op_aa  = dat+7*BSZxBSZ;
    volatile static float *out_aa = dat+8*BSZxBSZ;

    if (__builtin_expect(K >= N-2, 0)) {
        inverse_l();
        for (J = K+1; J < N; J += NUMBER_OF_SPES) {
            get_block_with_list((unsigned int)in_uu, ppe_a, K, J, TAG0, dmalist_uu);
            DMA_WAIT(1);
            ld_matmul_SIMD32(l_inv, in_uu, out_uu);
            put_block_with_list((unsigned int)out_uu, TAG0, dmalist_uu);
            DMA_WAIT(1);

            for (I = K+1; I < N; I++) {
                get_block_with_list((unsigned int)in_aa, ppe_a, I, J, TAG0, in_list_aa);
                get_block_with_list((unsigned int)in_ll, ppe_a, I, K, TAG0, in_list_ll);
                DMA_WAIT(1);
                matmulsub_SIMD32(in_ll, out_uu, in_aa);
                put_block_with_list((unsigned int)in_aa, TAG0, in_list_aa);
                DMA_WAIT(1);
            }
        }
        return;
    } 


    J = K + 1;
    get_block_with_list((unsigned int)in_uu, ppe_a, K, J, TAG1, dmalist_uu);
    inverse_l();

    while (J < N) {
        I = K + 1;
        DMA_WAIT(2);
        get_block_with_list((unsigned int)in_aa, ppe_a, I, J, TAG0, in_list_aa);
        get_block_with_list((unsigned int)in_ll, ppe_a, I, K, TAG0, in_list_ll);
        ld_matmul_SIMD32(l_inv, in_uu, out_uu);

        put_block_with_list((unsigned int)out_uu, TAG1, dmalist_uu); 
        DMA_WAIT(1);

        I++;
        shift_aa_buf();
        swap_ll_buf();
        get_block_with_list((unsigned int)in_aa, ppe_a, I, J, TAG0, in_list_aa);
        get_block_with_list((unsigned int)in_ll, ppe_a, I, K, TAG0, in_list_ll);
        matmulsub_SIMD32(op_ll, out_uu, op_aa);
        DMA_WAIT(3);

        I++;
        while (I < N) {
            shift_aa_buf();
            swap_ll_buf();
            put_block_with_list((unsigned int)out_aa, TAG0, out_list_aa);
            get_block_with_list((unsigned int)in_aa, ppe_a, I, J, TAG0, in_list_aa);
            get_block_with_list((unsigned int)in_ll, ppe_a, I, K, TAG0, in_list_ll);
            matmulsub_SIMD32(op_ll, out_uu, op_aa);
            I++;
            DMA_WAIT(1);
        }

        shift_aa_buf();
        swap_ll_buf();
        put_block_with_list((unsigned int)out_aa, TAG0, out_list_aa);
        J += NUMBER_OF_SPES;
        if (J < N) {
            get_block_with_list((unsigned int)in_uu, ppe_a, K, J, TAG1, dmalist_uu);
        }
        matmulsub_SIMD32(op_ll, out_uu, op_aa);
        DMA_WAIT(1);
        shift_aa_buf();
        put_block_with_list((unsigned int)out_aa, TAG0, out_list_aa);
    } 
    DMA_WAIT(1);
}

void spe_soleqs(struct spe_ctrl* sc){
    int i, K;
    int id;
    unsigned int ppe_a, ppe_b, ppe_x, ppe_c;
    unsigned int ppe_s;
    volatile static struct spe_sync ss _GALIGN;
    
    ss.flag = 0;

    n  = sc->n;
    m  = sc->m;
    id = sc->id;
    ppe_a = sc->buf;
    ppe_b = ppe_a + n * n * sizeof(float);
    ppe_x = ppe_b + n * m * sizeof(float);
    ppe_c = ppe_x + n * m * sizeof(float);
    ppe_s = ppe_c + n * m * sizeof(float);
    N = n / BSZ;
    onerow_sz = n * sizeof(float);
    
    /* for syncronization */
    ss.flag = 0XFFFFFFFF;
    ss.addr = (unsigned int)sc->ls_addr[id] + (unsigned int)&sd[0];
    dmaput((void*)&ss, (ppe_s+128*id) , 128);
    ppe_ls[0] = ss.addr;

    /* Get addresses for each sharing memory of SPE */
    ss.flag = 0;
    for(i = 1; i < NUMBER_OF_SPES; i++){
        do{
            mfc_get(&ss, (ppe_s+128*i), 128, TAG0, 0, 0);
            DMA_WAIT(1);
        } while(ss.flag != 0XFFFFFFFF);
        ppe_ls[i] = ss.addr;
        sync_mfclist[i-1].eal  = ppe_ls[i] + 128*i;
        sync_mfclist[i-1].size = 128;
        ss.flag = 0;
    }

    /* LU decomposition */
    for (K = 0; K < N-1; K++) {
        lu_block(K, ppe_a, ppe_b);
        sync_collect(SYNC_7);
        sync_dist(SYNC_8);

        row_and_other_update(K, ppe_a);
        sync_dist(SYNC_9);
        sync_collect(SYNC_A);
    }
    lu_block(N-1, ppe_a, ppe_b);
    sync_dist(SYNC_B);
    sync_collect(SYNC_C);

    /* Forward Substitution and Backward Substitution */
    if (__builtin_expect(N >= 3, 1)) {
        for(i = 0; i < m; i += NUMBER_OF_SPES) {
            solve(ppe_a, ppe_b, ppe_x, i);
        }
    } else {
        for(i = 0; i < m; i += NUMBER_OF_SPES) {
            solve_small(ppe_a, ppe_b, ppe_x, i);
        }
    }
}

