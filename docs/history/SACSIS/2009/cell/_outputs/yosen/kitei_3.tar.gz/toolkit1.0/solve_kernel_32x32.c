#define BSZ 32

inline void solve_kernel_32x32(float *xI, float *xJ, float *op)
{
    int j;
    float *px; 
    float *pop0, *pop1, *pop2, *pop3, *pop4, *pop5,  *pop6, *pop7;
    float xx0, xx1, xx2, xx3, xx4, xx5, xx6, xx7;

    pop0 = op;
    pop1 = op +    BSZ;
    pop2 = op +  2*BSZ;
    pop3 = op +  3*BSZ;
    pop4 = op +  4*BSZ;
    pop5 = op +  5*BSZ;
    pop6 = op +  6*BSZ;
    pop7 = op +  7*BSZ;

    xx0 = *(xI     );
    xx1 = *(xI +  1);
    xx2 = *(xI +  2);
    xx3 = *(xI +  3);
    xx4 = *(xI +  4);
    xx5 = *(xI +  5);
    xx6 = *(xI +  6);
    xx7 = *(xI +  7);

    px = xJ;

    for (j = 0; j < BSZ; j++) {
        xx0 -= *pop0 * *px; pop0++;
        xx1 -= *pop1 * *px; pop1++;
        xx2 -= *pop2 * *px; pop2++;
        xx3 -= *pop3 * *px; pop3++;
        xx4 -= *pop4 * *px; pop4++;
        xx5 -= *pop5 * *px; pop5++;
        xx6 -= *pop6 * *px; pop6++;
        xx7 -= *pop7 * *px; pop7++;
        px++;
    }

    *(xI     ) = xx0;
    *(xI +  1) = xx1;
    *(xI +  2) = xx2;
    *(xI +  3) = xx3;
    *(xI +  4) = xx4;
    *(xI +  5) = xx5;
    *(xI +  6) = xx6;
    *(xI +  7) = xx7;


    pop0 = op +  8*BSZ;
    pop1 = op +  9*BSZ;
    pop2 = op + 10*BSZ;
    pop3 = op + 11*BSZ;
    pop4 = op + 12*BSZ;
    pop5 = op + 13*BSZ;
    pop6 = op + 14*BSZ;
    pop7 = op + 15*BSZ;

    xx0 = *(xI +  8);
    xx1 = *(xI +  9);
    xx2 = *(xI + 10);
    xx3 = *(xI + 11);
    xx4 = *(xI + 12);
    xx5 = *(xI + 13);
    xx6 = *(xI + 14);
    xx7 = *(xI + 15);

    px = xJ;

    for (j = 0; j < BSZ; j++) {
        xx0 -= *pop0 * *px; pop0++;
        xx1 -= *pop1 * *px; pop1++;
        xx2 -= *pop2 * *px; pop2++;
        xx3 -= *pop3 * *px; pop3++;
        xx4 -= *pop4 * *px; pop4++;
        xx5 -= *pop5 * *px; pop5++;
        xx6 -= *pop6 * *px; pop6++;
        xx7 -= *pop7 * *px; pop7++;
        px++;
    }

    *(xI +  8) = xx0;
    *(xI +  9) = xx1;
    *(xI + 10) = xx2;
    *(xI + 11) = xx3;
    *(xI + 12) = xx4;
    *(xI + 13) = xx5;
    *(xI + 14) = xx6;
    *(xI + 15) = xx7;
    

    pop0 = op + 16*BSZ;
    pop1 = op + 17*BSZ;
    pop2 = op + 18*BSZ;
    pop3 = op + 19*BSZ;
    pop4 = op + 20*BSZ;
    pop5 = op + 21*BSZ;
    pop6 = op + 22*BSZ;
    pop7 = op + 23*BSZ;

    xx0 = *(xI + 16);
    xx1 = *(xI + 17);
    xx2 = *(xI + 18);
    xx3 = *(xI + 19);
    xx4 = *(xI + 20);
    xx5 = *(xI + 21);
    xx6 = *(xI + 22);
    xx7 = *(xI + 23);

    px = xJ;

    for (j = 0; j < BSZ; j++) {
        xx0 -= *pop0 * *px; pop0++;
        xx1 -= *pop1 * *px; pop1++;
        xx2 -= *pop2 * *px; pop2++;
        xx3 -= *pop3 * *px; pop3++;
        xx4 -= *pop4 * *px; pop4++;
        xx5 -= *pop5 * *px; pop5++;
        xx6 -= *pop6 * *px; pop6++;
        xx7 -= *pop7 * *px; pop7++;
        px++;
    }

    *(xI + 16) = xx0;
    *(xI + 17) = xx1;
    *(xI + 18) = xx2;
    *(xI + 19) = xx3;
    *(xI + 20) = xx4;
    *(xI + 21) = xx5;
    *(xI + 22) = xx6;
    *(xI + 23) = xx7;
    

    pop0 = op + 24*BSZ;
    pop1 = op + 25*BSZ;
    pop2 = op + 26*BSZ;
    pop3 = op + 27*BSZ;
    pop4 = op + 28*BSZ;
    pop5 = op + 29*BSZ;
    pop6 = op + 30*BSZ;
    pop7 = op + 31*BSZ;

    xx0 = *(xI + 24);
    xx1 = *(xI + 25);
    xx2 = *(xI + 26);
    xx3 = *(xI + 27);
    xx4 = *(xI + 28);
    xx5 = *(xI + 29);
    xx6 = *(xI + 30);
    xx7 = *(xI + 31);

    px = xJ;

    for (j = 0; j < BSZ; j++) {
        xx0 -= *pop0 * *px; pop0++;
        xx1 -= *pop1 * *px; pop1++;
        xx2 -= *pop2 * *px; pop2++;
        xx3 -= *pop3 * *px; pop3++;
        xx4 -= *pop4 * *px; pop4++;
        xx5 -= *pop5 * *px; pop5++;
        xx6 -= *pop6 * *px; pop6++;
        xx7 -= *pop7 * *px; pop7++;
        px++;
    }

    *(xI + 24) = xx0;
    *(xI + 25) = xx1;
    *(xI + 26) = xx2;
    *(xI + 27) = xx3;
    *(xI + 28) = xx4;
    *(xI + 29) = xx5;
    *(xI + 30) = xx6;
    *(xI + 31) = xx7;
}

inline void forward_substitution_32x32(float *x, float *op)
{
    int i, j;
    float xi, *px, *pop;

    for (i = 1; i < BSZ; i++) {
        px = x;
        pop = (op + i*BSZ);
        xi = *(x + i);
        for (j = 0; j < i; j++) {
            xi -= *pop * *px;
            pop++; px++;
        }
        *(x + i) = xi;
    }
}

inline void backward_substitution_32x32(float *x, float *op)
{
    int i, j;
    float xi, *px, *pop;

    for (i = BSZ-1; i >= 0; i--) {
        px =  (x + BSZ-1);
        pop = (op + i*BSZ + BSZ-1);
        xi = *(x + i);
        for (j = BSZ-1; j > i; j--) {
            xi -= *pop * *px;
            pop--; px--;
        }
        xi /= *pop;
        *(x + i) = xi;
    }
}

