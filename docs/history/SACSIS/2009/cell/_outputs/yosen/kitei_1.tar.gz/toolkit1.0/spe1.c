/*----------------------------------------------------------------------*/
// author: SATOSHIRO Haruki
// 
/*----------------------------------------------------------------------*/
#include <spu_intrinsics.h>
#include <spelib.h>
#include <spe_stdio.h>
#include <stdlib.h>
#include <spu_mfcio.h>
#include <float.h>
#include <math.h>
#include "spe_util.h"
#include "define.h"

/**
 * 命名規則
 * * 変数名
 *   eaから始まる変数は実行アドレス(型は整数を表すeaddr_t)
 *   lsから始まる変数はDMA転送のバッファに使うもの, volatileで修飾されたものはデータの取得に使用する
 *   ループカウンタはi, j, k
 *     ループカウンタの後ろにはループの種類によってA(大文字), a(小文字), mが付く
 *     Aはブロックについて回すとき, aは小行列の要素について回すとき, mは右辺ベクトルについて回すとき
 *     後置詞がないときはそれ以外のループ
 *   定数は全て大文字で命名
 *   本来関数内だけで参照するべきだが高速化のためグローバル変数にしたものは先頭にgを付加
 *
 * * 関数名
 *   関数名の最後に inner が付くものは inner なしの関数の内側のループを出したもの
 *   get, put が含まれる関数はDMA転送を行う
 *     iget, iputなどの i で始まる名前の関数は転送の終了を待たずに処理が戻ってくる
 *     iputb などの最後に b が付く名前の関数はバリア付き
 */

// ピボット決定後に交換を行うかどうか(デバッグ用)
#define ENABLE_SWAP

// デクリメンタの読み込み(デバッグ用)
#define READ_DECREMENTER

// 解を求めた後行列を元の形式に戻す(デバッグ用)
//#define FILL_A_AFTER_SOLEQS

#define PRINT_CYCLE 100000000

//#define PROF_MATRIX_NMSUB
//#define PRINT_PROF

// 縦方向にキャッシュするブロック数
#define COLCACHE_SIZE 24

/*----------------------------------------------------------------------*/
volatile static struct spe_ctrl       sc _GALIGN;

typedef unsigned int eaddr_t;

#define BLOCK_SIZE 32 // 変更不可
// 最適化により32周分のループ展開をした部分や、インラインアセンブリによる記述あり

#define INNER_BLOCK_SIZE 4 //変更不可
#define INNER_BLOCK_COUNT (BLOCK_SIZE/INNER_BLOCK_SIZE)

#define DMA_SIZE_MAX 16384
#define VEC_DMA_LINE (DMA_SIZE_MAX/(BLOCK_SIZE*sizeof(float)))

// コンパイラはキャストにも1Cycleかかるコードを生成するので回避
typedef union {
    vector float v;
    qword q;
} uv_float;

typedef union {
    vector unsigned int v;
    qword q;
} uv_uint;

typedef union {
    vector unsigned short v;
    qword q;
} uv_ushort;

typedef struct {
    unsigned int sigfork;
    signed int line;
    union {
        float max;
        int pivot;
    } p;
    unsigned int sigjoin;
} syncdata;

typedef union {
    syncdata s;
    vector unsigned int v;
    unsigned int pad[32];
} usyncdata;

typedef struct {
    unsigned int target;
    unsigned int pivot;
    unsigned int reserved[2];
} swapdata;

#define SYNC_SIZE 8 // 変更不可
#define SYNC_SIGNAL 7

unsigned int speid;
volatile usyncdata lssignal[SYNC_SIZE] _GALIGN = {
    { { 0, -1, {0.0f}, 0, } },
    { { 0, -1, {0.0f}, 0, } },
    { { 0, -1, {0.0f}, 0, } },
    { { 0, -1, {0.0f}, 0, } },
    { { 0, -1, {0.0f}, 0, } },
    { { 0, -1, {0.0f}, 0, } },
    { { 0, -1, {0.0f}, 0, } },
    { { 0, -1, {0.0f}, 0, } }, };

// 縦方向の通信用
volatile float lsuline[2][BLOCK_SIZE] _GALIGN;
#define ULINE_TARGET 0
#define ULINE_SWAP   1

usyncdata lssyncbuf[SYNC_SIZE] _GALIGN;
usyncdata lsresult[SYNC_SIZE] _GALIGN;

// 同期用
eaddr_t eals[SYNC_SIZE];
eaddr_t ealssignal[SYNC_SIZE];
eaddr_t ealsuline[SYNC_SIZE];

typedef struct mfc_list_element {
    unsigned int notify    : 1;
    unsigned int reserved  : 16;
    unsigned int size      : 15;
    unsigned int eal       : 32;
} mfc_list_element_t;

typedef union {
    mfc_list_element_t e;
    vector unsigned int v;
} u_mfc_list_element_t;

mfc_list_element_t mlsync[SYNC_SIZE] _LALIGN;

float lsulinecp[BLOCK_SIZE] _GALIGN;

volatile float lsrightelem[2][BLOCK_SIZE*sizeof(float)] _GALIGN;
mfc_list_element_t mlgetelem[2][BLOCK_SIZE] _GALIGN;

#define VECTOR_ARRAY_SIZE 10
volatile static float lsV[VECTOR_ARRAY_SIZE][BLOCK_SIZE] _GALIGN;
#define VECTOR_R 0
#define VECTOR_X 2
#define VECTOR_V 4

volatile static int lsperm[7][BLOCK_SIZE] _GALIGN;
#define PERM_INIT        0 // 4つ使用
#define PERM_TARGET      0
#define PERM_DECOM       0
#define PERM_RIGHT       0
#define PERM_L           2
#define PERM_PIVOT       2
#define PERM_SWAP_PIVOT  4
#define PERM_SWAP_TGTEMP 5
#define PERM_SWAP_PVTEMP 6

#define BLOCK_ARRAY_SIZE (11+COLCACHE_SIZE)

#define VECTOR_SIZE (BLOCK_ARRAY_SIZE/4*32)
#define VCACHE_SIZE (VECTOR_SIZE*4)

mfc_list_element_t mlget[BLOCK_ARRAY_SIZE][BLOCK_SIZE] _GALIGN;
mfc_list_element_t mlput[BLOCK_ARRAY_SIZE][BLOCK_SIZE] _GALIGN;
#define ML_RIGHT 0

volatile float lsblock[BLOCK_ARRAY_SIZE][BLOCK_SIZE][BLOCK_SIZE] _GALIGN;
#define BLOCK_DECOM     0
#define BLOCK_D         0
#define BLOCK_L         2
#define BLOCK_U         4
#define BLOCK_DIAG      6
#define BLOCK_TARGET    7
#define BLOCK_PIVOT     9
#define BLOCK_COLCACHE 11

int gcol;
int gcolcache_size;
vector unsigned int vcolcachevalid[COLCACHE_SIZE];

#define TAG_PERM_GET    8
#define TAG_PERM_PUT    9
#define TAG_BLOCK_GET  10
#define TAG_BLOCK_PUT  11
#define TAG_RIGHT      12
#define TAG_VECTOR_GET 13
#define TAG_VECTOR_PUT 14
#define TAG_SYNC       15
#define TAG_LINE_GET   16
#define TAG_LINE_PUT   17
#define TAG_PERM       18
#define TAG_DIAG       19
#define TAG_PVGET      20
#define TAG_SWAP       22 // 2個使用 

//リストDMA用
eaddr_t glinesize;
vector unsigned int gvinc;
vector unsigned int gveal0;
vector unsigned int gveal1;

#define SPE_MASTER 0
#define SPESIG_FORK 1
#define SPESIG_JOIN 1

int gswap_tag;
int gswap_tbuf;
int gswap_pbuf;
int gswap_col;
int gswap_skip;
int gswap_nxtdecom;
int gswap_nA;
int gswap_iA;
int gswap_pvcnt;
eaddr_t gswap_eaA;

#if defined READ_DECREMENTER
unsigned int gstep = 0;
unsigned int gsync = 0;
unsigned int dec = 0;
unsigned int s, t;
#endif

#if defined PRINT_PROF
unsigned int sp, tp;
#define PROF_START_ONCE() do { sp = spu_read_decrementer(); } while(0)
#define PROF_STOP_ONCE() do { tp = spu_read_decrementer(); if(dec == 0) { dec = sp-tp; } } while(0)
#else
#define PROF_START_ONCE() do { ; } while(0)
#define PROF_STOP_ONCE() do { ; } while(0)
#endif

/*----------------------------------------------------------------------*/

inline void set_linesize(eaddr_t linesize)
{
    vector unsigned int veal0 = { 0, linesize, 2*linesize, 3*linesize, };
    vector unsigned int veal1 = { 4*linesize, 5*linesize, 6*linesize, 7*linesize, };

    glinesize = linesize;
    gvinc = spu_splats(8*linesize);
    gveal0 = veal0;
    gveal1 = veal1;
}

#define line_assign(l, r) do {\
    *(vector float*)&(l)[ 0] = *(vector float*)&(r)[ 0]; \
    *(vector float*)&(l)[ 4] = *(vector float*)&(r)[ 4]; \
    *(vector float*)&(l)[ 8] = *(vector float*)&(r)[ 8]; \
    *(vector float*)&(l)[12] = *(vector float*)&(r)[12]; \
    *(vector float*)&(l)[16] = *(vector float*)&(r)[16]; \
    *(vector float*)&(l)[20] = *(vector float*)&(r)[20]; \
    *(vector float*)&(l)[24] = *(vector float*)&(r)[24]; \
    *(vector float*)&(l)[28] = *(vector float*)&(r)[28]; \
} while(0)

/////////////////////////////////////////////////////////////////////////////////////////////////
// 同期用関数
/////////////////////////////////////////////////////////////////////////////////////////////////

#define dma_wait(buf) do { mfc_write_tag_mask(1 << (buf)); mfc_read_tag_status_all(); } while(0)
//inline void dma_wait(int buf)
//{
//    mfc_write_tag_mask(1 << buf);
//    mfc_read_tag_status_all();
//}

inline int is_master()
{
    return (speid == 0);
}

// iA番目の対角ブロックを担当するときは1, そうでなければ0を返す
inline int is_assigned(int iA)
{
    return (speid == iA%NUMBER_OF_SPES);
}

/** 
 * fork-joinモデルの実装
 * マスタースレッドはrun_spesとjoin_spesの間
 * スレーブスレッドはwait_for_signalとsend_signalの間が並列実行
 */
inline void run_spes(usyncdata sync)
{
    vector unsigned int vmask = { 0, 0xFFFFFFFF, 0xFFFFFFFF, 0, };
    vector unsigned int vsig = { SPESIG_FORK, 0, 0, 0, };

    sync.v = spu_and(sync.v, vmask);
    sync.v = spu_or(sync.v, vsig);

    dma_wait(TAG_SYNC);

    lssyncbuf[0].v = sync.v;

    // 他のSPEに転送
    if(NUMBER_OF_SPES >= 2) {
        mfc_putb(&lssyncbuf[0], ealssignal[1]+sizeof(usyncdata)*1, sizeof(syncdata), TAG_SYNC, 0, 0);
    }
    if(NUMBER_OF_SPES >= 3) {
        mfc_putb(&lssyncbuf[0], ealssignal[2]+sizeof(usyncdata)*2, sizeof(syncdata), TAG_SYNC, 0, 0);
    }
    if(NUMBER_OF_SPES >= 4) {
        mfc_putb(&lssyncbuf[0], ealssignal[3]+sizeof(usyncdata)*3, sizeof(syncdata), TAG_SYNC, 0, 0);
    }
    if(NUMBER_OF_SPES >= 5) {
        mfc_putb(&lssyncbuf[0], ealssignal[4]+sizeof(usyncdata)*4, sizeof(syncdata), TAG_SYNC, 0, 0);
    }
    if(NUMBER_OF_SPES >= 6) {
        mfc_putb(&lssyncbuf[0], ealssignal[5]+sizeof(usyncdata)*5, sizeof(syncdata), TAG_SYNC, 0, 0);
    }
    if(NUMBER_OF_SPES >= 7) {
        mfc_putb(&lssyncbuf[0], ealssignal[6]+sizeof(usyncdata)*6, sizeof(syncdata), TAG_SYNC, 0, 0);
    }

#if defined READ_DECREMENTER
    gsync++;
#endif
}

void join_spes()
{
    int i;
    syncdata sync = { -1, 0, {0.0f}, SPESIG_JOIN, };
    vector unsigned int vinit = { (unsigned int)(-1), -1, 0, 0, };
    usyncdata usync _LALIGN;

    usync.s = sync;

    dma_wait(TAG_SYNC);

    for(i = 1; i < NUMBER_OF_SPES; i++) {
#if defined READ_DECREMENTER
        s = spu_read_decrementer();
        while(lssignal[i].s.sigjoin != SPESIG_JOIN) {
            t = spu_read_decrementer();
            if(s-t > PRINT_CYCLE) {
                spe_printf("SPE(%d): too late!(join_spes) step = %d, sync = %d, sig(%d) = %d\n", speid, gstep, gsync, i, lssignal[i].s.sigjoin);
                s = t;
            }
        }
#else
        while(lssignal[i].s.sigjoin != SPESIG_JOIN) {
            ;
        }
#endif
        lsresult[i].v = lssignal[i].v;
    }

    lssignal[0].v = vinit;
    lssignal[1].v = vinit;
    lssignal[2].v = vinit;
    lssignal[3].v = vinit;
    lssignal[4].v = vinit;
    lssignal[5].v = vinit;
    lssignal[6].v = vinit;
    lssignal[7].v = vinit;
}

void wait_for_signal()
{
    dma_wait(TAG_SYNC);

#if defined READ_DECREMENTER
    gsync++;
    s = spu_read_decrementer();
    while(lssignal[speid].s.sigfork != SPESIG_FORK) {
        t = spu_read_decrementer();
        if(s-t > PRINT_CYCLE) {
            spe_printf("SPE(%d): too late!(wait_for_signal) step = %d, sync = %d, sig(%d) = %d\n", speid, gstep, gsync, speid, lssignal[speid].s.sigfork);
            s = t;
        }
    }
#else
    while(lssignal[speid].s.sigfork != SPESIG_FORK) {
        ;
    }
#endif
}

// 一連のデータ送信の前にTAG_SYNCの転送の終了を待つ必要あり
inline void send_signal_to(int spe, usyncdata signal)
{
    //dma_wait(TAG_SYNC);

    lssyncbuf[speid].v = signal.v;
    mfc_putf(&lssyncbuf[speid], ealssignal[spe] + sizeof(lssyncbuf[speid])*speid, sizeof(syncdata), TAG_SYNC, 0, 0);
}

// スレーブスレッドがsend_signal_toに続いてマスタースレッドを待たずにsend_signalを呼び出すと同期が乱れる恐れあり
void send_signal(usyncdata signal)
{
    vector unsigned int vinit = { 0, -1, 0, 0, };
    vector unsigned int vmask = { 0, 0xFFFFFFFF, 0xFFFFFFFF, 0, };
    vector unsigned int vsig = { 0, 0, 0, SPESIG_JOIN, };

    dma_wait(TAG_SYNC);

    lssignal[0].v = vinit;
    lssignal[1].v = vinit;
    lssignal[2].v = vinit;
    lssignal[3].v = vinit;
    lssignal[4].v = vinit;
    lssignal[5].v = vinit;
    lssignal[6].v = vinit;
    lssignal[7].v = vinit;

    signal.v = spu_and(signal.v, vmask);
    signal.v = spu_or(signal.v, vsig);
    lssyncbuf[speid].v = signal.v;
    mfc_putf(&lssyncbuf[speid], ealssignal[SPE_MASTER] + sizeof(lssyncbuf[speid])*speid, sizeof(syncdata), TAG_SYNC, 0, 0);
}

// 8番目のバッファを使用してデータ送信
// 一連のデータ送信の前にTAG_SYNCの転送の終了を待つ必要あり
void send_signal_all(usyncdata signal)
{
    int i;
    vector unsigned int vmask = { 0, 0xFFFFFFFF, 0xFFFFFFFF, 0, };
    vector unsigned int vsig = { -1, 0, 0, 0, };

    signal.v = spu_and(signal.v, vmask);
    signal.v = spu_or(signal.v, vsig);

    //dma_wait(TAG_SYNC);

    lssyncbuf[SYNC_SIGNAL].v = signal.v;

    for(i = 0; i < NUMBER_OF_SPES; i++) {
        if(i != speid) {
            mfc_putf(&lssyncbuf[SYNC_SIGNAL], ealssignal[i]+sizeof(lssyncbuf[SYNC_SIGNAL])*SYNC_SIGNAL, sizeof(syncdata), TAG_SYNC, 0, 0);
        }
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////
// DMA転送用関数
/////////////////////////////////////////////////////////////////////////////////////////////////

inline void iget_perm(int buf, int tag, int iA, eaddr_t eaP)
{
    mfc_get(lsperm[buf],
            eaP+iA*BLOCK_SIZE*sizeof(float),
            sizeof(lsperm[buf]),
            tag, 0, 0);
}

inline void iput_perm(int buf, int tag, int iA, eaddr_t eaP)
{
    mfc_put(lsperm[buf], 
            eaP+iA*BLOCK_SIZE*sizeof(float), 
            sizeof(lsperm[buf]),
            tag, 0, 0);
}

inline eaddr_t cal_ea_block(int nA, int iA, int jA, eaddr_t eaA)
{
    //return (eaA + (iA*nA+jA)*BLOCK_SIZE*BLOCK_SIZE*sizeof(float));
    return (eaA + (jA*nA+iA)*BLOCK_SIZE*BLOCK_SIZE*sizeof(float));
}

inline void iget_line_p(volatile float *p, int tag, int nA, int line, int jA, eaddr_t eaA)
{
    unsigned int iA = line / BLOCK_SIZE;
    unsigned int lineA = line - iA*BLOCK_SIZE;
    eaddr_t eaLine = cal_ea_block(nA, iA, jA, eaA) + lineA*BLOCK_SIZE*sizeof(float);

    mfc_get(p, eaLine, BLOCK_SIZE*sizeof(float), tag, 0, 0);
}

inline void iput_line_p(volatile float *p, int tag, int nA, int line, int jA, eaddr_t eaA)
{
    unsigned int iA = line / BLOCK_SIZE;
    unsigned int lineA = line - iA*BLOCK_SIZE;
    eaddr_t eaLine = cal_ea_block(nA, iA, jA, eaA) + lineA*BLOCK_SIZE*sizeof(float);

    mfc_put(p, eaLine, BLOCK_SIZE*sizeof(float), tag, 0, 0);
}

// linesize = nA*BLOCK_SIZE*sizeof(float)
// lineoffset = jA*BLOCK_SIZE*sizeof(float)
// eaLineST = eaA + iA*BLOCK_SIZE*linesize + lineoffset
// リストエレメントをSIMDで計算
// eaLineSTは読み込むブロックの左上の要素のアドレス
void iget_block_ml_hs(int buf, eaddr_t eaLineST)
{
    //int i;
    vector unsigned int vln = spu_splats(eaLineST);
    const vector unsigned short cvml = { 0, BLOCK_SIZE*sizeof(float), 0, 0, 0, BLOCK_SIZE*sizeof(float), 0, 0, };
    vector unsigned short vml0, vml1, vml2, vml3;
    vector unsigned int veal0, veal1;
    const vector unsigned char vpattern0 = { 0, 1, 2, 3, 16, 17, 18, 19, 8, 9, 10, 11, 20, 21, 22, 23, };
    const vector unsigned char vpattern1 = { 0, 1, 2, 3, 24, 25, 26, 27, 8, 9, 10, 11, 28, 29, 30, 31, };

    veal0 = spu_add(vln, gveal0);
    veal1 = spu_add(vln, gveal1);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlget[buf][ 0] = vml0;
    *(vector unsigned short*)&mlget[buf][ 2] = vml1;
    *(vector unsigned short*)&mlget[buf][ 4] = vml2;
    *(vector unsigned short*)&mlget[buf][ 6] = vml3;

    veal0 = spu_add(veal0, gvinc);
    veal1 = spu_add(veal1, gvinc);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlget[buf][ 8] = vml0;
    *(vector unsigned short*)&mlget[buf][10] = vml1;
    *(vector unsigned short*)&mlget[buf][12] = vml2;
    *(vector unsigned short*)&mlget[buf][14] = vml3;

    veal0 = spu_add(veal0, gvinc);
    veal1 = spu_add(veal1, gvinc);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlget[buf][16] = vml0;
    *(vector unsigned short*)&mlget[buf][18] = vml1;
    *(vector unsigned short*)&mlget[buf][20] = vml2;
    *(vector unsigned short*)&mlget[buf][22] = vml3;

    veal0 = spu_add(veal0, gvinc);
    veal1 = spu_add(veal1, gvinc);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlget[buf][24] = vml0;
    *(vector unsigned short*)&mlget[buf][26] = vml1;
    *(vector unsigned short*)&mlget[buf][28] = vml2;
    *(vector unsigned short*)&mlget[buf][30] = vml3;

    /*for(i = 0; i < BLOCK_SIZE; i += 8) {
        vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
        vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
        vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
        vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

        *(vector unsigned short*)&mlget[buf][i  ] = vml0;
        *(vector unsigned short*)&mlget[buf][i+2] = vml1;
        *(vector unsigned short*)&mlget[buf][i+4] = vml2;
        *(vector unsigned short*)&mlget[buf][i+6] = vml3;

        veal0 = spu_add(veal0, gvinc);
        veal1 = spu_add(veal1, gvinc);
    }*/
}

/*#define iget_block_line(buf, tag, nA, iA, jA, eaA) do { \
    mfc_get(lsblock[buf], cal_ea_block(nA, iA, jA, eaA), sizeof(lsblock[buf]), tag, 0, 0); \
} while(0)*/
inline void iget_block_line(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    eaddr_t ea = cal_ea_block(nA, iA, jA, eaA);

    mfc_get(lsblock[buf], ea, sizeof(lsblock[buf]), tag, 0, 0);
}

inline void igetb_block_line(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    eaddr_t ea = cal_ea_block(nA, iA, jA, eaA);

    mfc_getb(lsblock[buf], ea, sizeof(lsblock[buf]), tag, 0, 0);
}

inline void iget_block_ml(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    eaddr_t lineoffset = jA*BLOCK_SIZE*sizeof(float);
    eaddr_t eaLineST = eaA + iA*BLOCK_SIZE*glinesize + lineoffset;

    iget_block_ml_hs(buf, eaLineST);

    mfc_getl(lsblock[buf], 0, mlget[buf], sizeof(mlget[buf]), tag, 0, 0);
}

//#define iget_block(buf, tag, nA, iA, jA, eaA) iget_block_line(buf, tag, nA, iA, jA, eaA)
inline void iget_block(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    //iget_block_ml(buf, tag, nA, iA, jA, eaA);
    iget_block_line(buf, tag, nA, iA, jA, eaA);
}

void iput_block_ml_hs(int buf, eaddr_t eaLineST)
{
    //int i;
    vector unsigned int vln = spu_splats(eaLineST);
    const vector unsigned short cvml = { 0, BLOCK_SIZE*sizeof(float), 0, 0, 0, BLOCK_SIZE*sizeof(float), 0, 0, };
    vector unsigned short vml0, vml1, vml2, vml3;
    vector unsigned int veal0, veal1;
    const vector unsigned char vpattern0 = { 0, 1, 2, 3, 16, 17, 18, 19, 8, 9, 10, 11, 20, 21, 22, 23, };
    const vector unsigned char vpattern1 = { 0, 1, 2, 3, 24, 25, 26, 27, 8, 9, 10, 11, 28, 29, 30, 31, };

    veal0 = spu_add(vln, gveal0);
    veal1 = spu_add(vln, gveal1);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlput[buf][ 0] = vml0;
    *(vector unsigned short*)&mlput[buf][ 2] = vml1;
    *(vector unsigned short*)&mlput[buf][ 4] = vml2;
    *(vector unsigned short*)&mlput[buf][ 6] = vml3;

    veal0 = spu_add(veal0, gvinc);
    veal1 = spu_add(veal1, gvinc);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlput[buf][ 8] = vml0;
    *(vector unsigned short*)&mlput[buf][10] = vml1;
    *(vector unsigned short*)&mlput[buf][12] = vml2;
    *(vector unsigned short*)&mlput[buf][14] = vml3;

    veal0 = spu_add(veal0, gvinc);
    veal1 = spu_add(veal1, gvinc);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlput[buf][16] = vml0;
    *(vector unsigned short*)&mlput[buf][18] = vml1;
    *(vector unsigned short*)&mlput[buf][20] = vml2;
    *(vector unsigned short*)&mlput[buf][22] = vml3;

    veal0 = spu_add(veal0, gvinc);
    veal1 = spu_add(veal1, gvinc);

    vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
    vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
    vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
    vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

    *(vector unsigned short*)&mlput[buf][24] = vml0;
    *(vector unsigned short*)&mlput[buf][26] = vml1;
    *(vector unsigned short*)&mlput[buf][28] = vml2;
    *(vector unsigned short*)&mlput[buf][30] = vml3;

    /*for(i = 0; i < BLOCK_SIZE; i += 8) {
        vml0 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern0);
        vml1 = spu_shuffle(cvml, (vector unsigned short)veal0, vpattern1);
        vml2 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern0);
        vml3 = spu_shuffle(cvml, (vector unsigned short)veal1, vpattern1);

        *(vector unsigned short*)&mlput[buf][i  ] = vml0;
        *(vector unsigned short*)&mlput[buf][i+2] = vml1;
        *(vector unsigned short*)&mlput[buf][i+4] = vml2;
        *(vector unsigned short*)&mlput[buf][i+6] = vml3;

        veal0 = spu_add(veal0, gvinc);
        veal1 = spu_add(veal1, gvinc);
    }*/
}

inline void iput_block_ml(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    eaddr_t lineoffset = jA*BLOCK_SIZE*sizeof(float);
    eaddr_t eaLineST = eaA + iA*BLOCK_SIZE*glinesize + lineoffset;

    iput_block_ml_hs(buf, eaLineST);

    mfc_putl(lsblock[buf], 0, mlput[buf], sizeof(mlput[buf]), tag, 0, 0);
}

inline void iputb_block_ml(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    eaddr_t lineoffset = jA*BLOCK_SIZE*sizeof(float);
    eaddr_t eaLineST = eaA + iA*BLOCK_SIZE*glinesize + lineoffset;

    iput_block_ml_hs(buf, eaLineST);

    mfc_putlb(lsblock[buf], 0, mlput[buf], sizeof(mlput[buf]), tag, 0, 0);
}

inline void iput_block_line(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    eaddr_t ea = cal_ea_block(nA, iA, jA, eaA);

    mfc_put(lsblock[buf], ea, sizeof(lsblock[buf]), tag, 0, 0);
}

inline void iputb_block_line(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    eaddr_t ea = cal_ea_block(nA, iA, jA, eaA);

    mfc_putb(lsblock[buf], ea, sizeof(lsblock[buf]), tag, 0, 0);
}

inline void iput_block(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    //iput_block_ml(buf, tag, nA, iA, jA, eaA);
    iput_block_line(buf, tag, nA, iA, jA, eaA);
}

//#define iputb_block(buf, tag, nA, iA, jA, eaA) iputb_block_line(buf, tag, nA, iA, jA, eaA)
inline void iputb_block(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    //iputb_block_ml(buf, tag, nA, iA, jA, eaA);
    iputb_block_line(buf, tag, nA, iA, jA, eaA);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
// 列方向キャッシュ
/////////////////////////////////////////////////////////////////////////////////////////////////

inline void colcache_init(int nA)
{
    int i;
    vector unsigned int vzero = spu_splats(0u);
    gcol = 0;
    gcolcache_size = (nA+NUMBER_OF_SPES-1)/NUMBER_OF_SPES;
    if(gcolcache_size > COLCACHE_SIZE) {
        gcolcache_size = COLCACHE_SIZE;
    }

    for(i = 0; i < gcolcache_size; i++) {
        vcolcachevalid[i] = vzero;
    }
}

inline void colcache_next(int nA, eaddr_t eaA)
{
    int i;
    vector unsigned int vzero = spu_splats(0u);

    for(i = 0; i < gcolcache_size; i++) {
        if(spu_extract(vcolcachevalid[i], 0)) {
             iput_block(BLOCK_COLCACHE+i, TAG_SYNC, nA, i*NUMBER_OF_SPES+speid, gcol, eaA);
        }
        vcolcachevalid[i] = vzero;
    }

    gcol += 1;

    dma_wait(TAG_SYNC);
}

inline void colcache_sync(int nA, eaddr_t eaA)
{
    int i;
    vector unsigned int vzero = spu_splats(0u);

    for(i = 0; i < gcolcache_size; i++) {
        if(spu_extract(vcolcachevalid[i], 0)) {
             iput_block(BLOCK_COLCACHE+i, TAG_SYNC, nA, i*NUMBER_OF_SPES+speid, gcol, eaA);
        }
        vcolcachevalid[i] = vzero;
    }
    dma_wait(TAG_SYNC);
}

// 前提条件: (iA%NUMBER_OF_SPES==speid)
// まずキャッシュからブロックを探す。
// 無ければメインメモリから転送し、可能ならばキャッシュする。
// 戻り値は実際にデータが格納されているバッファのインデックス
int colcache_iget_block(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    int index = iA/NUMBER_OF_SPES;
    vector unsigned int vvalid = spu_splats(1u);

    if(index < gcolcache_size) {
        // キャッシュ可
        if(spu_extract(vcolcachevalid[index], 0) == 0) {
            // キャッシュなし
            iget_block(BLOCK_COLCACHE+index, tag, nA, iA, jA, eaA);
            vcolcachevalid[index] = vvalid;
        }
        return BLOCK_COLCACHE+index;
    } else {
        // キャッシュ不可
        iget_block(buf, tag, nA, iA, jA, eaA);
        return buf;
    }
}

// 前提条件: (iA%NUMBER_OF_SPES==speid), 
//           以前に同じブロックに対してcolcache_iget_block関数を呼び出したことがある
// キャッシュに入っていればメインメモリまで転送する必要の無いもの
inline void colcache_iputb_block(int buf, int tag, int nA, int iA, int jA, eaddr_t eaA)
{
    int index = iA/NUMBER_OF_SPES;
    if(index >= gcolcache_size) {
        iputb_block(buf, tag, nA, iA, jA, eaA);
    }
}

// 前提条件: (iA%NUMBER_OF_SPES==speid), 列は現在分解中のもの
// 戻り値: ブロックのインデックス、キャッシュされていないときは-1
inline int colcache_get_index(int iA)
{
    int index = iA/NUMBER_OF_SPES;
    if(index < gcolcache_size) {
        if(spu_extract(vcolcachevalid[index], 0)) {
            return BLOCK_COLCACHE+index;
        }
    }

    return -1;
}

inline void colcache_invalidate(int iA)
{
    vector unsigned int vzero = spu_splats(0u);

    int index = iA/NUMBER_OF_SPES;
    vcolcachevalid[index] = vzero;
}

inline void colcache_invalidate_all()
{
    int i;
    vector unsigned int vzero = spu_splats(0u);

    for(i = 0; i < gcolcache_size; i++) {
        vcolcachevalid[i] = vzero;
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////
// 行の交換
/////////////////////////////////////////////////////////////////////////////////////////////////

void swap_igetb_block(int buf, int tag, int nA, int perm, int count, int col, eaddr_t eaA)
{
    int i;
    unsigned int line;
    unsigned int iA;
    unsigned int lineA;
    eaddr_t eaLine;

    for(i = 0; i < count; i++) {
        line = lsperm[perm][i];

        iA = line / BLOCK_SIZE;
        lineA = line - iA*BLOCK_SIZE;
        eaLine = cal_ea_block(nA, iA, col, eaA) + lineA*BLOCK_SIZE*sizeof(float);

        mlget[buf][i].notify = 0;
        mlget[buf][i].reserved = 0;
        mlget[buf][i].size = BLOCK_SIZE*sizeof(float);
        mlget[buf][i].eal = eaLine;
    }

    mfc_getlb(lsblock[buf], 0, mlget[buf], sizeof(mfc_list_element_t)*count, tag, 0, 0);
}

void swap_iputb_block(int buf, int tag, int nA, int perm, int count, int col, eaddr_t eaA)
{
    int i;
    unsigned int line;
    unsigned int iA;
    unsigned int lineA;
    eaddr_t eaLine;

    for(i = 0; i <count; i++) {
        line = lsperm[perm][i];

        iA = line / BLOCK_SIZE;
        lineA = line - iA*BLOCK_SIZE;
        eaLine = cal_ea_block(nA, iA, col, eaA) + lineA*BLOCK_SIZE*sizeof(float);

        mlput[buf][i].notify = 0;
        mlput[buf][i].reserved = 0;
        mlput[buf][i].size = BLOCK_SIZE*sizeof(float);
        mlput[buf][i].eal = eaLine;
    }

    mfc_putlb(lsblock[buf], 0, mlput[buf], sizeof(mfc_list_element_t)*count, tag, 0, 0);
}

void swap_init_perm(int iA)
{
    vector unsigned int vcnt0 = { 0, 1, 2, 3, };
    vector unsigned int vcnt1 = { 4, 5, 6, 7, };
    vector unsigned int vcnt2 = { 8, 9, 10, 11, };
    vector unsigned int vcnt3 = { 12, 13, 14, 15, };
    vector unsigned int vcnt4 = { 16, 17, 18, 19, };
    vector unsigned int vcnt5 = { 20, 21, 22, 23, };
    vector unsigned int vcnt6 = { 24, 25, 26, 27, };
    vector unsigned int vcnt7 = { 28, 29, 30, 31, };
    vector unsigned int vperm0;
    vector unsigned int vperm1;
    vector unsigned int vperm2;
    vector unsigned int vperm3;
    vector unsigned int vperm4;
    vector unsigned int vperm5;
    vector unsigned int vperm6;
    vector unsigned int vperm7;
    unsigned int base = iA*BLOCK_SIZE;

    gswap_pvcnt = 0;

    vperm0 = spu_splats(base);
    vperm1 = spu_splats(base);
    vperm2 = spu_splats(base);
    vperm3 = spu_splats(base);
    vperm4 = spu_splats(base);
    vperm5 = spu_splats(base);
    vperm6 = spu_splats(base);
    vperm7 = spu_splats(base);

    vperm0 = spu_add(vperm0, vcnt0);
    vperm1 = spu_add(vperm1, vcnt1);
    vperm2 = spu_add(vperm2, vcnt2);
    vperm3 = spu_add(vperm3, vcnt3);
    vperm4 = spu_add(vperm4, vcnt4);
    vperm5 = spu_add(vperm5, vcnt5);
    vperm6 = spu_add(vperm6, vcnt6);
    vperm7 = spu_add(vperm7, vcnt7);

    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][ 0] = vperm0;
    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][ 4] = vperm1;
    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][ 8] = vperm2;
    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][12] = vperm3;
    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][16] = vperm4;
    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][20] = vperm5;
    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][24] = vperm6;
    *(vector unsigned int*)&lsperm[PERM_SWAP_TGTEMP][28] = vperm7;

    /*int i;
    gswap_pvcnt = 0;
    for(i = 0; i < BLOCK_SIZE; i++) {
        lsperm[PERM_SWAP_TGTEMP][i] = i+iA*BLOCK_SIZE;
    }*/
}

void swap_set_perm(int target, int pivot)
{
    int i;
    int ta = target % BLOCK_SIZE;
    int pa;
    int temp;

    if(target/BLOCK_SIZE == pivot/BLOCK_SIZE) {
        pa = pivot % BLOCK_SIZE;
        temp = lsperm[PERM_SWAP_TGTEMP][ta];
        lsperm[PERM_SWAP_TGTEMP][ta] = lsperm[PERM_SWAP_TGTEMP][pa];
        lsperm[PERM_SWAP_TGTEMP][pa] = temp;        
    } else {
        for(i = 0; i < gswap_pvcnt; i++) {
            if(pivot == lsperm[PERM_SWAP_PIVOT][i]) {
                temp = lsperm[PERM_SWAP_PVTEMP][i];
                lsperm[PERM_SWAP_PVTEMP][i] = lsperm[PERM_SWAP_TGTEMP][ta];
                lsperm[PERM_SWAP_TGTEMP][ta] = temp;
                return;
            }
        }

        lsperm[PERM_SWAP_PIVOT][gswap_pvcnt] = pivot;
        lsperm[PERM_SWAP_PVTEMP][gswap_pvcnt] = lsperm[PERM_SWAP_TGTEMP][ta];
        lsperm[PERM_SWAP_TGTEMP][ta] = pivot;
        gswap_pvcnt++;
    }
}

void swap_begin(int nA, int iA, eaddr_t eaA)
{
    gswap_nA = nA;
    gswap_iA = iA;
    gswap_skip = iA;
    gswap_nxtdecom = iA+1;
    gswap_eaA = eaA;

    gswap_col = speid;
    if(gswap_col == gswap_skip || gswap_col == gswap_nxtdecom) {
        gswap_col += NUMBER_OF_SPES;
    }
#if NUMBER_OF_SPES == 1
    if(gswap_col == gswap_nxtdecom) {
        gswap_col += NUMBER_OF_SPES;
    }
#endif

    gswap_tag = TAG_SWAP;
    gswap_tbuf = BLOCK_TARGET + gswap_tag - TAG_SWAP;
    gswap_pbuf = BLOCK_PIVOT + gswap_tag - TAG_SWAP;

    // 次に分解する列は読み込みが発生するため先に交換する
    if(is_assigned(gswap_nxtdecom) && gswap_nxtdecom < nA) {
        swap_igetb_block(gswap_tbuf, gswap_tag, gswap_nA, PERM_SWAP_TGTEMP, BLOCK_SIZE, gswap_nxtdecom, gswap_eaA);
        swap_igetb_block(gswap_pbuf, gswap_tag, gswap_nA, PERM_SWAP_PVTEMP, gswap_pvcnt, gswap_nxtdecom, gswap_eaA);

        iputb_block(gswap_tbuf, gswap_tag, gswap_nA, gswap_iA, gswap_nxtdecom, gswap_eaA);
        swap_iputb_block(gswap_pbuf, gswap_tag, gswap_nA, PERM_SWAP_PIVOT, gswap_pvcnt, gswap_nxtdecom, gswap_eaA);
        dma_wait(gswap_tag);
    }
}

void swap_continue_sync()
{
    if(gswap_col >= gswap_nA) {
        return;
    }

    gswap_tag = ((gswap_tag+1) & 1) + TAG_SWAP;
    gswap_tbuf = BLOCK_TARGET + gswap_tag - TAG_SWAP;
    gswap_pbuf = BLOCK_PIVOT + gswap_tag - TAG_SWAP;

    dma_wait(TAG_SYNC);
    swap_igetb_block(gswap_tbuf, TAG_SYNC, gswap_nA, PERM_SWAP_TGTEMP, BLOCK_SIZE, gswap_col, gswap_eaA);
    swap_igetb_block(gswap_pbuf, TAG_SYNC, gswap_nA, PERM_SWAP_PVTEMP, gswap_pvcnt, gswap_col, gswap_eaA);

    iputb_block(gswap_tbuf, TAG_SYNC, gswap_nA, gswap_iA, gswap_col, gswap_eaA);
    swap_iputb_block(gswap_pbuf, TAG_SYNC, gswap_nA, PERM_SWAP_PIVOT, gswap_pvcnt, gswap_col, gswap_eaA);

    gswap_col += NUMBER_OF_SPES;
    if(gswap_col == gswap_skip || gswap_col == gswap_nxtdecom) {
        gswap_col += NUMBER_OF_SPES;
    }
#if NUMBER_OF_SPES == 1
    if(gswap_col == gswap_nxtdecom) {
        gswap_col += NUMBER_OF_SPES;
    }
#endif
}

void swap_continue()
{
    if(gswap_col >= gswap_nA) {
        return;
    }

    gswap_tag = ((gswap_tag+1) & 1) + TAG_SWAP;
    gswap_tbuf = BLOCK_TARGET + gswap_tag - TAG_SWAP;
    gswap_pbuf = BLOCK_PIVOT + gswap_tag - TAG_SWAP;

    dma_wait(gswap_tag);
    swap_igetb_block(gswap_tbuf, gswap_tag, gswap_nA, PERM_SWAP_TGTEMP, BLOCK_SIZE, gswap_col, gswap_eaA);
    swap_igetb_block(gswap_pbuf, gswap_tag, gswap_nA, PERM_SWAP_PVTEMP, gswap_pvcnt, gswap_col, gswap_eaA);

    iputb_block(gswap_tbuf, gswap_tag, gswap_nA, gswap_iA, gswap_col, gswap_eaA);
    swap_iputb_block(gswap_pbuf, gswap_tag, gswap_nA, PERM_SWAP_PIVOT, gswap_pvcnt, gswap_col, gswap_eaA);

    gswap_col += NUMBER_OF_SPES;
    if(gswap_col == gswap_skip || gswap_col == gswap_nxtdecom) {
        gswap_col += NUMBER_OF_SPES;
    }
#if NUMBER_OF_SPES == 1
    if(gswap_col == gswap_nxtdecom) {
        gswap_col += NUMBER_OF_SPES;
    }
#endif
}

#define swap_wait_all() do { dma_wait(TAG_SWAP); dma_wait(TAG_SWAP+1); } while(0)
//inline void swap_wait_all()
//{
//    dma_wait(TAG_SWAP);
//    dma_wait(TAG_SWAP+1);
//}

// 直前の交換の終了を待つ
#define swap_wait() do { dma_wait(gswap_tag); } while(0)
//inline void swap_wait()
//{
//    dma_wait(gswap_tag);
//}

inline void swap_rest()
{
    dma_wait(TAG_SYNC);
    while(gswap_col < gswap_nA) {
        swap_continue();
    }
}

void swap_diag(int dbuf, int perm, int target, int pivot, int nA, int iA, eaddr_t eaA, eaddr_t eaP)
{
    int index;
    int temp;
    int tA, pivotA;
    int ta, pivota;
    int ja;
    float ftemp;
    int spepivot;

    swap_set_perm(target, pivot);

    tA = target / BLOCK_SIZE;
    pivotA = pivot / BLOCK_SIZE;
    ta = target % BLOCK_SIZE;
    pivota = pivot % BLOCK_SIZE;

    //spe_printf("swap %d <-> %d\n", target, pivot);

    *(vector float*)&lsuline[ULINE_SWAP][ 0] = *(vector float*)&lsblock[dbuf][ta][ 0];
    *(vector float*)&lsuline[ULINE_SWAP][ 4] = *(vector float*)&lsblock[dbuf][ta][ 4];
    *(vector float*)&lsuline[ULINE_SWAP][ 8] = *(vector float*)&lsblock[dbuf][ta][ 8];
    *(vector float*)&lsuline[ULINE_SWAP][12] = *(vector float*)&lsblock[dbuf][ta][12];
    *(vector float*)&lsuline[ULINE_SWAP][16] = *(vector float*)&lsblock[dbuf][ta][16];
    *(vector float*)&lsuline[ULINE_SWAP][20] = *(vector float*)&lsblock[dbuf][ta][20];
    *(vector float*)&lsuline[ULINE_SWAP][24] = *(vector float*)&lsblock[dbuf][ta][24];
    *(vector float*)&lsuline[ULINE_SWAP][28] = *(vector float*)&lsblock[dbuf][ta][28];

    if(pivot == target) {
        return;
    }

    spepivot = pivotA % NUMBER_OF_SPES;
    if(spepivot == speid) {
        if(pivotA == tA) {
            temp = lsperm[perm][ta];
            lsperm[perm][ta] = lsperm[perm][pivota];
            lsperm[perm][pivota] = temp;

            for(ja = 0; ja < BLOCK_SIZE; ja++) {
                ftemp = lsblock[dbuf][ta][ja];
                lsblock[dbuf][ta][ja] = lsblock[dbuf][pivota][ja];
                lsblock[dbuf][pivota][ja] = ftemp;
            }
        } else {
            dma_wait(TAG_SYNC);
            iget_perm(PERM_PIVOT, TAG_PERM, pivotA, eaP);

            index = colcache_get_index(pivotA);
            if(index == -1) {
                iget_line_p(lsblock[dbuf][ta], TAG_SYNC, nA, pivot, iA, eaA);
                dma_wait(TAG_SYNC);
                iput_line_p(lsuline[ULINE_SWAP], TAG_SYNC, nA, pivot, iA, eaA);
            } else {
                for(ja = 0; ja < BLOCK_SIZE; ja++) {
                    lsblock[dbuf][ta][ja] = lsblock[index][pivota][ja];
                    lsblock[index][pivota][ja] = lsuline[ULINE_SWAP][ja];
                }
            }

            dma_wait(TAG_PERM);
            temp = lsperm[perm][ta];
            lsperm[perm][ta] = lsperm[PERM_PIVOT][pivota];
            lsperm[PERM_PIVOT][pivota] = temp;

            iput_perm(PERM_PIVOT, TAG_SYNC, pivotA, eaP);
        }
    } else {
        // ピボット候補の中から選んで取得する
        mfc_get(lsblock[dbuf][ta], ealsuline[spepivot], sizeof(lsblock[dbuf][ta]), TAG_PVGET, 0, 0);

        // 行の要素をspepivotに送る
        mfc_put(lsuline[ULINE_SWAP], ealsuline[spepivot]+BLOCK_SIZE*sizeof(float), sizeof(lsuline[ULINE_SWAP]), TAG_SYNC, 0, 0);

        dma_wait(TAG_PERM);
        iget_perm(PERM_PIVOT, TAG_PERM, pivotA, eaP);

        dma_wait(TAG_PERM);
        temp = lsperm[perm][ta];
        lsperm[perm][ta] = lsperm[PERM_PIVOT][pivota];
        lsperm[PERM_PIVOT][pivota] = temp;

        iput_perm(PERM_PIVOT, TAG_PERM, pivotA, eaP);

        dma_wait(TAG_PVGET);
    }
}

void swap_down(int target, int pivot, int nA, int iA, eaddr_t eaA)
{
    int i;
    int index;
    int pivotA;
    int pivota;

    swap_set_perm(target, pivot);

    pivotA = pivot / BLOCK_SIZE;
    pivota = pivot % BLOCK_SIZE;
    if(pivotA%NUMBER_OF_SPES == speid) {
        index = colcache_get_index(pivotA);
        if(index == -1) {
            iput_line_p(lsuline[ULINE_SWAP], TAG_SYNC, nA, pivot, iA, eaA);
        } else {
            for(i = 0; i < BLOCK_SIZE; i++) {
                lsblock[index][pivota][i] = lsuline[ULINE_SWAP][i];
            }
        }
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////
// LU Decomposition
/////////////////////////////////////////////////////////////////////////////////////////////////

void pivot_selection_diag_vfirst(int *oapivot, float *oamax, int dbuf, int iv)
{
    float (*a)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[dbuf];
    int apivot = 0;
    float amax = 0.0f;
    int ia;
    float f;
    int pos = iv*INNER_BLOCK_SIZE;

    for(ia = pos; ia < BLOCK_SIZE; ia++) {
        f = fabs(a[ia][pos]);
        if(f > amax) {
            apivot = ia;
            amax = f;
        }
    }

    *oapivot = apivot;
    *oamax = amax;

    //spe_printf("vf diag pivot = %d, max = %.2f\n", apivot, amax);
}

void pivot_selection_down_vfirst_inner(int *oapivot, float *oamax, int dbuf, int iv)
{
    float (*a)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[dbuf];
    int apivot = 0;
    float amax = 0.0f;
    int ka;
    float f;
    int ivline;
    vector float va0, va1, va2, va3;
    vector float va4, va5, va6, va7;
    vector unsigned int vcmp0, vcmp1, vcmp2, vcmp3;
    vector unsigned int vkaini0 = { 0, 0, 0, 0, };
    vector unsigned int vkaini1 = { 1, 1, 1, 1, };
    vector unsigned int vkaini2 = { 2, 2, 2, 2, };
    vector unsigned int vkaini3 = { 3, 3, 3, 3, };
    vector unsigned int vkaini4 = { 4, 4, 4, 4, };
    vector unsigned int vkaini5 = { 5, 5, 5, 5, };
    vector unsigned int vkaini6 = { 6, 6, 6, 6, };
    vector unsigned int vkaini7 = { 7, 7, 7, 7, };
    vector unsigned int vka0, vka1, vka2, vka3; 
    vector unsigned int vka4, vka5, vka6, vka7;

    ivline = iv*4;

    for(ka = 0; ka < BLOCK_SIZE; ka += 8) {
        // ピボットを決める
        vka0 = vkaini0;
        vka1 = vkaini1;
        vka2 = vkaini2;
        vka3 = vkaini3;
        vka4 = vkaini4;
        vka5 = vkaini5;
        vka6 = vkaini6;
        vka7 = vkaini7;

        va0 = *(vector float*)&a[ka  ][ivline];
        va1 = *(vector float*)&a[ka+1][ivline];
        va2 = *(vector float*)&a[ka+2][ivline];
        va3 = *(vector float*)&a[ka+3][ivline];
        va4 = *(vector float*)&a[ka+4][ivline];
        va5 = *(vector float*)&a[ka+5][ivline];
        va6 = *(vector float*)&a[ka+6][ivline];
        va7 = *(vector float*)&a[ka+7][ivline];

        vcmp0 = spu_cmpabsgt(va0, va1);
        vcmp1 = spu_cmpabsgt(va2, va3);
        vcmp2 = spu_cmpabsgt(va4, va5);
        vcmp3 = spu_cmpabsgt(va6, va7);
        va0 = spu_sel(va1, va0, vcmp0);
        va2 = spu_sel(va3, va2, vcmp1);
        va4 = spu_sel(va5, va4, vcmp2);
        va6 = spu_sel(va7, va6, vcmp3);
        vka0 = spu_sel(vka1, vka0, vcmp0);
        vka2 = spu_sel(vka3, vka2, vcmp1);
        vka4 = spu_sel(vka5, vka4, vcmp2);
        vka6 = spu_sel(vka7, vka6, vcmp3);

        vcmp0 = spu_cmpabsgt(va0, va2);
        vcmp2 = spu_cmpabsgt(va4, va6);
        va1 = spu_sel(va2, va0, vcmp0);
        va3 = spu_sel(va6, va4, vcmp2);
        vka1 = spu_sel(vka2, vka0, vcmp0);
        vka3 = spu_sel(vka6, vka4, vcmp2);

        vcmp1 = spu_cmpabsgt(va1, va3);
        va0 = spu_sel(va3, va1, vcmp1);
        vka0 = spu_sel(vka3, vka1, vcmp1);

        f = fabs(spu_extract(va0, 0));
        if(f > amax) {
            apivot = spu_extract(vka0, 0) + ka;
            amax = f;
        }
    }

    *oapivot = apivot;
    *oamax = amax;

    //spe_printf("vf block pivot = %d, max = %.2f\n", apivot, amax);
}

void pivot_selection_down_vfirst(int *oApivot, float *oAmax, int nA, int iA, int iv, eaddr_t eaA)
{
    int i;
    int jA;
    int Apivot = 0;
    float Amax = 0.0f;
    int apivot = 0;
    float amax = 0.0f;
    int ltag = 0;
    int lbuf;

    jA = (iA+1)/NUMBER_OF_SPES*NUMBER_OF_SPES+speid;
    if(jA < iA+1) {
        jA += NUMBER_OF_SPES;
    }

    for(; jA < nA; jA += NUMBER_OF_SPES) {
        lbuf = BLOCK_L;
        lbuf = colcache_iget_block(lbuf, ltag, nA, jA, iA, eaA);

        dma_wait(ltag);
        pivot_selection_down_vfirst_inner(&apivot, &amax, lbuf, iv);
        if(amax > Amax) {
            Apivot = apivot + jA*BLOCK_SIZE;
            Amax = amax;
            // ピボットの候補は退避
            for(i = 0; i < BLOCK_SIZE; i++) {
                lsuline[ULINE_TARGET][i] = lsblock[lbuf][apivot][i];
            }
        }
    }

    *oApivot = Apivot;
    *oAmax = Amax;
}

void send_U_and_pivot(int ubuf, int Apivot, int iA, int iv, int ia)
{
    int i;
    float (*u)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[ubuf];
    usyncdata sync = { { 0, 0, {0}, 0, }, };

    // 他のSPEにUの(iv*4+ia)行を送る
    dma_wait(TAG_SYNC);
    for(i = 0; i < NUMBER_OF_SPES; i++) {
        if(i != speid) {
            mfc_put(u[iv*4+ia], ealsuline[i], sizeof(u[iv*4+ia]), TAG_SYNC, 0, 0);
        }
    }

    sync.s.line = ia+iv*4+iA*BLOCK_SIZE;
    sync.s.p.pivot = Apivot;
    send_signal_all(sync);
}

void receive_U_and_pivot(int *opivot, int ubuf, int iA, int iv, int ia)
{
    int i;

    // 対角担当のSPEからUの(iv*4+ia)行を受け取る
#if defined READ_DECREMENTER
    s = spu_read_decrementer();
    while(lssignal[SYNC_SIGNAL].s.line < ia+iv*4+iA*BLOCK_SIZE) {
        t = spu_read_decrementer();
        if(s-t > PRINT_CYCLE) {
            spe_printf("SPE(%d): too late!(wait U line) step = %d, line(%d) = %d, expected %d\n", speid, gstep, SYNC_SIZE-1, lssignal[SYNC_SIGNAL].s.line, ia);
            s = t;
        }
    }
#else
    while(lssignal[SYNC_SIGNAL].s.line < ia+iv*4+iA*BLOCK_SIZE)  {
        ;
    }
#endif

    *opivot = lssignal[SYNC_SIGNAL].s.p.pivot;

    for(i = 0; i < BLOCK_SIZE; i++) {
        lsblock[ubuf][ia+iv*4][i] = lsuline[ULINE_TARGET][i];
    }
}

void cal_diag_right(int dbuf, int iv, int ia)
{
    int ja;
    int ivline;
    volatile float(*a)[BLOCK_SIZE] = lsblock[dbuf];
    vector float va, vas;
    vector signed int via;
    vector signed int vcnt = { 0, 1, 2, 3, };
    vector unsigned char vsplats0 = { 0, 1, 2, 3 ,0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, };
    vector unsigned char vsplats1 = { 4, 5, 6, 7 ,4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, };
    vector unsigned char vsplats2 = { 8, 9, 10, 11 ,8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, };
    vector unsigned int vcmp;
    int diag;
    vector float vinva;
    vector float vlv0;
    vector float vl0, vl1, vl2;
    vector float vu0, vu1, vu2;

    // 他のSPEに送る行の更新
    // 右側の要素を計算する
    ivline = iv*4;
    diag = ivline+ia;
    via = spu_splats(ia);
    vinva = spu_splats(1.0f/a[diag][diag]);

    va = *(vector float*)&a[diag][ivline];
    vas = spu_mul(va, vinva);

    // diag+1列より左側の部分は元の値に戻す
    vcmp = spu_cmpgt(vcnt, via);
    va = spu_sel(va, vas, vcmp);
    *(vector float*)&a[diag][ivline] = va;

    if(ia == 0) {
        for(ja = ivline+4; ja < BLOCK_SIZE; ja += 4) {
            va = *(vector float*)&a[diag][ja];
            va = spu_mul(va, vinva);
            *(vector float*)&a[diag][ja] = va;
        }
    } else if(ia == 1) {
        vlv0 = *(vector float*)&a[ivline+1][ivline];
        vl0 = spu_shuffle(vlv0, vlv0, vsplats0);

        for(ja = ivline+4; ja < BLOCK_SIZE; ja += 4) {
            va = *(vector float*)&a[diag][ja];
            vu0 = *(vector float*)&a[ivline][ja];
            va = spu_nmsub(vl0, vu0, va);
            va = spu_mul(va, vinva);
            *(vector float*)&a[diag][ja] = va;
        }
    } else if(ia == 2) {
        vlv0 = *(vector float*)&a[ivline+2][ivline];
        vl0 = spu_shuffle(vlv0, vlv0, vsplats0);
        vl1 = spu_shuffle(vlv0, vlv0, vsplats1);

        for(ja = ivline+4; ja < BLOCK_SIZE; ja += 4) {
            va = *(vector float*)&a[diag][ja];
            vu0 = *(vector float*)&a[ivline  ][ja];
            vu1 = *(vector float*)&a[ivline+1][ja];
            va = spu_nmsub(vl0, vu0, va);
            va = spu_nmsub(vl1, vu1, va);
            va = spu_mul(va, vinva);
            *(vector float*)&a[diag][ja] = va;
        }
    } else {
        vlv0 = *(vector float*)&a[ivline+3][ivline];
        vl0 = spu_shuffle(vlv0, vlv0, vsplats0);
        vl1 = spu_shuffle(vlv0, vlv0, vsplats1);
        vl2 = spu_shuffle(vlv0, vlv0, vsplats2);

        for(ja = ivline+4; ja < BLOCK_SIZE; ja += 4) {
            va = *(vector float*)&a[diag][ja];
            vu0 = *(vector float*)&a[ivline  ][ja];
            vu1 = *(vector float*)&a[ivline+1][ja];
            vu2 = *(vector float*)&a[ivline+2][ja];
            va = spu_nmsub(vl0, vu0, va);
            va = spu_nmsub(vl1, vu1, va);
            va = spu_nmsub(vl2, vu2, va);
            va = spu_mul(va, vinva);
            *(vector float*)&a[diag][ja] = va;
        }
    }
}

void cal_diag_iline_and_pivot(int *oapivot, float *oamax, int dbuf, int iv, int ia)
{
    int ka;
    int vline;
    volatile float(*a)[BLOCK_SIZE] = lsblock[dbuf];
    int apivot = 0;
    float amax = 0.0f;
    float f;
    vector float vu0;
    vector float va0, va1, va2, va3;
    vector float vl0, vl1, vl2, vl3;
    vector float vas0, vas1, vas2, vas3;
    vector signed int via;
    vector signed int vcnt = { 0, 1, 2, 3, };
    vector unsigned char viasplats = { 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, };
    vector unsigned char vsplats0 = { 0, 1, 2, 3 ,0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, };
    vector unsigned char vsplats1 = { 4, 5, 6, 7 ,4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, };
    vector unsigned char vsplats2 = { 8, 9, 10, 11 ,8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, };
    vector unsigned char vsplats3 = { 12, 13, 14, 15 ,12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, };
    vector unsigned char vtemp;
    vector unsigned int vcmp;
    vector unsigned int vcmp0, vcmp1, vcmp2, vcmp3;
    vector unsigned int vpvcmp0, vpvcmp1;
    vector signed int vka0, vka1, vka2, vka3;
    vector float vgt0, vgt1;
    vector float vmax;
    vector signed int vpivot;
    vector signed int vpv0, vpv1;
    int pvpos;

    vtemp = spu_splats((unsigned char)(ia*4));
    viasplats = spu_or(viasplats, vtemp);

    // 16バイト境界で読み込んだ後そのまま計算、余計な部分は元に戻す
    pvpos = ia+1;
    vline = iv*4;
    via = spu_splats(ia);
    vcmp = spu_cmpgt(vcnt, via);

    va0 = *(vector float*)&a[vline  ][vline];
    va1 = *(vector float*)&a[vline+1][vline];
    va2 = *(vector float*)&a[vline+2][vline];
    va3 = *(vector float*)&a[vline+3][vline];
    vl0 = spu_splats(a[vline  ][vline+ia]);
    vl1 = spu_splats(a[vline+1][vline+ia]);
    vl2 = spu_splats(a[vline+2][vline+ia]);
    vl3 = spu_splats(a[vline+3][vline+ia]);
    vu0 = *(vector float*)&a[vline+ia][vline];

    vas0 = spu_nmsub(vl0, vu0, va0);
    vas1 = spu_nmsub(vl1, vu0, va1);
    vas2 = spu_nmsub(vl2, vu0, va2);
    vas3 = spu_nmsub(vl3, vu0, va3);

    vcmp0 = spu_shuffle(vcmp, vcmp, vsplats0);
    vcmp1 = spu_shuffle(vcmp, vcmp, vsplats1);
    vcmp2 = spu_shuffle(vcmp, vcmp, vsplats2);
    vcmp3 = spu_shuffle(vcmp, vcmp, vsplats3);

    vcmp0 = spu_and(vcmp0, vcmp);
    vcmp1 = spu_and(vcmp1, vcmp);
    vcmp2 = spu_and(vcmp2, vcmp);
    vcmp3 = spu_and(vcmp3, vcmp);

    va0 = spu_sel(va0, vas0, vcmp0);
    va1 = spu_sel(va1, vas1, vcmp1);
    va2 = spu_sel(va2, vas2, vcmp2);
    va3 = spu_sel(va3, vas3, vcmp3);

    *(vector float*)&a[vline  ][vline] = va0;
    *(vector float*)&a[vline+1][vline] = va1;
    *(vector float*)&a[vline+2][vline] = va2;
    *(vector float*)&a[vline+3][vline] = va3;

    va0 = (vector float)spu_and(vcmp0, (vector unsigned int)va0);
    va1 = (vector float)spu_and(vcmp1, (vector unsigned int)va1);
    va2 = (vector float)spu_and(vcmp2, (vector unsigned int)va2);
    va3 = (vector float)spu_and(vcmp3, (vector unsigned int)va3);

    vpvcmp0 = spu_cmpabsgt(va0, va1);
    vpvcmp1 = spu_cmpabsgt(va2, va3);

    vka0 = spu_splats(vline  );
    vka1 = spu_splats(vline+1);
    vka2 = spu_splats(vline+2);
    vka3 = spu_splats(vline+3);

    vgt0 = spu_sel(va1, va0, vpvcmp0);
    vpv0 = spu_sel(vka1, vka0, vpvcmp0);
    vgt1 = spu_sel(va3, va2, vpvcmp1);
    vpv1 = spu_sel(vka3, vka2, vpvcmp1);

    vpvcmp0 = spu_cmpabsgt(vgt0, vgt1);

    vmax = spu_sel(vgt1, vgt0, vpvcmp0);
    vpivot = spu_sel(vpv1, vpv0, vpvcmp0);

    apivot = spu_extract(vpivot, pvpos);
    amax = (float)fabs(spu_extract(vmax, pvpos));

    for(ka = vline+4; ka < BLOCK_SIZE; ka += 4) {
        va0 = *(vector float*)&a[ka  ][vline];
        va1 = *(vector float*)&a[ka+1][vline];
        va2 = *(vector float*)&a[ka+2][vline];
        va3 = *(vector float*)&a[ka+3][vline];
        vl0 = spu_shuffle(va0, va0, viasplats);
        vl1 = spu_shuffle(va1, va1, viasplats);
        vl2 = spu_shuffle(va2, va2, viasplats);
        vl3 = spu_shuffle(va3, va3, viasplats);
        vu0 = *(vector float*)&a[vline+ia][vline];

        vas0 = spu_nmsub(vl0, vu0, va0);
        vas1 = spu_nmsub(vl1, vu0, va1);
        vas2 = spu_nmsub(vl2, vu0, va2);
        vas3 = spu_nmsub(vl3, vu0, va3);

        // ia+1列より左側の部分は元の値に戻す
        va0 = spu_sel(va0, vas0, vcmp);
        va1 = spu_sel(va1, vas1, vcmp);
        va2 = spu_sel(va2, vas2, vcmp);
        va3 = spu_sel(va3, vas3, vcmp);
        *(vector float*)&a[ka  ][vline] = va0;
        *(vector float*)&a[ka+1][vline] = va1;
        *(vector float*)&a[ka+2][vline] = va2;
        *(vector float*)&a[ka+3][vline] = va3;

        f = (float)fabs(spu_extract(va0, pvpos));
        if(f > amax) {
            apivot = ka;
            amax = f;
        }
        f = (float)fabs(spu_extract(va1, pvpos));
        if(f > amax) {
            apivot = ka+1;
            amax = f;
        }
        f = (float)fabs(spu_extract(va2, pvpos));
        if(f > amax) {
            apivot = ka+2;
            amax = f;
        }
        f = (float)fabs(spu_extract(va3, pvpos));
        if(f > amax) {
            apivot = ka+3;
            amax = f;
        }
    }

    *oapivot = apivot;
    *oamax = amax;

    //spe_printf("diag pivot = %d, max = %.2f\n", apivot, amax);
}

void cal_down_iline_and_pivot_inner(int *oapivot, float *oamax, int dbuf, int ubuf, int iv, int ia)
{
    int ka;
    int ivline;
    int pvpos;
    int posqw;
    float (*a)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[dbuf];
    float (*u)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[ubuf];
    int apivot = 0;
    float amax = 0.0f;
    vector float vu0;
    vector float va0, va1, va2, va3;
    vector float va4, va5, va6, va7;
    vector float vl0, vl1, vl2, vl3;
    vector float vl4, vl5, vl6, vl7;
    vector float vas0, vas1, vas2, vas3;
    vector float vas4, vas5, vas6, vas7;
    vector signed int via;
    vector signed int vcnt = { 0, 1, 2, 3, };
    vector unsigned int vcmp;
    vector unsigned char viasplats = { 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, };
    vector unsigned char vtemp;
    vector unsigned int vcmp0, vcmp1, vcmp2, vcmp3;
    vector unsigned int vkaini0 = { 0, 0, 0, 0, };
    vector unsigned int vkaini1 = { 1, 1, 1, 1, };
    vector unsigned int vkaini2 = { 2, 2, 2, 2, };
    vector unsigned int vkaini3 = { 3, 3, 3, 3, };
    vector unsigned int vkaini4 = { 4, 4, 4, 4, };
    vector unsigned int vkaini5 = { 5, 5, 5, 5, };
    vector unsigned int vkaini6 = { 6, 6, 6, 6, };
    vector unsigned int vkaini7 = { 7, 7, 7, 7, };
    vector unsigned int vka0, vka1, vka2, vka3;
    vector unsigned int vka4, vka5, vka6, vka7;
    float f;

    ivline = iv*4;
    via = spu_splats(ia);
    vcmp = spu_cmpgt(vcnt, via);
    pvpos = ia+1;
    posqw = pvpos*4;
    vtemp = spu_splats((unsigned char)(ia*4));
    viasplats = spu_or(viasplats, vtemp);
 
    for(ka = 0; ka < BLOCK_SIZE; ka += 8) {
        va0 = *(vector float*)&a[ka  ][ivline];
        va1 = *(vector float*)&a[ka+1][ivline];
        va2 = *(vector float*)&a[ka+2][ivline];
        va3 = *(vector float*)&a[ka+3][ivline];
        va4 = *(vector float*)&a[ka+4][ivline];
        va5 = *(vector float*)&a[ka+5][ivline];
        va6 = *(vector float*)&a[ka+6][ivline];
        va7 = *(vector float*)&a[ka+7][ivline];
        vl0 = spu_shuffle(va0, va0, viasplats);
        vl1 = spu_shuffle(va1, va1, viasplats);
        vl2 = spu_shuffle(va2, va2, viasplats);
        vl3 = spu_shuffle(va3, va3, viasplats);
        vl4 = spu_shuffle(va4, va4, viasplats);
        vl5 = spu_shuffle(va5, va5, viasplats);
        vl6 = spu_shuffle(va6, va6, viasplats);
        vl7 = spu_shuffle(va7, va7, viasplats);
        vu0 = *(vector float*)&u[ivline+ia][ivline];

        vas0 = spu_nmsub(vl0, vu0, va0);
        vas1 = spu_nmsub(vl1, vu0, va1);
        vas2 = spu_nmsub(vl2, vu0, va2);
        vas3 = spu_nmsub(vl3, vu0, va3);
        vas4 = spu_nmsub(vl4, vu0, va4);
        vas5 = spu_nmsub(vl5, vu0, va5);
        vas6 = spu_nmsub(vl6, vu0, va6);
        vas7 = spu_nmsub(vl7, vu0, va7);

        // ia+1列より左側の部分は元の値に戻す
        va0 = spu_sel(va0, vas0, vcmp);
        va1 = spu_sel(va1, vas1, vcmp);
        va2 = spu_sel(va2, vas2, vcmp);
        va3 = spu_sel(va3, vas3, vcmp);
        va4 = spu_sel(va4, vas4, vcmp);
        va5 = spu_sel(va5, vas5, vcmp);
        va6 = spu_sel(va6, vas6, vcmp);
        va7 = spu_sel(va7, vas7, vcmp);
        *(vector float*)&a[ka  ][ivline] = va0;
        *(vector float*)&a[ka+1][ivline] = va1;
        *(vector float*)&a[ka+2][ivline] = va2;
        *(vector float*)&a[ka+3][ivline] = va3;
        *(vector float*)&a[ka+4][ivline] = va4;
        *(vector float*)&a[ka+5][ivline] = va5;
        *(vector float*)&a[ka+6][ivline] = va6;
        *(vector float*)&a[ka+7][ivline] = va7;

        // ピボットを決める
        vka0 = vkaini0;
        vka1 = vkaini1;
        vka2 = vkaini2;
        vka3 = vkaini3;
        vka4 = vkaini4;
        vka5 = vkaini5;
        vka6 = vkaini6;
        vka7 = vkaini7;

        vcmp0 = spu_cmpabsgt(vas0, vas1);
        vcmp1 = spu_cmpabsgt(vas2, vas3);
        vcmp2 = spu_cmpabsgt(vas4, vas5);
        vcmp3 = spu_cmpabsgt(vas6, vas7);
        vas0 = spu_sel(vas1, vas0, vcmp0);
        vas2 = spu_sel(vas3, vas2, vcmp1);
        vas4 = spu_sel(vas5, vas4, vcmp2);
        vas6 = spu_sel(vas7, vas6, vcmp3);
        vka0 = spu_sel(vka1, vka0, vcmp0);
        vka2 = spu_sel(vka3, vka2, vcmp1);
        vka4 = spu_sel(vka5, vka4, vcmp2);
        vka6 = spu_sel(vka7, vka6, vcmp3);

        vcmp0 = spu_cmpabsgt(vas0, vas2);
        vcmp2 = spu_cmpabsgt(vas4, vas6);
        vas1 = spu_sel(vas2, vas0, vcmp0);
        vas3 = spu_sel(vas6, vas4, vcmp2);
        vka1 = spu_sel(vka2, vka0, vcmp0);
        vka3 = spu_sel(vka6, vka4, vcmp2);

        vcmp1 = spu_cmpabsgt(vas1, vas3);
        vas0 = spu_sel(vas3, vas1, vcmp1);
        vka0 = spu_sel(vka3, vka1, vcmp1);

        f = fabs(spu_extract(vas0, pvpos));
        if(f > amax) {
            apivot = spu_extract(vka0, pvpos) + ka;
            amax = f;
        }
    }

    *oapivot =apivot;
    *oamax = amax;

    //spe_printf("block pivot = %d, max = %.2f\n", apivot, amax);
}

void cal_down_iline_and_pivot(int *oApivot, float *oAmax, int ubuf, int nA, int iA, int iv, int ia, eaddr_t eaA)
{
    int i;
    int jA;
    int Apivot = 0;
    float Amax = 0.0f;
    int apivot = 0;
    float amax = 0.0f;
    int ltag = 0;
    int lbuf;

    jA = (iA+1)/NUMBER_OF_SPES*NUMBER_OF_SPES+speid;
    if(jA < iA+1) {
        jA += NUMBER_OF_SPES;
    }

    for(; jA < nA; jA += NUMBER_OF_SPES) {
        lbuf = BLOCK_L;
        lbuf = colcache_iget_block(lbuf, ltag, nA, jA, iA, eaA);

        dma_wait(ltag);
        cal_down_iline_and_pivot_inner(&apivot, &amax, lbuf, ubuf, iv, ia);

        if(amax > Amax) {
            Apivot = apivot + jA*BLOCK_SIZE;
            Amax = amax;
            // ピボットの候補は退避
            for(i = 0; i < BLOCK_SIZE; i++) {
                lsuline[ULINE_TARGET][i] = lsblock[lbuf][apivot][i];
            }
        }

        colcache_iputb_block(lbuf, ltag, nA, jA, iA, eaA);
    }

    *oApivot = Apivot;
    *oAmax = Amax;
}

void receive_pivot(int *oApivot, int Apivot, float Amax)
{
    int i;

    // 他のSPEからのシグナルを待つ
    for(i = 0; i < NUMBER_OF_SPES; i++) {
        if(i != speid) {
#if defined READ_DECREMENTER
            s = spu_read_decrementer();
            while(lssignal[i].s.line == -1) {
                t = spu_read_decrementer();
                if(s-t > PRINT_CYCLE) {
                    spe_printf("SPE(%d): too late!(wait pivot) step = %d, sig(%d) = %d\n", speid, gstep, i, lssignal[i].s.line);
                    s = t;
                }
            }
#else
            while(lssignal[i].s.line == -1) {
                ;
            }
#endif
            lsresult[i].v = lssignal[i].v;
            lssignal[i].s.line = -1;

            /*if(lsresult[i].s.p.max > Amax) {
                Apivot = lsresult[i].s.line;
                Amax = lsresult[i].s.p.max;
            }*/
        }
    }

    for(i = 0; i < NUMBER_OF_SPES; i++) {
        if(lsresult[i].s.p.max > Amax && i != speid) {
            Apivot = lsresult[i].s.line;
            Amax = lsresult[i].s.p.max;
        }
    }

    *oApivot = Apivot;
}

void send_pivot(int diagspe, int Apivot, float Amax)
{
    usyncdata signal = { { 0, 0, {0}, 0, }, };

    // 対角担当のSPEに情報を送る
    signal.s.line = Apivot;
    signal.s.p.max = Amax;
    dma_wait(TAG_SYNC);
    send_signal_to(diagspe, signal);
}

void cal_diag_down_right(int dbuf, int iv)
{
    int ja, ka;
    int ivline;
    float (*a)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[dbuf];
    vector float va0;
    vector float vlv0;
    vector float vl0, vl1, vl2, vl3;
    vector float vu0, vu1, vu2, vu3;
    vector unsigned char vsplats0 = { 0, 1, 2, 3 ,0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, };
    vector unsigned char vsplats1 = { 4, 5, 6, 7 ,4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, };
    vector unsigned char vsplats2 = { 8, 9, 10, 11 ,8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, };
    vector unsigned char vsplats3 = { 12, 13, 14, 15 ,12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, };

    ivline = iv*4;

    for(ka = ivline+4; ka < BLOCK_SIZE; ka++) {
        vlv0 = *(vector float*)&a[ka][ivline];
        vl0 = spu_shuffle(vlv0, vlv0, vsplats0);
        vl1 = spu_shuffle(vlv0, vlv0, vsplats1);
        vl2 = spu_shuffle(vlv0, vlv0, vsplats2);
        vl3 = spu_shuffle(vlv0, vlv0, vsplats3);

        for(ja = ivline+4; ja < BLOCK_SIZE; ja += 4) {
            va0 = *(vector float*)&a[ka][ja];
            vu0 = *(vector float*)&a[ivline  ][ja];
            vu1 = *(vector float*)&a[ivline+1][ja];
            vu2 = *(vector float*)&a[ivline+2][ja];
            vu3 = *(vector float*)&a[ivline+3][ja];
            va0 = spu_nmsub(vl0, vu0, va0);
            va0 = spu_nmsub(vl1, vu1, va0);
            va0 = spu_nmsub(vl2, vu2, va0);
            va0 = spu_nmsub(vl3, vu3, va0);
            *(vector float*)&a[ka][ja] = va0;
        }
    }
}

void cal_down_right_inner(int dbuf, int ubuf, int iv)
{
    int ja, ka;
    int ivline;
    float (*a)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[dbuf];
    float (*u)[BLOCK_SIZE] = (float(*)[BLOCK_SIZE])lsblock[ubuf];
    vector float va0, va1, va2, va3;
    vector float vlv0, vlv1, vlv2, vlv3;
    vector float vl00, vl10, vl20, vl30;
    vector float vl01, vl11, vl21, vl31;
    vector float vl02, vl12, vl22, vl32;
    vector float vl03, vl13, vl23, vl33;
    vector float vu0, vu1, vu2, vu3;
    vector unsigned char vsplats0 = { 0, 1, 2, 3 ,0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, };
    vector unsigned char vsplats1 = { 4, 5, 6, 7 ,4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, };
    vector unsigned char vsplats2 = { 8, 9, 10, 11 ,8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, };
    vector unsigned char vsplats3 = { 12, 13, 14, 15 ,12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, };

    ivline = iv*4;

    for(ka = 0; ka < BLOCK_SIZE; ka += 4) {
        vlv0 = *(vector float*)&a[ka  ][ivline];
        vl00 = spu_shuffle(vlv0, vlv0, vsplats0);
        vl01 = spu_shuffle(vlv0, vlv0, vsplats1);
        vl02 = spu_shuffle(vlv0, vlv0, vsplats2);
        vl03 = spu_shuffle(vlv0, vlv0, vsplats3);

        vlv1 = *(vector float*)&a[ka+1][ivline];
        vl10 = spu_shuffle(vlv1, vlv1, vsplats0);
        vl11 = spu_shuffle(vlv1, vlv1, vsplats1);
        vl12 = spu_shuffle(vlv1, vlv1, vsplats2);
        vl13 = spu_shuffle(vlv1, vlv1, vsplats3);

        vlv2 = *(vector float*)&a[ka+2][ivline];
        vl20 = spu_shuffle(vlv2, vlv2, vsplats0);
        vl21 = spu_shuffle(vlv2, vlv2, vsplats1);
        vl22 = spu_shuffle(vlv2, vlv2, vsplats2);
        vl23 = spu_shuffle(vlv2, vlv2, vsplats3);

        vlv3 = *(vector float*)&a[ka+3][ivline];
        vl30 = spu_shuffle(vlv3, vlv3, vsplats0);
        vl31 = spu_shuffle(vlv3, vlv3, vsplats1);
        vl32 = spu_shuffle(vlv3, vlv3, vsplats2);
        vl33 = spu_shuffle(vlv3, vlv3, vsplats3);

        for(ja = ivline+4; ja < BLOCK_SIZE; ja += 4) {
            va0 = *(vector float*)&a[ka  ][ja];
            va1 = *(vector float*)&a[ka+1][ja];
            va2 = *(vector float*)&a[ka+2][ja];
            va3 = *(vector float*)&a[ka+3][ja];
            vu0 = *(vector float*)&u[ivline  ][ja];
            vu1 = *(vector float*)&u[ivline+1][ja];
            vu2 = *(vector float*)&u[ivline+2][ja];
            vu3 = *(vector float*)&u[ivline+3][ja];

            va0 = spu_nmsub(vl00, vu0, va0);
            va0 = spu_nmsub(vl01, vu1, va0);
            va0 = spu_nmsub(vl02, vu2, va0);
            va0 = spu_nmsub(vl03, vu3, va0);

            va1 = spu_nmsub(vl10, vu0, va1);
            va1 = spu_nmsub(vl11, vu1, va1);
            va1 = spu_nmsub(vl12, vu2, va1);
            va1 = spu_nmsub(vl13, vu3, va1);

            va2 = spu_nmsub(vl20, vu0, va2);
            va2 = spu_nmsub(vl21, vu1, va2);
            va2 = spu_nmsub(vl22, vu2, va2);
            va2 = spu_nmsub(vl23, vu3, va2);

            va3 = spu_nmsub(vl30, vu0, va3);
            va3 = spu_nmsub(vl31, vu1, va3);
            va3 = spu_nmsub(vl32, vu2, va3);
            va3 = spu_nmsub(vl33, vu3, va3);

            *(vector float*)&a[ka  ][ja] = va0;
            *(vector float*)&a[ka+1][ja] = va1;
            *(vector float*)&a[ka+2][ja] = va2;
            *(vector float*)&a[ka+3][ja] = va3;
        }
    }
}

void cal_down_right(int ubuf, int nA, int iA, int iv, eaddr_t eaA)
{
    int jA;
    int ltag = 0;
    int lbuf;

    jA = (iA+1)/NUMBER_OF_SPES*NUMBER_OF_SPES+speid;
    if(jA < iA+1) {
        jA += NUMBER_OF_SPES;
    }

    for(; jA < nA; jA += NUMBER_OF_SPES) {
        lbuf = BLOCK_L;
        lbuf = colcache_iget_block(lbuf, ltag, nA, jA, iA, eaA);

        dma_wait(ltag);
        cal_down_right_inner(lbuf, ubuf, iv);

        colcache_iputb_block(lbuf, ltag, nA, jA, iA, eaA);
    }
}

/*void column_block_decomposition_diag_inner(int *ioApivot, int dbuf, int perm, int nA, int iA, int iv, int ia, eaddr_t eaA, eaddr_t eaP)
{
    int i;
    int apivot = 0;
    float amax = 0.0f;
    int Apivot = 0;
    float Amax = 0.0f;

    Apivot = *ioApivot;

#if defined ENABLE_SWAP
    swap_diag(dbuf, perm, iA*BLOCK_SIZE+iv*4+ia, Apivot, nA, iA, eaA, eaP);
#endif

    cal_diag_right(dbuf, iv, ia);
    send_U_and_pivot(dbuf, Apivot, iA, iv, ia);

    cal_diag_iline_and_pivot(&apivot, &amax, dbuf, iv, ia);
    cal_down_iline_and_pivot(&Apivot, &Amax, dbuf, nA, iA, iv, ia, eaA);

    if(amax > Amax) {
        Apivot = apivot + iA*BLOCK_SIZE;
        Amax = amax;
        for(i = 0; i < BLOCK_SIZE; i++) {
            lsuline[ULINE_TARGET][i] = lsblock[dbuf][apivot][i];
        }
    }

    receive_pivot(&Apivot, Apivot, Amax);

    *ioApivot = Apivot;
}*/

void column_block_decomposition_diag(int nA, int iA, eaddr_t eaA, eaddr_t eaP)
{
    volatile float (*a)[BLOCK_SIZE];
    int i;
    int iv, ia;
    int Apivot;
    float Amax;
    int apivot;
    float amax;
    int dbuf;
    int perm = PERM_TARGET;

    dbuf = colcache_iget_block(BLOCK_D, TAG_SYNC, nA, iA, iA, eaA);
    dma_wait(TAG_SYNC);
    a = lsblock[dbuf];

    iget_perm(perm, TAG_PERM, iA, eaP);

    swap_init_perm(iA);

    dma_wait(TAG_PERM);

    for(iv = 0; iv < INNER_BLOCK_COUNT; iv++) {
        Apivot = 0;
        Amax = 0.0f;
        pivot_selection_diag_vfirst(&apivot, &amax, dbuf, iv);
        pivot_selection_down_vfirst(&Apivot, &Amax, nA, iA, iv, eaA);

        if(amax > Amax) {
            Apivot = apivot + iA*BLOCK_SIZE;
            Amax = amax;
            for(i = 0; i < BLOCK_SIZE; i++) {
                lsuline[ULINE_TARGET][i] = lsblock[dbuf][apivot][i];
            }
        }

        receive_pivot(&Apivot, Apivot, Amax);

        for(ia = 0; ia < 3; ia++) {
            //column_block_decomposition_diag_inner(&Apivot, dbuf, perm, nA, iA, iv, ia, eaA, eaP);
#if defined ENABLE_SWAP
            //spe_printf("pivot(%d) = %d\n", iA*BLOCK_SIZE+iv*4+ia, Apivot);
            swap_diag(dbuf, perm, iA*BLOCK_SIZE+iv*4+ia, Apivot, nA, iA, eaA, eaP);
#endif

            cal_diag_right(dbuf, iv, ia);
            send_U_and_pivot(dbuf, Apivot, iA, iv, ia);

            Apivot = 0;
            Amax = 0.0f;
            cal_diag_iline_and_pivot(&apivot, &amax, dbuf, iv, ia);
            cal_down_iline_and_pivot(&Apivot, &Amax, dbuf, nA, iA, iv, ia, eaA);

            if(amax > Amax) {
                Apivot = apivot + iA*BLOCK_SIZE;
                Amax = amax;
                for(i = 0; i < BLOCK_SIZE; i++) {
                    lsuline[ULINE_TARGET][i] = lsblock[dbuf][apivot][i];
                }
            }

            receive_pivot(&Apivot, Apivot, Amax);
        }

#if defined ENABLE_SWAP
        //spe_printf("pivot(%d) = %d\n", iA*BLOCK_SIZE+iv*4+ia, Apivot);
        swap_diag(dbuf, perm, iA*BLOCK_SIZE+iv*4+ia, Apivot, nA, iA, eaA, eaP);
#endif
        cal_diag_right(dbuf, iv, ia);
        send_U_and_pivot(dbuf, Apivot, iA, iv, ia);

        if(__builtin_expect((iv < INNER_BLOCK_COUNT-1), 1)) {
            cal_diag_down_right(dbuf, iv);
            cal_down_right(dbuf, nA, iA, iv, eaA);
        }
    }

#if defined ENABLE_SWAP
    swap_begin(nA, iA, eaA);
  #if NUMBER_OF_SPES > 1
    swap_continue_sync(); // 最初の更新領域を交換
  #else
    swap_rest(); // 処理が難しいので全部交換
    swap_wait_all();
  #endif
#endif

    iput_perm(perm, TAG_PERM, iA, eaP);
    colcache_iputb_block(dbuf, TAG_SYNC, nA, iA, iA, eaA);

    dma_wait(TAG_PERM);

    //spe_printf("SPE(%d): finished\n", speid);
}

void column_block_decomposition_down(int nA, int iA, eaddr_t eaA, eaddr_t eaP)
{
    int iv, ia;
    int Apivot;
    float Amax;
    int ubuf = BLOCK_U;
    int diagspe = iA % NUMBER_OF_SPES;

    swap_init_perm(iA);

    for(iv = 0; iv < INNER_BLOCK_COUNT; iv++) {
        pivot_selection_down_vfirst(&Apivot, &Amax, nA, iA, iv, eaA);

        send_pivot(diagspe, Apivot, Amax);

        for(ia = 0; ia < 3; ia++) {
            receive_U_and_pivot(&Apivot, ubuf, iA, iv, ia);

#if defined ENABLE_SWAP
            swap_down(iA*BLOCK_SIZE+iv*4+ia, Apivot, nA, iA, eaA);
#endif

            cal_down_iline_and_pivot(&Apivot, &Amax, ubuf, nA, iA, iv, ia, eaA);

            send_pivot(diagspe, Apivot, Amax);
        }

        receive_U_and_pivot(&Apivot, ubuf, iA, iv, ia);

#if defined ENABLE_SWAP
        swap_down(iA*BLOCK_SIZE+iv*4+ia, Apivot, nA, iA, eaA);
#endif

        if(__builtin_expect((iv < INNER_BLOCK_COUNT-1), 1)) {
            cal_down_right(ubuf, nA, iA, iv, eaA);
        }
    }

#if defined ENABLE_SWAP
    swap_begin(nA, iA, eaA);
  #if NUMBER_OF_SPES > 1
    swap_continue_sync(); // 最初の更新領域を交換
  #else
    swap_rest(); // 処理が難しいので全部交換
    swap_wait_all();
  #endif
#endif
}

void column_block_decomposition_master(int nA, int iA, eaddr_t eaA, eaddr_t eaP)
{
    usyncdata signal = { { -1, -1, {0}, 0, }, };
    int funcidx;
    void (*pfcolumn_block_decomposition[NUMBER_OF_SPES])(int, int, eaddr_t, eaddr_t) = {
        column_block_decomposition_diag,
        column_block_decomposition_down,
        column_block_decomposition_down,
        column_block_decomposition_down,
        column_block_decomposition_down,
        column_block_decomposition_down,
        column_block_decomposition_down,
    };

    funcidx = iA%NUMBER_OF_SPES;

    run_spes(signal);

    (*pfcolumn_block_decomposition[funcidx])(nA, iA, eaA, eaP);

    join_spes();
}

void column_block_decomposition_slave(int nA, int iA, eaddr_t eaA, eaddr_t eaP)
{
    usyncdata signal = { { -1, -1, {0}, 0, }, };
    int funcidx;
    void (*pfcolumn_block_decomposition[NUMBER_OF_SPES])(int, int, eaddr_t, eaddr_t) = {
        column_block_decomposition_diag,
        column_block_decomposition_down,
        column_block_decomposition_down,
        column_block_decomposition_down,
        column_block_decomposition_down,
        column_block_decomposition_down,
        column_block_decomposition_down,
    };

    funcidx = (NUMBER_OF_SPES+iA-speid)%NUMBER_OF_SPES;

    wait_for_signal();

    (*pfcolumn_block_decomposition[funcidx])(nA, iA, eaA, eaP);

    send_signal(signal);
}

void decompose_U(int ubuf, int dbuf)
{
    int ia, ja, ka;
    vector float va1, va2, va3;
    vector float va00, va01, va02, va03;
    vector float va10, va11, va12, va13;
    vector float va20, va21, va22, va23;
    vector float va30, va31, va32, va33;
    vector float vu00, vu01, vu02, vu03;
    vector float vu10, vu11, vu12, vu13;
    vector float vu20, vu21, vu22, vu23;
    vector float vu30, vu31, vu32, vu33; 
    vector float vku00, vku01, vku02, vku03;
    vector float vku10, vku11, vku12, vku13;
    vector float vku20, vku21, vku22, vku23;
    vector float vku30, vku31, vku32, vku33;
    vector float vinva0, vinva1, vinva2, vinva3;
    vector float vav0, vav1, vav2, vav3;
    vector unsigned char vsplats0 = { 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, };
    vector unsigned char vsplats1 = { 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, };
    vector unsigned char vsplats2 = { 8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, };
    vector unsigned char vsplats3 = { 12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, };
    volatile float (*u)[BLOCK_SIZE] = lsblock[ubuf];
    volatile float (*a)[BLOCK_SIZE] = lsblock[dbuf];

    for(ia = 0; ia < BLOCK_SIZE; ia += 4) {
        for(ja = 0; ja < BLOCK_SIZE; ja += 16) {
            vu00 = *(vector float*)&u[ia  ][ja   ];
            vu01 = *(vector float*)&u[ia  ][ja+ 4];
            vu02 = *(vector float*)&u[ia  ][ja+ 8];
            vu03 = *(vector float*)&u[ia  ][ja+12];
            vu10 = *(vector float*)&u[ia+1][ja   ];
            vu11 = *(vector float*)&u[ia+1][ja+ 4];
            vu12 = *(vector float*)&u[ia+1][ja+ 8];
            vu13 = *(vector float*)&u[ia+1][ja+12];
            vu20 = *(vector float*)&u[ia+2][ja   ];
            vu21 = *(vector float*)&u[ia+2][ja+ 4];
            vu22 = *(vector float*)&u[ia+2][ja+ 8];
            vu23 = *(vector float*)&u[ia+2][ja+12];
            vu30 = *(vector float*)&u[ia+3][ja   ];
            vu31 = *(vector float*)&u[ia+3][ja+ 4];
            vu32 = *(vector float*)&u[ia+3][ja+ 8];
            vu33 = *(vector float*)&u[ia+3][ja+12];
            vav0 = *(vector float*)&a[ia  ][ia];
            vav1 = *(vector float*)&a[ia+1][ia];
            vav2 = *(vector float*)&a[ia+2][ia];
            vav3 = *(vector float*)&a[ia+3][ia];

            vinva0 = spu_splats(1.0f/spu_extract(vav0, 0));
            vinva1 = spu_splats(1.0f/spu_extract(vav1, 1));
            vinva2 = spu_splats(1.0f/spu_extract(vav2, 2));
            vinva3 = spu_splats(1.0f/spu_extract(vav3, 3));

            va1 = spu_shuffle(vav1, vav1, vsplats0);
            va2 = spu_shuffle(vav2, vav2, vsplats0);
            va3 = spu_shuffle(vav3, vav3, vsplats0);
            vu00 = spu_mul(vu00, vinva0);
            vu01 = spu_mul(vu01, vinva0);
            vu02 = spu_mul(vu02, vinva0);
            vu03 = spu_mul(vu03, vinva0);
            vu10 = spu_nmsub(va1, vu00, vu10);
            vu11 = spu_nmsub(va1, vu01, vu11);
            vu12 = spu_nmsub(va1, vu02, vu12);
            vu13 = spu_nmsub(va1, vu03, vu13);
            vu20 = spu_nmsub(va2, vu00, vu20);
            vu21 = spu_nmsub(va2, vu01, vu21);
            vu22 = spu_nmsub(va2, vu02, vu22);
            vu23 = spu_nmsub(va2, vu03, vu23);
            vu30 = spu_nmsub(va3, vu00, vu30);
            vu31 = spu_nmsub(va3, vu01, vu31);
            vu32 = spu_nmsub(va3, vu02, vu32);
            vu33 = spu_nmsub(va3, vu03, vu33);

            va2 = spu_shuffle(vav2, vav2, vsplats1);
            va3 = spu_shuffle(vav3, vav3, vsplats1);
            vu10 = spu_mul(vu10, vinva1);
            vu11 = spu_mul(vu11, vinva1);
            vu12 = spu_mul(vu12, vinva1);
            vu13 = spu_mul(vu13, vinva1);
            vu20 = spu_nmsub(va2, vu10, vu20);
            vu21 = spu_nmsub(va2, vu11, vu21);
            vu22 = spu_nmsub(va2, vu12, vu22);
            vu23 = spu_nmsub(va2, vu13, vu23);
            vu30 = spu_nmsub(va3, vu10, vu30);
            vu31 = spu_nmsub(va3, vu11, vu31);
            vu32 = spu_nmsub(va3, vu12, vu32);
            vu33 = spu_nmsub(va3, vu13, vu33);

            va3 = spu_shuffle(vav3, vav3, vsplats2);
            vu20 = spu_mul(vu20, vinva2);
            vu21 = spu_mul(vu21, vinva2);
            vu22 = spu_mul(vu22, vinva2);
            vu23 = spu_mul(vu23, vinva2);
            vu30 = spu_nmsub(va3, vu20, vu30);
            vu31 = spu_nmsub(va3, vu21, vu31);
            vu32 = spu_nmsub(va3, vu22, vu32);
            vu33 = spu_nmsub(va3, vu23, vu33);
            
            vu30 = spu_mul(vu30, vinva3);
            vu31 = spu_mul(vu31, vinva3);
            vu32 = spu_mul(vu32, vinva3);
            vu33 = spu_mul(vu33, vinva3);

            *(vector float*)&u[ia  ][ja   ] = vu00;
            *(vector float*)&u[ia  ][ja+ 4] = vu01;
            *(vector float*)&u[ia  ][ja+ 8] = vu02;
            *(vector float*)&u[ia  ][ja+12] = vu03;
            *(vector float*)&u[ia+1][ja   ] = vu10;
            *(vector float*)&u[ia+1][ja+ 4] = vu11;
            *(vector float*)&u[ia+1][ja+ 8] = vu12;
            *(vector float*)&u[ia+1][ja+12] = vu13;
            *(vector float*)&u[ia+2][ja   ] = vu20;
            *(vector float*)&u[ia+2][ja+ 4] = vu21;
            *(vector float*)&u[ia+2][ja+ 8] = vu22;
            *(vector float*)&u[ia+2][ja+12] = vu23;
            *(vector float*)&u[ia+3][ja   ] = vu30;
            *(vector float*)&u[ia+3][ja+ 4] = vu31;
            *(vector float*)&u[ia+3][ja+ 8] = vu32;
            *(vector float*)&u[ia+3][ja+12] = vu33;

            for(ka = ia+4; ka < BLOCK_SIZE; ka += 4) {
                vav0 = *(vector float*)&a[ka  ][ia];
                vav1 = *(vector float*)&a[ka+1][ia];
                vav2 = *(vector float*)&a[ka+2][ia];
                vav3 = *(vector float*)&a[ka+3][ia];
                va00 = spu_shuffle(vav0, vav0, vsplats0);
                va01 = spu_shuffle(vav0, vav0, vsplats1);
                va02 = spu_shuffle(vav0, vav0, vsplats2);
                va03 = spu_shuffle(vav0, vav0, vsplats3);
                va10 = spu_shuffle(vav1, vav1, vsplats0);
                va11 = spu_shuffle(vav1, vav1, vsplats1);
                va12 = spu_shuffle(vav1, vav1, vsplats2);
                va13 = spu_shuffle(vav1, vav1, vsplats3);
                va20 = spu_shuffle(vav2, vav2, vsplats0);
                va21 = spu_shuffle(vav2, vav2, vsplats1);
                va22 = spu_shuffle(vav2, vav2, vsplats2);
                va23 = spu_shuffle(vav2, vav2, vsplats3);
                va30 = spu_shuffle(vav3, vav3, vsplats0);
                va31 = spu_shuffle(vav3, vav3, vsplats1);
                va32 = spu_shuffle(vav3, vav3, vsplats2);
                va33 = spu_shuffle(vav3, vav3, vsplats3);
                vku00 = *(vector float*)&u[ka  ][ja   ];
                vku01 = *(vector float*)&u[ka  ][ja+ 4];
                vku02 = *(vector float*)&u[ka  ][ja+ 8];
                vku03 = *(vector float*)&u[ka  ][ja+12];
                vku10 = *(vector float*)&u[ka+1][ja   ];
                vku11 = *(vector float*)&u[ka+1][ja+ 4];
                vku12 = *(vector float*)&u[ka+1][ja+ 8];
                vku13 = *(vector float*)&u[ka+1][ja+12];
                vku20 = *(vector float*)&u[ka+2][ja   ];
                vku21 = *(vector float*)&u[ka+2][ja+ 4];
                vku22 = *(vector float*)&u[ka+2][ja+ 8];
                vku23 = *(vector float*)&u[ka+2][ja+12];
                vku30 = *(vector float*)&u[ka+3][ja   ];
                vku31 = *(vector float*)&u[ka+3][ja+ 4];
                vku32 = *(vector float*)&u[ka+3][ja+ 8];
                vku33 = *(vector float*)&u[ka+3][ja+12];

                vku00 = spu_nmsub(va00, vu00, vku00);
                vku00 = spu_nmsub(va01, vu10, vku00);
                vku00 = spu_nmsub(va02, vu20, vku00);
                vku00 = spu_nmsub(va03, vu30, vku00);
                vku01 = spu_nmsub(va00, vu01, vku01);
                vku01 = spu_nmsub(va01, vu11, vku01);
                vku01 = spu_nmsub(va02, vu21, vku01);
                vku01 = spu_nmsub(va03, vu31, vku01);
                vku02 = spu_nmsub(va00, vu02, vku02);
                vku02 = spu_nmsub(va01, vu12, vku02);
                vku02 = spu_nmsub(va02, vu22, vku02);
                vku02 = spu_nmsub(va03, vu32, vku02);
                vku03 = spu_nmsub(va00, vu03, vku03);
                vku03 = spu_nmsub(va01, vu13, vku03);
                vku03 = spu_nmsub(va02, vu23, vku03);
                vku03 = spu_nmsub(va03, vu33, vku03);

                vku10 = spu_nmsub(va10, vu00, vku10);
                vku10 = spu_nmsub(va11, vu10, vku10);
                vku10 = spu_nmsub(va12, vu20, vku10);
                vku10 = spu_nmsub(va13, vu30, vku10);
                vku11 = spu_nmsub(va10, vu01, vku11);
                vku11 = spu_nmsub(va11, vu11, vku11);
                vku11 = spu_nmsub(va12, vu21, vku11);
                vku11 = spu_nmsub(va13, vu31, vku11);
                vku12 = spu_nmsub(va10, vu02, vku12);
                vku12 = spu_nmsub(va11, vu12, vku12);
                vku12 = spu_nmsub(va12, vu22, vku12);
                vku12 = spu_nmsub(va13, vu32, vku12);
                vku13 = spu_nmsub(va10, vu03, vku13);
                vku13 = spu_nmsub(va11, vu13, vku13);
                vku13 = spu_nmsub(va12, vu23, vku13);
                vku13 = spu_nmsub(va13, vu33, vku13);

                vku20 = spu_nmsub(va20, vu00, vku20);
                vku20 = spu_nmsub(va21, vu10, vku20);
                vku20 = spu_nmsub(va22, vu20, vku20);
                vku20 = spu_nmsub(va23, vu30, vku20);
                vku21 = spu_nmsub(va20, vu01, vku21);
                vku21 = spu_nmsub(va21, vu11, vku21);
                vku21 = spu_nmsub(va22, vu21, vku21);
                vku21 = spu_nmsub(va23, vu31, vku21);
                vku22 = spu_nmsub(va20, vu02, vku22);
                vku22 = spu_nmsub(va21, vu12, vku22);
                vku22 = spu_nmsub(va22, vu22, vku22);
                vku22 = spu_nmsub(va23, vu32, vku22);
                vku23 = spu_nmsub(va20, vu03, vku23);
                vku23 = spu_nmsub(va21, vu13, vku23);
                vku23 = spu_nmsub(va22, vu23, vku23);
                vku23 = spu_nmsub(va23, vu33, vku23);

                vku30 = spu_nmsub(va30, vu00, vku30);
                vku30 = spu_nmsub(va31, vu10, vku30);
                vku30 = spu_nmsub(va32, vu20, vku30);
                vku30 = spu_nmsub(va33, vu30, vku30);
                vku31 = spu_nmsub(va30, vu01, vku31);
                vku31 = spu_nmsub(va31, vu11, vku31);
                vku31 = spu_nmsub(va32, vu21, vku31);
                vku31 = spu_nmsub(va33, vu31, vku31);
                vku32 = spu_nmsub(va30, vu02, vku32);
                vku32 = spu_nmsub(va31, vu12, vku32);
                vku32 = spu_nmsub(va32, vu22, vku32);
                vku32 = spu_nmsub(va33, vu32, vku32);
                vku33 = spu_nmsub(va30, vu03, vku33);
                vku33 = spu_nmsub(va31, vu13, vku33);
                vku33 = spu_nmsub(va32, vu23, vku33);
                vku33 = spu_nmsub(va33, vu33, vku33);

                *(vector float*)&u[ka  ][ja   ] = vku00;
                *(vector float*)&u[ka  ][ja+ 4] = vku01;
                *(vector float*)&u[ka  ][ja+ 8] = vku02;
                *(vector float*)&u[ka  ][ja+12] = vku03;
                *(vector float*)&u[ka+1][ja   ] = vku10;
                *(vector float*)&u[ka+1][ja+ 4] = vku11;
                *(vector float*)&u[ka+1][ja+ 8] = vku12;
                *(vector float*)&u[ka+1][ja+12] = vku13;
                *(vector float*)&u[ka+2][ja   ] = vku20;
                *(vector float*)&u[ka+2][ja+ 4] = vku21;
                *(vector float*)&u[ka+2][ja+ 8] = vku22;
                *(vector float*)&u[ka+2][ja+12] = vku23;
                *(vector float*)&u[ka+3][ja   ] = vku30;
                *(vector float*)&u[ka+3][ja+ 4] = vku31;
                *(vector float*)&u[ka+3][ja+ 8] = vku32;
                *(vector float*)&u[ka+3][ja+12] = vku33;
            }
        }
    }
}

void matrix_nmsub(int dbuf, int lbuf, int ubuf)
{
    int ia;
    volatile float (*a)[BLOCK_SIZE] = lsblock[dbuf];
    volatile float (*l)[BLOCK_SIZE] = lsblock[lbuf];
    volatile float (*u)[BLOCK_SIZE] = lsblock[ubuf];
    vector unsigned char vsplats0 = { 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, };
    vector unsigned char vsplats1 = { 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, };
    vector unsigned char vsplats2 = { 8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, };
    vector unsigned char vsplats3 = { 12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, };
    vector float va00, va10, va20, va30;
    vector float va01, va11, va21, va31;
    vector float va02, va12, va22, va32;
    vector float va03, va13, va23, va33;
    vector float va04, va14, va24, va34;
    vector float va05, va15, va25, va35;
    vector float va06, va16, va26, va36;
    vector float va07, va17, va27, va37;
    vector float vlv0, vlv1, vlv2, vlv3;
    vector float vl00, vl01, vl02, vl03;
    vector float vl10, vl11, vl12, vl13;
    vector float vl20, vl21, vl22, vl23;
    vector float vl30, vl31, vl32, vl33;
    vector float vu00, vu10, vu20, vu30;
    vector float vu01, vu11, vu21, vu31;
    vector float vu02, vu12, vu22, vu32;
    vector float vu03, vu13, vu23, vu33;
    vector float vu04, vu14, vu24, vu34;
    vector float vu05, vu15, vu25, vu35;
    vector float vu06, vu16, vu26, vu36;
    vector float vu07, vu17, vu27, vu37;
    vector unsigned short vkcounterinit = { 0, 7, 6, 5, 4, 3, 2, 1, }; // 7回左ローテーションするとプリファードスロットに0が入る
    vector unsigned short vkcounter;
    unsigned short kcounter;
    unsigned int base_uka;
    unsigned int base_lka;

#if defined PROF_MATRIX_NMSUB
    s = spu_read_decrementer();
#endif

    for(ia = 0; ia < BLOCK_SIZE; ia += 4) {
        base_lka = (unsigned int)l + ia*BLOCK_SIZE*sizeof(float);
        vkcounter = vkcounterinit;

        va00 = *(vector float*)&a[ia  ][ 0];
        va10 = *(vector float*)&a[ia+1][ 0];
        va20 = *(vector float*)&a[ia+2][ 0];
        va30 = *(vector float*)&a[ia+3][ 0];
        va01 = *(vector float*)&a[ia  ][ 4];
        va11 = *(vector float*)&a[ia+1][ 4];
        va21 = *(vector float*)&a[ia+2][ 4];
        va31 = *(vector float*)&a[ia+3][ 4];
        va02 = *(vector float*)&a[ia  ][ 8];
        va12 = *(vector float*)&a[ia+1][ 8];
        va22 = *(vector float*)&a[ia+2][ 8];
        va32 = *(vector float*)&a[ia+3][ 8];
        va03 = *(vector float*)&a[ia  ][12];
        va13 = *(vector float*)&a[ia+1][12];
        va23 = *(vector float*)&a[ia+2][12];
        va33 = *(vector float*)&a[ia+3][12];
        va04 = *(vector float*)&a[ia  ][16];
        va14 = *(vector float*)&a[ia+1][16];
        va24 = *(vector float*)&a[ia+2][16];
        va34 = *(vector float*)&a[ia+3][16];
        va05 = *(vector float*)&a[ia  ][20];
        va15 = *(vector float*)&a[ia+1][20];
        va25 = *(vector float*)&a[ia+2][20];
        va35 = *(vector float*)&a[ia+3][20];
        va06 = *(vector float*)&a[ia  ][24];
        va16 = *(vector float*)&a[ia+1][24];
        va26 = *(vector float*)&a[ia+2][24];
        va36 = *(vector float*)&a[ia+3][24];
        va07 = *(vector float*)&a[ia  ][28];
        va17 = *(vector float*)&a[ia+1][28];
        va27 = *(vector float*)&a[ia+2][28];
        va37 = *(vector float*)&a[ia+3][28];

        // ループの最初の6サイクルを積和演算で埋めるために先読み
        vlv0 = *(vector float*)&l[ia  ][ 0];
        vlv1 = *(vector float*)&l[ia+1][ 0];
        vlv2 = *(vector float*)&l[ia+2][ 0];
        vlv3 = *(vector float*)&l[ia+3][ 0];

        vl00 = spu_shuffle(vlv0, vlv0, vsplats0);
        vl10 = spu_shuffle(vlv1, vlv1, vsplats0);
        vl20 = spu_shuffle(vlv2, vlv2, vsplats0);

        vu00 = *(vector float*)&u[0][ 0];
        vu10 = *(vector float*)&u[1][ 0];
        vu20 = *(vector float*)&u[2][ 0];

        vu01 = *(vector float*)&u[0][ 4];
        vu11 = *(vector float*)&u[1][ 4];
        vu21 = *(vector float*)&u[2][ 4];
 
        base_uka = (unsigned int)u;
        //for(ka = 0; ka < BLOCK_SIZE-4; ka += 4) {
        do {
            // ロード命令にかかる6サイクル分の積和演算を確保
            va00 = spu_nmsub(vl00, vu00, va00);
            va10 = spu_nmsub(vl10, vu00, va10);
            va20 = spu_nmsub(vl20, vu00, va20);

            va01 = spu_nmsub(vl00, vu01, va01);
            va11 = spu_nmsub(vl10, vu01, va11);
            va21 = spu_nmsub(vl20, vu01, va21);

            vl01 = spu_shuffle(vlv0, vlv0, vsplats1);
            vl02 = spu_shuffle(vlv0, vlv0, vsplats2);
            vl03 = spu_shuffle(vlv0, vlv0, vsplats3);

            vl11 = spu_shuffle(vlv1, vlv1, vsplats1);
            vl12 = spu_shuffle(vlv1, vlv1, vsplats2);
            vl13 = spu_shuffle(vlv1, vlv1, vsplats3);

            vl21 = spu_shuffle(vlv2, vlv2, vsplats1);
            vl22 = spu_shuffle(vlv2, vlv2, vsplats2);
            vl23 = spu_shuffle(vlv2, vlv2, vsplats3);

            vl30 = spu_shuffle(vlv3, vlv3, vsplats0);
            vl31 = spu_shuffle(vlv3, vlv3, vsplats1);
            vl32 = spu_shuffle(vlv3, vlv3, vsplats2);
            vl33 = spu_shuffle(vlv3, vlv3, vsplats3);

            vu30 = *(vector float*)(base_uka + 384     );
            vu31 = *(vector float*)(base_uka + 384 + 16);
            vu02 = *(vector float*)(base_uka +       32);
            vu12 = *(vector float*)(base_uka + 128 + 32);
            vu22 = *(vector float*)(base_uka + 256 + 32);
            vu32 = *(vector float*)(base_uka + 384 + 32);
            vu03 = *(vector float*)(base_uka +       48);
            vu13 = *(vector float*)(base_uka + 128 + 48);
            vu23 = *(vector float*)(base_uka + 256 + 48);
            vu33 = *(vector float*)(base_uka + 384 + 48);
            vu04 = *(vector float*)(base_uka +       64);
            vu14 = *(vector float*)(base_uka + 128 + 64);
            vu24 = *(vector float*)(base_uka + 256 + 64);
            vu34 = *(vector float*)(base_uka + 384 + 64);
            vu05 = *(vector float*)(base_uka +       80);
            vu15 = *(vector float*)(base_uka + 128 + 80);
            vu25 = *(vector float*)(base_uka + 256 + 80);
            vu35 = *(vector float*)(base_uka + 384 + 80);
            vu06 = *(vector float*)(base_uka +       96);
            vu16 = *(vector float*)(base_uka + 128 + 96);
            vu26 = *(vector float*)(base_uka + 256 + 96);
            vu36 = *(vector float*)(base_uka + 384 + 96);
            vu07 = *(vector float*)(base_uka +       112);
            vu17 = *(vector float*)(base_uka + 128 + 112);
            vu27 = *(vector float*)(base_uka + 256 + 112);
            vu37 = *(vector float*)(base_uka + 384 + 112);

            va00 = spu_nmsub(vl01, vu10, va00);
            va00 = spu_nmsub(vl02, vu20, va00);
            va00 = spu_nmsub(vl03, vu30, va00);
            va10 = spu_nmsub(vl11, vu10, va10);
            va10 = spu_nmsub(vl12, vu20, va10);
            va10 = spu_nmsub(vl13, vu30, va10);
            va20 = spu_nmsub(vl21, vu10, va20);
            va20 = spu_nmsub(vl22, vu20, va20);
            va20 = spu_nmsub(vl23, vu30, va20);
            va30 = spu_nmsub(vl30, vu00, va30);
            va30 = spu_nmsub(vl31, vu10, va30);
            va30 = spu_nmsub(vl32, vu20, va30);
            va30 = spu_nmsub(vl33, vu30, va30);

            va01 = spu_nmsub(vl01, vu11, va01);
            va01 = spu_nmsub(vl02, vu21, va01);
            va01 = spu_nmsub(vl03, vu31, va01);
            va11 = spu_nmsub(vl11, vu11, va11);
            va11 = spu_nmsub(vl12, vu21, va11);
            va11 = spu_nmsub(vl13, vu31, va11);
            va21 = spu_nmsub(vl21, vu11, va21);
            va21 = spu_nmsub(vl22, vu21, va21);
            va21 = spu_nmsub(vl23, vu31, va21);
            va31 = spu_nmsub(vl30, vu01, va31);
            va31 = spu_nmsub(vl31, vu11, va31);
            va31 = spu_nmsub(vl32, vu21, va31);
            va31 = spu_nmsub(vl33, vu31, va31);

            va02 = spu_nmsub(vl00, vu02, va02);
            va02 = spu_nmsub(vl01, vu12, va02);
            va02 = spu_nmsub(vl02, vu22, va02);
            va02 = spu_nmsub(vl03, vu32, va02);
            va12 = spu_nmsub(vl10, vu02, va12);
            va12 = spu_nmsub(vl11, vu12, va12);
            va12 = spu_nmsub(vl12, vu22, va12);
            va12 = spu_nmsub(vl13, vu32, va12);
            va22 = spu_nmsub(vl20, vu02, va22);
            va22 = spu_nmsub(vl21, vu12, va22);
            va22 = spu_nmsub(vl22, vu22, va22);
            va22 = spu_nmsub(vl23, vu32, va22);
            va32 = spu_nmsub(vl30, vu02, va32);
            va32 = spu_nmsub(vl31, vu12, va32);
            va32 = spu_nmsub(vl32, vu22, va32);
            va32 = spu_nmsub(vl33, vu32, va32);

            va03 = spu_nmsub(vl00, vu03, va03);
            va03 = spu_nmsub(vl01, vu13, va03);
            va03 = spu_nmsub(vl02, vu23, va03);
            va03 = spu_nmsub(vl03, vu33, va03);
            va13 = spu_nmsub(vl10, vu03, va13);
            va13 = spu_nmsub(vl11, vu13, va13);
            va13 = spu_nmsub(vl12, vu23, va13);
            va13 = spu_nmsub(vl13, vu33, va13);
            va23 = spu_nmsub(vl20, vu03, va23);
            va23 = spu_nmsub(vl21, vu13, va23);
            va23 = spu_nmsub(vl22, vu23, va23);
            va23 = spu_nmsub(vl23, vu33, va23);
            va33 = spu_nmsub(vl30, vu03, va33);
            va33 = spu_nmsub(vl31, vu13, va33);
            va33 = spu_nmsub(vl32, vu23, va33);
            va33 = spu_nmsub(vl33, vu33, va33);

            va04 = spu_nmsub(vl00, vu04, va04);
            va04 = spu_nmsub(vl01, vu14, va04);
            va04 = spu_nmsub(vl02, vu24, va04);
            va04 = spu_nmsub(vl03, vu34, va04);
            va14 = spu_nmsub(vl10, vu04, va14);
            va14 = spu_nmsub(vl11, vu14, va14);
            va14 = spu_nmsub(vl12, vu24, va14);
            va14 = spu_nmsub(vl13, vu34, va14);
            va24 = spu_nmsub(vl20, vu04, va24);
            va24 = spu_nmsub(vl21, vu14, va24);
            va24 = spu_nmsub(vl22, vu24, va24);
            va24 = spu_nmsub(vl23, vu34, va24);
            va34 = spu_nmsub(vl30, vu04, va34);
            va34 = spu_nmsub(vl31, vu14, va34);
            va34 = spu_nmsub(vl32, vu24, va34);
            va34 = spu_nmsub(vl33, vu34, va34);

            va05 = spu_nmsub(vl00, vu05, va05);
            va05 = spu_nmsub(vl01, vu15, va05);
            va05 = spu_nmsub(vl02, vu25, va05);
            va05 = spu_nmsub(vl03, vu35, va05);
            va15 = spu_nmsub(vl10, vu05, va15);
            va15 = spu_nmsub(vl11, vu15, va15);
            va15 = spu_nmsub(vl12, vu25, va15);
            va15 = spu_nmsub(vl13, vu35, va15);
            va25 = spu_nmsub(vl20, vu05, va25);
            va25 = spu_nmsub(vl21, vu15, va25);
            va25 = spu_nmsub(vl22, vu25, va25);
            va25 = spu_nmsub(vl23, vu35, va25);
            va35 = spu_nmsub(vl30, vu05, va35);
            va35 = spu_nmsub(vl31, vu15, va35);
            va35 = spu_nmsub(vl32, vu25, va35);
            va35 = spu_nmsub(vl33, vu35, va35);

            va06 = spu_nmsub(vl00, vu06, va06);
            va06 = spu_nmsub(vl01, vu16, va06);
            va06 = spu_nmsub(vl02, vu26, va06);
            va06 = spu_nmsub(vl03, vu36, va06);
            va16 = spu_nmsub(vl10, vu06, va16);
            va16 = spu_nmsub(vl11, vu16, va16);
            va16 = spu_nmsub(vl12, vu26, va16);
            va16 = spu_nmsub(vl13, vu36, va16);
            va26 = spu_nmsub(vl20, vu06, va26);
            va26 = spu_nmsub(vl21, vu16, va26);
            va26 = spu_nmsub(vl22, vu26, va26);
            va26 = spu_nmsub(vl23, vu36, va26);
            va36 = spu_nmsub(vl30, vu06, va36);
            va36 = spu_nmsub(vl31, vu16, va36);
            va36 = spu_nmsub(vl32, vu26, va36);
            va36 = spu_nmsub(vl33, vu36, va36);

            va07 = spu_nmsub(vl00, vu07, va07);
            va07 = spu_nmsub(vl01, vu17, va07);
            va07 = spu_nmsub(vl02, vu27, va07);
            va07 = spu_nmsub(vl03, vu37, va07);
            va17 = spu_nmsub(vl10, vu07, va17);
            va17 = spu_nmsub(vl11, vu17, va17);
            va17 = spu_nmsub(vl12, vu27, va17);
            va17 = spu_nmsub(vl13, vu37, va17);
            va27 = spu_nmsub(vl20, vu07, va27);
            va27 = spu_nmsub(vl21, vu17, va27);
            va27 = spu_nmsub(vl22, vu27, va27);
            va27 = spu_nmsub(vl23, vu37, va27);
            va37 = spu_nmsub(vl30, vu07, va37);
            va37 = spu_nmsub(vl31, vu17, va37);
            va37 = spu_nmsub(vl32, vu27, va37);
            va37 = spu_nmsub(vl33, vu37, va37);

            base_lka += 4*sizeof(float);
            vlv0 = *(vector float*)(base_lka      );
            vlv1 = *(vector float*)(base_lka + 128);
            vlv2 = *(vector float*)(base_lka + 256);
            vlv3 = *(vector float*)(base_lka + 384);

            vl00 = spu_shuffle(vlv0, vlv0, vsplats0);
            vl10 = spu_shuffle(vlv1, vlv1, vsplats0);
            vl20 = spu_shuffle(vlv2, vlv2, vsplats0);

            base_uka += 4*BLOCK_SIZE*sizeof(float);

            vu00 = *(vector float*)(base_uka      );
            vu10 = *(vector float*)(base_uka + 128);
            vu20 = *(vector float*)(base_uka + 256);

            vu01 = *(vector float*)(base_uka +       16);
            vu11 = *(vector float*)(base_uka + 128 + 16);
            vu21 = *(vector float*)(base_uka + 256 + 16);

            vkcounter = spu_rlqwbyte(vkcounter, 2);
            kcounter = spu_extract(vkcounter, 1);
        } while(kcounter);

        vl01 = spu_shuffle(vlv0, vlv0, vsplats1);
        vl02 = spu_shuffle(vlv0, vlv0, vsplats2);
        vl03 = spu_shuffle(vlv0, vlv0, vsplats3);

        vl11 = spu_shuffle(vlv1, vlv1, vsplats1);
        vl12 = spu_shuffle(vlv1, vlv1, vsplats2);
        vl13 = spu_shuffle(vlv1, vlv1, vsplats3);

        vl21 = spu_shuffle(vlv2, vlv2, vsplats1);
        vl22 = spu_shuffle(vlv2, vlv2, vsplats2);
        vl23 = spu_shuffle(vlv2, vlv2, vsplats3);

        vl30 = spu_shuffle(vlv3, vlv3, vsplats0);
        vl31 = spu_shuffle(vlv3, vlv3, vsplats1);
        vl32 = spu_shuffle(vlv3, vlv3, vsplats2);
        vl33 = spu_shuffle(vlv3, vlv3, vsplats3);

        vu30 = *(vector float*)(base_uka + 384     );
        vu31 = *(vector float*)(base_uka + 384 + 16);
        vu02 = *(vector float*)(base_uka +       32);
        vu12 = *(vector float*)(base_uka + 128 + 32);
        vu22 = *(vector float*)(base_uka + 256 + 32);
        vu32 = *(vector float*)(base_uka + 384 + 32);
        vu03 = *(vector float*)(base_uka +       48);
        vu13 = *(vector float*)(base_uka + 128 + 48);
        vu23 = *(vector float*)(base_uka + 256 + 48);
        vu33 = *(vector float*)(base_uka + 384 + 48);
        vu04 = *(vector float*)(base_uka +       64);
        vu14 = *(vector float*)(base_uka + 128 + 64);
        vu24 = *(vector float*)(base_uka + 256 + 64);
        vu34 = *(vector float*)(base_uka + 384 + 64);
        vu05 = *(vector float*)(base_uka +       80);
        vu15 = *(vector float*)(base_uka + 128 + 80);
        vu25 = *(vector float*)(base_uka + 256 + 80);
        vu35 = *(vector float*)(base_uka + 384 + 80);
        vu06 = *(vector float*)(base_uka +       96);
        vu16 = *(vector float*)(base_uka + 128 + 96);
        vu26 = *(vector float*)(base_uka + 256 + 96);
        vu36 = *(vector float*)(base_uka + 384 + 96);
        vu07 = *(vector float*)(base_uka +       112);
        vu17 = *(vector float*)(base_uka + 128 + 112);
        vu27 = *(vector float*)(base_uka + 256 + 112);
        vu37 = *(vector float*)(base_uka + 384 + 112);

        va00 = spu_nmsub(vl00, vu00, va00);
        va00 = spu_nmsub(vl01, vu10, va00);
        va00 = spu_nmsub(vl02, vu20, va00);
        va00 = spu_nmsub(vl03, vu30, va00);
        va10 = spu_nmsub(vl10, vu00, va10);
        va10 = spu_nmsub(vl11, vu10, va10);
        va10 = spu_nmsub(vl12, vu20, va10);
        va10 = spu_nmsub(vl13, vu30, va10);
        va20 = spu_nmsub(vl20, vu00, va20);
        va20 = spu_nmsub(vl21, vu10, va20);
        va20 = spu_nmsub(vl22, vu20, va20);
        va20 = spu_nmsub(vl23, vu30, va20);
        va30 = spu_nmsub(vl30, vu00, va30);
        va30 = spu_nmsub(vl31, vu10, va30);
        va30 = spu_nmsub(vl32, vu20, va30);
        va30 = spu_nmsub(vl33, vu30, va30);

        va01 = spu_nmsub(vl00, vu01, va01);
        va01 = spu_nmsub(vl01, vu11, va01);
        va01 = spu_nmsub(vl02, vu21, va01);
        va01 = spu_nmsub(vl03, vu31, va01);
        va11 = spu_nmsub(vl10, vu01, va11);
        va11 = spu_nmsub(vl11, vu11, va11);
        va11 = spu_nmsub(vl12, vu21, va11);
        va11 = spu_nmsub(vl13, vu31, va11);
        va21 = spu_nmsub(vl20, vu01, va21);
        va21 = spu_nmsub(vl21, vu11, va21);
        va21 = spu_nmsub(vl22, vu21, va21);
        va21 = spu_nmsub(vl23, vu31, va21);
        va31 = spu_nmsub(vl30, vu01, va31);
        va31 = spu_nmsub(vl31, vu11, va31);
        va31 = spu_nmsub(vl32, vu21, va31);
        va31 = spu_nmsub(vl33, vu31, va31);

        va02 = spu_nmsub(vl00, vu02, va02);
        va02 = spu_nmsub(vl01, vu12, va02);
        va02 = spu_nmsub(vl02, vu22, va02);
        va02 = spu_nmsub(vl03, vu32, va02);
        va12 = spu_nmsub(vl10, vu02, va12);
        va12 = spu_nmsub(vl11, vu12, va12);
        va12 = spu_nmsub(vl12, vu22, va12);
        va12 = spu_nmsub(vl13, vu32, va12);
        va22 = spu_nmsub(vl20, vu02, va22);
        va22 = spu_nmsub(vl21, vu12, va22);
        va22 = spu_nmsub(vl22, vu22, va22);
        va22 = spu_nmsub(vl23, vu32, va22);
        va32 = spu_nmsub(vl30, vu02, va32);
        va32 = spu_nmsub(vl31, vu12, va32);
        va32 = spu_nmsub(vl32, vu22, va32);
        va32 = spu_nmsub(vl33, vu32, va32);

        va03 = spu_nmsub(vl00, vu03, va03);
        va03 = spu_nmsub(vl01, vu13, va03);
        va03 = spu_nmsub(vl02, vu23, va03);
        va03 = spu_nmsub(vl03, vu33, va03);
        va13 = spu_nmsub(vl10, vu03, va13);
        va13 = spu_nmsub(vl11, vu13, va13);
        va13 = spu_nmsub(vl12, vu23, va13);
        va13 = spu_nmsub(vl13, vu33, va13);
        va23 = spu_nmsub(vl20, vu03, va23);
        va23 = spu_nmsub(vl21, vu13, va23);
        va23 = spu_nmsub(vl22, vu23, va23);
        va23 = spu_nmsub(vl23, vu33, va23);
        va33 = spu_nmsub(vl30, vu03, va33);
        va33 = spu_nmsub(vl31, vu13, va33);
        va33 = spu_nmsub(vl32, vu23, va33);
        va33 = spu_nmsub(vl33, vu33, va33);

        va04 = spu_nmsub(vl00, vu04, va04);
        va04 = spu_nmsub(vl01, vu14, va04);
        va04 = spu_nmsub(vl02, vu24, va04);
        va04 = spu_nmsub(vl03, vu34, va04);
        va14 = spu_nmsub(vl10, vu04, va14);
        va14 = spu_nmsub(vl11, vu14, va14);
        va14 = spu_nmsub(vl12, vu24, va14);
        va14 = spu_nmsub(vl13, vu34, va14);
        va24 = spu_nmsub(vl20, vu04, va24);
        va24 = spu_nmsub(vl21, vu14, va24);
        va24 = spu_nmsub(vl22, vu24, va24);
        va24 = spu_nmsub(vl23, vu34, va24);
        va34 = spu_nmsub(vl30, vu04, va34);
        va34 = spu_nmsub(vl31, vu14, va34);
        va34 = spu_nmsub(vl32, vu24, va34);
        va34 = spu_nmsub(vl33, vu34, va34);

        va05 = spu_nmsub(vl00, vu05, va05);
        va05 = spu_nmsub(vl01, vu15, va05);
        va05 = spu_nmsub(vl02, vu25, va05);
        va05 = spu_nmsub(vl03, vu35, va05);
        va15 = spu_nmsub(vl10, vu05, va15);
        va15 = spu_nmsub(vl11, vu15, va15);
        va15 = spu_nmsub(vl12, vu25, va15);
        va15 = spu_nmsub(vl13, vu35, va15);
        va25 = spu_nmsub(vl20, vu05, va25);
        va25 = spu_nmsub(vl21, vu15, va25);
        va25 = spu_nmsub(vl22, vu25, va25);
        va25 = spu_nmsub(vl23, vu35, va25);
        va35 = spu_nmsub(vl30, vu05, va35);
        va35 = spu_nmsub(vl31, vu15, va35);
        va35 = spu_nmsub(vl32, vu25, va35);
        va35 = spu_nmsub(vl33, vu35, va35);

        va06 = spu_nmsub(vl00, vu06, va06);
        va06 = spu_nmsub(vl01, vu16, va06);
        va06 = spu_nmsub(vl02, vu26, va06);
        va06 = spu_nmsub(vl03, vu36, va06);
        va16 = spu_nmsub(vl10, vu06, va16);
        va16 = spu_nmsub(vl11, vu16, va16);
        va16 = spu_nmsub(vl12, vu26, va16);
        va16 = spu_nmsub(vl13, vu36, va16);
        va26 = spu_nmsub(vl20, vu06, va26);
        va26 = spu_nmsub(vl21, vu16, va26);
        va26 = spu_nmsub(vl22, vu26, va26);
        va26 = spu_nmsub(vl23, vu36, va26);
        va36 = spu_nmsub(vl30, vu06, va36);
        va36 = spu_nmsub(vl31, vu16, va36);
        va36 = spu_nmsub(vl32, vu26, va36);
        va36 = spu_nmsub(vl33, vu36, va36);

        va07 = spu_nmsub(vl00, vu07, va07);
        va07 = spu_nmsub(vl01, vu17, va07);
        va07 = spu_nmsub(vl02, vu27, va07);
        va07 = spu_nmsub(vl03, vu37, va07);
        va17 = spu_nmsub(vl10, vu07, va17);
        va17 = spu_nmsub(vl11, vu17, va17);
        va17 = spu_nmsub(vl12, vu27, va17);
        va17 = spu_nmsub(vl13, vu37, va17);
        va27 = spu_nmsub(vl20, vu07, va27);
        va27 = spu_nmsub(vl21, vu17, va27);
        va27 = spu_nmsub(vl22, vu27, va27);
        va27 = spu_nmsub(vl23, vu37, va27);
        va37 = spu_nmsub(vl30, vu07, va37);
        va37 = spu_nmsub(vl31, vu17, va37);
        va37 = spu_nmsub(vl32, vu27, va37);
        va37 = spu_nmsub(vl33, vu37, va37);

        *(vector float*)&a[ia  ][ 0] = va00;
        *(vector float*)&a[ia+1][ 0] = va10;
        *(vector float*)&a[ia+2][ 0] = va20;
        *(vector float*)&a[ia+3][ 0] = va30;
        *(vector float*)&a[ia  ][ 4] = va01;
        *(vector float*)&a[ia+1][ 4] = va11;
        *(vector float*)&a[ia+2][ 4] = va21;
        *(vector float*)&a[ia+3][ 4] = va31;
        *(vector float*)&a[ia  ][ 8] = va02;
        *(vector float*)&a[ia+1][ 8] = va12;
        *(vector float*)&a[ia+2][ 8] = va22;
        *(vector float*)&a[ia+3][ 8] = va32;
        *(vector float*)&a[ia  ][12] = va03;
        *(vector float*)&a[ia+1][12] = va13;
        *(vector float*)&a[ia+2][12] = va23;
        *(vector float*)&a[ia+3][12] = va33;
        *(vector float*)&a[ia  ][16] = va04;
        *(vector float*)&a[ia+1][16] = va14;
        *(vector float*)&a[ia+2][16] = va24;
        *(vector float*)&a[ia+3][16] = va34;
        *(vector float*)&a[ia  ][20] = va05;
        *(vector float*)&a[ia+1][20] = va15;
        *(vector float*)&a[ia+2][20] = va25;
        *(vector float*)&a[ia+3][20] = va35;
        *(vector float*)&a[ia  ][24] = va06;
        *(vector float*)&a[ia+1][24] = va16;
        *(vector float*)&a[ia+2][24] = va26;
        *(vector float*)&a[ia+3][24] = va36;
        *(vector float*)&a[ia  ][28] = va07;
        *(vector float*)&a[ia+1][28] = va17;
        *(vector float*)&a[ia+2][28] = va27;
        *(vector float*)&a[ia+3][28] = va37;
    }

#if defined PROF_MATRIX_NMSUB
    t = spu_read_decrementer();
    if(dec == 0) {
        dec = s - t;
    }
#endif
}

void init_perm(int nA, eaddr_t eaP)
{
    int i;
    int iA;
    int count = 0;
    int buf;

    for(iA = speid; iA < nA; iA += NUMBER_OF_SPES, count++) {
        buf = count&3;
        dma_wait(buf);

        for(i = 0; i < BLOCK_SIZE; i++) {
            lsperm[buf][i] = iA*BLOCK_SIZE+i;
        }
        iput_perm(buf, buf, iA, eaP);
    }
    mfc_barrier(TAG_SYNC);
}

void init_perm_master(int nA, eaddr_t eaP)
{
    usyncdata sync = { { 0, 0, {0.0f}, 0, }, };

    run_spes(sync);
    init_perm(nA, eaP);
    join_spes();
}

void init_perm_slave(int nA, eaddr_t eaP)
{
    usyncdata signal = { { 0, 0, {0}, 0, }, };

    wait_for_signal();
    init_perm(nA, eaP);
    send_signal(signal);
}

void update_and_pivot(int nA, int iA, eaddr_t eaA)
{
    int jA, kA;
    int cur_utag, nxt_utag;
    int cur_ubuf, nxt_ubuf;
    int diagbuf;
    int cur_ltag, nxt_ltag = 0;
    int cur_dtag, nxt_dtag = 0;
    int cur_lbuf, nxt_lbuf = 0;
    int cur_dbuf, nxt_dbuf = 0;
    int cur_kA, nxt_kA = 0;
    usyncdata signal = { { 0, 0, {0}, 0, }, };
    int diagA;
    int uready = 0;
    int diagspe;

    jA = 0;

    nxt_utag = 4;
    nxt_ubuf = BLOCK_U-4+nxt_utag;

    diagbuf = BLOCK_DIAG;

    // 最初に使う対角ブロックを取得する
    diagA = speid;
    if(diagA < iA) {
        iget_block(diagbuf, TAG_DIAG, nA, diagA, diagA, eaA);
    }

    // 最初のUの計算
    if(speid == 0) {
#if defined ENABLE_SWAP
        swap_continue_sync(); // 更新が行の交換に追いつかないようにする
#endif
        cur_ubuf = colcache_iget_block(BLOCK_U, TAG_SYNC, nA, jA, iA, eaA);
        dma_wait(TAG_DIAG);
        dma_wait(TAG_SYNC);

        decompose_U(cur_ubuf, diagbuf);

        iputb_block(cur_ubuf, TAG_SYNC, nA, jA, iA, eaA);
        mfc_sync(TAG_SYNC);
        signal.s.line = jA;
        send_signal_all(signal);

        diagA += NUMBER_OF_SPES;
        if(diagA < iA) {
            iget_block(diagbuf, TAG_DIAG, nA, diagA, diagA, eaA);
        }
    }

    // Lと分解するブロックの先読み
    kA = (jA+1)/NUMBER_OF_SPES*NUMBER_OF_SPES+speid;
    if(kA < jA+1) {
        kA += NUMBER_OF_SPES;
    }
    if(kA < nA) {
        nxt_kA = kA;
        nxt_ltag = 0;
        nxt_dtag = 2;
        nxt_lbuf = BLOCK_L+nxt_ltag;
        nxt_dbuf = BLOCK_D-2+nxt_dtag;

        iget_block(nxt_lbuf, nxt_ltag, nA, nxt_kA, jA, eaA);
        nxt_dbuf = colcache_iget_block(nxt_dbuf, nxt_dtag, nA, nxt_kA, iA, eaA);
    }

    for(jA = 0; jA < iA; jA++) {
        cur_utag = nxt_utag;
        nxt_utag = ((nxt_utag+1) & 1) + 4;
        cur_ubuf = nxt_ubuf;
        nxt_ubuf = BLOCK_U-4+nxt_utag;

        diagspe = jA % NUMBER_OF_SPES;
        if(diagspe == speid) {
            cur_ubuf = colcache_iget_block(cur_ubuf, cur_utag, nA, jA, iA, eaA);
        } else if (kA < nA) {
            if(!uready) {
#if defined READ_DECREMENTER
                s = spu_read_decrementer();
                while(lssignal[SYNC_SIGNAL].s.line < jA) {
                    t = spu_read_decrementer();
                    if(s-t > PRINT_CYCLE) {
                        spe_printf("SPE(%d): too late!(wait U) step = %d, line(%d) = %d\n", speid, gstep, SYNC_SIGNAL, lssignal[SYNC_SIGNAL].s.line);
                        s = t;
                    }
                }
#else
                while(lssignal[SYNC_SIGNAL].s.line < jA)  {
                    ;
                }
#endif
                iget_block(cur_ubuf, cur_utag, nA, jA, iA, eaA);
                dma_wait(cur_utag);
            }
        }
        uready = 0;
#if defined ENABLE_SWAP
        swap_continue_sync(); // 更新が行の交換に追いつかないようにする
#endif

        if(kA < nA) {
            kA += NUMBER_OF_SPES;
            for(; kA < nA; kA += NUMBER_OF_SPES) {
                cur_kA = nxt_kA;
                nxt_kA = kA;
                cur_ltag = nxt_ltag;
                nxt_ltag = ((nxt_ltag+1) & 1);
                cur_dtag = nxt_dtag;
                nxt_dtag = ((nxt_dtag+1) & 1) + 2;
                cur_lbuf = nxt_lbuf;
                nxt_lbuf = BLOCK_L+nxt_ltag;
                cur_dbuf = nxt_dbuf;
                nxt_dbuf = BLOCK_D-2+nxt_dtag;

                iget_block(nxt_lbuf, nxt_ltag, nA, nxt_kA, jA, eaA);
                nxt_dbuf = colcache_iget_block(nxt_dbuf, nxt_dtag, nA, nxt_kA, iA, eaA);

                dma_wait(cur_ltag);
                dma_wait(cur_dtag);
                dma_wait(cur_utag);
                matrix_nmsub(cur_dbuf, cur_lbuf, cur_ubuf);

                if(cur_kA == jA+1 && jA+1 < iA) {
                    dma_wait(TAG_DIAG);
                    decompose_U(cur_dbuf, diagbuf);

                    dma_wait(TAG_SYNC);
                    iputb_block(cur_dbuf, TAG_SYNC, nA, cur_kA, iA, eaA);
                    mfc_sync(TAG_SYNC);
                    signal.s.line = jA+1;
                    send_signal_all(signal);

                    diagA += NUMBER_OF_SPES;
                    if(diagA < iA) {
                        iget_block(diagbuf, TAG_DIAG, nA, diagA, diagA, eaA);
                    }
                } else {
                    colcache_iputb_block(cur_dbuf, cur_dtag, nA, cur_kA, iA, eaA);
                    dma_wait(cur_dtag); // 必要な理由が不明、そのうち解析する予定
                }
            }

            cur_kA = nxt_kA;
            cur_ltag = nxt_ltag;
            cur_dtag = nxt_dtag;
            cur_lbuf = nxt_lbuf;
            cur_dbuf = nxt_dbuf;

            if(jA+1 < iA) {
                // Lと分解するブロックの先読み
                kA = (jA+2)/NUMBER_OF_SPES*NUMBER_OF_SPES+speid;
                if(kA < jA+2) {
                    kA += NUMBER_OF_SPES;
                }
                if(kA < nA) {
                    nxt_kA = kA;
                    nxt_ltag = ((nxt_ltag+1) & 1);
                    nxt_lbuf = BLOCK_L+nxt_ltag;

                    iget_block(nxt_lbuf, nxt_ltag, nA, nxt_kA, jA+1, eaA);

                    // 最後に読み込んだブロックが次に使われるときは転送なし
                    if(nxt_kA == cur_kA) {
                        nxt_dtag = cur_dtag;
                        nxt_dbuf = cur_dbuf;
                    } else {
                        nxt_dtag = ((nxt_dtag+1) & 1) + 2;
                        nxt_dbuf = BLOCK_D-2+nxt_dtag;
                        nxt_dbuf = colcache_iget_block(nxt_dbuf, nxt_dtag, nA, nxt_kA, iA, eaA);
                    }
                }
            }

            if(lssignal[SYNC_SIGNAL].s.line >= jA+1 && jA+1 < iA) {
                uready = 1;
                iget_block(nxt_ubuf, nxt_utag, nA, jA+1, iA, eaA);
            }

            dma_wait(cur_ltag);
            dma_wait(cur_dtag);
            dma_wait(cur_utag);
            matrix_nmsub(cur_dbuf, cur_lbuf, cur_ubuf);

            if(cur_kA == jA+1 && jA+1 < iA) {
                dma_wait(TAG_DIAG);
                decompose_U(cur_dbuf, diagbuf);

                dma_wait(TAG_SYNC);
                iputb_block(cur_dbuf, TAG_SYNC, nA, cur_kA, iA, eaA);
                mfc_sync(TAG_SYNC);
                signal.s.line = jA+1;
                send_signal_all(signal);

                diagA += NUMBER_OF_SPES;
                if(diagA < iA) {
                    iget_block(diagbuf, TAG_DIAG, nA, diagA, diagA, eaA);
                }
            } else {
                colcache_iputb_block(cur_dbuf, cur_dtag, nA, cur_kA, iA, eaA);
                dma_wait(cur_dtag); // 必要な理由が不明、そのうち解析する予定。
                // キャッシュが当たる限りはパフォーマンスに影響なし
            }
        }
    }
}

void update_and_pivot_master(int nA, int iA, eaddr_t eaA)
{
    usyncdata signal = { { -1, -1, {0}, 0, }, };

    run_spes(signal);

    update_and_pivot(nA, iA, eaA);

    join_spes();
}

void update_and_pivot_slave(int nA, int iA, eaddr_t eaA)
{
    usyncdata signal = { { -1, -1, {0}, 0, }, };

    wait_for_signal();

    update_and_pivot(nA, iA, eaA);

    send_signal(signal);
}

void blocked_lu_decomposition(int n, int m, eaddr_t eaA, eaddr_t eaP)
{
    int iA;
    int nA = n / BLOCK_SIZE;
    void (*pfcolumn_block_decomposition)(int, int, eaddr_t, eaddr_t);
    void (*pfupdate_and_pivot)(int, int, eaddr_t);
    void (*pfinit_perm)(int, eaddr_t);

    iA = 0;

    colcache_init(nA);

    if(is_master()) {
        pfcolumn_block_decomposition = column_block_decomposition_master;
        pfupdate_and_pivot = update_and_pivot_master;
        pfinit_perm = init_perm_master;
    } else {
        pfcolumn_block_decomposition = column_block_decomposition_slave;
        pfupdate_and_pivot = update_and_pivot_slave;
        pfinit_perm = init_perm_slave;
    }

    (*pfinit_perm)(nA, eaP);

    (*pfcolumn_block_decomposition)(nA, iA, eaA, eaP);

    for(iA = 1; iA < nA; iA++) {
        colcache_next(nA, eaA);

#if defined READ_DECREMENTER
        gstep = iA;
#endif

        (*pfupdate_and_pivot)(nA, iA, eaA);

#if defined ENABLE_SWAP
        swap_rest();
        swap_wait_all();
#endif
   
        (*pfcolumn_block_decomposition)(nA, iA, eaA, eaP);
    }

    colcache_sync(nA, eaA);

    swap_rest();
    swap_wait_all();
}

//////////////////////////////////////////////////////////////////////////////
// forward & backward substitution
//////////////////////////////////////////////////////////////////////////////

inline void iget_vector(int buf, int tag, int iV, eaddr_t eaV)
{
    mfc_get(lsV[buf], eaV + iV*BLOCK_SIZE*sizeof(float), sizeof(lsV[buf]), tag, 0, 0);
}

inline void get_vector(int buf, int iV, eaddr_t eaV)
{
    mfc_get(lsV[buf], eaV + iV*BLOCK_SIZE*sizeof(float), sizeof(lsV[buf]), TAG_VECTOR_GET, 0, 0);
    mfc_write_tag_mask(1 << TAG_VECTOR_GET);
    mfc_read_tag_status_all();
}

inline void iput_vector(int buf, int tag, int iV, eaddr_t eaV)
{
    mfc_put(lsV[buf], eaV + iV*BLOCK_SIZE*sizeof(float), sizeof(lsV[buf]), tag, 0, 0);
}

inline void iputb_vector(int buf, int tag, int iV, eaddr_t eaV)
{
    mfc_putb(lsV[buf], eaV + iV*BLOCK_SIZE*sizeof(float), sizeof(lsV[buf]), tag, 0, 0);
}

inline void put_vector(int buf, int iV, eaddr_t eaV)
{
    mfc_put(lsV[buf], eaV + iV*BLOCK_SIZE*sizeof(float), sizeof(lsV[buf]), TAG_VECTOR_PUT, 0, 0);
    mfc_write_tag_mask(1 << TAG_VECTOR_PUT);
    mfc_read_tag_status_all();
}

void iget_right_vector_elem(int buf, int tag, int perm, eaddr_t eaB)
{
    int i;

    for(i = 0; i < BLOCK_SIZE; i++) {
        mlgetelem[buf][i].notify = 0;
        mlgetelem[buf][i].reserved = 0;
        mlgetelem[buf][i].size = sizeof(float)*4;
        mlgetelem[buf][i].eal = eaB + (lsperm[perm][i]/4)*4*sizeof(float);
    }

    mfc_getl(lsrightelem[buf], 0, mlgetelem[buf], sizeof(mlgetelem[buf]), tag, 0, 0);
}

void iget_vector_all(int buf, int tag, int nA, eaddr_t eaV)
{
    int i;
    unsigned int size;
    float (*v)[VECTOR_SIZE*BLOCK_SIZE] = (float(*)[VECTOR_SIZE*BLOCK_SIZE])lsblock;

    for(i = 0; i < nA; i += VEC_DMA_LINE) {
        if(nA < i+VEC_DMA_LINE) {
            size = (nA-i)*BLOCK_SIZE*sizeof(float);
        } else {
            size = DMA_SIZE_MAX;
        }
        mfc_get(&v[buf][i*BLOCK_SIZE], eaV + i*BLOCK_SIZE*sizeof(float), size, tag, 0, 0);
    }
}

void iget_perm_all(int buf, int tag, int nA, eaddr_t eaP)
{
    int i;
    unsigned int size;
    int (*v)[VECTOR_SIZE*BLOCK_SIZE] = (int(*)[VECTOR_SIZE*BLOCK_SIZE])lsblock;

    for(i = 0; i < nA; i+= VEC_DMA_LINE) {
        if(nA < i+VEC_DMA_LINE) {
            size = (nA-i)*BLOCK_SIZE*sizeof(float);
        } else {
            size = DMA_SIZE_MAX;
        }
        mfc_get(&v[buf][i*BLOCK_SIZE], eaP + i*BLOCK_SIZE*sizeof(float), size, tag, 0, 0);
    }
}

void iputb_vector_all(int buf, int tag, int nA, eaddr_t eaV)
{
    int i;
    unsigned int size;
    float (*v)[VECTOR_SIZE*BLOCK_SIZE] = (float(*)[VECTOR_SIZE*BLOCK_SIZE])lsblock;

    for(i = 0; i < nA; i += VEC_DMA_LINE) {
        if(nA < i+VEC_DMA_LINE) {
            size = (nA-i)*BLOCK_SIZE*sizeof(float);
        } else {
            size = DMA_SIZE_MAX;
        }
        mfc_putb(&v[buf][i*BLOCK_SIZE], eaV + i*BLOCK_SIZE*sizeof(float), size, tag, 0, 0);
    }
}

void perm_vector(int rbuf, int ebuf, int perm)
{
    int i;
    for(i = 0; i < BLOCK_SIZE; i++) {
        lsV[rbuf][i] = lsrightelem[ebuf][i*4+lsperm[perm][i]%4];
    }
}

// 任意の大きさの右辺ベクトルを置換する
void perm_right_vector_large(int nA, int m, eaddr_t eaB, eaddr_t eaX, eaddr_t eaP)
{
    int iA, im;
    int nxt_eaB;
    int cur_eaX, nxt_eaX;
    int cur_vtag, nxt_vtag;
    int cur_vbuf, nxt_vbuf;

    cur_vtag = 0;

    for(iA = speid; iA < nA; iA += NUMBER_OF_SPES) {
        iget_perm(PERM_RIGHT, TAG_PERM, iA, eaP);
        dma_wait(TAG_PERM);

        nxt_eaB = eaB;
        nxt_eaX = eaX;
        nxt_vtag = 0; 
        nxt_vbuf = VECTOR_V+nxt_vtag;
        iget_right_vector_elem(nxt_vbuf, nxt_vtag, PERM_RIGHT, nxt_eaB);

        for(im = 0; im < m; im++) {
            nxt_eaB = eaB + im*nA*BLOCK_SIZE*sizeof(float);
            cur_eaX = nxt_eaX;
            nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
            cur_vtag = nxt_vtag;
            nxt_vtag = ((nxt_vtag+1) & 1);
            cur_vbuf = nxt_vbuf;
            nxt_vbuf = VECTOR_V+nxt_vtag;

            iget_right_vector_elem(nxt_vbuf, nxt_vtag, PERM_RIGHT, nxt_eaB);

            dma_wait(cur_vtag);
            perm_vector(cur_vbuf, cur_vbuf, PERM_RIGHT);

            iputb_vector(cur_vbuf, cur_vtag, iA, cur_eaX);
        }

        dma_wait(nxt_vtag);
        perm_vector(nxt_vbuf, nxt_vbuf, PERM_RIGHT);

        iputb_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

        dma_wait(cur_vtag);
        dma_wait(nxt_vtag);
    }
}

void perm_vector_all(int outbuf, int refbuf, int permbuf, int nA)
{
    int *o = (int *)((unsigned int)(lsblock) + outbuf*VECTOR_SIZE*BLOCK_SIZE*sizeof(float));
    int *r = (int *)((unsigned int)(lsblock) + refbuf*VECTOR_SIZE*BLOCK_SIZE*sizeof(float));
    int *p = (int *)((unsigned int)(lsblock) + permbuf*VECTOR_SIZE*BLOCK_SIZE*sizeof(float));
    int i;

    for(i = 0; i < nA*BLOCK_SIZE; i += 4) {
        o[i  ] = r[p[i  ]];
        o[i+1] = r[p[i+1]];
        o[i+2] = r[p[i+2]];
        o[i+3] = r[p[i+3]];
    }
}

// ローカルストアに入りきる大きさの右辺ベクトルを置換する
// 8000個程度のfloatを処理可能
void perm_right_vector_small(int nA, int m, eaddr_t eaB, eaddr_t eaX, eaddr_t eaP)
{
    // ブロック用に確保した領域を流用
    // 0: 置換行列
    // 1-3: 入力、計算、出力の役割を順番に交代

    int im;
    int in_tag, ref_tag, out_tag;
    int in_buf, ref_buf, out_buf;
    int temp;
    int perm = 3;
    eaddr_t in_eaB;
    eaddr_t out_eaX;

    im = speid;
    if(im >= m) {
        return;
    }

    in_eaB = eaB + im*nA*BLOCK_SIZE*sizeof(float);
    in_tag = 0;
    ref_tag = 1;
    out_tag = 2;
    in_buf = 2;
    ref_buf = 1;
    out_buf = 0;

    // 置換行列をすべてローカルストア内に取得
    iget_perm_all(perm, TAG_PERM, nA, eaP);
    dma_wait(TAG_PERM);

    iget_vector_all(in_buf, in_tag, nA, in_eaB);

    im += NUMBER_OF_SPES;
    for(; im < m; im += NUMBER_OF_SPES) {
        in_eaB = eaB + im*nA*BLOCK_SIZE*sizeof(float);
        out_eaX = eaX + (im-NUMBER_OF_SPES)*nA*BLOCK_SIZE*sizeof(float);
        temp = out_tag;
        out_tag = ref_tag;
        ref_tag = in_tag;
        in_tag = temp;
        temp = out_buf;
        out_buf = ref_buf;
        ref_buf = in_buf;
        in_buf = temp;

        iget_vector_all(in_buf, in_tag, nA, in_eaB);

        dma_wait(ref_tag);
        perm_vector_all(out_buf, ref_buf, perm, nA);

        iputb_vector_all(out_buf, out_tag, nA, out_eaX);
    }

    out_eaX = eaX + (im-NUMBER_OF_SPES)*nA*BLOCK_SIZE*sizeof(float);
    temp = out_tag;
    out_tag = ref_tag;
    ref_tag = in_tag;
    in_tag = temp;
    temp = out_buf;
    out_buf = ref_buf;
    ref_buf = in_buf;
    in_buf = temp;

    dma_wait(ref_tag);
    perm_vector_all(out_buf, ref_buf, perm, nA);

    iputb_vector_all(out_buf, out_tag, nA, out_eaX);
    dma_wait(in_tag);
    dma_wait(out_tag);
}

void perm_right_vector(int nA, int m, eaddr_t eaB, eaddr_t eaX, eaddr_t eaP)
{
    if(nA < VECTOR_SIZE) {
        perm_right_vector_small(nA, m, eaB, eaX, eaP);
    } else {
        perm_right_vector_large(nA, m, eaB, eaX, eaP);
    }
}

void sub_diag_down_turn(int target, int block)
{
    volatile float *x = lsV[target];
    volatile float (*a)[BLOCK_SIZE] = lsblock[block];
    int ia, ja;
    vector float vv, vx;
    vector float vv0, vv1, vv2, vv3;
    vector float va0, va1, va2, va3;
    vector unsigned char vsplats0 = { 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, };
    vector unsigned char vsplats1 = { 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, };
    vector unsigned char vsplats2 = { 8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, };
    vector unsigned char vsplats3 = { 12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, };

    for(ia = 0; ia < BLOCK_SIZE; ia += 4) {
        x[ia  ] /= a[ia  ][ia  ];
        x[ia+1] -= x[ia  ] * a[ia  ][ia+1];
        x[ia+2] -= x[ia  ] * a[ia  ][ia+2];
        x[ia+3] -= x[ia  ] * a[ia  ][ia+3];

        x[ia+1] /= a[ia+1][ia+1];
        x[ia+2] -= x[ia+1] * a[ia+1][ia+2];
        x[ia+3] -= x[ia+1] * a[ia+1][ia+3];

        x[ia+2] /= a[ia+2][ia+2];
        x[ia+3] -= x[ia+2] * a[ia+2][ia+3];

        x[ia+3] /= a[ia+3][ia+3];

        vv = *(vector float*)&x[ia];
        vv0 = spu_shuffle(vv, vv, vsplats0);
        vv1 = spu_shuffle(vv, vv, vsplats1);
        vv2 = spu_shuffle(vv, vv, vsplats2);
        vv3 = spu_shuffle(vv, vv, vsplats3);

        for(ja = ia+4; ja < BLOCK_SIZE; ja += 4) {
            vx = *(vector float*)&x[ja];
            va0 = *(vector float*)&a[ja  ][ia];
            va1 = *(vector float*)&a[ja+1][ia];
            va2 = *(vector float*)&a[ja+2][ia];
            va3 = *(vector float*)&a[ja+3][ia];

            vx = spu_nmsub(vv0, va0, vx);
            vx = spu_nmsub(vv1, va1, vx);
            vx = spu_nmsub(vv2, va2, vx);
            vx = spu_nmsub(vv3, va3, vx);

            *(vector float*)&x[ja] = vx;
        }
    }
}

// 4x4の小行列内で転置する
// ついでにゼロ行列の判定を行い、ゼロ行列ならば0以外の値を返す
int matrix_inner_turn(int buf)
{
    volatile float (*a)[BLOCK_SIZE] = lsblock[buf];
    int ia, ja;
    vector float vs0, vs1, vs2, vs3;
    vector float vt0, vt1, vt2, vt3;
    vector float vd0, vd1, vd2, vd3;
    vector unsigned char vturn00 = { 0, 1, 2, 3, 4, 5, 6, 7, 16, 17, 18, 19, 20, 21, 22, 23, };
    vector unsigned char vturn01 = { 8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29, 30, 31, };
    vector unsigned char vturn10 = { 0, 1, 2, 3, 16, 17, 18, 19, 8, 9, 10, 11, 24, 25, 26, 27, };
    vector unsigned char vturn11 = { 4, 5, 6, 7, 20, 21, 22, 23, 12, 13, 14, 15, 28, 29, 30, 31, };
    vector unsigned int vor0, vor1;
    vector unsigned int vallor = spu_splats(0u);
    vector unsigned int vcmp;
    vector unsigned int vgather;

    for(ia = 0; ia < BLOCK_SIZE; ia += 4) {
        for(ja = 0; ja < BLOCK_SIZE; ja += 4) {
            vs0 = *(vector float *)&a[ia  ][ja];
            vs1 = *(vector float *)&a[ia+1][ja];
            vs2 = *(vector float *)&a[ia+2][ja];
            vs3 = *(vector float *)&a[ia+3][ja];

            vor0 = (vector unsigned int)spu_or(vs0, vs1);
            vor1 = (vector unsigned int)spu_or(vs2, vs3);
            vor0 = spu_or(vor0, vor1);
            vallor = spu_or(vor0, vallor);

            vt0 = spu_shuffle(vs0, vs2, vturn00);
            vt1 = spu_shuffle(vs1, vs3, vturn00);
            vt2 = spu_shuffle(vs0, vs2, vturn01);
            vt3 = spu_shuffle(vs1, vs3, vturn01);

            vd0 = spu_shuffle(vt0, vt1, vturn10);
            vd1 = spu_shuffle(vt0, vt1, vturn11);
            vd2 = spu_shuffle(vt2, vt3, vturn10);
            vd3 = spu_shuffle(vt2, vt3, vturn11);

            *(vector float *)&a[ia  ][ja] = vd0;
            *(vector float *)&a[ia+1][ja] = vd1;
            *(vector float *)&a[ia+2][ja] = vd2;
            *(vector float *)&a[ia+3][ja] = vd3;
        }
    }

    vcmp = spu_cmpeq(vallor, 0);
    vgather = spu_gather(vcmp);
    return spu_extract(vgather, 0);
}

// blockは4x4の小行列内で転置済み
void sub_inner_turn(int target, int block, int diag)
{
    int ja;
    volatile float (*a)[BLOCK_SIZE] = lsblock[block];
    volatile float *t = lsV[target];
    volatile float *d = lsV[diag];
    uv_float vat0, vat1, vat2, vat3;
    uv_float vat4, vat5, vat6, vat7;
    uv_float vat8, vat9, vat10, vat11;
    uv_float vat12, vat13, vat14, vat15;
    uv_float vat16, vat17, vat18, vat19;
    uv_float vat20, vat21, vat22, vat23;
    uv_float vat24, vat25, vat26, vat27;
    uv_float vat28, vat29, vat30, vat31;
    uv_float vt0, vt1, vt2, vt3;
    uv_float vt4, vt5, vt6, vt7;
    uv_float vdv0;
    uv_float vd0, vd1, vd2, vd3;
    vector unsigned char vsplats0 = { 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, };
    vector unsigned char vsplats1 = { 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, };
    vector unsigned char vsplats2 = { 8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, };
    vector unsigned char vsplats3 = { 12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, };
    uv_uint vaddr;
    vector unsigned int vaddr_inc = { 16, 16, 16, 16, }; // sizeof(float)*4

    vt0.v = *(vector float*)&t[ 0];
    vt1.v = *(vector float*)&t[ 4];
    vt2.v = *(vector float*)&t[ 8];
    vt3.v = *(vector float*)&t[12];
    vt4.v = *(vector float*)&t[16];
    vt5.v = *(vector float*)&t[20];
    vt6.v = *(vector float*)&t[24];
    vt7.v = *(vector float*)&t[28];

    ja = 0;
    vdv0.v = *(vector float*)&d[ja];
    vd0.v = spu_shuffle(vdv0.v, vdv0.v, vsplats0);
    vd1.v = spu_shuffle(vdv0.v, vdv0.v, vsplats1);
    vd2.v = spu_shuffle(vdv0.v, vdv0.v, vsplats2);
    vd3.v = spu_shuffle(vdv0.v, vdv0.v, vsplats3);
    vat0.v  = *(vector float*)&a[ 0][ja];
    vat1.v  = *(vector float*)&a[ 1][ja];
    vat2.v  = *(vector float*)&a[ 2][ja];
    vat3.v  = *(vector float*)&a[ 3][ja];
    vat4.v  = *(vector float*)&a[ 4][ja];
    vat5.v  = *(vector float*)&a[ 5][ja];
    vat6.v  = *(vector float*)&a[ 6][ja];
    vat7.v  = *(vector float*)&a[ 7][ja];
    vat8.v  = *(vector float*)&a[ 8][ja];
    vat9.v  = *(vector float*)&a[ 9][ja];
    vat10.v = *(vector float*)&a[10][ja];
    vat11.v = *(vector float*)&a[11][ja];
    vat12.v = *(vector float*)&a[12][ja];
    vat13.v = *(vector float*)&a[13][ja];
    vat14.v = *(vector float*)&a[14][ja];
    vat15.v = *(vector float*)&a[15][ja];
    vat16.v = *(vector float*)&a[16][ja];
    vat17.v = *(vector float*)&a[17][ja];
    vat18.v = *(vector float*)&a[18][ja];
    vat19.v = *(vector float*)&a[19][ja];
    vat20.v = *(vector float*)&a[20][ja];
    vat21.v = *(vector float*)&a[21][ja];
    vat22.v = *(vector float*)&a[22][ja];
    vat23.v = *(vector float*)&a[23][ja];
    vat24.v = *(vector float*)&a[24][ja];
    vat25.v = *(vector float*)&a[25][ja];
    vat26.v = *(vector float*)&a[26][ja];
    vat27.v = *(vector float*)&a[27][ja];
    vat28.v = *(vector float*)&a[28][ja];
    vat29.v = *(vector float*)&a[29][ja];
    vat30.v = *(vector float*)&a[30][ja];
    vat31.v = *(vector float*)&a[31][ja];

    vaddr.v = spu_splats((unsigned int)(a));
    vaddr.v = spu_add(vaddr.v, vaddr_inc);

    for(ja = 4; ja < BLOCK_SIZE; ja += 4) {
        vt0.v = spu_nmsub(vd0.v, vat0.v, vt0.v);
        vt0.v = spu_nmsub(vd1.v, vat1.v, vt0.v);
        vt0.v = spu_nmsub(vd2.v, vat2.v, vt0.v);
        vt0.v = spu_nmsub(vd3.v, vat3.v, vt0.v);

        vt1.v = spu_nmsub(vd0.v, vat4.v, vt1.v);
        vt1.v = spu_nmsub(vd1.v, vat5.v, vt1.v);
        vt1.v = spu_nmsub(vd2.v, vat6.v, vt1.v);
        vt1.v = spu_nmsub(vd3.v, vat7.v, vt1.v);

        vt2.v = spu_nmsub(vd0.v, vat8.v, vt2.v);
        vt2.v = spu_nmsub(vd1.v, vat9.v, vt2.v);
        vt2.v = spu_nmsub(vd2.v, vat10.v, vt2.v);
        vt2.v = spu_nmsub(vd3.v, vat11.v, vt2.v);

        vt3.v = spu_nmsub(vd0.v, vat12.v, vt3.v);
        vt3.v = spu_nmsub(vd1.v, vat13.v, vt3.v);
        vt3.v = spu_nmsub(vd2.v, vat14.v, vt3.v);
        vt3.v = spu_nmsub(vd3.v, vat15.v, vt3.v);

        vt4.v = spu_nmsub(vd0.v, vat16.v, vt4.v);
        vt4.v = spu_nmsub(vd1.v, vat17.v, vt4.v);
        vt4.v = spu_nmsub(vd2.v, vat18.v, vt4.v);
        vt4.v = spu_nmsub(vd3.v, vat19.v, vt4.v);

        vt5.v = spu_nmsub(vd0.v, vat20.v, vt5.v);
        vt5.v = spu_nmsub(vd1.v, vat21.v, vt5.v);
        vt5.v = spu_nmsub(vd2.v, vat22.v, vt5.v);
        vt5.v = spu_nmsub(vd3.v, vat23.v, vt5.v);

        vt6.v = spu_nmsub(vd0.v, vat24.v, vt6.v);
        vt6.v = spu_nmsub(vd1.v, vat25.v, vt6.v);
        vt6.v = spu_nmsub(vd2.v, vat26.v, vt6.v);
        vt6.v = spu_nmsub(vd3.v, vat27.v, vt6.v);

        vt7.v = spu_nmsub(vd0.v, vat28.v, vt7.v);
        vt7.v = spu_nmsub(vd1.v, vat29.v, vt7.v);
        vt7.v = spu_nmsub(vd2.v, vat30.v, vt7.v);
        vt7.v = spu_nmsub(vd3.v, vat31.v, vt7.v);

        vat0.q  = si_lqd(vaddr.q, 0);
        vat1.q  = si_lqd(vaddr.q, 128);
        vat2.q  = si_lqd(vaddr.q, 256);
        vat3.q  = si_lqd(vaddr.q, 384);
        vat4.q  = si_lqd(vaddr.q, 512);
        vat5.q  = si_lqd(vaddr.q, 640);
        vat6.q  = si_lqd(vaddr.q, 768);
        vat7.q  = si_lqd(vaddr.q, 896);
        vat8.q  = si_lqd(vaddr.q, 1024);
        vat9.q  = si_lqd(vaddr.q, 1152);
        vat10.q = si_lqd(vaddr.q, 1280);
        vat11.q = si_lqd(vaddr.q, 1408);
        vat12.q = si_lqd(vaddr.q, 1536);
        vat13.q = si_lqd(vaddr.q, 1664);
        vat14.q = si_lqd(vaddr.q, 1792);
        vat15.q = si_lqd(vaddr.q, 1920);
        vat16.q = si_lqd(vaddr.q, 2048);
        vat17.q = si_lqd(vaddr.q, 2176);
        vat18.q = si_lqd(vaddr.q, 2304);
        vat19.q = si_lqd(vaddr.q, 2432);
        vat20.q = si_lqd(vaddr.q, 2560);
        vat21.q = si_lqd(vaddr.q, 2688);
        vat22.q = si_lqd(vaddr.q, 2816);
        vat23.q = si_lqd(vaddr.q, 2944);
        vat24.q = si_lqd(vaddr.q, 3072);
        vat25.q = si_lqd(vaddr.q, 3200);
        vat26.q = si_lqd(vaddr.q, 3328);
        vat27.q = si_lqd(vaddr.q, 3456);
        vat28.q = si_lqd(vaddr.q, 3584);
        vat29.q = si_lqd(vaddr.q, 3712);
        vat30.q = si_lqd(vaddr.q, 3840);
        vat31.q = si_lqd(vaddr.q, 3968);
        vdv0.v = *(vector float*)&d[ja];
        vd0.v = spu_shuffle(vdv0.v, vdv0.v, vsplats0);
        vd1.v = spu_shuffle(vdv0.v, vdv0.v, vsplats1);
        vd2.v = spu_shuffle(vdv0.v, vdv0.v, vsplats2);
        vd3.v = spu_shuffle(vdv0.v, vdv0.v, vsplats3);
        vaddr.v = spu_add(vaddr.v, vaddr_inc);
    }

    vt0.v = spu_nmsub(vd0.v, vat0.v, vt0.v);
    vt0.v = spu_nmsub(vd1.v, vat1.v, vt0.v);
    vt0.v = spu_nmsub(vd2.v, vat2.v, vt0.v);
    vt0.v = spu_nmsub(vd3.v, vat3.v, vt0.v);

    vt1.v = spu_nmsub(vd0.v, vat4.v, vt1.v);
    vt1.v = spu_nmsub(vd1.v, vat5.v, vt1.v);
    vt1.v = spu_nmsub(vd2.v, vat6.v, vt1.v);
    vt1.v = spu_nmsub(vd3.v, vat7.v, vt1.v);

    vt2.v = spu_nmsub(vd0.v, vat8.v, vt2.v);
    vt2.v = spu_nmsub(vd1.v, vat9.v, vt2.v);
    vt2.v = spu_nmsub(vd2.v, vat10.v, vt2.v);
    vt2.v = spu_nmsub(vd3.v, vat11.v, vt2.v);

    vt3.v = spu_nmsub(vd0.v, vat12.v, vt3.v);
    vt3.v = spu_nmsub(vd1.v, vat13.v, vt3.v);
    vt3.v = spu_nmsub(vd2.v, vat14.v, vt3.v);
    vt3.v = spu_nmsub(vd3.v, vat15.v, vt3.v);

    vt4.v = spu_nmsub(vd0.v, vat16.v, vt4.v);
    vt4.v = spu_nmsub(vd1.v, vat17.v, vt4.v);
    vt4.v = spu_nmsub(vd2.v, vat18.v, vt4.v);
    vt4.v = spu_nmsub(vd3.v, vat19.v, vt4.v);

    vt5.v = spu_nmsub(vd0.v, vat20.v, vt5.v);
    vt5.v = spu_nmsub(vd1.v, vat21.v, vt5.v);
    vt5.v = spu_nmsub(vd2.v, vat22.v, vt5.v);
    vt5.v = spu_nmsub(vd3.v, vat23.v, vt5.v);

    vt6.v = spu_nmsub(vd0.v, vat24.v, vt6.v);
    vt6.v = spu_nmsub(vd1.v, vat25.v, vt6.v);
    vt6.v = spu_nmsub(vd2.v, vat26.v, vt6.v);
    vt6.v = spu_nmsub(vd3.v, vat27.v, vt6.v);

    vt7.v = spu_nmsub(vd0.v, vat28.v, vt7.v);
    vt7.v = spu_nmsub(vd1.v, vat29.v, vt7.v);
    vt7.v = spu_nmsub(vd2.v, vat30.v, vt7.v);
    vt7.v = spu_nmsub(vd3.v, vat31.v, vt7.v);

    *(vector float*)&t[ 0] = vt0.v;
    *(vector float*)&t[ 4] = vt1.v;
    *(vector float*)&t[ 8] = vt2.v;
    *(vector float*)&t[12] = vt3.v;
    *(vector float*)&t[16] = vt4.v;
    *(vector float*)&t[20] = vt5.v;
    *(vector float*)&t[24] = vt6.v;
    *(vector float*)&t[28] = vt7.v;
}

// 各SPEが少なくとも1本は担当することが前提
void forward_substitution_1spe(int nA, int m, eaddr_t eaA, eaddr_t eaX)
{
    int iA, jA;
    int im;
    eaddr_t cur_eaX, nxt_eaX;
    int cur_dtag, nxt_dtag;
    int cur_utag, nxt_utag;
    int cur_vtag, nxt_vtag;
    int cur_dbuf, nxt_dbuf;
    int cur_ubuf, nxt_ubuf;
    int cur_vbuf, nxt_vbuf;
    int cur_xbuf, nxt_xbuf;
    int iszero;

    nxt_dtag = 0;
    nxt_utag = 2;
    nxt_vtag = 4;
    nxt_dbuf = BLOCK_D+nxt_dtag;
    nxt_ubuf = BLOCK_U-2+nxt_utag;
    nxt_vbuf = VECTOR_V-4+nxt_vtag;
    nxt_xbuf = VECTOR_X-4+nxt_vtag;

    for(iA = 0; iA < nA; iA++) {
        cur_dtag = 0;
        cur_dbuf = BLOCK_D+nxt_dtag;
        iget_block(cur_dbuf, cur_dtag, nA, iA, iA, eaA);

        im = speid;
        cur_vtag = 5;
        nxt_eaX = eaX+im*nA*BLOCK_SIZE*sizeof(float);
        nxt_vtag = 4;
        nxt_vbuf = VECTOR_V-4+nxt_vtag;
        iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

        dma_wait(cur_dtag);
        (void)matrix_inner_turn(cur_dbuf);

        im += NUMBER_OF_SPES;
        for(; im < m; im += NUMBER_OF_SPES) {
            cur_eaX = nxt_eaX;
            nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
            cur_vtag = nxt_vtag;
            nxt_vtag = ((nxt_vtag+1) & 1) + 4;
            cur_vbuf = nxt_vbuf;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;

            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

            dma_wait(cur_vbuf);
            sub_diag_down_turn(cur_vbuf, cur_dbuf);

            iputb_vector(cur_vbuf, cur_vtag, iA, cur_eaX);
        }

        dma_wait(nxt_vtag);
        sub_diag_down_turn(nxt_vbuf, cur_dbuf);

        iputb_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
       
        for(jA = iA+1; jA < nA; jA++) {
            cur_utag = 2;
            cur_ubuf = BLOCK_U-2+cur_utag;
            iget_block(cur_ubuf, cur_utag, nA, jA, iA, eaA);
            dma_wait(cur_utag);

            iszero = matrix_inner_turn(cur_ubuf);
            //if(__builtin_expect(iszero, 0)) {
            //    continue;
            //}

            im = speid;
            nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
            nxt_vtag = ((nxt_vtag+1) & 1) + 4;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;
            nxt_xbuf = VECTOR_X-4+nxt_vtag;
            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
            iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

            im += NUMBER_OF_SPES;
            for(; im < m; im += NUMBER_OF_SPES) {
                cur_eaX = nxt_eaX;
                nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
                cur_vtag = nxt_vtag;
                nxt_vtag = ((nxt_vtag+1) & 1) + 4;
                cur_vbuf = nxt_vbuf;
                nxt_vbuf = VECTOR_V-4+nxt_vtag;
                cur_xbuf = nxt_xbuf;
                nxt_xbuf = VECTOR_X-4+nxt_vtag;

                iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
                iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

                dma_wait(cur_vtag);
                sub_inner_turn(cur_xbuf, cur_ubuf, cur_vbuf);

                iputb_vector(cur_xbuf, cur_vtag, jA, cur_eaX);
            }

            dma_wait(nxt_vtag);
            sub_inner_turn(nxt_xbuf, cur_ubuf, nxt_vbuf);

            iputb_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);
            dma_wait(nxt_vtag);
        }
    }

    mfc_barrier(TAG_SYNC);
}

void forward_substitution_nspe(int nA, int m, eaddr_t eaA, eaddr_t eaX)
{
    int iA, jA;
    int im;
    eaddr_t cur_eaX, nxt_eaX;
    int cur_dtag, nxt_dtag;
    int cur_utag, nxt_utag;
    int cur_vtag, nxt_vtag;
    int cur_dbuf, nxt_dbuf;
    int cur_ubuf, nxt_ubuf;
    int cur_vbuf, nxt_vbuf;
    int cur_xbuf, nxt_xbuf;
    usyncdata signal = { { 0, 0, {0}, 0, }, };
    int iszero;

    nxt_dtag = 0;
    nxt_utag = 2;
    nxt_vtag = 4;
    nxt_dbuf = BLOCK_D+nxt_dtag;
    nxt_ubuf = BLOCK_U-2+nxt_utag;
    nxt_vbuf = VECTOR_V-4+nxt_vtag;
    nxt_xbuf = VECTOR_X-4+nxt_vtag;

    for(iA = 0; iA < nA; iA++) {
        if(is_assigned(iA)) {
            cur_dtag = 0;
            cur_dbuf = BLOCK_D+nxt_dtag;
            iget_block(cur_dbuf, cur_dtag, nA, iA, iA, eaA);

            cur_vtag = 5;
            nxt_eaX = eaX;
            nxt_vtag = 4;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;
            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

            dma_wait(cur_dtag);
            (void)matrix_inner_turn(cur_dbuf);

            for(im = 1; im < m; im++) {
                cur_eaX = nxt_eaX;
                nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
                cur_vtag = nxt_vtag;
                nxt_vtag = ((nxt_vtag+1) & 1) + 4;
                cur_vbuf = nxt_vbuf;
                nxt_vbuf = VECTOR_V-4+nxt_vtag;

                iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

                dma_wait(cur_vbuf);
                sub_diag_down_turn(cur_vbuf, cur_dbuf);

                iputb_vector(cur_vbuf, cur_vtag, iA, cur_eaX);
            }

            dma_wait(nxt_vtag);
            sub_diag_down_turn(nxt_vbuf, cur_dbuf);

            iputb_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

            mfc_barrier(TAG_SYNC);

            signal.s.line = iA;
            send_signal_all(signal);
        } else {
#if defined READ_DECREMENTER
            s = spu_read_decrementer();
            while(lssignal[SYNC_SIGNAL].s.line < iA) {
                t = spu_read_decrementer();
                if(s-t > PRINT_CYCLE) {
                    spe_printf("SPE(%d): too late!(wait diag up vector) line(%d) = %d\n", speid, SYNC_SIGNAL, lssignal[SYNC_SIGNAL].s.line);
                    s = t;
                }
            }
#else
            while(lssignal[SYNC_SIGNAL].s.line < iA)  {
                ;
            }
#endif
        }

        jA = (iA+1)/NUMBER_OF_SPES*NUMBER_OF_SPES+speid;
        if(jA < iA+1) {
            jA += NUMBER_OF_SPES;
        }
        for(; jA < nA; jA += NUMBER_OF_SPES) {
            cur_utag = 2;
            cur_ubuf = BLOCK_U-2+cur_utag;
            iget_block(cur_ubuf, cur_utag, nA, jA, iA, eaA);
            dma_wait(cur_utag);

            iszero = matrix_inner_turn(cur_ubuf);
            //if(__builtin_expect(iszero, 0)) { 
            //    continue;
            //}

            nxt_eaX = eaX;
            nxt_vtag = ((nxt_vtag+1) & 1) + 4;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;
            nxt_xbuf = VECTOR_X-4+nxt_vtag;
            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
            iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

            for(im = 1; im < m; im++) {
                cur_eaX = nxt_eaX;
                nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
                cur_vtag = nxt_vtag;
                nxt_vtag = ((nxt_vtag+1) & 1) + 4;
                cur_vbuf = nxt_vbuf;
                nxt_vbuf = VECTOR_V-4+nxt_vtag;
                cur_xbuf = nxt_xbuf;
                nxt_xbuf = VECTOR_X-4+nxt_vtag;

                iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
                iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

                dma_wait(cur_vtag);
                sub_inner_turn(cur_xbuf, cur_ubuf, cur_vbuf);

                iputb_vector(cur_xbuf, cur_vtag, jA, cur_eaX);
            }

            dma_wait(nxt_vtag);
            sub_inner_turn(nxt_xbuf, cur_ubuf, nxt_vbuf);

            iputb_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);
            dma_wait(nxt_vtag);
        }
    }

    mfc_barrier(TAG_SYNC);
}

void sub_diag_up_turn(int target, int ublock)
{
    volatile float *x = lsV[target];
    volatile float (*a)[BLOCK_SIZE] = lsblock[ublock];
    int ia, ja;
    vector float vv, vx;
    vector float vv0, vv1, vv2, vv3;
    vector float va0, va1, va2, va3;
    vector unsigned char vsplats0 = { 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, };
    vector unsigned char vsplats1 = { 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, };
    vector unsigned char vsplats2 = { 8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, };
    vector unsigned char vsplats3 = { 12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, };

    for(ia = BLOCK_SIZE-4; ia >= 0; ia -= 4) {
        x[ia+2] -= x[ia+3] * a[ia+3][ia+2];
        x[ia+1] -= x[ia+3] * a[ia+3][ia+1];
        x[ia  ] -= x[ia+3] * a[ia+3][ia  ];

        x[ia+1] -= x[ia+2] * a[ia+2][ia+1];
        x[ia  ] -= x[ia+2] * a[ia+2][ia  ];

        x[ia  ] -= x[ia+1] * a[ia+1][ia  ];

        vv = *(vector float*)&x[ia];
        vv0 = spu_shuffle(vv, vv, vsplats0);
        vv1 = spu_shuffle(vv, vv, vsplats1);
        vv2 = spu_shuffle(vv, vv, vsplats2);
        vv3 = spu_shuffle(vv, vv, vsplats3);
        for(ja = ia-4; ja >= 0; ja -= 4) {
            vx = *(vector float*)&x[ja];
            va0 = *(vector float*)&a[ja  ][ia];
            va1 = *(vector float*)&a[ja+1][ia];
            va2 = *(vector float*)&a[ja+2][ia];
            va3 = *(vector float*)&a[ja+3][ia];

            vx = spu_nmsub(vv0, va0, vx);
            vx = spu_nmsub(vv1, va1, vx);
            vx = spu_nmsub(vv2, va2, vx);
            vx = spu_nmsub(vv3, va3, vx);

            *(vector float*)&x[ja] = vx;
        }
    }
}

// 各SPEが少なくとも1本は担当することが前提
void backward_substitution_1spe(int nA, int m, eaddr_t eaA, eaddr_t eaX)
{
    int iA, jA;
    int im;
    eaddr_t cur_eaX, nxt_eaX;
    int cur_dtag, nxt_dtag;
    int cur_utag, nxt_utag;
    int cur_vtag, nxt_vtag;
    int cur_dbuf, nxt_dbuf;
    int cur_ubuf, nxt_ubuf;
    int cur_vbuf, nxt_vbuf;
    int cur_xbuf, nxt_xbuf;
    usyncdata signal = { { 0, 0, {0}, 0, }, };
    int iszero;

    nxt_dtag = 0;
    nxt_utag = 2;
    nxt_vtag = 4;
    nxt_dbuf = BLOCK_D+nxt_dtag;
    nxt_ubuf = BLOCK_U-2+nxt_utag;
    nxt_vbuf = VECTOR_V-4+nxt_vtag;
    nxt_xbuf = VECTOR_X-4+nxt_vtag;

    for(iA = nA-1; iA >= 0; iA--) {
        cur_dtag = 0;
        cur_dbuf = BLOCK_D+nxt_dtag;
        iget_block(cur_dbuf, cur_dtag, nA, iA, iA, eaA);

        im = speid;
        nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
        nxt_vtag = 4;
        nxt_vbuf = VECTOR_V-4+nxt_vtag;
        iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

        dma_wait(cur_dtag);
        (void)matrix_inner_turn(cur_dbuf);

        im += NUMBER_OF_SPES;
        for(; im < m; im += NUMBER_OF_SPES) {
            cur_eaX = nxt_eaX;
            nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
            cur_vtag = nxt_vtag;
            nxt_vtag = ((nxt_vtag+1) & 1) + 4;
            cur_vbuf = nxt_vbuf;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;

            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

            dma_wait(cur_vbuf);
            sub_diag_up_turn(cur_vbuf, cur_dbuf);

            iputb_vector(cur_vbuf, cur_vtag, iA, cur_eaX);
        }
        dma_wait(nxt_vtag);
        sub_diag_up_turn(nxt_vbuf, cur_dbuf);

        iputb_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

        mfc_barrier(TAG_SYNC);

        signal.s.line = nA-1-iA;
        send_signal_all(signal);

        for(jA = 0; jA < iA; jA++) {
            cur_utag = 2;
            cur_ubuf = BLOCK_U-2+cur_utag;
            iget_block(cur_ubuf, cur_utag, nA, jA, iA, eaA);
            dma_wait(cur_utag);

            iszero = matrix_inner_turn(cur_ubuf);
            //if(__builtin_expect(iszero, 0)) {
            //    continue;
            //}

            im = speid;
            nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
            nxt_vtag = ((nxt_vtag+1) & 1) + 4;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;
            nxt_xbuf = VECTOR_X-4+nxt_vtag;
            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
            iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

            im += NUMBER_OF_SPES;
            for(; im < m; im += NUMBER_OF_SPES) {
                cur_eaX = nxt_eaX;
                nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
                cur_vtag = nxt_vtag;
                nxt_vtag = ((nxt_vtag+1) & 1) + 4;
                cur_vbuf = nxt_vbuf;
                nxt_vbuf = VECTOR_V-4+nxt_vtag;
                cur_xbuf = nxt_xbuf;
                nxt_xbuf = VECTOR_X-4+nxt_vtag;

                iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
                iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

                dma_wait(cur_vtag);
                sub_inner_turn(cur_xbuf, cur_ubuf, cur_vbuf);

                iputb_vector(cur_xbuf, cur_vtag, jA, cur_eaX);
            }

            dma_wait(nxt_vtag);
            sub_inner_turn(nxt_xbuf, cur_ubuf, nxt_vbuf);

            iputb_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

            dma_wait(nxt_vtag);
        }
    }

    mfc_barrier(TAG_SYNC);
}

void backward_substitution_nspe(int nA, int m, eaddr_t eaA, eaddr_t eaX)
{
    int iA, jA;
    int im;
    eaddr_t cur_eaX, nxt_eaX;
    int cur_dtag, nxt_dtag;
    int cur_utag, nxt_utag;
    int cur_vtag, nxt_vtag;
    int cur_dbuf, nxt_dbuf;
    int cur_ubuf, nxt_ubuf;
    int cur_vbuf, nxt_vbuf;
    int cur_xbuf, nxt_xbuf;
    usyncdata signal = { { 0, 0, {0}, 0, }, };
    int iszero;

    nxt_dtag = 0;
    nxt_utag = 2;
    nxt_vtag = 4;
    nxt_dbuf = BLOCK_D+nxt_dtag;
    nxt_ubuf = BLOCK_U-2+nxt_utag;
    nxt_vbuf = VECTOR_V-4+nxt_vtag;
    nxt_xbuf = VECTOR_X-4+nxt_vtag;

    for(iA = nA-1; iA >= 0; iA--) {
        if(is_assigned(iA)) {
            cur_dtag = 0;
            cur_dbuf = BLOCK_D+nxt_dtag;
            iget_block(cur_dbuf, cur_dtag, nA, iA, iA, eaA);

            nxt_eaX = eaX;
            nxt_vtag = 4;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;
            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

            dma_wait(cur_dtag);
            (void)matrix_inner_turn(cur_dbuf);

            for(im = 1; im < m; im++) {
                cur_eaX = nxt_eaX;
                nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
                cur_vtag = nxt_vtag;
                nxt_vtag = ((nxt_vtag+1) & 1) + 4;
                cur_vbuf = nxt_vbuf;
                nxt_vbuf = VECTOR_V-4+nxt_vtag;

                iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

                dma_wait(cur_vbuf);
                sub_diag_up_turn(cur_vbuf, cur_dbuf);

                iputb_vector(cur_vbuf, cur_vtag, iA, cur_eaX);
            }

            dma_wait(nxt_vtag);
            sub_diag_up_turn(nxt_vbuf, cur_dbuf);

            iputb_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);

            mfc_barrier(TAG_SYNC);

            signal.s.line = nA-1-iA;
            send_signal_all(signal);
        } else {
#if defined READ_DECREMENTER
            s = spu_read_decrementer();
            while(lssignal[SYNC_SIGNAL].s.line < nA-1-iA) {
                t = spu_read_decrementer();
                if(s-t > PRINT_CYCLE) {
                    spe_printf("SPE(%d): too late!(wait diag down vector) line(%d) = %d\n", speid, SYNC_SIGNAL, lssignal[SYNC_SIGNAL].s.line);
                    s = t;
                }
            }
#else
            while(lssignal[SYNC_SIGNAL].s.line < nA-1-iA)  {
                ;
            }
#endif
        }

        for(jA = speid; jA < iA; jA += NUMBER_OF_SPES) {
            cur_utag = 2;
            cur_ubuf = BLOCK_U-2+cur_utag;
            iget_block(cur_ubuf, cur_utag, nA, jA, iA, eaA);
            dma_wait(cur_utag);

            iszero = matrix_inner_turn(cur_ubuf);
            //if(__builtin_expect(iszero, 0)) {
            //    continue;
            //}

            nxt_eaX = eaX;
            nxt_vtag = ((nxt_vtag+1) & 1) + 4;
            nxt_vbuf = VECTOR_V-4+nxt_vtag;
            nxt_xbuf = VECTOR_X-4+nxt_vtag;
            iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
            iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

            for(im = 1; im < m; im++) {
                cur_eaX = nxt_eaX;
                nxt_eaX = eaX + im*nA*BLOCK_SIZE*sizeof(float);
                cur_vtag = nxt_vtag;
                nxt_vtag = ((nxt_vtag+1) & 1) + 4;
                cur_vbuf = nxt_vbuf;
                nxt_vbuf = VECTOR_V-4+nxt_vtag;
                cur_xbuf = nxt_xbuf;
                nxt_xbuf = VECTOR_X-4+nxt_vtag;

                iget_vector(nxt_vbuf, nxt_vtag, iA, nxt_eaX);
                iget_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

                dma_wait(cur_vtag);
                sub_inner_turn(cur_xbuf, cur_ubuf, cur_vbuf);

                iputb_vector(cur_xbuf, cur_vtag, jA, cur_eaX);
            }

            dma_wait(nxt_vtag);
            sub_inner_turn(nxt_xbuf, cur_ubuf, nxt_vbuf);

            iputb_vector(nxt_xbuf, nxt_vtag, jA, nxt_eaX);

            dma_wait(nxt_vtag);
        }
    }

    mfc_barrier(TAG_SYNC);
}

void solve_1spe_master(int nA, int m, eaddr_t eaA, eaddr_t eaP, eaddr_t eaB, eaddr_t eaX)
{
    usyncdata signal = { { 0, 0, {0}, 0, }, };

    perm_right_vector(nA, m, eaB, eaX, eaP);

    run_spes(signal);
    forward_substitution_1spe(nA, m, eaA, eaX);
    backward_substitution_1spe(nA, m, eaA, eaX);
    join_spes();
}

void solve_nspe_master(int nA, int m, eaddr_t eaA, eaddr_t eaP, eaddr_t eaB, eaddr_t eaX)
{
    usyncdata signal = { { 0, 0, {0}, 0, }, };

    perm_right_vector(nA, m, eaB, eaX, eaP);

    run_spes(signal);
    forward_substitution_nspe(nA, m, eaA, eaX);
    join_spes();

    run_spes(signal);
    backward_substitution_nspe(nA, m, eaA, eaX);
    join_spes();
}

void solve_1spe_slave(int nA, int m, eaddr_t eaA, eaddr_t eaP, eaddr_t eaB, eaddr_t eaX)
{
    usyncdata signal = { { 0, 0, {0}, 0, }, };

    perm_right_vector(nA, m, eaB, eaX, eaP);

    wait_for_signal();
    forward_substitution_1spe(nA, m, eaA, eaX);
    backward_substitution_1spe(nA, m, eaA, eaX);
    send_signal(signal);
}

void solve_nspe_slave(int nA, int m, eaddr_t eaA, eaddr_t eaP, eaddr_t eaB, eaddr_t eaX)
{
    usyncdata signal = { { 0, 0, {0}, 0, }, };

    perm_right_vector(nA, m, eaB, eaX, eaP);

    wait_for_signal();
    forward_substitution_nspe(nA, m, eaA, eaX);
    send_signal(signal);

    wait_for_signal();
    backward_substitution_nspe(nA, m, eaA, eaX);
    send_signal(signal);
}

void spe_soleqs(struct spe_ctrl* sc){
    int i;
    int n = sc->n;
    int m = sc->m;
    int nA = n / BLOCK_SIZE;
    eaddr_t eaA = (eaddr_t)sc->buf;
    eaddr_t eaB = (eaddr_t)sc->buf+sizeof(float)*(n*n);
    eaddr_t eaX = (eaddr_t)sc->buf+sizeof(float)*(n*n+n*m);
    eaddr_t eaD = (eaddr_t)sc->buf+sizeof(float)*(n*n+n*m+n*m);
    eaddr_t eaP = (eaddr_t)sc->buf+sizeof(float)*(n*n+n*m+n*m+n*n);
    int cur_buf, nxt_buf;
    int cur_iA, nxt_iA;
    int cur_jA, nxt_jA;
    speid = sc->id;
    vector unsigned int vinit = { 0, 0, 0, 0, };
    void (*pfsolve)(int, int, eaddr_t, eaddr_t, eaddr_t, eaddr_t);
    int mperspe;

    set_linesize(nA*BLOCK_SIZE*sizeof(float));

    for(i = 0; i < NUMBER_OF_SPES; i++) {
        lsresult[i].v = vinit;

        eals[i] = sc->ls_addr[i];
        ealssignal[i] = sc->ls_addr[i] + (eaddr_t)&lssignal;
        ealsuline[i] = sc->ls_addr[i] + (eaddr_t)&lsuline;
    }

    i = speid;
    nxt_buf = 0;
    nxt_iA = i / nA;
    nxt_jA = i % nA;

    mperspe = m / NUMBER_OF_SPES;
    if(mperspe < 16) {
        if(is_master()) {
            pfsolve = solve_nspe_master;
        } else {
            pfsolve = solve_nspe_slave;
        }
    } else {
        if(is_master()) {
            pfsolve = solve_1spe_master;
        } else {
            pfsolve = solve_1spe_slave;
        }
    }


    if(i < nA*nA) {
        iget_block_ml(nxt_buf, nxt_buf, nA, nxt_iA, nxt_jA, eaA);

        i += NUMBER_OF_SPES;
        for(; i < nA*nA; i += NUMBER_OF_SPES) {
            cur_buf = nxt_buf;
            nxt_buf = (nxt_buf+1) & 3;
            cur_iA = nxt_iA;
            nxt_iA = i / nA;
            cur_jA = nxt_jA;
            nxt_jA = i % nA;

            iget_block_ml(nxt_buf, nxt_buf, nA, nxt_iA, nxt_jA, eaA);
            dma_wait(cur_buf);
            iputb_block_line(cur_buf, cur_buf, nA, cur_iA, cur_jA, eaD);
        }

        iputb_block_line(nxt_buf, nxt_buf, nA, nxt_iA, nxt_jA, eaD);
        mfc_barrier(TAG_SYNC);
    }

    blocked_lu_decomposition(n, m, eaD, eaP);

    (*pfsolve)(nA, m, eaD, eaP, eaB, eaX);

#if defined FILL_A_AFTER_SOLEQS
    if(speid == 0) {
        nxt_buf = 0;
        nxt_iA = 0;
        nxt_jA = 0;

        iget_block_line(nxt_buf, nxt_buf, nA, nxt_iA, nxt_jA, eaD);

        for(i = 1; i < nA*nA; i++) {
            cur_buf = nxt_buf;
            nxt_buf = (nxt_buf+1) & 1;
            cur_iA = nxt_iA;
            nxt_iA = i / nA;
            cur_jA = nxt_jA;
            nxt_jA = i % nA;

            iget_block_line(nxt_buf, nxt_buf, nA, nxt_iA, nxt_jA, eaD);
            dma_wait(cur_buf);
            iputb_block_ml(cur_buf, cur_buf, nA, cur_iA, cur_jA, eaA);
        }

        iputb_block_ml(nxt_buf, nxt_buf, nA, nxt_iA, nxt_jA, eaA);
        dma_wait(nxt_buf);
    }
#endif

    mfc_barrier(TAG_SYNC);
    dma_wait(TAG_SYNC);

#if defined PROF_MATRIX_NMSUB || defined PRINT_PROF
    if(speid == 0) {
        spe_printf("dec = %d, %lf sec, %f cycle\n", dec, dec/(100.0*1024.0*1024.0), (dec/(100.0*1024.0*1024.0))*3.2e9);
    }
#endif
}

