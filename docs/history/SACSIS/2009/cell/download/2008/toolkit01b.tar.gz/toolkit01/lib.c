/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2007-12-07                */
/*----------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <spe/sys/spelib_types.h>
#include <spe_stdio_srv.h>
#include "define.h"
#include <math.h>

typedef union fs{
    float f;
    unsigned char c[4];
}FS;

/*----------------------------------------------------------------------*/
double my_clock()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec + (double)tv.tv_usec*1e-6;
};

void matrix_multiplication(int n, int m, float* a, float* x, float* b)
{
    int i,j,k;

    for(k=0;k<m;k++){
        for(i=0;i<n;i++){
            b[k*n+i] = 0.0;
            for(j=0;j<n;j++){
                b[k*n+i] += a[n*i+j]*x[k*n+j];
            }
        }
    }
}

void get_matrix(int n, int m, float* a, unsigned int s)
{
    int i,j;
    int p,q;

    // generate by random values
    // srand((unsigned int)time(NULL));
    if(s == 1){
        // tridiagonal matrix
        p=2;
        q=2;
        for(i=0;i<n;i++){
            for(j=0;j<m;j++){
                if(i+p<=j || j+q<=i) a[n*i+j] = 0.0;
                else a[n*i+j] = ((float)rand()/(float)RAND_MAX);
            }
        }
    }
    else{
        for(j=0;j<m;j++){
            for(i=0;i<n;i++){
                a[n*j+i] = ((float)rand()/(float)RAND_MAX);
            }
        }
    }
}

void generate_matrix(int n, int m, float* buf, unsigned int s)
{
    int i;
    float* b;
    float* x;
    
    b = (float*)((unsigned int)buf+sizeof(float)*n*n);
    x = (float*)((unsigned int)b+sizeof(float)*n*m);

    if(s == 0){
        for(i=0;i<n*m;i++) x[i] = 1.0;
    }
    else{
        for(i=0;i<n*m;i++) x[i] = ((float)rand()/(float)RAND_MAX);
    }

    matrix_multiplication(n,m,buf,x,b);
}

void check(int n, int m, float* buf, unsigned int s)
{
    int i,j;
    float* b;
    float* c;
    float* x;
    float ftxmax;
    float famax;
    float fta;

    float feps;
    FS fs;
    
    b = (float*)((unsigned int)buf+sizeof(float)*n*n);
    x = (float*)((unsigned int)b+sizeof(float)*n*m);
    c = (float*)((unsigned int)x+sizeof(float)*n*m);

    srand(s);
    get_matrix(n,n,buf,s);
    matrix_multiplication(n, m, buf, x, c);

    generate_matrix(n, m, buf, s);

    feps = 1.0;
    for(i=0;i<23;i++){
        feps *= 0.5;
    }

    famax = 0.0;
    for(i=0;i<n;i++){
        fta = 0.0;
        for(j=0;j<n;j++)
            fta += fabs(buf[n*j+i]);
        if(famax < fta) famax = fta;
    }

    ftxmax = fabs(c[0] - b[0]);
    for(i=1;i<n*m;i++){
        if(fabs(c[i] - b[i]) > ftxmax){
            ftxmax = fabs(c[i] - b[i]);
        }
    }
    fs.f = (float)ftxmax/((float)feps*(float)famax*(float)n);
    // for x86
    /*
      printf("check[%2d] : %1.5f (%02X%02X%02X%02X)\n",k,fs.f,
              *(unsigned char*)&fs.c[3],
              *(unsigned char*)&fs.c[2],
              *(unsigned char*)&fs.c[1],
              *(unsigned char*)&fs.c[0]);
    */
    // for ppc
    printf("check : %1.5f (%02X%02X%02X%02X)\n",
           fs.f,
           *(unsigned char*)&fs.c[0],
           *(unsigned char*)&fs.c[1],
           *(unsigned char*)&fs.c[2],
           *(unsigned char*)&fs.c[3]);
}

void disp_matrix(int n, int m, float* a)
{
    int i, j;

    // for standard output
    for(j=0;j<m;j++){
        for(i=0;i<n;i++){
            printf("%1.5f ",a[j*n+i]);
        }
        printf("\n");
    }
}
