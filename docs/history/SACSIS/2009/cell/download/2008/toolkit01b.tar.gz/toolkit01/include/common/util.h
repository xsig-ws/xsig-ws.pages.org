/* ============================================================================
       Copyright(C) 2005-2006 TOSHIBA CORPORATION, All Rights Reserved.
                  There is NO WARRANTY for this source code.
             You can not MODIFY or COPY or RE-DISTRIBUTE this file.
 ============================================================================*/

#ifndef __UTIL_H__
#define __UTIL_H__

#define BEST_ALIGN 128
#define DMA_TAG_MASK(x) (1 << x)
#define SIZE_128(type) (128 / sizeof(type))

typedef unsigned int uint;
typedef unsigned char uchar;

#endif // __UTIL_H__
