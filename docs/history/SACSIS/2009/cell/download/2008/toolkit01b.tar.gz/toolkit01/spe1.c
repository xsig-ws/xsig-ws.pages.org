/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2007-12-07                */
/*----------------------------------------------------------------------*/
#include <stdlib.h>
#include <float.h>
#include <spu_intrinsics.h>
#include <spelib.h>
#include <spe_stdio.h>
#include <spu_mfcio.h>
#include "spe_util.h"
#include "define.h"
#include "spe.h"

#define DEC_INIT_VAL 0x77359400

/*-----------------------------------------------------------------------*/

volatile static struct argument arg _GALIGN;
volatile static struct spe_ctrl sc _GALIGN;

volatile static struct spe_sync_block spe_sync _GALIGN;
volatile static struct spe_sync_block sync_addr _GALIGN;
unsigned int dec_cnt;

/*----------------------------------------------------------------------*/
void dmaget(void* d, unsigned long long addr, unsigned int size){
    /***** DMA Data Transfer, Memory -> LS *****/
    mfc_get(d, addr, size, DMA_TAG, 0, 0);
    mfc_write_tag_mask(DMA_TAG_MASK(DMA_TAG));
    mfc_write_tag_update_all();
    mfc_read_tag_status();
}

/*----------------------------------------------------------------------*/
void dmaput(void* d, unsigned long long addr, unsigned int size){
    /***** DMA Data Transfer, LS -> Memory *****/
    mfc_put(d, addr, size, DMA_TAG, 0, 0);
    mfc_write_tag_mask(DMA_TAG_MASK(DMA_TAG));
    mfc_write_tag_update_all();
    mfc_read_tag_status();
}

/*----------------------------------------------------------------------*/

void spe_time_start(struct spe_ctrl* sc, unsigned long long argv){
    int i;

    dmaget((void*)&arg, argv, SPE_DMA_ALIGN);
    
    sc->flag = 0;
    while(sc->flag==0){
        dmaget((void*)sc, arg.sc_addr, SPE_DMA_ALIGN);
    }

    sync_addr.data[0] = (unsigned int)&spe_sync;
    dmaput((void*)&sync_addr, sc->sync_addr + sc->id * SPE_DMA_ALIGN, SPE_DMA_ALIGN);

    if(sc->id == 0){
        spe_sync.data[0] = 1;

        spu_write_decrementer(DEC_INIT_VAL);
        dec_cnt = spu_read_decrementer();

        for(i=1;i<NUMBER_OF_SPES;i++){
            dmaget((void*)&sync_addr, sc->sync_addr + i * SPE_DMA_ALIGN, SPE_DMA_ALIGN);
            sync_addr.data[1] = sync_addr.data[0] + sc->ls_addr[i];

            dmaput((void*)&spe_sync, sync_addr.data[1], SPE_DMA_ALIGN);
        }
    }
    else{
        while(1){
            if(spe_sync.data[0] == 1){
                break;
            }
        }
    }
};

/*----------------------------------------------------------------------*/

void spe_time_end(struct spe_ctrl* sc){
    if(sc->id == 0){
        sc->dec_cnt = dec_cnt - spu_read_decrementer();
        dmaput((void*)sc, arg.sc_addr, SPE_DMA_ALIGN);
    }
};

/*----------------------------------------------------------------------*/
