/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2007-12-09                */
/*----------------------------------------------------------------------*/
#include <spu_intrinsics.h>
#include <spelib.h>
#include <spe_stdio.h>
#include <stdlib.h>
#include <spu_mfcio.h>
#include <float.h>
#include <math.h>
#include "spe_util.h"
#include "define.h"

/*----------------------------------------------------------------------*/
volatile static struct spe_ctrl       sc _GALIGN;

//extern void spe_sort(struct spe_ctrl* sc);
extern void dmaget(void* d, unsigned long long addr, unsigned int size);
extern void dmaput(void* d, unsigned long long addr, unsigned int size);
extern void spe_time_start(struct spe_ctrl* sc,unsigned long long argv);
extern void spe_time_end(struct spe_ctrl* sc);

struct transfer_block{ // 128 Byte
    float data[32];
};

volatile static struct transfer_block tb _GALIGN;

/*----------------------------------------------------------------------*/
void swap_row(int s, int d, int n, float* a){
    int i;
    float t;
    for(i=0;i<n;i++){
        t = a[n*s+i];
        a[n*s+i] = a[n*d+i];
        a[n*d+i] = t;
    }
}

void swap_col(int s, int d, int n, int m, float* b){
    int i;
    float t;
    for(i=0;i<m;i++){
        t = b[n*i+s];
        b[n*i+s] = b[n*i+d];
        b[n*i+d] = t;
    }
}

void forward_substitution(int n, int m, float* a, float* b, float* c){
    int i,j;
    for(i=0;i<n;i++){
        c[i] = b[m*n+i];
        for(j=0;j<i;j++){
            c[i] -= a[i*n+j] * c[j];
        }
    }
}

void backward_substitution(int n, int m, float* a, float* c, float* x){
    int i,j;
    for(i=n-1;i>=0;i--){
        x[m*n+i] = c[i];
        for(j=n-1;j>i;j--){
            x[m*n+i] -= a[i*n+j]*x[m*n+j];
        }
        x[m*n+i] /= a[i*n+i];
    }
}

void lu_deconposition(int n, int m, float* a, float* b){
    int i,j,k;
    float t;
    int maxj;

    for(i=0;i<n;i++){
        // pivot selection
        maxj = i;
        t = a[i];
        for(j=i+1;j<n;j++){
            if(fabs(a[n*j+i]) > fabs(a[n*maxj+i])){
                maxj = j;
            }
        }
        swap_row(i,maxj,n,a);
        swap_col(i,maxj,n,m,b);
        // right looking 
        for(j = i+1; j < n; j++) {
            a[n*j+i] /= a[n*i+i];
            for(k=i+1; k<n; k++){
                a[n*j+k] -= a[n*i+k] * a[n*j+i];
            }
        }
    }
}

void spe_lu_deconposition(int n, int m, float* buf){
    int i;
    float* b;
    float* c;
    float* x;

    b = (float*)((unsigned int)buf+sizeof(float)*(n*n));
    x = (float*)((unsigned int)buf+sizeof(float)*(n*n+n*m));
    c = (float*)((unsigned int)buf+sizeof(float)*(n*n+n*m+n*m));

    lu_deconposition(n, m, buf, b);

    for(i=0;i<m;i++){
        forward_substitution(n, i, buf, b, c);
        backward_substitution(n, i, buf, c, x);
    }
}

void spe_soleqs(struct spe_ctrl* sc){
    int i;

    unsigned int msize;
    unsigned int paddr,saddr;
    volatile static float buf[224*256] _GALIGN;

    if(sc->id == 0){
        msize = (sc->n * sc->n + sc->n * sc->m) * sizeof(float);
        paddr  = sc->buf;
        saddr  = (unsigned int)buf;
        for(i=0; i<=msize/128; i++){
            dmaget((void*)saddr, paddr, 128);
            saddr+=128;
            paddr+=128;
        }

        spe_lu_deconposition((int)sc->n, (int)sc->m, (float*)buf);

        msize = (sc->n * sc->n + sc->n * sc->m * 2) * sizeof(float);
        paddr  = sc->buf;
        saddr  = (unsigned int)buf;
        for(i=0; i<=msize/128; i++){
            dmaput((void*)saddr, paddr, 128);
            saddr+=128;
            paddr+=128;
        }
    }
}

/*----------------------------------------------------------------------*/
/* SPE main program                                                     */
/*----------------------------------------------------------------------*/

int main(int speid, unsigned long long argv)
{
    spe_time_start((struct spe_ctrl*)&sc, argv);
/*-----------------------*/
    // modify codes in function "spe_soleqs".
    spe_soleqs((struct spe_ctrl*)&sc);
/*-----------------------*/
    spe_time_end((struct spe_ctrl*)&sc);

    return 0;
}
/*----------------------------------------------------------------------*/
