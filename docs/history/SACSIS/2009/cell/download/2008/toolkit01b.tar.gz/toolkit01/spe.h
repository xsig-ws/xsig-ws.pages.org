/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2007-12-07                */
/*----------------------------------------------------------------------*/
#define EXE_SPE1 "/export/home/USERNAME/toolkit01/spe1"
#define EXE_SPE2 "/export/home/USERNAME/toolkit01/spe1"
#define EXE_SPE3 "/export/home/USERNAME/toolkit01/spe1"
#define EXE_SPE4 "/export/home/USERNAME/toolkit01/spe1"
#define EXE_SPE5 "/export/home/USERNAME/toolkit01/spe1"
#define EXE_SPE6 "/export/home/USERNAME/toolkit01/spe1"
#define EXE_SPE7 "/export/home/USERNAME/toolkit01/spe1"
/*----------------------------------------------------------------------*/
