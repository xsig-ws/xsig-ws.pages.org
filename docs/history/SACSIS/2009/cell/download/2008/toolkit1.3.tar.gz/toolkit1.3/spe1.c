/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2008-02-05                */
/*----------------------------------------------------------------------*/
#include <stdio.h>
#include <spu_intrinsics.h>
#include <spu_mfcio.h>
#include <float.h>
#include <math.h>
#include "define.h"
/*----------------------------------------------------------------------*/

volatile static struct spe_ctrl sc _ALIGN;

extern void dmaget(void* d, unsigned long long addr, UINT32 size);
extern void dmaput(void* d, unsigned long long addr, UINT32 size);
extern void spe_time_start(struct spe_ctrl* sc,unsigned long long argv);
extern void spe_time_end(struct spe_ctrl* sc);

/*----------------------------------------------------------------------*/
void dmaget_burst(UINT64 ppe_addr, UINT32 spe_addr, UINT32 row, UINT32 col, UINT32 n){
    UINT64 paddr;
    paddr = ppe_addr + (UINT64)(n * col * sizeof(float) + (row / 32) * 128);
    dmaget((void*)spe_addr, paddr, 128);
}

float dmaget_value(UINT64 addr, UINT32 row, UINT32 col, UINT32 n){
    volatile static float buf[32] _ALIGN;
    dmaget_burst(addr, (UINT32)buf, row, col, n);
    return buf[row%32];
}

void dmaput_value(UINT64 addr, UINT32 row, UINT32 col, UINT32 n, float value){
    UINT64 paddr;
    volatile static float buf[32] _ALIGN;

    paddr = addr + (UINT64)(n * col * sizeof(float) + (row / 32) * 128);
    dmaget((void*)buf, paddr, 128);
    buf[row%32] = value;

    dmaput((void*)buf, paddr, 128);
}

void sync(UINT32 id, UINT32* ppe_ls, volatile struct spe_sync* sd, UINT32 key){
    int j;
    UINT32 key1, key2;
    key1 = key;
    key2 = key - 0X00010000;
    volatile static struct spe_sync ss _ALIGN;

    if(id==0){
        ss.start_flag=key1;
        for(j=1;j<NUM_SPE;j++) dmaput((void*)&ss, ppe_ls[j]+128*j, 128);
        for(j=1;j<NUM_SPE;j++) while(sd[j].end_flag != key2) ;
    }
    else{
        while(sd[id].start_flag != key1) ;
        sd[id].end_flag = key2;
        dmaput((void*)&sd[id],ppe_ls[0]+128*id,128);
    }
}



void pivoting(int id, UINT32 addr,
              UINT32 n, int s, int* maxj,
              UINT32* ppe_ls, volatile struct spe_sync* sd,
              UINT32 key){
    int i,j;
    float t1, t2;

    *maxj = s+(n-s)*id/NUM_SPE;
    t1 = fabs(dmaget_value(addr, s, s+(n-s)*id/NUM_SPE, n));
    for(j=s+(n-s)*id/NUM_SPE+1;j<s+(n-s)*(id+1)/NUM_SPE;j++){    
        t2 = fabs(dmaget_value(addr, s, j, n));
        if(t2 > t1){
            *maxj = j;
            t1   = t2;
        }
    }

    if(id == 0){
        for(i=1;i<NUM_SPE;i++){
            while(sd[i].pivot_flag != key+2) ;

            if(sd[i].pivot_max > t1){
                *maxj = sd[i].pivot_idx;
                t1    = sd[i].pivot_max;
            }
        }

        for(i=1;i<NUM_SPE;i++){
            sd[i].pivot_flag = key + 8;
            sd[i].pivot_max  = *maxj;
            dmaput((void*)&sd[i],ppe_ls[i]+128*i,128);
        }
    }
    else{
        sd[id].pivot_flag = key+2;
        sd[id].pivot_idx  = *maxj;
        sd[id].pivot_max  = t1;
        dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);

        while(sd[id].pivot_flag != key + 8) ;
        *maxj = sd[id].pivot_max;
    }
}

void swap_row(int id, UINT32 addr, UINT32 r1, UINT32 r2, UINT32 n){
    int i;
    volatile static float buf1[32] _ALIGN;
    volatile static float buf2[32] _ALIGN;
    UINT32 ppe_addr1;
    UINT32 ppe_addr2;

    for(i=id; i<n/32; i=i+NUM_SPE){
        ppe_addr1 = addr + sizeof(float) * n * r1 + 128 * i;
        ppe_addr2 = addr + sizeof(float) * n * r2 + 128 * i;

        dmaget((void*)buf1, ppe_addr1, 128);
        dmaget((void*)buf2, ppe_addr2, 128);
        dmaput((void*)buf2, ppe_addr1, 128);
        dmaput((void*)buf1, ppe_addr2, 128);
    }
}

void swap_col(int id, UINT32 addr, UINT32 r1, UINT32 r2, UINT32 n, UINT32 m){
    int i;
    float t1, t2;

    for(i=id;i<m;i=i+NUM_SPE){
        t1 = dmaget_value(addr, r1, i, n);
        t2 = dmaget_value(addr, r2, i, n);
        dmaput_value(addr, r1, i, n, t2);
        dmaput_value(addr, r2, i, n, t1);
    }
}

void lu_decomposition(int id, UINT32 addr, int row, int n){
    int p,q,s;
    int i,k;
    int r;
    float t1;

    float diag;
    
    volatile static float buf1[32] _ALIGN;
    volatile static float buf2[32] _ALIGN;
    volatile static float buf3[32] _ALIGN;

    s = n /32;
    r = (row+1)/32;

    diag = dmaget_value(addr, row, row, n);
    dmaget_burst(addr, (UINT32)buf2, (row+1), row, n);
    
    for(i=row+1+id;i<n;i=i+NUM_SPE){
        t1 = dmaget_value(addr, row, i, n) / diag;
        dmaput_value(addr, row, i, n, t1);
        
        p = addr+n*i*sizeof(float);

        dmaget((void*)buf1,p+128*r,128);
        for(k=row+1; k<32*(r+1); k++)
            buf1[k%32] -= buf2[k%32] * t1;
        dmaput((void*)buf1,p+128*r,128);

        for(q=r+1;q<s;q++){
            dmaget((void*)buf1, p+q*128,128);
            dmaget((void*)buf3, addr+n*row*sizeof(float)+q*128,128);
            for(k=0; k<32; k++)
                buf1[k] -= buf3[k] * t1;
            dmaput((void*)buf1,p+q*128,128);
        }
    }
}

void forward_substitution(UINT32 ppe_a, UINT32 ppe_b, UINT32 ppe_c, UINT32 idx, UINT32 n){
    int i,j,p;
    float t1;
    volatile static float buf1[32] _ALIGN;
    volatile static float buf2[32] _ALIGN;

    for(i=0;i<n;i++){
        t1 = dmaget_value(ppe_b, i, idx, n);
        p=0;
        for(j=0;j<i;j++){
            if(j%32==0){
                dmaget((void*)buf1, ppe_a+n*sizeof(float)*i+p*128,128);
                dmaget((void*)buf2, ppe_c+n*sizeof(float)*idx+p*128,128);
                p++;
            }
            t1 -= buf1[j%32] * buf2[j%32];
        }
        dmaput_value(ppe_c, i, idx, n, t1);
    }
}

void backward_substitution(int id, UINT32 ppe_a, UINT32 ppe_b, UINT32 ppe_c, UINT32 ppe_x, UINT32 idx, UINT32 n){
    int i,j;
    float t1;
    float diag;

    volatile static float buf1[32] _ALIGN;
    volatile static float buf2[32] _ALIGN;

    for(i=n-1;i>=0;i--){
        t1 = dmaget_value(ppe_c, i, idx, n);
        
        diag = dmaget_value(ppe_a, i, i, n);

        for(j=i+1;j<n;j++){
            if((j==i+1) || (j%32==0)){
                dmaget_burst(ppe_a,(UINT32)buf1, j, i,   n);
                dmaget_burst(ppe_x,(UINT32)buf2, j, idx, n);
            }

            t1 -= buf1[j%32] * buf2[j%32];
        }
        t1 = t1 / diag;
        dmaput_value(ppe_x, i, idx, n, t1);
    }
}

void spe_soleqs(spe_ctrl* sc){
  int i;
  int maxj;
  UINT32 ppe_ls[NUM_SPE];
  volatile static spe_sync ss _ALIGN;
  volatile static spe_sync sd[NUM_SPE] _ALIGN;

  int    n     = (int)sc->n;
  int    m     = sc->m;
  int    id    = sc->id;
  UINT32 ppe_a = sc->buf;
  UINT32 ppe_b = ppe_a + n * n * sizeof(float);
  UINT32 ppe_x = ppe_b + n * m * sizeof(float);
  UINT32 ppe_c = ppe_x + n * m * sizeof(float);
  UINT32 ppe_s = ppe_c + n * m * sizeof(float);

  // Set & Get addresses for each sharing memory of SPE
  ss.flag = 0XA0000000;
  ss.addr = (UINT32)sc->ls_addr[id] + (UINT32)&sd[0];
  dmaput((void*)&ss, (ppe_s+128*id) , 128);

  ppe_ls[id] = ss.addr;
  ss.flag = 0;
  for(i=0;i<NUM_SPE;i++){
    if(i != id){
      while(ss.flag != 0XA0000000){
        dmaget((void*)&ss, (ppe_s+128*i), 128);
      }
      ppe_ls[i] = ss.addr;
    }
    ss.flag = 0;
  }

  //  sync(id, ppe_ls, sd, i+0X10000000);

  for(i=0;i<n;i++){
    pivoting(id, ppe_a, n, i, &maxj, ppe_ls, sd, i+3);
    swap_row(id, ppe_a, i, maxj, n);
    swap_col(id, ppe_b, i, maxj, n, m);
    // Syncronization : SPE[0] notates (notice starting for all SPE)
    sync(id, ppe_ls, sd, i+0X20000000);
    // right looking LU decomposition
    lu_decomposition(id, (UINT32)ppe_a, i, n);
    // Syncronization : notates SPE[0] (notice end of the calculation)
    sync(id, ppe_ls, sd, i+0X40000000);
  }
  for(i=id;i<m;i=i+NUM_SPE){
    // forward substitution
    forward_substitution(ppe_a, ppe_b, ppe_c, i, n);
    // backward substitution
    backward_substitution(id, ppe_a, ppe_b, ppe_c, ppe_x, i, n);
  }
}
