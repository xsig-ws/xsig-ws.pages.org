#include <stdio.h>
#include <stdlib.h>
#include <libspe2.h>
#include <pthread.h>
#include "define.h"

void get_matrix(int n, int m, float* a, UINT32 s);
void generate_matrix(int n, int m, float* buf, UINT32 s);
void matrix_multiplication(int n, int m, float* a, float* x, float* b);
void disp_matrix(int n, int m, float* a);
double check(int n, int m, float* buf, double etime, UINT32 s);
double calculate_flops(int n, int m, double etime);
void get_prob(int n, int m, int s, float* buf);
double my_clock();

typedef struct{
  spe_context_ptr_t   spe;
  spe_ctrl            *sc;
}thread_arg_t;

static struct spe_ctrl sc[NUM_SPE] _ALIGN;
volatile static float buf[USER_MEM] _ALIGN;

void *run_spe(void *thread_arg){
  int ret;
  UINT32 entry;
  spe_stop_info_t stop_info;
  thread_arg_t *arg = (thread_arg_t *) thread_arg;
  
  entry = SPE_DEFAULT_ENTRY;
  ret = spe_context_run(arg->spe, &entry, 0, arg->sc, NULL, &stop_info);
  if (ret < 0) {
    perror("spe_context_run");
    return NULL;
  }
  return NULL;
}

int main(int argc, char **argv){
  int n; // matrix vector
  int m; // number of solution vector

  int i, j;
  int ret;
  
  spe_program_handle_t *prog;
  
  spe_context_ptr_t spe[NUM_SPE];
  pthread_t thread[NUM_SPE];
  thread_arg_t arg[NUM_SPE];
  UINT32 ls_addr[NUM_SPE];

  double flops;
  double etime;
  double result;
  UINT32 s;     // problem number
  double t1,t2; // start and end time stamp
  UINT32 dec;     // decrementor count
  double ddec;

  if(argc != 4){
    printf("solver algebra : N (matrix size) M (vector number) S (Matrix No.).\n");
    exit(1);
  }
  if(atoi(argv[1])%32 != 0){
    printf("solver algebra : N (matrix size) [%d] must be a multiple of 32.\n",atoi(argv[1]));
    exit(1);
  }

  n = atoi(argv[1]);
  m = atoi(argv[2]);
  s = atoi(argv[3]);
  
  printf("[ppe_] N %4d  M %4d Mem %1.2f[KByte].\n",
         n,m,(float)sizeof(float)*(n*n+n*m*2)/1024.0);
  
  // Generate matrix
  get_prob(n, m, s, (float*)buf);

  //  disp_matrix(n, n, &buf[0]);
  //  printf("\n");
  //  disp_matrix(n, m, &buf[n*n]);
  //  printf("\n");
  //  disp_matrix(n, m, &buf[n*n+n*m]);

  //  prog = spe_image_open("/home/user/staff/yosimi/ca08/beta/spe1");
  prog = spe_image_open(EXE_SPE1);
  if (!prog) {
    perror("spe_image_open");
    exit(1);
  }

  for(i=0;i<NUM_SPE;i++){
    spe[i] = spe_context_create(SPE_EVENTS_ENABLE|SPE_MAP_PS, NULL);
    //    spe[i] = spe_context_create(0, NULL);
    if (!spe[i]) {
      perror("spe_context_create");
      exit(1);
    }
    ret = spe_program_load(spe[i], prog);
    if (ret) {
      perror("spe_program_load");
      exit(1);
    }
    ls_addr[i] = (UINT32)spe_ls_area_get(spe[i]);
  }


  for(i=0;i<NUM_SPE;i++){
    sc[i].flag    = (UINT32) 0XFFFFFFFF;
    sc[i].id      = (UINT32) i;
    sc[i].n       = n;
    sc[i].m       = m;
    sc[i].buf     = (UINT32)&buf[0];
    sc[i].b       = (UINT32)&buf[n*n];
    sc[i].x       = (UINT32)&buf[n*n+n*m];
    sc[i].num_spe = NUM_SPE;
    for(j=0;j<NUM_SPE;j++){
      sc[i].ls_addr[j] = ls_addr[j];
    }
    arg[i].spe = spe[i];
    arg[i].sc  = &sc[i];

    ret = pthread_create(&thread[i], NULL, run_spe, &arg[i]);
    if (ret) {
      perror("pthread_create");
      exit(1);
    }
  }


  for(i=0;i<NUM_SPE;i++){
    do{ ; }while(sc[i].flag != 0XF0000001);
  }



  for(i=0;i<n*m;i++) buf[n*n+n*m+i] = 0.0;
  for(i=n*(n+2*m);i<USER_MEM;i++) buf[i] = 0.0;

  t1 = my_clock();

  for(i=0;i<NUM_SPE;i++){
    sc[i].flag = 0XF0000002;
  }

  for (i=0; i<NUM_SPE; i++) {
    pthread_join(thread[i], NULL);
    ret = spe_context_destroy(spe[i]);
    if (ret) {
      perror("spe_context_destroy");
      exit(1);
    }
  }

  ret = spe_image_close(prog);
  if (ret) {
    perror("spe_image_close");
    exit(1);
  }

  //  printf("\n");
  //  disp_matrix(n, m, &buf[n*n+n*m]);

  t2 = my_clock();
  etime = (double)(t2 - t1);
  printf("eclock : %1.8f\n", etime);
  
  dec = 0;
  for(i=0;i<NUM_SPE;i++){
    if(dec < sc[i].dec_cnt) dec = sc[i].dec_cnt;
  }
  ddec = (double)dec / (100.0 * 1000.0 * 1000.0);
  printf("dec_cnt: %1.8f\n", ddec);

  flops = calculate_flops(n, m, etime);
  result = check(n,m,(float*)buf, etime, s);

  if(result < 3.0) printf("SUCCESSFUL. ");
  else             printf("***** FAILED ! *****");
  printf(" : %5.6f [MFlops]\n", flops);

  return 0;
}
