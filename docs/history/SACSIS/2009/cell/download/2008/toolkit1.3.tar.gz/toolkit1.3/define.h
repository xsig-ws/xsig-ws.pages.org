#include "spe.h"
#define USER_MEM (20*1024*1024)
#define NUM_SPE 7

#define _ALIGN __attribute__((aligned(128)))
typedef unsigned long long UINT64;
typedef unsigned int       UINT32;

/*----------------------------------------------------------------------*/
typedef struct spe_ctrl{
    UINT32 flag;        //
    UINT32 id;          //
    UINT32 num_spe;     //
    UINT32 buf;         //
    UINT32 x;         //
    UINT32 b;         //
    UINT32 c;         //

    UINT32 buf_ctrl;    // 

    UINT32 n;           // matrix size
    UINT32 m;           // number of solution vector
    UINT32 dec_cnt;
    UINT32 sync_addr;
    UINT32 ls_addr[NUM_SPE];    // 
    UINT32 padding[20-NUM_SPE]; // just for padding
}spe_ctrl;
/*----------------------------------------------------------------------*/
typedef struct spe_sync{
    UINT32 flag;
    UINT32 start_flag;
    UINT32 end_flag;
    UINT32 addr; // address for sd
    UINT32 pivot_flag;
    UINT32 pivot_idx;
    float  pivot_max;
    UINT32 data[25];
}spe_sync;
/*----------------------------------------------------------------------*/
