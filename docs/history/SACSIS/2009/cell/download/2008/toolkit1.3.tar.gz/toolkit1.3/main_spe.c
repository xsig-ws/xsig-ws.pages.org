#include <stdio.h>
#include <spu_intrinsics.h>
#include <spu_mfcio.h>
#include "define.h"

#define DEC_CNT 0XFFFFFFFF

void spe_soleqs(spe_ctrl* sc);

/*----------------------------------------------------------------------*/
//void dmaget(void* d, UINT32 addr, UINT32 size){
void dmaget(void* d, UINT64 addr, UINT32 size){
  int tag = 1;
  /***** DMA Data Transfer, Memory -> LS *****/
  spu_mfcdma64(d, mfc_ea2h(addr), mfc_ea2l(addr), size, tag, MFC_GET_CMD);
  //  spu_mfcdma32(d, (UINT32)addr, size, tag, MFC_GET_CMD);
  spu_writech(MFC_WrTagMask, 1 << tag);
  spu_mfcstat(MFC_TAG_UPDATE_ALL);
}

/*----------------------------------------------------------------------*/
//void dmaput(void* d, UINT32 addr, UINT32 size){
void dmaput(void* d, UINT64 addr, UINT32 size){
  int tag = 1;
  /***** DMA Data Transfer, LS -> Memory *****/
  spu_mfcdma64(d, mfc_ea2h(addr), mfc_ea2l(addr), size, tag, MFC_PUT_CMD);
  //  spu_mfcdma32(d, (UINT32)addr, size, tag, MFC_PUT_CMD);
  spu_writech(MFC_WrTagMask, 1 << tag);
  spu_mfcstat(MFC_TAG_UPDATE_ALL);
}

/*----------------------------------------------------------------------*/
void matrix_mult_sub(UINT32 addr, int p, int q, int n, int m){
    UINT32 a,b,x;
    int i,j,k;
    volatile static float buf1[32] _ALIGN;
    volatile static float buf2[32] _ALIGN;
    volatile static float buf3[32] _ALIGN;

    vector float ma = {0.0, 0.0, 0.0, 0.0};

    a = addr;
    b = a + n * n * sizeof(float);
    x = b + n * m * sizeof(float);

    for(k=0;k<32;k++){
        for(i=0;i<4;i++) ma = spu_insert(0.0, ma, i);

        for(i=0;i<n/32;i++){
          dmaget((void*)buf1, a+n*sizeof(float)*(p+k)+i*128, 128);
          dmaget((void*)buf2, x+n*sizeof(float)*q    +i*128, 128);
          for(j=0;j<8;j++){
            ma = spu_madd(*(vector float*)&buf1[j*4], *(vector float*)&buf2[j*4], ma);
          }
        }

        buf3[k] = (float)spu_extract(ma,0);
        for(i=1;i<4;i++){
          buf3[k] += (float)spu_extract(ma,i);
        }
    }
    dmaput((void*)buf3, b+n*sizeof(float)*q+p*sizeof(float), 128);
}

/*----------------------------------------------------------------------*/
void matrix_mult(int id, UINT32 addr, int n, int m){
    int i,j;

    for(i=0;i<n;i=i+32){
      for(j=id;j<m;j=j+NUM_SPE){
        matrix_mult_sub(addr, i, j, n, m);
      }
    }
}

/*----------------------------------------------------------------------*/
int main(unsigned long long spe, unsigned long long argp, unsigned long long envp){
  volatile static spe_ctrl sc _ALIGN;
  UINT32 t1, t2;
  /* DMA Transfer 1 : GET input/output parameters */
  spu_writech(SPU_WrDec, DEC_CNT);
  dmaget((void*)&sc, argp, sizeof(sc));
  matrix_mult(sc.id, sc.buf, sc.n, sc.m);
  sc.flag    = 0XF0000001;
  dmaput((void*)&sc, argp, sizeof(sc));
  do{
    dmaget((void*)&sc, argp, sizeof(sc));
  }while(sc.flag != 0XF0000002);

  t1 = spu_readch(SPU_RdDec);

  spe_soleqs((spe_ctrl*)&sc);

  t2 = spu_readch(SPU_RdDec);

  sc.dec_cnt = t1 - t2;
  dmaput((void*)&sc, argp, sizeof(sc));

  return 0;
}
/*----------------------------------------------------------------------*/
