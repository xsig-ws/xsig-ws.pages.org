/*---------------------------------------------------------------------------*/
/* Cell Challenge 2009, ToolKit Version 2009-01-28                           */
/*---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <libspe2.h>
#include <pthread.h>
#include <sys/time.h>
#include <time.h>
#include <math.h>
#include "define.h"

#define D(I1,I2) d[((I1)&1)*(lenStr2+1)+(I2)]

/*---------------------------------------------------------------------------*/
volatile static unsigned int str1[STR_MEM] __attribute__((aligned(128)));
volatile static unsigned int str2[STR_MEM] __attribute__((aligned(128)));
volatile static unsigned int ans[32] __attribute__((aligned(128)));

/*---------------------------------------------------------------------------*/
double my_clock()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec + (double)tv.tv_usec*1e-6;
};
/*---------------------------------------------------------------------------*/
int min(int a,  int b, int c){
  if(a > b){
    if(b > c) return c;
    else      return b;
  }
  else{
    if(a > c) return c;
    else      return a;
  }
}
/*---------------------------------------------------------------------------*/

int
LevenshteinDistance (char *str1, int lenStr1, char *str2, int lenStr2)
{
  int *d;
  int i1;
  int i2, cost;
  int k;
  d = malloc (sizeof (int) * (2) * (lenStr2 + 1));
  if (d == NULL) {
    perror ("malloc");
    return (-1);
  }
  for (i1 = 0; i1 <= lenStr2; i1++)
    D (0, i1) = i1;

  k = 0;
  for (i1 = 1; i1 <= lenStr1; i1++) {
    D (i1, 0) = i1;
    for (i2 = 1; i2 <= lenStr2; i2++) {
      if (str1[i1 - 1] == str2[i2 - 1])
        cost = 0;
      else
        cost = 1;
      D (i1, i2) = min(D (i1 - 1, i2    ) + 1,
                       D (i1    , i2 - 1) + 1,
                       D (i1 - 1, i2 - 1) + cost);

    }
  }
  return D (lenStr1, lenStr2);
}


/*---------------------------------------------------------------------------*/

int main(int argc, char **argv){
  int i;  

  double etime;
  double t1,t2; // start and end time stamp
  unsigned int ppe_res;

  int num1, num2;
  FILE *fp;

  /*-------------------------------------------------------------------------*/
  for(i=0;i<STR_MEM;i++){
    str1[i] = 0;
    str2[i] = 0;
  }

  /*-------------------------------------------------------------------------*/
  if (argc < 3) {
    fprintf (stderr, "usage: %s file1 file2 [answer]\n", argv[0]);
    return 0;
  }else if (argc > 3) {
    /* 実行時間節約のため答えがあたえられた場合はそれを利用する。 */
    ppe_res = atoi(argv[3]);
    printf("answer = %d\n", ppe_res);
  }else{
    ppe_res = -1;
  }

  fp = fopen (argv[1], "r");
  if (fp == NULL) {
    perror ("file1");
    return (0);
  }
  num1 = fread ((char*)&str1, 1, STR_MEM*4-1, fp);
  ((char*)str1)[num1] = '\0';
  fclose (fp);
  printf ("strnum(a)= %d\n", num1);

  fp = fopen (argv[2], "r");
  if (fp == NULL) {
    perror ("file2");
    return (0);
  }
  num2 = fread ((char*)&str2, 1, STR_MEM*4-1, fp);
  ((char*)str2)[num2] = '\0';
  fclose (fp);
  printf ("strnum(b)= %d\n", num2);

  if(((num1 % 32) != 0) | ((num2 % 32) != 0)){
    fprintf (stderr, "Numbers of strings in fileA and fileB have to the multiple of 32.\n");
    return 0;
  }

  if(ppe_res == -1){
    ppe_res = LevenshteinDistance ((char*)&str1, num1, (char*)&str2, num2);
    //  ppe_res = 0XAABBCCDD;
  }
  ans[0] = 0XFFFFFFFF;

  t1 = my_clock();

  ppe_user((unsigned int*)str1, 
           (unsigned int*)str2, 
           (unsigned int*)ans, 
           num1, num2);

  t2 = my_clock();


  printf("[SPE_] : %d\n",ans[0]);
  printf("[PPE_] : %d\n",ppe_res);

  etime = (double)(t2 - t1);
  printf("eclock  : %1.8f\n", etime);

  if(ppe_res == ans[0])
    printf("SUCCESSFUL.\n");
  else
    printf("*** FAILED ! ***.\n");

  return 0;
}
/*---------------------------------------------------------------------------*/
