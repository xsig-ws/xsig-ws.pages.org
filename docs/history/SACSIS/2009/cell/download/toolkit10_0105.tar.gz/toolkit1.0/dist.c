#define MAXLEN 50000

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define minimum(A,B,C) (A>B ? B>C ? C:B : A>C ? C:A)
#define D(I1,I2) d[(I1&1)*(lenStr2+1)+(I2)]

int
LevenshteinDistance (char *str1, int lenStr1, char *str2, int lenStr2)
{
  int *d;
  int i1;
  d = malloc (sizeof (int) * (2) * (lenStr2 + 1));
  printf ("malloc %lld\n",
          ((long long) sizeof (int) * (2) * (lenStr2 + 1)));
  if (d == NULL) {
    perror ("malloc");
    return (-1);
  }
  for (i1 = 0; i1 <= lenStr1; i1++)
    D (i1, 0) = i1;
  for (i1 = 0; i1 <= lenStr2; i1++)
    D (0, i1) = i1;

  for (i1 = 1; i1 <= lenStr1; i1++) {
    int i2, cost;
    for (i2 = 1; i2 <= lenStr2; i2++) {
      if (str1[i1 - 1] == str2[i2 - 1])
        cost = 0;
      else
        cost = 1;
      D (i1, i2) = minimum (D (i1 - 1, i2    ) + 1,
                            D (i1    , i2 - 1) + 1,
                            D (i1 - 1, i2 - 1) + cost);
    }
  }
  return D (lenStr1, lenStr2);
}

int
main (int argc, char *argv[])
{
  char a[MAXLEN + 1], b[MAXLEN + 1];
  int ret;
  int len1, len2;
  FILE *fp;

  if (argc < 3) {
    fprintf (stderr, "usage: %s file1 file2\n", argv[0]);
    return 0;
  }
  fp = fopen (argv[1], "r");
  if (fp == NULL) {
    perror ("file1");
    return (0);
  }
  len1 = fread (a, 1, MAXLEN, fp);
  a[len1] = '\0';
  printf ("strlen(a)= %d\n", len1);
  fclose (fp);

  fp = fopen (argv[2], "r");
  if (fp == NULL) {
    perror ("file2");
    return (0);
  }
  len2 = fread (b, 1, MAXLEN, fp);
  b[len2] = '\0';
  printf ("strlen(b)= %d\n", len2);
  fclose (fp);

  ret = LevenshteinDistance (a, len1, b, len2);
  printf ("%d\n", ret);

  return 0;
}
