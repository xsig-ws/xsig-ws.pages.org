/*---------------------------------------------------------------------------*/
/* Cell Challenge 2009, ToolKit Version 2009-01-04                           */
/*---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <libspe2.h>
#include <pthread.h>
#include <stdbool.h>
#include "define.h"
#include "spe.h"

/*---------------------------------------------------------------------------*/
volatile static unsigned int buf[USER_MEM] __attribute__((aligned(128)));

typedef struct{
  spe_context_ptr_t   spe;
  spe_ctrl            *sc;
}thread_arg_t;

typedef struct{
  UINT32 head, tail;
  UINT32 state;
  UINT32 entry[QUEUE_SIZE];
}queue;

void queue_init(queue* qu){
  qu->head  = 0;
  qu->tail  = 0;
  qu->state = QUEUE_EMPTY;
};

void queue_enq(UINT32 in, queue* qu){
  qu->entry[qu->head] = in;
  if(qu->head != QUEUE_SIZE-1) qu->head++;
  else                         qu->head = 0;
  if(qu->head == qu->tail-1)   qu->state = QUEUE_FULL;
  else                         qu->state = QUEUE_IDLE;
};

UINT32 queue_deq(queue* qu){
  UINT32 r;
  r =  qu->entry[qu->tail];
  if(qu->tail != QUEUE_SIZE-1) qu->tail++;
  else                         qu->tail = 0;
  if(qu->tail == qu->head)     qu->state = QUEUE_EMPTY;
  else                         qu->state = QUEUE_IDLE;
  return r;
};

volatile static struct spe_ctrl sc[NUM_SPE] _ALIGN;
volatile static struct spe_info si[NUM_SPE] _ALIGN;

void *run_spe(void *thread_arg){
  int ret;
  UINT32 entry;
  spe_stop_info_t stop_info;
  thread_arg_t *arg = (thread_arg_t *) thread_arg;
  
  entry = SPE_DEFAULT_ENTRY;
  ret = spe_context_run(arg->spe, &entry, 0, arg->sc, NULL, &stop_info);
  if (ret < 0) {
    perror("spe_context_run");
    return NULL;
  }
  return NULL;
}

UINT32 chk_comp(UINT32 x, UINT32 y, bool* comp, UINT32 bnum1, UINT32 bnum2){
  UINT32 r;
  UINT32 t1, t2, t3;
  r = 0;

  if(x < bnum1 && y < bnum2){
    if(comp[y * bnum1 + x] == 0){
      if(y == 0) t1 = 1;
      else       t1 = comp[(y-1) * bnum1 + x];
      
      if(x == 0 || y == 0) t2 = 1;
      else                 t2 = comp[(y-1) * bnum1 + (x-1)];
      
      if(x == 0) t3 = 1;
      else       t3 = comp[y * bnum1 + (x-1)];
      
      if((t1 == 1) & (t2 == 1) & (t3 == 1)){
        r = 1;
      }
    }
  }

  return r;
}

void ppe_user(UINT32* str1, UINT32* str2, UINT32* ans, UINT32 num1, UINT32 num2){
  int i,j;
  int ret;
  spe_program_handle_t *prog;
  spe_context_ptr_t spe[NUM_SPE];
  pthread_t thread[NUM_SPE];
  thread_arg_t arg[NUM_SPE];
  UINT32 ls_addr[NUM_SPE];

  UINT32 bnum1, bnum2;
  bool* comp;
  bool* issue;
  UINT32 end;
  queue  bqueue;
  UINT32 blk_id;
  UINT32* angle;

  queue_init(&bqueue);

  bnum1 = num1 / 128;
  bnum2 = num2 / 128;
  comp  = (bool*)calloc(bnum1*bnum2, sizeof(bool));
  issue = (bool*)calloc(bnum1*bnum2, sizeof(bool));


  prog = spe_image_open(EXE_SPE1);
  if (!prog) {
    perror("spe_image_open");
    exit(1);
  }

  for(i=0;i<NUM_SPE;i++){
    spe[i] = spe_context_create(SPE_EVENTS_ENABLE|SPE_MAP_PS, NULL);

    if (!spe[i]) {
      perror("spe_context_create");
      exit(1);
    }
  }

  for(i=0;i<NUM_SPE;i++){
    ret = spe_program_load(spe[i], prog);
    if (ret) {
      perror("spe_program_load");
      exit(1);
    }
  }
  for(i=0;i<NUM_SPE;i++) ls_addr[i] = (UINT32)spe_ls_area_get(spe[i]);

  for(i=0;i<NUM_SPE;i++){
    sc[i].id      = (UINT32) i;
    sc[i].num_spe = NUM_SPE;
    sc[i].str1    = (UINT32)&str1[0];
    sc[i].str2    = (UINT32)&str2[0];
    sc[i].buf     = (UINT32)&buf[0];
    sc[i].ans     = (UINT32)&ans[0];
    sc[i].bnum1   = (UINT32)bnum1;
    sc[i].bnum2   = (UINT32)bnum2;
    
    sc[i].info    = (UINT32)&si[i];

    for(j=0;j<NUM_SPE;j++) sc[i].ls_addr[j] = ls_addr[j];
    arg[i].spe = spe[i];
    arg[i].sc  = (spe_ctrl*)&sc[i];
  }

  for(i=0;i<NUM_SPE;i++){
    si[i].flag    = SPE_IDLE;
    si[i].x       = (UINT32) 0XFFFFFFFF;
    si[i].y       = (UINT32) 0XFFFFFFFF;
    si[i].angle   = (UINT32) 0XFFFFFFFF;
  }

  for(i=0;i<NUM_SPE;i++){
    ret = pthread_create(&thread[i], NULL, run_spe, &arg[i]);
    if (ret) {
      perror("pthread_create");
      exit(1);
    }
  }

  angle = (UINT32*)&buf[bnum1*128+bnum2*128];

  angle[0] = 0;
  for(i=1;i<bnum1;i++) angle[2*i-1] = 128*i;
  for(i=1;i<bnum2;i++) angle[2*i]   = 128*i;

  end = 0;
  blk_id = 0;
  queue_enq(blk_id, &bqueue);

  while(end == 0){
    for(i=0;i<NUM_SPE;i++){
      // �֥��å��׻��γ���
      if(bqueue.state != QUEUE_EMPTY){
        if(si[i].flag == SPE_IDLE){
          blk_id = queue_deq(&bqueue);
          si[i].x = blk_id % bnum1;
          si[i].y = blk_id / bnum1;
          if(chk_comp(si[i].x, si[i].y, comp, bnum1, bnum2)){
            if(si[i].y >= si[i].x) si[i].angle = angle[(si[i].y-si[i].x)*2];
            else                   si[i].angle = angle[(si[i].x-si[i].y)*2 - 1];
            si[i].flag   = SPE_REQ;
          }
          else queue_enq(blk_id, &bqueue);
        }
      }
      // �֥��å��׻���λ�θ���
      if(bqueue.state != QUEUE_FULL){
        if(si[i].flag == SPE_ACK){
          si[i].flag = SPE_IDLE;
          blk_id = si[i].y * bnum1 + si[i].x;
          comp[blk_id] = 1;
          if(si[i].y >= si[i].x) angle[(si[i].y-si[i].x)*2] = si[i].angle;
          else                   angle[(si[i].x-si[i].y)*2 - 1] = si[i].angle;
          
          if(blk_id >= bnum1 * bnum2 - 1) end = 1;
          else{
            if(chk_comp(si[i].x+1, si[i].y, comp, bnum1, bnum2) != 0){
              if(issue[blk_id+1] == 0){
                queue_enq(blk_id + 1, &bqueue);
                issue[blk_id+1] = 1;
              }
            }
            if(chk_comp(si[i].x, si[i].y+1, comp, bnum1, bnum2) != 0){
              if(issue[blk_id+bnum1] == 0){
                queue_enq(blk_id + bnum1, &bqueue);
                issue[blk_id+bnum1] = 1;
              }
            }
          }
        }
      }
    }
  }

  for(i=0;i<NUM_SPE;i++) si[i].flag    = SPE_QUIT;
  ans[0] = buf[bnum1*128+bnum2*128-1];

  for (i=0; i<NUM_SPE; i++) pthread_join(thread[i], NULL);
  for (i=0; i<NUM_SPE; i++){
    ret = spe_context_destroy(spe[i]);
    if (ret) {
      perror("spe_context_destroy");
      exit(1);
    }
  }

  ret = spe_image_close(prog);
  if (ret) {
    perror("spe_image_close");
    exit(1);
  }

  return;
}
