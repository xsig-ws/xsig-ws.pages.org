#include<stdio.h>

int main(int argc, char** argv){
  int i;
  int num;
  unsigned int seed;
  int flag;
  char c;

  if(argc < 3){
    fprintf (stderr, "usage: %s num seed\n", argv[0]);
    return 0;
  }

  num  = atoi(argv[1]);
  seed = atoi(argv[2]);

  srand(seed);

  for(i=0;i<num;i++){
    flag = rand() % 3;
    if(flag == 0){
      c = 'a' + (rand() % 26 );
    }
    else if(flag == 1){
      c = 'A' + (rand() % 26 );
    }
    else{
      c = '0' + (rand() % 10 );
    }
    printf("%c",c);
  }
  return 0;
}

