/*---------------------------------------------------------------------------*/
/* Cell Challenge 2009, ToolKit Version 2009-01-04                           */
/*---------------------------------------------------------------------------*/
#include <stdio.h>
#include <spu_intrinsics.h>
#include <spu_mfcio.h>
#include "define.h"
#include "spe.h"

/*---------------------------------------------------------------------------*/

volatile static struct spe_ctrl sc _ALIGN;
volatile static struct spe_info si _ALIGN;
volatile static UINT32 buf[128*128] _ALIGN;
volatile static UINT32 vbuf[128] _ALIGN;
volatile static UINT32 hbuf[128] _ALIGN;
volatile static UINT8 str1[128] _ALIGN;
volatile static UINT8 str2[128] _ALIGN;

/*---------------------------------------------------------------------------*/
void dmaget(void* d, UINT64 addr, UINT32 size){
  int tag = 1;
  /***** DMA Data Transfer, Memory -> LS *****/
  spu_mfcdma64(d, mfc_ea2h(addr), mfc_ea2l(addr), size, tag, MFC_GET_CMD);
  spu_writech(MFC_WrTagMask, 1 << tag);
  spu_mfcstat(MFC_TAG_UPDATE_ALL);
}

/*---------------------------------------------------------------------------*/
void dmaput(void* d, UINT64 addr, UINT32 size){
  int tag = 1;
  spu_mfcdma64(d, mfc_ea2h(addr), mfc_ea2l(addr), size, tag, MFC_PUT_CMD);
  spu_writech(MFC_WrTagMask, 1 << tag);
  spu_mfcstat(MFC_TAG_UPDATE_ALL);
}

/*---------------------------------------------------------------------------*/
int min(int a,  int b, int c){
  if(a > b){
    if(b > c) return c;
    else      return b;
  }
  else{
    if(a > c) return c;
    else      return a;
  }
}

/*---------------------------------------------------------------------------*/
void spe_LD(UINT32* angle, UINT8* str1, UINT8* str2,
            UINT32* vbuf, UINT32* hbuf){

  int i, j;
  UINT32 t1, t2, t3;
  UINT32 cost;

  for(i=0;i<128;i++){
    for(j=0;j<128;j++){
      // t1
      if(j==0)   t1 = hbuf[i];
      else       t1 = buf[128*i+(j-1)];
      // t2
      if(i==0){
        if(j==0) t2 = *angle;
        else     t2 = vbuf[j-1];
      }
      else{
        if(j==0) t2 = hbuf[i-1];
        else     t2 = buf[128*(i-1)+(j-1)];
      }
      // t3
      if(i==0)   t3 = vbuf[j];
      else       t3 = buf[128*(i-1)+j];

      if(str1[i] == str2[j]) cost = 0;
      else                   cost = 1;

      buf[128 * i + j] = min(t1 + 1, t2 + cost, t3 + 1);
    }
  }

  for(i=0;i<128;i++){
    vbuf[i] = buf[128*127+i];
    hbuf[i] = buf[(i+1)*128-1];
  }
  *angle = (UINT32)hbuf[127];
};

void blkcal(UINT32 x, UINT32 y,
            UINT32 str1_addr, UINT32 str2_addr,
            UINT32 hbaddr, UINT32 vbaddr,
            UINT32* angle){

  int i;
  // ��ʬʸ����μ���
  dmaget((void*)str1, str1_addr+128*x, 128);
  dmaget((void*)str2, str2_addr+128*y, 128);

  //��Ԥ����
  if(y==0) for(i=1;i<=128;i++) hbuf[i-1] = x*128+i;
  else     dmaget((void*)hbuf, hbaddr+512*x, 512);

  //��������
  if(x==0) for(i=1;i<=128;i++) vbuf[i-1] = y*128+i;
  else     dmaget((void*)vbuf, vbaddr+512*y, 512);

  // ��ʬʸ������Խ���Υ��׻�
  spe_LD((UINT32*)angle, 
         (UINT8*)&str1[0], (UINT8*)&str2[0],
         (UINT32*)&vbuf[0], (UINT32*)&hbuf[0]);

  //��Ԥ�񤭽Ф�
  dmaput((void*)hbuf, hbaddr+512*x, 512);
  //�����񤭽Ф�
  dmaput((void*)vbuf, vbaddr+512*y, 512);
};

/*---------------------------------------------------------------------------*/

int main(unsigned long long spe,
         unsigned long long argp,
         unsigned long long envp){

  UINT32 bnum1, bnum2;
  UINT32 str1_addr, str2_addr;
  UINT32 hbaddr, vbaddr;
  UINT32 info;
  UINT32 angle;

  dmaget((void*)&sc, argp, sizeof(sc));

  bnum1     = sc.bnum1;
  bnum2     = sc.bnum2;

  str1_addr = sc.str1;
  str2_addr = sc.str2;
  hbaddr    = sc.buf;
  vbaddr    = sc.buf + 512 * bnum1;

  info      = sc.info;

  do{
    dmaget((void*)&si, info, sizeof(si));
    
    if(si.flag == SPE_REQ){
      angle = si.angle;

      blkcal(si.x, si.y, str1_addr, str2_addr,
             hbaddr, vbaddr,
             (UINT32*)&angle);

      si.angle = angle;
      si.flag  = SPE_ACK;
      dmaput((void*)&si, sc.info, sizeof(si));
    }

  }while(si.flag != SPE_QUIT);

  return 0;
}
/*---------------------------------------------------------------------------*/
