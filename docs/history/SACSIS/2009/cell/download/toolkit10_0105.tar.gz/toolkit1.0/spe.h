/*---------------------------------------------------------------------------*/
/* Cell Challenge 2009, ToolKit Version 2009-01-04                           */
/*---------------------------------------------------------------------------*/
#define NUM_SPE 7

#define EXE_PATH "toolkit1.0/"
#define EXE_SPE1 EXE_PATH"spe1"
#define EXE_SPE2 EXE_PATH"spe1"
#define EXE_SPE3 EXE_PATH"spe1"
#define EXE_SPE4 EXE_PATH"spe1"
#define EXE_SPE5 EXE_PATH"spe1"
#define EXE_SPE6 EXE_PATH"spe1"
#define EXE_SPE7 EXE_PATH"spe1"

#define SPE_IDLE 0XFFFFFFFF
#define SPE_QUIT 0XFFFFFFFA
#define SPE_REQ  0XFFFFFFFB
#define SPE_ACK  0XFFFFFFFC

#define QUEUE_EMPTY 0XFFFFFFFF
#define QUEUE_IDLE  0XFFFFFFFE
#define QUEUE_FULL  0XFFFFFFFD

#define QUEUE_SIZE 512
#define USER_MEM (10*1024*1024) // 40MB

/*---------------------------------------------------------------------------*/
#define _ALIGN __attribute__((aligned(128)))
typedef unsigned long long UINT64;
typedef unsigned int       UINT32;
typedef unsigned char      UINT8;
/*---------------------------------------------------------------------------*/
typedef struct spe_ctrl{
  UINT32 id;
  UINT32 str1;
  UINT32 str2;
  UINT32 buf; 
  UINT32 ans; 
  UINT32 bnum1;
  UINT32 bnum2;
  UINT32 num_spe;
  UINT32 ls_addr[7];
  UINT32 info;
  UINT32 padding[16]; // just for padding
}spe_ctrl;

/*----------------------------------------------------------------------*/
typedef struct spe_info{
  UINT32 flag;
  UINT32 x;
  UINT32 y;
  UINT32 angle;
  UINT32 padding[28]; // just for padding
}spe_info;

/*---------------------------------------------------------------------------*/
