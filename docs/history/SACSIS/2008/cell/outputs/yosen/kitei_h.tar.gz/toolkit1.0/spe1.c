/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2008-02-05                */
/*----------------------------------------------------------------------*/
#include <spu_intrinsics.h>
#include <spelib.h>
#include <spe_stdio.h>
#include <stdlib.h>
#include <spu_mfcio.h>
#include <float.h>
#include <math.h>
#include "spe_util.h"
#include "define.h"

/*----------------------------------------------------------------------*/
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;

typedef vector unsigned int vuint_t;
typedef vector unsigned char vuchar_t;
typedef vector float vfloat_t;

typedef vector signed int vsint_t;
typedef vector signed short vsshort_t;

/*----------------------------------------------------------------------*/
#define N_MAX (8*1024)

#define ELM          (32)
#define ELM_BLK      (ELM*ELM)
#define ELM_SIZE     (ELM*sizeof(float))
#define ELM_BLK_SIZE (ELM_BLK*sizeof(float))
#define ELM_VEC      (ELM>>2) // ELM/4

#define LIST_SIZE    (ELM*sizeof(uint64_t))
#define LIST_SIZE2   ( 4 *sizeof(uint64_t))

#define PIVOT_KEY       0XFFFFFFFF
#define DIST_END_KEY    0XFFFFFFF0
#define COLLECT_END_KEY 0XFFFFFF00
#define FORWARD_KEY     0XFFFFF000
#define BACKWARD_KEY    0XFFFF0000
#define SYNCALL_KEY     0XFFF00000

#define DMA_TAG01     1
#define DMA_TAG02     2
#define DMA_TAG03     3
#define DMA_TAG04     4
#define DMA_TAG05     5
#define BCAST_DMA_TAG 8

/*----------------------------------------------------------------------*/
struct spe_sync{
    uint32_t flag;
    uint32_t start_flag;
    uint32_t end_flag;
    uint32_t addr;  // address for sd
    uint32_t addrv; // address for vector "vec"
    uint32_t pivot_flag;
    uint32_t pivot_idx;
    float    pivot_max;
    uint32_t data[24];
};

extern void dmaget(void* d, uint64_t addr, uint32_t size);
extern void dmaput(void* d, uint64_t addr, uint32_t size);
extern void spe_time_start(struct spe_ctrl* sc,uint64_t argv);
extern void spe_time_end(struct spe_ctrl* sc);

volatile static struct spe_ctrl sc _GALIGN;

volatile static float block1[ELM_BLK] _GALIGN;       // 4KB
volatile static float block2[ELM_BLK] _GALIGN;       // 4KB
volatile static float block3[ELM_BLK] _GALIGN;       // 4KB
volatile static float block4[ELM_BLK] _GALIGN;       // 4KB
volatile static float block5[ELM_BLK] _GALIGN;       // 4KB

volatile static float blockd1[2][ELM_BLK*2] _GALIGN; // 16KB
volatile static float blockd2[2][ELM_BLK*2] _GALIGN; // 16KB
volatile static float blockd3[2][ELM_BLK*2] _GALIGN; // 16KB
volatile static float blockd4[2][ELM_BLK*2] _GALIGN; // 16KB
volatile static float blockd5[2][ELM_BLK*2] _GALIGN; // 16KB

uint64_t list1[ELM];
uint64_t list2[ELM];
uint64_t list3[ELM];
uint64_t list4[ELM];
uint64_t list5[ELM];

uint64_t listd1[2][ELM*2];
uint64_t listd2[2][ELM*2];
uint64_t listd3[2][ELM*2];
uint64_t listd4[2][ELM*2];
uint64_t listd5[2][ELM*2];

/*--- DMA --------------------------------------------------------------*/
/*----------------------------------------------------------------------*/  
inline void dmagetx(void *d, uint64_t addr, uint32_t size, int tag)
{
    mfc_get(d, addr, size, tag, 0, 0);
}
inline void dmaputx(void *d, uint64_t addr, uint32_t size, int tag)
{
    mfc_put(d, addr, size, tag, 0, 0);
}
inline void dmawait(int tag)
{
    mfc_write_tag_mask(DMA_TAG_MASK(tag));
    mfc_read_tag_status_all();
}

/*----------------------------------------------------------------------*/
inline void dmagetlx(void *d, uint64_t *list, int lsize, int tag)
{
    mfc_getl(d, 0, list, lsize, tag, 0, 0);
}
inline void dmaputlx(void *d, uint64_t *list, int lsize, int tag)
{
    mfc_putl(d, 0, list, lsize, tag, 0, 0);
}

/*----------------------------------------------------------------------*/
#define INPUT(x, size) {                                          \
  addrv[x]     = spu_madd(indexv[x], tmpv1, tmpv2);               \
  listv[2*x]   = (vuint_t){size, addr[4*x+0], size, addr[4*x+1]}; \
  listv[2*x+1] = (vuint_t){size, addr[4*x+2], size, addr[4*x+3]}; \
}
inline void input_list(uint64_t *list, uint32_t ppe_addr, 
                       volatile int* index,  uint32_t rowbl, uint32_t n)
{
    uint32_t nsize = n*sizeof(float);
    uint32_t paddr = ppe_addr+rowbl*ELM_SIZE;
    vuint_t *listv;

    volatile uint32_t addr[ELM];
    volatile vsint_t *addrv;
    vsint_t tmpv2;
    vsshort_t *indexv, tmpv1;

    listv  = (vuint_t *)list;
    indexv = (vsshort_t *)index;
    addrv  = (vsint_t *)addr;
    tmpv1  = (vsshort_t)spu_splats(nsize);
    tmpv2  = (vsint_t)spu_splats(paddr);

    INPUT(0, ELM_SIZE);  INPUT(1, ELM_SIZE);
    INPUT(2, ELM_SIZE);  INPUT(3, ELM_SIZE);
    INPUT(4, ELM_SIZE);  INPUT(5, ELM_SIZE);
    INPUT(6, ELM_SIZE);  INPUT(7, ELM_SIZE);
}

#define INPUTA(x) {             \
  listv[2*x]   = tmpv0;         \
  listv[2*x+1] = tmpv1;         \
  tmpv0 = spu_add(tmpv0, addv); \
  tmpv1 = spu_add(tmpv1, addv); \
}
inline void input_lista(uint64_t *list, uint32_t ppe_addr, 
                        uint32_t colbl,  uint32_t rowbl, uint32_t n)
{
    uint32_t nsize = n*sizeof(float);
    uint32_t paddr = ppe_addr+colbl*ELM*nsize+rowbl*ELM_SIZE;
    vuint_t *listv;

    vuint_t tmpv0, tmpv1, addv;

    addv = (vuint_t){0, nsize*4, 0, nsize*4};
    tmpv0 = (vuint_t){ELM_SIZE, paddr,         ELM_SIZE, paddr+nsize};
    tmpv1 = (vuint_t){ELM_SIZE, paddr+nsize*2, ELM_SIZE, paddr+nsize*3};

    listv  = (vuint_t *)list;

    INPUTA(0);  INPUTA(1);
    INPUTA(2);  INPUTA(3);
    INPUTA(4);  INPUTA(5);
    INPUTA(6);  INPUTA(7);
}

/*----------------------------------------------------------------------*/
inline void input_list2(uint64_t *list, uint32_t ppe_addr, uint32_t col,
                        uint32_t rowbl, uint32_t n)
{
    int nsize = n*sizeof(float);
    int paddr = ppe_addr+col*nsize+rowbl*ELM_SIZE;
    vuint_t *listv;
    listv = (vuint_t *)list;

    listv[0]  = (vuint_t){ELM_SIZE, paddr,          ELM_SIZE, paddr+nsize};
    listv[1]  = (vuint_t){ELM_SIZE, paddr+2*nsize,  ELM_SIZE, paddr+3*nsize};
}

/*----------------------------------------------------------------------*/
void dmaget_vector(uint32_t ppe_addr, uint32_t spe_addr,
                   uint32_t col, uint32_t rowbl, uint32_t n)
{
    uint32_t paddr;
    paddr = ppe_addr + col*n*sizeof(float) + rowbl*ELM_SIZE;
    dmaget((void*)spe_addr, paddr, ELM_SIZE);
}
void dmaput_vector(uint32_t ppe_addr, uint32_t spe_addr,
                   uint32_t col, uint32_t rowbl, uint32_t n)
{
    uint32_t paddr;
    paddr = ppe_addr + col*n*sizeof(float) + rowbl*ELM_SIZE;
    dmaput((void*)spe_addr, paddr, ELM_SIZE);
}
void dmagetx_vector(uint32_t ppe_addr, uint32_t spe_addr,
                    uint32_t col, uint32_t rowbl, uint32_t n, int tag)
{
    uint32_t paddr;
    paddr = ppe_addr + col*n*sizeof(float) + rowbl*ELM_SIZE;
    dmagetx((void*)spe_addr, paddr, ELM_SIZE, tag);
}
void dmaputx_vector(uint32_t ppe_addr, uint32_t spe_addr,
                    uint32_t col, uint32_t rowbl, uint32_t n, int tag)
{
    uint32_t paddr;
    paddr = ppe_addr + col*n*sizeof(float) + rowbl*ELM_SIZE;
    dmaputx((void*)spe_addr, paddr, ELM_SIZE, tag);
}

/*----------------------------------------------------------------------*/
void dmaputx_vector_spes(uint32_t spe_addr, uint32_t addr, int tag)
{
    dmaputx((void*)addr, spe_addr, ELM_SIZE, tag);
}

/*----------------------------------------------------------------------*/
void dmaget_index(uint32_t ppe_addr, uint32_t spe_addr, int colbl)
{
    uint32_t paddr;
    paddr = ppe_addr + colbl*ELM_SIZE;
    dmaget((void*)spe_addr, paddr, ELM_SIZE);
}
void dmaput_index(uint32_t ppe_addr, uint32_t spe_addr, int colbl)
{
    uint32_t paddr;
    paddr = ppe_addr + colbl*ELM_SIZE;
    dmaput((void*)spe_addr, paddr, ELM_SIZE);
}
void dmaget_index_burst(uint32_t ppe_addr, uint32_t spe_addr, int i)
{
    uint32_t paddr;
    paddr = ppe_addr + (i/ELM)*ELM_SIZE;
    dmaget((void*)spe_addr, paddr, ELM_SIZE);
}
void dmaput_index_burst(uint32_t ppe_addr, uint32_t spe_addr, int i)
{
    uint32_t paddr;
    paddr = ppe_addr + (i/ELM)*ELM_SIZE;
    dmaput((void*)spe_addr, paddr, ELM_SIZE);
}
int dmaget_index_value(uint32_t addr, int i)
{
    volatile static int buf[ELM] _GALIGN;
    dmaget_index_burst(addr, (uint32_t)buf, i);
    return buf[i%ELM];
}
void dmaput_index_value(uint32_t addr, int i, int value)
{
    volatile static int buf[ELM] _GALIGN;
    dmaget_index_burst(addr, (uint32_t)buf, i);
    buf[i%ELM] = value;
    dmaput_index_burst(addr, (uint32_t)buf, i);
}

/*----------------------------------------------------------------------*/
#define INPUT2(x, size) {                                         \
  addrv[x] = spu_sl(spu_rlmaska(indexv[x], -5), 7);               \
  addrv[x] = spu_add(addrv[x], tmpv);                             \
  listv[2*x]   = (vuint_t){size, addr[4*x+0], size, addr[4*x+1]}; \
  listv[2*x+1] = (vuint_t){size, addr[4*x+2], size, addr[4*x+3]}; \
}
void dmagetx_value_gather(uint32_t ppe_addr, volatile float* buf, uint64_t *list,
                          volatile int *index, uint32_t col, uint32_t n, int tag)
{
    uint32_t paddr = ppe_addr+n*col*sizeof(float);
    vuint_t *listv;

    volatile uint32_t addr[ELM];
    volatile vuint_t *addrv;
    vuint_t *indexv, tmpv;

    listv  = (vuint_t *)list;
    indexv = (vuint_t *)index;
    addrv  = (vuint_t *)addr;
    tmpv   = (vuint_t)spu_splats(paddr);

    INPUT2(0, ELM_SIZE);  INPUT2(1, ELM_SIZE);
    INPUT2(2, ELM_SIZE);  INPUT2(3, ELM_SIZE);
    INPUT2(4, ELM_SIZE);  INPUT2(5, ELM_SIZE);
    INPUT2(6, ELM_SIZE);  INPUT2(7, ELM_SIZE);

    dmagetlx((void*)buf, list, LIST_SIZE, tag);
}

/*--- SYNC -------------------------------------------------------------*/
/*----------------------------------------------------------------------*/
void sync_dist(uint32_t id, uint32_t* ppe_ls, 
               volatile struct spe_sync* sd, uint32_t key)
{
    int j;
    volatile static struct spe_sync ss _GALIGN;

    if(id==0){
        ss.start_flag=key;

        for(j=1;j<NUMBER_OF_SPES;j++){
            dmaputx((void*)&ss, ppe_ls[j]+128*j, 128, BCAST_DMA_TAG);
        }
        dmawait(BCAST_DMA_TAG);
    }
    else{
        while(sd[id].start_flag != key) ;
        sd[id].start_flag = DIST_END_KEY;
    }
}
void sync_collect(uint32_t id, uint32_t* ppe_ls, 
                  volatile struct spe_sync* sd, uint32_t key)
{
    int j;
    if(id==0){
        for(j=1;j<NUMBER_OF_SPES;j++){
            while(sd[j].end_flag != key) ;
            sd[j].end_flag = COLLECT_END_KEY;
        }
    }
    else{
        sd[id].end_flag = key;
        dmaput((void*)&sd[id],ppe_ls[0]+128*id,128);
    }
}
void sync_spes(uint32_t id, uint32_t* ppe_ls, 
               volatile struct spe_sync* sd, uint32_t key) 
{
    sync_dist(id, ppe_ls, sd, key);
    sync_collect(id, ppe_ls, sd, key);
}

void sync_spes2(int id, uint32_t* ppe_ls, volatile struct spe_sync* sd)
{
    int i;
    
    if(id == 0){
        for(i=1; i<NUMBER_OF_SPES; i++)
            while(sd[i].flag != SYNCALL_KEY) ;
        
        for(i=1;i<NUMBER_OF_SPES;i++){
            sd[i].flag = SYNCALL_KEY + 1;
            dmaputx((void*)&sd[i],ppe_ls[i]+128*i,128, BCAST_DMA_TAG);
        }
        dmawait(BCAST_DMA_TAG);
    }
    else{
        sd[id].flag = SYNCALL_KEY;
        dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);
        
        while(sd[id].flag != SYNCALL_KEY + 1) ;
    }
}

/*--- PIVOTING ---------------------------------------------------------*/
/*----------------------------------------------------------------------*/
void sync_pivoting(int id, int* maxj, float maxv, uint32_t* ppe_ls,
                   volatile struct spe_sync* sd)
{
    int i;
    
    if(id == 0){
        for(i=1; i<NUMBER_OF_SPES; i++){
            while(sd[i].pivot_flag != PIVOT_KEY) ;

            if(sd[i].pivot_max > maxv){
                *maxj = sd[i].pivot_idx;
                maxv  = sd[i].pivot_max;
            }
        }
        sd[0].pivot_max  = maxv;
        sd[0].pivot_idx  = *maxj;
        
        for(i=1;i<NUMBER_OF_SPES;i++){
            sd[i].pivot_flag = PIVOT_KEY + 1;
            sd[i].pivot_idx  = *maxj;
            dmaputx((void*)&sd[i],ppe_ls[i]+128*i,128, BCAST_DMA_TAG);
        }
        dmawait(BCAST_DMA_TAG);
    }
    else{
        sd[id].pivot_flag = PIVOT_KEY;
        sd[id].pivot_idx  = *maxj;
        sd[id].pivot_max  = maxv;
        dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);
        
        while(sd[id].pivot_flag != PIVOT_KEY + 1) ;
        *maxj = sd[id].pivot_idx;
    }
}

/*----------------------------------------------------------------------*/
void first_pivoting(int id, uint32_t ppe_a, uint32_t n, int* maxj,
                    uint32_t* ppe_ls, volatile struct spe_sync* sd)
{
    int i, k;
    float maxv;
    uint32_t paddr;
    
    int nsize = n*sizeof(float);

    vuint_t maxjv, tmaxjv, cmpv;
    vfloat_t maxvv, tmaxvv;

    maxjv = spu_promote((uint32_t)0, 0);
    maxvv = spu_promote(0.0f, 0);

    vuint_t *listv;
    listv = (vuint_t *)list1;

    vuint_t addv = (vuint_t){0, nsize*4, 0, nsize*4};
    vuint_t tmpv0, tmpv1;

    for(i = id; i < n/ELM; i+=NUMBER_OF_SPES) {
        paddr = ppe_a+i*ELM*nsize;

        tmpv0 = (vuint_t){ELM_SIZE, paddr,         ELM_SIZE, paddr+nsize};
        tmpv1 = (vuint_t){ELM_SIZE, paddr+nsize*2, ELM_SIZE, paddr+nsize*3};
        
        INPUTA(0);  INPUTA(1);
        INPUTA(2);  INPUTA(3);
        INPUTA(4);  INPUTA(5);
        INPUTA(6);  INPUTA(7);

        dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
        dmawait(DMA_TAG);
      
        for(k = 0; k < ELM; k++) {
            // for pivoting index
            tmaxvv = spu_promote((float)(fabs(block1[k*ELM])), 0);
            tmaxjv = spu_promote((uint32_t)(i*ELM+k), 0);
            cmpv   = spu_cmpgt(maxvv, tmaxvv);
            maxjv  = spu_sel(tmaxjv, maxjv, cmpv);
            maxvv  = spu_sel(tmaxvv, maxvv, cmpv);
        }
    }
    *maxj = spu_extract(maxjv, 0);
    maxv  = spu_extract(maxvv, 0);

    sync_pivoting(id, maxj, maxv, ppe_ls, sd);
}

/*--- INDEX (n > N_MAX) ------------------------------------------------*/
/*----------------------------------------------------------------------*/
void init_index(int id, uint32_t addr, uint32_t n)
{
    int i, j;
    volatile static int buf[ELM] _GALIGN;
    
    for(i = id; i < n/ELM; i+=NUMBER_OF_SPES) {
        for(j = 0; j < ELM; j++) buf[j] = i*ELM + j;
        dmaput((void*)buf, addr+i*ELM_SIZE, ELM_SIZE);
    }
}

void swap_index(uint32_t addr, int i, int max)
{
    int tmp1, tmp2;
    tmp1 = dmaget_index_value(addr, i);
    tmp2 = dmaget_index_value(addr, max);
    dmaput_index_value(addr, i,   tmp2);
    dmaput_index_value(addr, max, tmp1);
}

void sort_col_large(int id, uint32_t addr_b, uint32_t addr_b2,
                    uint32_t addr_i, uint32_t n, uint32_t m)
{

    int i, j, k;
    volatile static int index[ELM] _GALIGN;
    volatile static float vec[ELM] _GALIGN;
    
    for(i = id; i < n/ELM; i+=NUMBER_OF_SPES) {
        dmaget_index(addr_i, (uint32_t)index, i);
        for(j = 0; j < m; j++) {
            dmagetx_value_gather(addr_b, block1, list1, index, j, n, DMA_TAG);
            dmawait(DMA_TAG);
            for(k = 0; k < ELM; k+=4) {
                vec[k+0] = block1[(k+0)*ELM+index[k+0]%ELM];
                vec[k+1] = block1[(k+1)*ELM+index[k+1]%ELM];
                vec[k+2] = block1[(k+2)*ELM+index[k+2]%ELM];
                vec[k+3] = block1[(k+3)*ELM+index[k+3]%ELM];
            }
            dmaputx_vector(addr_b2, (uint32_t)vec, j, i, n, DMA_TAG);
            dmawait(DMA_TAG);
        }
    }
}

/*----------------------------------------------------------------------*/
void sort_col(int id, uint32_t addr_b, uint32_t addr_b2,
               int* index, uint32_t n, uint32_t m)
{
    int i, j, k;
    volatile static float vec[ELM] _GALIGN;
    
    for(i = id; i < n/ELM; i+=NUMBER_OF_SPES) {
        for(j = 0; j < m; j++) {
            dmagetx_value_gather(addr_b, block1, list1, &index[i*ELM], j, n, DMA_TAG);
            dmawait(DMA_TAG);
            for(k = 0; k < ELM; k+=4) {
                vec[k+0] = block1[(k+0)*ELM+index[i*ELM+k+0]%ELM];
                vec[k+1] = block1[(k+1)*ELM+index[i*ELM+k+1]%ELM];
                vec[k+2] = block1[(k+2)*ELM+index[i*ELM+k+2]%ELM];
                vec[k+3] = block1[(k+3)*ELM+index[i*ELM+k+3]%ELM];
            }
            dmaputx_vector(addr_b2, (uint32_t)vec, j, i, n, DMA_TAG);
            dmawait(DMA_TAG);
        }
    }
}

/*--- MATRIX & VECTOR (SIMD) -------------------------------------------*/
/*----------------------------------------------------------------------*/
void matrix_vector_calcv(volatile float* blk, volatile float* vec, 
                         int col, int row, int colbl, int *maxj, float *maxv)
{
    int coli, rowi;
    int i = (row+1)/4;
    int j = (row+1)%4;

    float tmp;

    vfloat_t tmpv1;
    vfloat_t tmpv2;

    volatile vfloat_t *blkv = (volatile vfloat_t *)blk;
    volatile vfloat_t *vecv = (volatile vfloat_t *)vec;

    vuint_t pat[4];
    pat[0] = (vuint_t){0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff};
    pat[1] = (vuint_t){0x00000000, 0xffffffff, 0xffffffff, 0xffffffff};
    pat[2] = (vuint_t){0x00000000, 0x00000000, 0xffffffff, 0xffffffff};
    pat[3] = (vuint_t){0x00000000, 0x00000000, 0x00000000, 0xffffffff};

    for(coli = col; coli < ELM; coli++) {
        if(blk[coli*ELM+row] == 0.0) continue;
        
        tmpv1 = spu_splats(blk[coli*ELM+row]);
        tmpv2 = spu_sub(blkv[coli*ELM_VEC+i], spu_mul(vecv[i], tmpv1));
        
        blkv[coli*ELM_VEC+i] = spu_sel(blkv[coli*ELM_VEC+i], tmpv2, pat[j]);
        
        for(rowi = i+1; rowi < ELM_VEC; rowi++) {
            //blk(coli, rowi) -= blk(coli, row)*vec[rowi];
            blkv[coli*ELM_VEC+rowi] = spu_sub(blkv[coli*ELM_VEC+rowi], 
                                              spu_mul(vecv[rowi], tmpv1));
        }
    }

    // for pivoting index
    for(coli = col; coli < ELM; coli++) {
        tmp = fabs(blk[ELM*coli+row+1]);
        if(tmp > *maxv) {
            *maxj = ELM*colbl+coli;
            *maxv = tmp;
        }
    }
}

// no pivoting
void matrix_vector_calcv_no_pivoting(volatile float* blk, volatile float* vec, 
                                     int col, int row, int colbl)
{

    int coli, rowi;
    vfloat_t tmpv1, tmpv2;

    int i = (row+1)/4;
    int j = (row+1)%4;

    vfloat_t *blkv = (vfloat_t *)blk;
    vfloat_t *vecv = (vfloat_t *)vec;

    vuint_t pat[4];
    pat[0] = (vuint_t){0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff};
    pat[1] = (vuint_t){0x00000000, 0xffffffff, 0xffffffff, 0xffffffff};
    pat[2] = (vuint_t){0x00000000, 0x00000000, 0xffffffff, 0xffffffff};
    pat[3] = (vuint_t){0x00000000, 0x00000000, 0x00000000, 0xffffffff};

    for(coli = col; coli < ELM; coli++) {
        if(blk[coli*ELM+row] == 0.0f) continue;
        tmpv1 = spu_splats(blk[coli*ELM+row]);
        tmpv2 = spu_nmsub(vecv[i], tmpv1, blkv[coli*ELM_VEC+i]);
        
        blkv[coli*ELM_VEC+i] = spu_sel(blkv[coli*ELM_VEC+i], tmpv2, pat[j]);
        for(rowi = i+1; rowi < ELM_VEC; rowi++) {
            //blk(coli, rowi) -= blk(coli, row)*vec[rowi];
            blkv[coli*ELM_VEC+rowi] = spu_nmsub(vecv[rowi], tmpv1, blkv[coli*ELM_VEC+rowi]);
        }
    }
}

void matrices_calcv(volatile float* blk, volatile float* blkr)
{
      
    int i, colj;
    vfloat_t x0, x1, x2, x3, x4, x5, x6, x7;
    vfloat_t tmpv;

    vfloat_t tmpv0, tmpv1, tmpv2;
    vfloat_t tmpv3 = (vfloat_t){1.0f, 1.0f, 1.0f, 1.0f};
    vfloat_t tmpre;

    vfloat_t *blkrv  = (vfloat_t *)blkr;
    
    for(i = 0; i < ELM; i++) {
        tmpv0 = spu_splats(blk[i*ELM+i]); // = A
        tmpre = spu_re(tmpv0);

        // Newton Method 3 (tmpre = 1/A)
        tmpv1 = spu_sub(tmpv3, spu_mul(tmpv0, tmpre));
        tmpv2 = spu_add(spu_add(tmpv3, tmpv1), spu_mul(tmpv1, tmpv1));
        tmpre = spu_mul(tmpre, tmpv2);

        // blkr[i*ELM+rowj] /= blk[i*ELM+i]
        blkrv[i*ELM_VEC+0] = spu_mul(blkrv[i*ELM_VEC+0], tmpre);
        blkrv[i*ELM_VEC+1] = spu_mul(blkrv[i*ELM_VEC+1], tmpre);
        blkrv[i*ELM_VEC+2] = spu_mul(blkrv[i*ELM_VEC+2], tmpre);
        blkrv[i*ELM_VEC+3] = spu_mul(blkrv[i*ELM_VEC+3], tmpre);
        blkrv[i*ELM_VEC+4] = spu_mul(blkrv[i*ELM_VEC+4], tmpre);
        blkrv[i*ELM_VEC+5] = spu_mul(blkrv[i*ELM_VEC+5], tmpre);
        blkrv[i*ELM_VEC+6] = spu_mul(blkrv[i*ELM_VEC+6], tmpre);
        blkrv[i*ELM_VEC+7] = spu_mul(blkrv[i*ELM_VEC+7], tmpre);

        x0 = blkrv[i*ELM_VEC+0];
        x1 = blkrv[i*ELM_VEC+1];
        x2 = blkrv[i*ELM_VEC+2];
        x3 = blkrv[i*ELM_VEC+3];
        x4 = blkrv[i*ELM_VEC+4];
        x5 = blkrv[i*ELM_VEC+5];
        x6 = blkrv[i*ELM_VEC+6];
        x7 = blkrv[i*ELM_VEC+7];

        for(colj = i+1; colj < ELM; colj++) {
            tmpv = spu_splats(blk[colj*ELM+i]);
            
            //blkr(colj, rowj) -= blkr(i, rowj)*blk(colj, i);
            blkrv[colj*ELM_VEC]   = spu_nmsub(x0, tmpv, blkrv[colj*ELM_VEC]);
            blkrv[colj*ELM_VEC+1] = spu_nmsub(x1, tmpv, blkrv[colj*ELM_VEC+1]);
            blkrv[colj*ELM_VEC+2] = spu_nmsub(x2, tmpv, blkrv[colj*ELM_VEC+2]);
            blkrv[colj*ELM_VEC+3] = spu_nmsub(x3, tmpv, blkrv[colj*ELM_VEC+3]);
            blkrv[colj*ELM_VEC+4] = spu_nmsub(x4, tmpv, blkrv[colj*ELM_VEC+4]);
            blkrv[colj*ELM_VEC+5] = spu_nmsub(x5, tmpv, blkrv[colj*ELM_VEC+5]);
            blkrv[colj*ELM_VEC+6] = spu_nmsub(x6, tmpv, blkrv[colj*ELM_VEC+6]);
            blkrv[colj*ELM_VEC+7] = spu_nmsub(x7, tmpv, blkrv[colj*ELM_VEC+7]);
        }
    }
}

#define MULSUB(x, tmpv) {                \
  tmpv = spu_splats(blkc[coli*ELM+x]);   \
  x0 = spu_nmsub(blkrv[j++], tmpv, x0);  \
  x1 = spu_nmsub(blkrv[j++], tmpv, x1);  \
  x2 = spu_nmsub(blkrv[j++], tmpv, x2);  \
  x3 = spu_nmsub(blkrv[j++], tmpv, x3);  \
  x4 = spu_nmsub(blkrv[j++], tmpv, x4);  \
  x5 = spu_nmsub(blkrv[j++], tmpv, x5);  \
  x6 = spu_nmsub(blkrv[j++], tmpv, x6);  \
  x7 = spu_nmsub(blkrv[j++], tmpv, x7);  \
}  
void matrices_mulsubv(volatile float* blk, volatile float* blkc, volatile float* blkr)
{
    int j, coli;
    vfloat_t x0, x1, x2, x3, x4, x5, x6, x7;
    vfloat_t tmpv0,  tmpv1,  tmpv2,  tmpv3,  tmpv4,  tmpv5,  tmpv6,  tmpv7; 
    vfloat_t tmpv8,  tmpv9,  tmpv10, tmpv11, tmpv12, tmpv13, tmpv14, tmpv15; 
    vfloat_t tmpv16, tmpv17, tmpv18, tmpv19, tmpv20, tmpv21, tmpv22, tmpv23; 
    vfloat_t tmpv24, tmpv25, tmpv26, tmpv27, tmpv28, tmpv29, tmpv30, tmpv31; 

    vfloat_t *blkv   = (vfloat_t *)blk;
    vfloat_t *blkrv  = (vfloat_t *)blkr;
    
    for(coli = 0; coli < ELM; coli++) {
        x0 = blkv[coli*ELM_VEC];
        x1 = blkv[coli*ELM_VEC+1];
        x2 = blkv[coli*ELM_VEC+2];
        x3 = blkv[coli*ELM_VEC+3];
        x4 = blkv[coli*ELM_VEC+4];
        x5 = blkv[coli*ELM_VEC+5];
        x6 = blkv[coli*ELM_VEC+6];
        x7 = blkv[coli*ELM_VEC+7];

        j = 0;
            
        MULSUB( 0, tmpv0);   MULSUB( 1, tmpv1);
        MULSUB( 2, tmpv2);   MULSUB( 3, tmpv3);
        MULSUB( 4, tmpv4);   MULSUB( 5, tmpv5);
        MULSUB( 6, tmpv6);   MULSUB( 7, tmpv7);
        MULSUB( 8, tmpv8);   MULSUB( 9, tmpv9);
        MULSUB(10, tmpv10);  MULSUB(11, tmpv11);
        MULSUB(12, tmpv12);  MULSUB(13, tmpv13);
        MULSUB(14, tmpv14);  MULSUB(15, tmpv15);
        MULSUB(16, tmpv16);  MULSUB(17, tmpv17);
        MULSUB(18, tmpv18);  MULSUB(19, tmpv19);
        MULSUB(20, tmpv20);  MULSUB(21, tmpv21);
        MULSUB(22, tmpv22);  MULSUB(23, tmpv23);
        MULSUB(24, tmpv24);  MULSUB(25, tmpv25);
        MULSUB(26, tmpv26);  MULSUB(27, tmpv27);
        MULSUB(28, tmpv28);  MULSUB(29, tmpv29);
        MULSUB(30, tmpv30);  MULSUB(31, tmpv31);

        blkv[coli*ELM_VEC]   = x0;
        blkv[coli*ELM_VEC+1] = x1;
        blkv[coli*ELM_VEC+2] = x2;
        blkv[coli*ELM_VEC+3] = x3;
        blkv[coli*ELM_VEC+4] = x4;
        blkv[coli*ELM_VEC+5] = x5;
        blkv[coli*ELM_VEC+6] = x6;
        blkv[coli*ELM_VEC+7] = x7;
    }
}

/*----------------------------------------------------------------------*/
void create_matrixT(volatile vfloat_t* inblk, volatile vfloat_t* outblk)
{
    int j = 0;

    vfloat_t tmpv0, tmpv1, tmpv2, tmpv3;

    vuchar_t pattern1 = 
        (vuchar_t){0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                   0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17};
    vuchar_t pattern2 = 
        (vuchar_t){0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                   0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f};
    vuchar_t pattern3 = 
        (vuchar_t){0x00, 0x01, 0x02, 0x03, 0x10, 0x11, 0x12, 0x13,
                   0x08, 0x09, 0x0a, 0x0b, 0x18, 0x19, 0x1a, 0x1b};
    vuchar_t pattern4 = 
        (vuchar_t){0x04, 0x05, 0x06, 0x07, 0x14, 0x15, 0x16, 0x17,
                   0x0c, 0x0d, 0x0e, 0x0f, 0x1c, 0x1d, 0x1e, 0x1f};
    while(1){
        tmpv0 = spu_shuffle(inblk[j],         inblk[2*ELM_VEC+j], pattern1);
        tmpv1 = spu_shuffle(inblk[ELM_VEC+j], inblk[3*ELM_VEC+j], pattern1);
        tmpv2 = spu_shuffle(inblk[j],         inblk[2*ELM_VEC+j], pattern2);
        tmpv3 = spu_shuffle(inblk[ELM_VEC+j], inblk[3*ELM_VEC+j], pattern2);
        
        outblk[4*j]   = spu_shuffle(tmpv0, tmpv1, pattern3);
        outblk[4*j+1] = spu_shuffle(tmpv0, tmpv1, pattern4);
        outblk[4*j+2] = spu_shuffle(tmpv2, tmpv3, pattern3);
        outblk[4*j+3] = spu_shuffle(tmpv2, tmpv3, pattern4);

        if(__builtin_expect((++j >= ELM_VEC), 0)) break;
    }
}

void return_matrixT(volatile vfloat_t* inblk, volatile vfloat_t* outblk)
{
    int j = 0;

    vfloat_t tmpv0, tmpv1, tmpv2, tmpv3;

    vuchar_t pattern1 = 
        (vuchar_t){0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                   0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17};
    vuchar_t pattern2 = 
        (vuchar_t){0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                   0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f};
    vuchar_t pattern3 = 
        (vuchar_t){0x00, 0x01, 0x02, 0x03, 0x10, 0x11, 0x12, 0x13,
                   0x08, 0x09, 0x0a, 0x0b, 0x18, 0x19, 0x1a, 0x1b};
    vuchar_t pattern4 = 
        (vuchar_t){0x04, 0x05, 0x06, 0x07, 0x14, 0x15, 0x16, 0x17,
                   0x0c, 0x0d, 0x0e, 0x0f, 0x1c, 0x1d, 0x1e, 0x1f};
    while(1) {
        tmpv0 = spu_shuffle(inblk[4*j],   inblk[4*j+2], pattern1);
        tmpv1 = spu_shuffle(inblk[4*j+1], inblk[4*j+3], pattern1);
        tmpv2 = spu_shuffle(inblk[4*j],   inblk[4*j+2], pattern2);
        tmpv3 = spu_shuffle(inblk[4*j+1], inblk[4*j+3], pattern2);
        
        outblk[j]           = spu_shuffle(tmpv0, tmpv1, pattern3);
        outblk[ELM_VEC+j]   = spu_shuffle(tmpv0, tmpv1, pattern4);
        outblk[2*ELM_VEC+j] = spu_shuffle(tmpv2, tmpv3, pattern3);
        outblk[3*ELM_VEC+j] = spu_shuffle(tmpv2, tmpv3, pattern4);

        if(__builtin_expect((++j >= ELM_VEC), 0)) break;
    }
}

void create_matrixT2(volatile vfloat_t* inblk, volatile vfloat_t* outblk)
{
    int i, j;

    vfloat_t tmpv0,  tmpv1,  tmpv2,  tmpv3;

    vuchar_t pattern1 = 
        (vuchar_t){0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                   0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17};
    vuchar_t pattern2 = 
        (vuchar_t){0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                   0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f};
    vuchar_t pattern3 = 
        (vuchar_t){0x00, 0x01, 0x02, 0x03, 0x10, 0x11, 0x12, 0x13,
                   0x08, 0x09, 0x0a, 0x0b, 0x18, 0x19, 0x1a, 0x1b};
    vuchar_t pattern4 = 
        (vuchar_t){0x04, 0x05, 0x06, 0x07, 0x14, 0x15, 0x16, 0x17,
                   0x0c, 0x0d, 0x0e, 0x0f, 0x1c, 0x1d, 0x1e, 0x1f};

    for(i = 0; i < ELM_VEC; i++) {
        for(j = 0; j < ELM_VEC; j++) {
            tmpv0 = spu_shuffle(inblk[(4*i+0)*ELM_VEC+j], inblk[(4*i+2)*ELM_VEC+j], pattern1);
            tmpv1 = spu_shuffle(inblk[(4*i+1)*ELM_VEC+j], inblk[(4*i+3)*ELM_VEC+j], pattern1);
            tmpv2 = spu_shuffle(inblk[(4*i+0)*ELM_VEC+j], inblk[(4*i+2)*ELM_VEC+j], pattern2);
            tmpv3 = spu_shuffle(inblk[(4*i+1)*ELM_VEC+j], inblk[(4*i+3)*ELM_VEC+j], pattern2);
            
            outblk[(4*j+0)*ELM_VEC+i] = spu_shuffle(tmpv0, tmpv1, pattern3);
            outblk[(4*j+1)*ELM_VEC+i] = spu_shuffle(tmpv0, tmpv1, pattern4);
            outblk[(4*j+2)*ELM_VEC+i] = spu_shuffle(tmpv2, tmpv3, pattern3);
            outblk[(4*j+3)*ELM_VEC+i] = spu_shuffle(tmpv2, tmpv3, pattern4);
        }
    }
}

/*----------------------------------------------------------------------*/
#define SUBCALC(x, tmpv) {                                     \
  tmpv = blkcvT[x];                                            \
  x0  = spu_nmsub(tmpv,  spu_splats(blka[(i+ 0)*ELM+x]),  x0); \
  x1  = spu_nmsub(tmpv,  spu_splats(blka[(i+ 1)*ELM+x]),  x1); \
  x2  = spu_nmsub(tmpv,  spu_splats(blka[(i+ 2)*ELM+x]),  x2); \
  x3  = spu_nmsub(tmpv,  spu_splats(blka[(i+ 3)*ELM+x]),  x3); \
  x4  = spu_nmsub(tmpv,  spu_splats(blka[(i+ 4)*ELM+x]),  x4); \
  x5  = spu_nmsub(tmpv,  spu_splats(blka[(i+ 5)*ELM+x]),  x5); \
  x6  = spu_nmsub(tmpv,  spu_splats(blka[(i+ 6)*ELM+x]),  x6); \
  x7  = spu_nmsub(tmpv,  spu_splats(blka[(i+ 7)*ELM+x]),  x7); \
  x8  = spu_nmsub(tmpv,  spu_splats(blka[(i+ 8)*ELM+x]),  x8); \
  x9  = spu_nmsub(tmpv,  spu_splats(blka[(i+ 9)*ELM+x]),  x9); \
  x10 = spu_nmsub(tmpv,  spu_splats(blka[(i+10)*ELM+x]), x10); \
  x11 = spu_nmsub(tmpv,  spu_splats(blka[(i+11)*ELM+x]), x11); \
  x12 = spu_nmsub(tmpv,  spu_splats(blka[(i+12)*ELM+x]), x12); \
  x13 = spu_nmsub(tmpv,  spu_splats(blka[(i+13)*ELM+x]), x13); \
  x14 = spu_nmsub(tmpv,  spu_splats(blka[(i+14)*ELM+x]), x14); \
  x15 = spu_nmsub(tmpv,  spu_splats(blka[(i+15)*ELM+x]), x15); \
}
void substitusion_calc(volatile float *blka, volatile float *blkb, volatile float *blkc)
{
    int i, j;

    vfloat_t blkbvT[ELM];
    vfloat_t blkcvT[ELM];

    vfloat_t x0, x1,  x2,  x3,  x4,  x5,  x6,  x7;
    vfloat_t x8, x9, x10, x11, x12, x13, x14, x15;
    vfloat_t cvT0,  cvT1,  cvT2,  cvT3,  cvT4,  cvT5,  cvT6,  cvT7;
    vfloat_t cvT8,  cvT9,  cvT10, cvT11, cvT12, cvT13, cvT14, cvT15;

    vfloat_t *blkbv = (vfloat_t*)blkb;
    vfloat_t *blkcv = (vfloat_t*)blkc;

    create_matrixT(blkbv, blkbvT);
    create_matrixT(blkcv, blkcvT);

    for(i = 0; i < ELM; i+=16) {

        x0  = blkbvT[i+ 0];  x1  = blkbvT[i+ 1];
        x2  = blkbvT[i+ 2];  x3  = blkbvT[i+ 3];
        x4  = blkbvT[i+ 4];  x5  = blkbvT[i+ 5];
        x6  = blkbvT[i+ 6];  x7  = blkbvT[i+ 7];
        x8  = blkbvT[i+ 8];  x9  = blkbvT[i+ 9];
        x10 = blkbvT[i+10];  x11 = blkbvT[i+11];
        x12 = blkbvT[i+12];  x13 = blkbvT[i+13];
        x14 = blkbvT[i+14];  x15 = blkbvT[i+15];

        for(j = 0; j < ELM; j+=16) {
            SUBCALC(j+0,  cvT0);   SUBCALC(j+1,  cvT1);
            SUBCALC(j+2,  cvT2);   SUBCALC(j+3,  cvT3);
            SUBCALC(j+4,  cvT4);   SUBCALC(j+5,  cvT5);
            SUBCALC(j+6,  cvT6);   SUBCALC(j+7,  cvT7);
            SUBCALC(j+8,  cvT8);   SUBCALC(j+9,  cvT9);
            SUBCALC(j+10, cvT10);  SUBCALC(j+11, cvT11);
            SUBCALC(j+12, cvT12);  SUBCALC(j+13, cvT13);
            SUBCALC(j+14, cvT14);  SUBCALC(j+15, cvT15);
        }
        blkbvT[i+ 0] = x0;   blkbvT[i+ 1] = x1;
        blkbvT[i+ 2] = x2;   blkbvT[i+ 3] = x3;
        blkbvT[i+ 4] = x4;   blkbvT[i+ 5] = x5;
        blkbvT[i+ 6] = x6;   blkbvT[i+ 7] = x7;
        blkbvT[i+ 8] = x8;   blkbvT[i+ 9] = x9;
        blkbvT[i+10] = x10;  blkbvT[i+11] = x11;
        blkbvT[i+12] = x12;  blkbvT[i+13] = x13;
        blkbvT[i+14] = x14;  blkbvT[i+15] = x15;
    }
    return_matrixT(blkbvT, blkbv);
}

#define SUBCALC2(x, tmpv) {                          \
    tmpv = spu_splats(vecc[x]);                      \
    x0 = spu_nmsub(blkavT[(x)*ELM_VEC+0], tmpv, x0); \
    x1 = spu_nmsub(blkavT[(x)*ELM_VEC+1], tmpv, x1); \
    x2 = spu_nmsub(blkavT[(x)*ELM_VEC+2], tmpv, x2); \
    x3 = spu_nmsub(blkavT[(x)*ELM_VEC+3], tmpv, x3); \
    x4 = spu_nmsub(blkavT[(x)*ELM_VEC+4], tmpv, x4); \
    x5 = spu_nmsub(blkavT[(x)*ELM_VEC+5], tmpv, x5); \
    x6 = spu_nmsub(blkavT[(x)*ELM_VEC+6], tmpv, x6); \
    x7 = spu_nmsub(blkavT[(x)*ELM_VEC+7], tmpv, x7); \
}

void substitusion_calc2(vfloat_t *blkavT, volatile float *vecb, volatile float *vecc)
{
    int i;
    vfloat_t *vecbv  = (vfloat_t *)vecb;
    vfloat_t tmpv0, tmpv1, tmpv2, tmpv3;
    vfloat_t x0, x1, x2, x3, x4, x5, x6, x7;

    x0 = vecbv[0];  x1 = vecbv[1];
    x2 = vecbv[2];  x3 = vecbv[3];
    x4 = vecbv[4];  x5 = vecbv[5];
    x6 = vecbv[6];  x7 = vecbv[7];
    
    for(i = 0; i < ELM; i+=4) {
        SUBCALC2(i+0, tmpv0);
        SUBCALC2(i+1, tmpv1);
        SUBCALC2(i+2, tmpv2);
        SUBCALC2(i+3, tmpv3);
    }
    vecbv[0] = x0;  vecbv[1] = x1;
    vecbv[2] = x2;  vecbv[3] = x3;
    vecbv[4] = x4;  vecbv[5] = x5;
    vecbv[6] = x6;  vecbv[7] = x7;
}

void forward_sub_calc(volatile float *blka, volatile float *blkb)
{
    int i, j;

    float blkbT[ELM*4];
    vfloat_t tmpv;
    vfloat_t *blkbvT = (vfloat_t*)blkbT;
    vfloat_t *blkbv  = (vfloat_t*)blkb;

    vfloat_t tmpv0, tmpv1, tmpv2;
    vfloat_t tmpv3 = (vfloat_t){1.0f, 1.0f, 1.0f, 1.0f};
    vfloat_t tmpre;

    create_matrixT(blkbv, blkbvT);

    for(i = 0; i < ELM; i++) {

        tmpv0 = spu_splats(blka[i*ELM+i]); // A
        tmpre = spu_re(tmpv0);

        // Newton Method 3 (tmpre = 1/A)
        tmpv1 = spu_sub(tmpv3, spu_mul(tmpv0, tmpre));
        tmpv2 = spu_add(spu_add(tmpv3, tmpv1), spu_mul(tmpv1, tmpv1));
        tmpre = spu_mul(tmpre, tmpv2);

        for(j = 0; j < i; j++) {
            tmpv = spu_splats(blka[i*ELM+j]);
            blkbvT[i] = spu_nmsub(blkbvT[j], tmpv, blkbvT[i]);
        }
        // blkbv[i] /= blka[i*ELM+i]
        blkbvT[i] = spu_mul(blkbvT[i], tmpre);
    }
    return_matrixT(blkbvT, blkbv);
}

void forward_sub_calc2(volatile float *blka, volatile float *vecb)
{
    int i, j;
    float *tmp = (float *)vecb;

    for(i = 0; i < ELM; i++) {
        for(j = 0; j < i; j++) {
            tmp[i] -= blka[i*ELM+j]*tmp[j];
        }
        tmp[i] /= blka[i*ELM+i];
    }    
}

void backward_sub_calc(volatile float *blka, volatile float *blkc)
{
    int i, j;

    float blkcT[ELM*4];
    vfloat_t tmpv;
    vfloat_t *blkcvT = (vfloat_t*)blkcT;
    vfloat_t *blkcv  = (vfloat_t*)blkc;

    create_matrixT(blkcv, blkcvT);

    for(i = ELM-1; i >= 0; i--) {
        for(j = ELM-1; j > i; j--) {
            tmpv = spu_splats(blka[i*ELM+j]);
            blkcvT[i] = spu_nmsub(blkcvT[j], tmpv, blkcvT[i]);
        }
    }
    return_matrixT(blkcvT, blkcv);
}

void backward_sub_calc2(volatile float *blka, volatile float *vecc)
{
    int i, j;
    float *tmp = (float *)vecc;

    for(i = ELM-1; i >= 0; i--) {
        for(j = ELM-1; j > i; j--) {
            tmp[i] -= blka[i*ELM+j]*tmp[j];
        }
    }    
}

/*--- LU DECOMPOSITION ( n > N_MAX, No Double Buffering) ---------------*/
/*----------------------------------------------------------------------*/
void spe_lu_decomposition_large(int id, uint32_t ppe_a, uint32_t ppe_i,
                                uint32_t* ppe_ls, uint32_t* ppe_vec, 
                                uint32_t n, uint32_t m,
                                volatile struct spe_sync* sd,
                                volatile float* vec)
{
    int i, j, k, h, rowi, rowj, colj;

    int   maxj = 0;
    float maxv = 0.0f;
    
    volatile static int index[ELM] _GALIGN;
    volatile static int indxi[ELM] _GALIGN;

    first_pivoting(id, ppe_a, n, &maxj, ppe_ls, sd);

    for(i = 0; i < n/ELM; i++) {

        /***************************** STEP1 ****************************/
        // (A_j, A_i)  LU decomposition of A_i ROW BLOCKS 

        for(rowi = 0; rowi < ELM-1; rowi++) {
            
            // (A_i, A_i) BLOCK
            if(id == 0) {
                // swap col
                swap_index(ppe_i, i*ELM+rowi, maxj);
                
                // Get rowi vector of (A_i, A_i) BLOCK
                dmaget_index(ppe_i, (uint32_t)indxi, i);
                dmaget_vector(ppe_a, (uint32_t)vec, indxi[rowi], i, n);

                for(rowj = rowi+1; rowj < ELM; rowj++) vec[rowj] /= vec[rowi];
                
                dmaputx_vector(ppe_a, (uint32_t)vec, indxi[rowi], i, n, BCAST_DMA_TAG);

                for(k = 1; k < NUMBER_OF_SPES; k++) 
                    dmaputx_vector_spes(ppe_vec[k], (uint32_t)vec, BCAST_DMA_TAG);
                
                dmawait(BCAST_DMA_TAG);
            }

            maxj = i*ELM+rowi+1;
            maxv = 0;

            // ## SYNC : wait for SPE[0]
            sync_dist(id, ppe_ls, sd, rowi+1);
            
            j = i+id;

            if(id == 0) {
                
                // Get (A_i, A_i) BLOCK
                input_list(list1, ppe_a, indxi, i, n);
                dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);

                matrix_vector_calcv(block1, vec, rowi+1, rowi, i, &maxj, &maxv);

                // Put (A_i, A_i) BLOCK
                dmaputlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);

                j += NUMBER_OF_SPES;
            }

            // (A_j, A_i) BLOCK
            for(; j < n/ELM; j += NUMBER_OF_SPES) {
                
                // Get (A_j, A_i) BLOCK
                dmaget_index(ppe_i, (uint32_t)index, j);

                input_list(list1, ppe_a, index, i, n);
                dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);

                matrix_vector_calcv(block1, vec, 0, rowi, j, &maxj, &maxv);

                // Put (A_j, A_i) BLOCK
                dmaputlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);
            }
            
            // ## SYNC & Pivoting : all spes
            sync_pivoting(id, &maxj, maxv, ppe_ls, sd);
        }
        
        if(__builtin_expect((i == n/ELM-1), 0)) return;

        if(id == 0) swap_index(ppe_i, i*ELM+ELM-1, maxj);
        
        // ## SYNC : wait for SPE[0] 
        sync_dist(id, ppe_ls, sd, i+ELM);

        /***************************** STEP2 ****************************/
        // (A_j, A_h) LU decomposition of A_h ROW BLOCK for all (i < h < n/ELM)
        
        h = i+id+1;

        // LU decomposition && Pivoting (h = i+1)
        if(id == 0) {
            maxj = (i+1)*ELM;
            maxv = 0;
            
            // Get (A_i, A_i) BLOCK
            dmaget_index(ppe_i, (uint32_t)indxi, i);

            input_list(list1, ppe_a, indxi, i, n);
            dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
            
            // Get (A_i, A_h) BLOCK   h = i+1
            input_list(list2, ppe_a, indxi, h, n);
            dmagetlx((void*)block2, list2, LIST_SIZE, DMA_TAG);
            dmawait(DMA_TAG);

            // Matrix Calc            
            matrices_calcv(block1, block2);

            // Put (A_i, A_h) BLOCK 
            dmaputlx((void*)block2, list2, LIST_SIZE, DMA_TAG);
            dmawait(DMA_TAG);

            // (A_j, A_h) BLOCK  j > i
            for(j = i+1; j < n/ELM; j++) {
                
                // Get (A_j, A_i) BLOCK 
                dmaget_index(ppe_i, (uint32_t)index, j);

                input_list(listd1[0], ppe_a, index, i, n);
                dmagetlx((void*)blockd1[0], listd1[0], LIST_SIZE, DMA_TAG);

                // Get (A_j, A_h) BLOCK                 
                input_list(listd1[1], ppe_a, index, h, n);
                dmagetlx((void*)blockd1[1], listd1[1], LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);
                
                // Matrix Multi & Sub
                matrices_mulsubv(blockd1[1], blockd1[0], block2);

                // for pivoting index                
                for(colj = 0; colj < ELM; colj++) {
                    if(fabs(blockd1[1][colj*ELM]) > maxv) {
                        maxj = j*ELM+colj;
                        maxv = fabs(blockd1[1][colj*ELM]);
                    }
                }
                dmaputlx((void*)blockd1[1], listd1[1], LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);
            }
            
            h+=NUMBER_OF_SPES;
        }
        else {
            // Get (A_i, A_i) BLOCK
            dmaget_index(ppe_i, (uint32_t)indxi, i);

            input_list(list1, ppe_a, indxi, i, n);
            dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
        }

        for(; h < n/ELM; h+=NUMBER_OF_SPES) {
            
            // Get (A_i, A_h) BLOCK
            input_list(list2, ppe_a, indxi, h, n);
            dmagetlx((void*)block2, list2, LIST_SIZE, DMA_TAG);
            dmawait(DMA_TAG);

            // Matrix Calc
            matrices_calcv(block1, block2);

            // Put (A_i, A_h) BLOCK
            dmaputlx((void*)block2, list2, LIST_SIZE, DMA_TAG);
            dmawait(DMA_TAG);

            // (A_j, A_h) BLOCK  j > i            
            for(j = i+1; j < n/ELM; j++) {
                
                // Get (A_j, A_i) BLOCK
                dmaget_index(ppe_i, (uint32_t)index, j);

                input_list(listd1[0], ppe_a, index, i, n);
                dmagetlx((void*)blockd1[0], listd1[0], LIST_SIZE, DMA_TAG);

                // Get (A_j, A_h) BLOCK
                input_list(listd1[1], ppe_a, index, h, n);
                dmagetlx((void*)blockd1[1], listd1[1], LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);

                // Matrix Multi & Sub
                matrices_mulsubv(blockd1[1], blockd1[0], block2);

                dmaputlx((void*)blockd1[1], listd1[1], LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);
            }
        }
        
        // ## SYNC : SPE[0] wait for all spes
        sync_collect(id, ppe_ls, sd, i+ELM*2);
    }
}

/*----------------------------------------------------------------------*/
void forward_substitution_large(int id, uint32_t ppe_a, uint32_t ppe_b,
                                uint32_t ppe_c, uint32_t ppe_i,
                                uint32_t* ppe_ls,
                                uint32_t n, uint32_t m,
                                volatile struct spe_sync* sd)
{
    int i, j;
    int mcoli;
    
    volatile static int  index[ELM] _GALIGN;
    volatile static float vecb[ELM] _GALIGN;
    volatile static float vecc[ELM] _GALIGN;

    volatile vfloat_t *block1v = (vfloat_t*)block1;
    vfloat_t block1vT[ELM_VEC*ELM];

    int mx = m/(NUMBER_OF_SPES*4);
    int my = m%(NUMBER_OF_SPES*4);

    int scol; // start col
    int ecol; // end col

    int hintid = (id == 0);

    if(id < my/4) {
        scol = m%4+id*mx*4+id*4;
        ecol = scol+(mx+1)*4;
    } else {
        scol = m%4+id*mx*4+(my/4)*4;
        ecol = scol+mx*4;
    }
    
    for(i = 0; i < n/ELM; i++) {
        
        // Get (A_i, A_i) BLOCK
        dmaget_index(ppe_i, (uint32_t)index, i);

        input_list(list1, ppe_a, index, i, n);
        dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
        dmawait(DMA_TAG);

        if(__builtin_expect((id == 0), hintid)) {
            for(mcoli = 0; mcoli < m%4; mcoli++) {
                dmaget_vector(ppe_b, (uint32_t)vecb, mcoli, i, n);
                //Calc
                forward_sub_calc2(block1, vecb);
                dmaput_vector(ppe_c, (uint32_t)vecb, mcoli, i, n);            
            }
        }
        if (scol != ecol){
            for(mcoli = scol; mcoli < ecol; mcoli+=4) {
                input_list2(list2, ppe_b, mcoli, i, n);
                dmagetlx((void*)block2, list2, LIST_SIZE2, DMA_TAG);
                dmawait(DMA_TAG);

                // SIMD
                forward_sub_calc(block1, block2);

                input_list2(list2, ppe_c, mcoli, i, n);
                dmaputlx((void*)block2, list2, LIST_SIZE2, DMA_TAG);
                dmawait(DMA_TAG);
            }
        }
        
        // ## SYNC : all spes
        sync_spes(id, ppe_ls, sd, FORWARD_KEY & i);

        if(__builtin_expect((i >= n/ELM-1), 0)) return;
        
        // (A_j, A_i) i < j
        for(j = i+id+1; j < n/ELM; j+=NUMBER_OF_SPES) {
            
            // Get (A_j, A_i) BLOCK
            dmaget_index(ppe_i, (uint32_t)index, j);

            input_list(list1, ppe_a, index, i, n);
            dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
            dmawait(DMA_TAG);

            for(mcoli = 0; mcoli < (m>>2); mcoli++) {

                input_list2(listd1[0], ppe_b, 4*mcoli, j, n);
                dmagetlx((void*)blockd1[0], listd1[0], LIST_SIZE2, DMA_TAG);
                input_list2(listd1[1], ppe_c, 4*mcoli, i, n);
                dmagetlx((void*)blockd1[1], listd1[1], LIST_SIZE2, DMA_TAG);
                dmawait(DMA_TAG);
                
                substitusion_calc(block1, blockd1[0], blockd1[1]);

                dmaputlx((void*)blockd1[0], listd1[0], LIST_SIZE2, DMA_TAG);
                dmawait(DMA_TAG);
            }
            
            if(m%4 != 0) {
                create_matrixT2(block1v, block1vT);

                for(mcoli = ((m>>2)<<2); mcoli < m; mcoli++) {
                    dmaget_vector(ppe_c, (uint32_t)vecc, mcoli, i, n);
                    dmaget_vector(ppe_b, (uint32_t)vecb, mcoli, j, n);

                    substitusion_calc2(block1vT, vecb, vecc);                    

                    dmaput_vector(ppe_b, (uint32_t)vecb, mcoli, j, n);
                }
            }
        }
        
        // ## SYNC : all spes
        sync_spes(id, ppe_ls, sd, FORWARD_KEY);
    }
}

/*----------------------------------------------------------------------*/
void backward_substitution_large(int id, uint32_t ppe_a, uint32_t ppe_c,
                                 uint32_t ppe_x, uint32_t ppe_i,
                                 uint32_t* ppe_ls,
                                 uint32_t n, uint32_t m,
                                 volatile struct spe_sync* sd)
{
    int i, j;
    int mcoli;

    volatile static int  index[ELM] _GALIGN;
    volatile static float vecc[ELM] _GALIGN;
    volatile static float vecx[ELM] _GALIGN;

    volatile vfloat_t *block1v = (vfloat_t*)block1;
    vfloat_t block1vT[ELM_VEC*ELM];

    int mx = m/(NUMBER_OF_SPES*4);
    int my = m%(NUMBER_OF_SPES*4);

    int scol; // start col
    int ecol; // end col

    int hintid = (id == 0);

    if(id < my/4) {
        scol = m%4+id*mx*4+id*4;
        ecol = scol+(mx+1)*4;
    } else {
        scol = m%4+id*mx*4+(my/4)*4;
        ecol = scol+mx*4;
    }
    
    for(i = n/ELM-1; i >= 0; i--) {

        // Get (A_i, A_i) BLOCK
        dmaget_index(ppe_i, (uint32_t)index, i);

        input_list(list1, ppe_a, index, i, n);
        dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
        dmawait(DMA_TAG);
        
        if(__builtin_expect((id == 0), hintid)) {
            for(mcoli = 0; mcoli < m%4; mcoli++) {
                dmaget_vector(ppe_c, (uint32_t)vecc, mcoli, i, n);
                // Calc
                backward_sub_calc2(block1, vecc);
                dmaput_vector(ppe_x, (uint32_t)vecc, mcoli, i, n);
            }
        }
        if (scol != ecol){
            for(mcoli = scol; mcoli < ecol; mcoli+=4) {

                input_list2(list2, ppe_c, mcoli, i, n);
                dmagetlx((void*)block2, list2, LIST_SIZE2, DMA_TAG);
                dmawait(DMA_TAG);

                // SIMD
                backward_sub_calc(block1, block2);

                input_list2(list2, ppe_x, mcoli, i, n);
                dmaputlx((void*)block2, list2, LIST_SIZE2, DMA_TAG);
                dmawait(DMA_TAG);

            }
        }
            
        // ## SYNC : all spes
        sync_spes(id, ppe_ls, sd, BACKWARD_KEY & i);

        if(__builtin_expect((i == 0), 0)) return;

        // (A_j, A_i) i > j
        for(j = i-id-1; j >= 0; j-=NUMBER_OF_SPES) {

            // Get (A_j, A_i) BLOCK
            dmaget_index(ppe_i, (uint32_t)index, j);

            input_list(list1, ppe_a, index, i, n);
            dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
            dmawait(DMA_TAG);

            for(mcoli = 0; mcoli < (m>>2); mcoli++) {

                input_list2(listd1[0], ppe_c, 4*mcoli, j, n);
                dmagetlx((void*)blockd1[0], listd1[0], LIST_SIZE2, DMA_TAG);
                input_list2(listd1[1], ppe_x, 4*mcoli, i, n);
                dmagetlx((void*)blockd1[1], listd1[1], LIST_SIZE2, DMA_TAG);
                dmawait(DMA_TAG);
                
                substitusion_calc(block1, blockd1[0], blockd1[1]);

                dmaputlx((void*)blockd1[0], listd1[0], LIST_SIZE2, DMA_TAG);
                dmawait(DMA_TAG);
            }

            if(m%4 != 0) {
                create_matrixT2(block1v, block1vT);

                for(mcoli = ((m>>2)<<2); mcoli < m; mcoli++) {
                    
                    dmaget_vector(ppe_x, (uint32_t)vecx, mcoli, i, n);
                    dmaget_vector(ppe_c, (uint32_t)vecc, mcoli, j, n);

                    substitusion_calc2(block1vT, vecc, vecx);

                    dmaput_vector(ppe_c, (uint32_t)vecc, mcoli, j, n);
                }
            }
        }
        // ## SYNC : all spes
        sync_spes(id, ppe_ls, sd, BACKWARD_KEY);
    }
}

/*--- LU DECOMPOSITION ( n < N_MAX, Double/Multi Buffering) ------------*/
/*----------------------------------------------------------------------*/
void spe_lu_decomposition(int id, uint32_t ppe_a, int* index,
                          uint32_t* ppe_ls, uint32_t* ppe_vec, 
                          uint32_t n, uint32_t m,
                          volatile struct spe_sync* sd,
                          volatile float* vec)
{
    int i, j, k, h, rowi, rowj, colj, tmp;
    float tmpf;
    int Bl_N   = n/ELM;
    int hintid = (id == 0);
    int hintbr1, hintbr2;

    int   maxj = 0;
    float maxv = 0.0f;

    vuint_t maxjv, tmaxjv, cmpv;
    vfloat_t maxvv, tmaxvv;

    int buf, nxtbuf;                 // for double/multi buffering
    int page[2];                     // for double/multi buffering
    uint32_t BUF_TAG1[2] = {30, 31}; // for double/multi buffering
    uint32_t BUF_TAG2[2] = {28, 29}; // for double/multi buffering
    uint32_t BUF_TAG3[2] = {26, 27}; // for double/multi buffering
    uint32_t BUF_TAG4[2] = {24, 25}; // for double/multi buffering

    hintbr1 = 1;
    hintbr2 = 1;

    first_pivoting(id, ppe_a, n, &maxj, ppe_ls, sd);

    // swap col
    tmp = index[maxj];
    index[maxj] = index[0];
    index[0] = tmp;

    // LU MAIN LOOP
    for(i = 0; __builtin_expect((i < Bl_N), hintbr1); i++) {
        hintbr1 = (i < Bl_N-1);

        /***************************** STEP1 ****************************/
        // (A_j, A_i)  LU decomposition of A_i ROW BLOCKS
        for(rowi = 0; __builtin_expect((rowi < ELM-1), hintbr2); rowi++) {
            hintbr2 = (rowi < (ELM-2));

            // (A_i, A_i) BLOCK
            if(__builtin_expect((id == 0), hintid)) {

                // Get rowi vector of (A_i, A_i)
                dmaget_vector(ppe_a, (uint32_t)vec, index[i*ELM+rowi], i, n);

                tmpf = vec[rowi];
                for(rowj = rowi+1; rowj < ELM; rowj++) vec[rowj] /= tmpf;

                // Put rowi vector of (A_i, A_i)
                dmaputx_vector(ppe_a, (uint32_t)vec, index[i*ELM+rowi], i, n, BCAST_DMA_TAG);
                for(k = 1; k < NUMBER_OF_SPES; k++)
                    dmaputx_vector_spes(ppe_vec[k], (uint32_t)vec, BCAST_DMA_TAG);
                dmawait(BCAST_DMA_TAG);
            }

            // ## SYNC : wait for SPE[0]
            sync_dist(id, ppe_ls, sd, rowi+1);
            
            j = i+id;

            maxj = i*ELM+rowi+1;
            maxv = 0.0f;

            if(__builtin_expect((id == 0), hintid)) {
                // Get (A_i, A_i)
                input_list(list1, ppe_a, &index[j*ELM], i, n);
                dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);

                matrix_vector_calcv(block1, vec, rowi+1, rowi, i, &maxj, &maxv);

                // Put (A_i, A_i)
                dmaputlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);               

                j += NUMBER_OF_SPES;
            }

            if(j < Bl_N) {
                //==== DOUBLE BUFFER START ====//
                buf = 0;
                page[0] = 0;
                page[1] = 0;

                //BUF PAGE 0
                input_list(&(listd1[buf][page[buf]]), ppe_a, &index[j*ELM], i, n);
                dmagetlx((void*)&(blockd1[buf][page[buf]]), 
                         &(listd1[buf][page[buf]]), LIST_SIZE, BUF_TAG1[buf]);
                
                for(; j < Bl_N-NUMBER_OF_SPES; j+=NUMBER_OF_SPES) {
                    nxtbuf = buf^1;
                    
                    input_list(&(listd1[nxtbuf][page[nxtbuf]*ELM]), 
                               ppe_a, &index[(j+NUMBER_OF_SPES)*ELM], i, n);
                    dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);
                    
                    dmawait(BUF_TAG1[buf]);
                    // Calc
                    matrix_vector_calcv(&(blockd1[buf][page[buf]*ELM_BLK]), 
                                         vec, 0, rowi, j, &maxj, &maxv);
                    
                    dmaputlx((void*)&(blockd1[buf][page[buf]*ELM_BLK]), 
                             &(listd1[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG1[buf]);

                    page[buf] ^= 1;
                    
                    buf = nxtbuf;
                }
                dmawait(BUF_TAG1[buf]);
                // Calc
                matrix_vector_calcv(&(blockd1[buf][buf[page]*ELM_BLK]), 
                                    vec, 0, rowi, j, &maxj, &maxv);
                
                dmaputlx((void*)&(blockd1[buf][buf[page]*ELM_BLK]), 
                         &(listd1[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG1[buf]);
                
                dmawait(BUF_TAG1[buf]);

                //==== DOUBLE BUFFER END ====//
            }

            // ## SYNC & Pivoting : all spes
            sync_pivoting(id, &maxj, maxv, ppe_ls, sd);

            // swap col
            tmp = index[maxj];
            index[maxj] = index[i*ELM+rowi+1];
            index[i*ELM+rowi+1] = tmp;
        }

        if(__builtin_expect((i >= Bl_N-1), 0)) return;
        hintbr2 = 1;
        
        // ## SYNC : wait for SPE[0] 
        sync_dist(id, ppe_ls, sd, i+ELM);

        /***************************** STEP2 ****************************/
        // (A_j, A_h) LU decomposition of A_h ROW BLOCK for all (i < h < Bl_N) 

        maxj = (i+1)*ELM;
        maxv = 0.0f;

        h = i+id+1;

        // LU decomposition && Pivoting (h = i+1)
        if(id == 0) {
            maxjv = spu_promote((uint32_t)maxj, 0);
            maxvv = spu_promote(maxv, 0);            

            // Get (A_i, A_i) BLOCK
            input_list(list1, ppe_a, &index[i*ELM], i, n);
            dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
            // Get (A_i, A_h) BLOCK   h = i+1
            input_list(list2, ppe_a, &index[i*ELM], h, n);
            dmagetlx((void*)block2, list2, LIST_SIZE, DMA_TAG);

            //==== DOUBLE BUFFER START ====//
            buf  = 0;
            page[0] = 0;
            page[1] = 0;

            input_list(&(listd1[buf][0]), ppe_a, &index[(i+1)*ELM], h, n);
            dmagetlx((void*)&(blockd1[buf][0]), &(listd1[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
            input_list(&(listd2[buf][0]), ppe_a, &index[(i+1)*ELM], i, n);
            dmagetlx((void*)&(blockd2[buf][0]), &(listd2[buf][0]), LIST_SIZE, BUF_TAG1[buf]);

            dmawait(DMA_TAG);
            
            // Calc (A_i, A_i) (A_i, A_h)
            matrices_calcv(block1, block2);
            // Put (A_i, A_h) BLOCK
            dmaputlx((void*)block2, list2, LIST_SIZE, DMA_TAG);

            for(j = i+1; j < Bl_N-1; j++) {
                nxtbuf = buf^1;

                input_list(&(listd1[nxtbuf][page[nxtbuf]*ELM]), ppe_a, &index[(j+1)*ELM], h, n);
                dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                         &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);
                input_list(&(listd2[nxtbuf][page[nxtbuf]*ELM]), ppe_a, &index[(j+1)*ELM], i, n);
                dmagetlx((void*)&(blockd2[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                         &(listd2[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);
                
                dmawait(BUF_TAG1[buf]);

                // Matrix Multi & Sub                
                matrices_mulsubv(&(blockd1[buf][page[buf]*ELM_BLK]), 
                                 &(blockd2[buf][page[buf]*ELM_BLK]), block2);

                // for pivoting index                
                for(colj = 0; colj < ELM; colj++) {
                    tmaxvv = spu_promote((float)(fabs(blockd1[buf][page[buf]*ELM_BLK+ELM*colj])), 0);
                    tmaxjv = spu_promote((unsigned int)(ELM*j+colj), 0);
                    cmpv   = spu_cmpgt(maxvv, tmaxvv);
                    maxjv  = spu_sel(tmaxjv, maxjv, cmpv);
                    maxvv  = spu_sel(tmaxvv, maxvv, cmpv);                    
                }
                
                dmaputlx((void*)&(blockd1[buf][page[buf]*ELM_BLK]), 
                         &(listd1[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG1[buf]);
                
                page[buf] ^= 1;
                
                buf = nxtbuf;
            }
            dmawait(BUF_TAG1[buf]);
            
            // Matrix Multi & Sub                
            matrices_mulsubv(&(blockd1[buf][page[buf]*ELM_BLK]), 
                             &(blockd2[buf][page[buf]*ELM_BLK]), block2);

            // for pivoting index
            for(colj = 0; colj < ELM; colj++) {
                tmaxvv = spu_promote((float)(fabs(blockd1[buf][page[buf]*ELM_BLK+ELM*colj])), 0);
                tmaxjv = spu_promote((unsigned int)(ELM*j+colj), 0);
                cmpv   = spu_cmpgt(maxvv, tmaxvv);
                maxjv  = spu_sel(tmaxjv, maxjv, cmpv);
                maxvv  = spu_sel(tmaxvv, maxvv, cmpv);                    
            }
            maxj = spu_extract(maxjv, 0);
            maxv = spu_extract(maxvv, 0);
            
            dmaputlx((void*)&(blockd1[buf][page[buf]*ELM_BLK]), 
                     &(listd1[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);
            dmawait(DMA_TAG);
            //==== DOUBLE BUFFER END ====//
        }
        else {
            // Get (A_i, A_i) BLOCK
            input_list(list1, ppe_a, &index[i*ELM], i, n);
            dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG01);

            for(; h < Bl_N-3*(NUMBER_OF_SPES-1); h+=4*(NUMBER_OF_SPES-1)) {
                // Get (A_i, A_h) BLOCK
                input_list(list2, ppe_a, &index[i*ELM], h, n);
                dmagetlx((void*)block2, list2, LIST_SIZE, DMA_TAG01);
                // Get (A_i, A_h_(NUMBER_OF_SPES-1)) BLOCK            
                input_list(list3, ppe_a, &index[i*ELM], h+(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)block3, list3, LIST_SIZE, DMA_TAG02);
                // Get (A_i, A_h_2*(NUMBER_OF_SPES-1)) BLOCK            
                input_list(list4, ppe_a, &index[i*ELM], h+2*(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)block4, list4, LIST_SIZE, DMA_TAG03);
                // Get (A_i, A_h_3*(NUMBER_OF_SPES-1)) BLOCK            
                input_list(list5, ppe_a, &index[i*ELM], h+3*(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)block5, list5, LIST_SIZE, DMA_TAG04);

                //==== MULTI BUFFER START ====//
                buf  = 0;
                page[0] = 0;
                page[1] = 0;

                input_list(&(listd1[buf][0]), ppe_a, &index[(i+1)*ELM], i, n);
                dmagetlx((void*)&(blockd1[buf][0]), &(listd1[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
                // 1
                input_list(&(listd2[buf][0]), ppe_a, &index[(i+1)*ELM], h, n);
                dmagetlx((void*)&(blockd2[buf][0]), &(listd2[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
                // 2
                input_list(&(listd3[buf][0]), ppe_a, &index[(i+1)*ELM], h+(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)&(blockd3[buf][0]), &(listd3[buf][0]), LIST_SIZE, BUF_TAG2[buf]);
                // 3
                input_list(&(listd4[buf][0]), ppe_a, &index[(i+1)*ELM], h+2*(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)&(blockd4[buf][0]), &(listd4[buf][0]), LIST_SIZE, BUF_TAG3[buf]);
                // 4
                input_list(&(listd5[buf][0]), ppe_a, &index[(i+1)*ELM], h+3*(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)&(blockd5[buf][0]), &(listd5[buf][0]), LIST_SIZE, BUF_TAG4[buf]);

                dmawait(DMA_TAG01);
                // Calc (A_i, A_i) (A_i, A_h)
                matrices_calcv(block1, block2);
                // Put (A_i, A_h) BLOCK
                dmaputlx((void*)block2, list2, LIST_SIZE, DMA_TAG);

                dmawait(DMA_TAG02);

                // Calc (A_i, A_i) (A_i, A_h+(NUMBER_OF_SPES-1))
                matrices_calcv(block1, block3);
                // Put (A_i, A_h+(NUMBER_OF_SPES-1)) BLOCK
                dmaputlx((void*)block3, list3, LIST_SIZE, DMA_TAG);

                dmawait(DMA_TAG03);

                // Calc (A_i, A_i) (A_i, A_h+(NUMBER_OF_SPES-1))
                matrices_calcv(block1, block4);
                // Put (A_i, A_h+(NUMBER_OF_SPES-1)) BLOCK
                dmaputlx((void*)block4, list4, LIST_SIZE, DMA_TAG);

                dmawait(DMA_TAG04);

                // Calc (A_i, A_i) (A_i, A_h+(NUMBER_OF_SPES-1))
                matrices_calcv(block1, block5);
                // Put (A_i, A_h+(NUMBER_OF_SPES-1)) BLOCK
                dmaputlx((void*)block5, list5, LIST_SIZE, DMA_TAG);

                for(j = i+1; j < Bl_N-1; j++) {
                    nxtbuf = buf^1;

                    input_list(&(listd1[nxtbuf][page[nxtbuf]*ELM]), ppe_a, &index[(j+1)*ELM], i, n);
                    dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);
                    // 1
                    input_list(&(listd2[nxtbuf][page[nxtbuf]*ELM]), ppe_a, &index[(j+1)*ELM], h, n);
                    dmagetlx((void*)&(blockd2[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd2[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);

                    dmawait(BUF_TAG1[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                    dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                             &(listd2[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG1[buf]);
                    // 2
                    input_list(&(listd3[nxtbuf][page[nxtbuf]*ELM]), ppe_a, 
                               &index[(j+1)*ELM], h+(NUMBER_OF_SPES-1), n);
                    dmagetlx((void*)&(blockd3[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd3[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG2[nxtbuf]);

                    dmawait(BUF_TAG2[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd3[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block3);

                    dmaputlx((void*)&(blockd3[buf][page[buf]*ELM_BLK]), 
                             &(listd3[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG2[buf]);
                    // 3
                    input_list(&(listd4[nxtbuf][page[nxtbuf]*ELM]), ppe_a, 
                               &index[(j+1)*ELM], h+2*(NUMBER_OF_SPES-1), n);
                    dmagetlx((void*)&(blockd4[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd4[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG3[nxtbuf]);

                    dmawait(BUF_TAG3[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd4[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block4);

                    dmaputlx((void*)&(blockd4[buf][page[buf]*ELM_BLK]), 
                             &(listd4[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG3[buf]);
                    // 4
                    input_list(&(listd5[nxtbuf][page[nxtbuf]*ELM]), ppe_a, 
                               &index[(j+1)*ELM], h+3*(NUMBER_OF_SPES-1), n);
                    dmagetlx((void*)&(blockd5[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd5[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG4[nxtbuf]);

                    dmawait(BUF_TAG4[buf]);

                    // Matrix Multi & Sub
                    matrices_mulsubv(&(blockd5[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block5);

                    dmaputlx((void*)&(blockd5[buf][page[buf]*ELM_BLK]), 
                             &(listd5[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG4[buf]);

                    page[buf] ^= 1;

                    buf = nxtbuf;                
                }
                dmawait(BUF_TAG1[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                         &(listd2[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);

                dmawait(BUF_TAG2[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd3[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block3);

                dmaputlx((void*)&(blockd3[buf][page[buf]*ELM_BLK]), 
                         &(listd3[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);

                dmawait(BUF_TAG3[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd4[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block4);

                dmaputlx((void*)&(blockd4[buf][page[buf]*ELM_BLK]), 
                         &(listd4[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);

                dmawait(BUF_TAG4[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd5[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block5);

                dmaputlx((void*)&(blockd5[buf][page[buf]*ELM_BLK]), 
                         &(listd5[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);
                //==== MULTI BUFFER END ====//
            }
            if(h < Bl_N-2*(NUMBER_OF_SPES-1)) {
                // Get (A_i, A_h) BLOCK
                input_list(list2, ppe_a, &index[i*ELM], h, n);
                dmagetlx((void*)block2, list2, LIST_SIZE, DMA_TAG01);
                // Get (A_i, A_h_(NUMBER_OF_SPES-1)) BLOCK            
                input_list(list3, ppe_a, &index[i*ELM], h+(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)block3, list3, LIST_SIZE, DMA_TAG02);
                // Get (A_i, A_h_2*(NUMBER_OF_SPES-1)) BLOCK            
                input_list(list4, ppe_a, &index[i*ELM], h+2*(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)block4, list4, LIST_SIZE, DMA_TAG03);

                //==== MULTI BUFFER START ====//
                buf  = 0;
                page[0] = 0;
                page[1] = 0;

                input_list(&(listd1[buf][0]), ppe_a, &index[(i+1)*ELM], i, n);
                dmagetlx((void*)&(blockd1[buf][0]), &(listd1[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
                // 1
                input_list(&(listd2[buf][0]), ppe_a, &index[(i+1)*ELM], h, n);
                dmagetlx((void*)&(blockd2[buf][0]), &(listd2[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
                // 2
                input_list(&(listd3[buf][0]), ppe_a, &index[(i+1)*ELM], h+(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)&(blockd3[buf][0]), &(listd3[buf][0]), LIST_SIZE, BUF_TAG2[buf]);
                // 3
                input_list(&(listd4[buf][0]), ppe_a, &index[(i+1)*ELM], h+2*(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)&(blockd4[buf][0]), &(listd4[buf][0]), LIST_SIZE, BUF_TAG3[buf]);

                dmawait(DMA_TAG01);
                // Calc (A_i, A_i) (A_i, A_h)
                matrices_calcv(block1, block2);
                // Put (A_i, A_h) BLOCK
                dmaputlx((void*)block2, list2, LIST_SIZE, DMA_TAG);

                dmawait(DMA_TAG02);

                // Calc (A_i, A_i) (A_i, A_h+(NUMBER_OF_SPES-1))
                matrices_calcv(block1, block3);
                // Put (A_i, A_h+(NUMBER_OF_SPES-1)) BLOCK
                dmaputlx((void*)block3, list3, LIST_SIZE, DMA_TAG);

                dmawait(DMA_TAG03);

                // Calc (A_i, A_i) (A_i, A_h+2*(NUMBER_OF_SPES-1))
                matrices_calcv(block1, block4);
                // Put (A_i, A_h+2*(NUMBER_OF_SPES-1)) BLOCK
                dmaputlx((void*)block4, list4, LIST_SIZE, DMA_TAG);

                for(j = i+1; j < Bl_N-1; j++) {
                    nxtbuf = buf^1;

                    input_list(&(listd1[nxtbuf][page[nxtbuf]*ELM]), ppe_a, &index[(j+1)*ELM], i, n);
                    dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);
                    // 1
                    input_list(&(listd2[nxtbuf][page[nxtbuf]*ELM]), ppe_a, &index[(j+1)*ELM], h, n);
                    dmagetlx((void*)&(blockd2[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd2[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);

                    dmawait(BUF_TAG1[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                    dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                             &(listd2[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG1[buf]);
                    // 2
                    input_list(&(listd3[nxtbuf][page[nxtbuf]*ELM]), ppe_a, 
                               &index[(j+1)*ELM], h+(NUMBER_OF_SPES-1), n);
                    dmagetlx((void*)&(blockd3[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd3[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG2[nxtbuf]);

                    dmawait(BUF_TAG2[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd3[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block3);

                    dmaputlx((void*)&(blockd3[buf][page[buf]*ELM_BLK]), 
                             &(listd3[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG2[buf]);
                    // 3
                    input_list(&(listd4[nxtbuf][page[nxtbuf]*ELM]), ppe_a, 
                               &index[(j+1)*ELM], h+2*(NUMBER_OF_SPES-1), n);
                    dmagetlx((void*)&(blockd4[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd4[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG3[nxtbuf]);

                    dmawait(BUF_TAG3[buf]);

                    // Matrix Multi & Sub
                    matrices_mulsubv(&(blockd4[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block4);

                    dmaputlx((void*)&(blockd4[buf][page[buf]*ELM_BLK]), 
                             &(listd4[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG3[buf]);

                    page[buf] ^= 1;

                    buf = nxtbuf;                
                }
                dmawait(BUF_TAG1[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                         &(listd2[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);

                dmawait(BUF_TAG2[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd3[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block3);

                dmaputlx((void*)&(blockd3[buf][page[buf]*ELM_BLK]), 
                         &(listd3[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);

                dmawait(BUF_TAG3[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd4[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block4);

                dmaputlx((void*)&(blockd4[buf][page[buf]*ELM_BLK]), 
                         &(listd4[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);
                //==== MULTI BUFFER END ====//
            }
            else if(h < Bl_N-(NUMBER_OF_SPES-1)) {
                // Get (A_i, A_h) BLOCK
                input_list(list2, ppe_a, &index[i*ELM], h, n);
                dmagetlx((void*)block2, list2, LIST_SIZE, DMA_TAG01);
                // Get (A_i, A_h_(NUMBER_OF_SPES-1)) BLOCK            
                input_list(list3, ppe_a, &index[i*ELM], h+(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)block3, list3, LIST_SIZE, DMA_TAG02);

                //==== MULTI BUFFER START ====//
                buf  = 0;
                page[0] = 0;
                page[1] = 0;

                input_list(&(listd1[buf][0]), ppe_a, &index[(i+1)*ELM], i, n);
                dmagetlx((void*)&(blockd1[buf][0]), &(listd1[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
                // 1
                input_list(&(listd2[buf][0]), ppe_a, &index[(i+1)*ELM], h, n);
                dmagetlx((void*)&(blockd2[buf][0]), &(listd2[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
                // 2
                input_list(&(listd3[buf][0]), ppe_a, &index[(i+1)*ELM], h+(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)&(blockd3[buf][0]), &(listd3[buf][0]), LIST_SIZE, BUF_TAG2[buf]);

                dmawait(DMA_TAG01);
                // Calc (A_i, A_i) (A_i, A_h)
                matrices_calcv(block1, block2);
                // Put (A_i, A_h) BLOCK
                dmaputlx((void*)block2, list2, LIST_SIZE, DMA_TAG);

                dmawait(DMA_TAG02);

                // Calc (A_i, A_i) (A_i, A_h+(NUMBER_OF_SPES-1))
                matrices_calcv(block1, block3);
                // Put (A_i, A_h+(NUMBER_OF_SPES-1)) BLOCK
                dmaputlx((void*)block3, list3, LIST_SIZE, DMA_TAG);

                for(j = i+1; j < Bl_N-1; j++) {
                    nxtbuf = buf^1;

                    input_list(&(listd1[nxtbuf][page[nxtbuf]*ELM]), ppe_a, &index[(j+1)*ELM], i, n);
                    dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);
                    // 1
                    input_list(&(listd2[nxtbuf][page[nxtbuf]*ELM]), ppe_a, &index[(j+1)*ELM], h, n);
                    dmagetlx((void*)&(blockd2[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd2[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);

                    dmawait(BUF_TAG1[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                    dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                             &(listd2[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG1[buf]);
                    // 2
                    input_list(&(listd3[nxtbuf][page[nxtbuf]*ELM]), ppe_a, 
                               &index[(j+1)*ELM], h+(NUMBER_OF_SPES-1), n);
                    dmagetlx((void*)&(blockd3[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd3[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG2[nxtbuf]);

                    dmawait(BUF_TAG2[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd3[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block3);

                    dmaputlx((void*)&(blockd3[buf][page[buf]*ELM_BLK]), 
                             &(listd3[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG2[buf]);

                    page[buf] ^= 1;

                    buf = nxtbuf;
                }
                dmawait(BUF_TAG1[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                         &(listd2[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);

                dmawait(BUF_TAG2[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd3[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block3);

                dmaputlx((void*)&(blockd3[buf][page[buf]*ELM_BLK]), 
                         &(listd3[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);
                //==== MULTI BUFFER END ====//
            }
            else if(h < Bl_N) {
                // Get (A_i, A_h) BLOCK
                input_list(list2, ppe_a, &index[i*ELM], h, n);
                dmagetlx((void*)block2, list2, LIST_SIZE, DMA_TAG01);

                //==== DOUBLE BUFFER START ====//
                buf  = 0;
                page[0] = 0;
                page[1] = 0;

                input_list(&(listd1[buf][0]), ppe_a, &index[(i+1)*ELM], i, n);
                dmagetlx((void*)&(blockd1[buf][0]), &(listd1[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
                input_list(&(listd2[buf][0]), ppe_a, &index[(i+1)*ELM], h, n);
                dmagetlx((void*)&(blockd2[buf][0]), &(listd2[buf][0]), LIST_SIZE, BUF_TAG1[buf]);

                dmawait(DMA_TAG01);

                matrices_calcv(block1, block2);

                // Put (A_i, A_h) BLOCK
                dmaputlx((void*)block2, list2, LIST_SIZE, DMA_TAG);

                for(j = i+1; j < Bl_N-1; j++) {
                    nxtbuf = buf^1;

                    input_list(&(listd1[nxtbuf][page[nxtbuf]*ELM]), ppe_a, &index[(j+1)*ELM], i, n);
                    dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);
                    input_list(&(listd2[nxtbuf][page[nxtbuf]*ELM]), ppe_a, &index[(j+1)*ELM], h, n);
                    dmagetlx((void*)&(blockd2[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd2[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);

                    dmawait(BUF_TAG1[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                    dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                             &(listd2[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG1[buf]);

                    page[buf] ^= 1;

                    buf = nxtbuf;                
                }        
                dmawait(BUF_TAG1[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                         &(listd2[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);

                dmawait(DMA_TAG);
                //==== DOUBLE BUFFER START ====//
            }
        }
        // ## SYNC & Pivoting : all spes
        sync_pivoting(id, &maxj, maxv, ppe_ls, sd);

        // swap col
        tmp = index[maxj];
        index[maxj] = index[(i+1)*ELM];
        index[(i+1)*ELM] = tmp;
    }
}

/*----------------------------------------------------------------------*/
void spe_lu_decomposition_no_pivoting(int id, uint32_t ppe_a,
                                      uint32_t* ppe_ls, uint32_t* ppe_vec, 
                                      uint32_t n, uint32_t m,
                                      volatile struct spe_sync* sd,
                                      volatile float* vec)
{
    int i, j, h, rowi, rowj;
    float tmpf;
    int Bl_N   = n/ELM;
    int hintid = (id == 0);
    int hintbr1;

    int buf, nxtbuf;                 // for double/multi buffering
    int page[2];                     // for double/multi buffering
    uint32_t BUF_TAG1[2] = {30, 31}; // for double/multi buffering
    uint32_t BUF_TAG2[2] = {28, 29}; // for double/multi buffering
    uint32_t BUF_TAG3[2] = {26, 27}; // for double/multi buffering
    uint32_t BUF_TAG4[2] = {24, 25}; // for double/multi buffering

    hintbr1 = 1;

    if(__builtin_expect((id == 0), hintid)) {
        // Get (A_i, A_i)
        input_lista(list1, ppe_a, 0, 0, n);
        dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
        dmawait(DMA_TAG);
        
        for(rowi = 0; rowi < ELM-1; rowi++) {
            tmpf = block1[rowi*ELM+rowi];
            for(rowj = rowi+1; rowj < ELM; rowj++) block1[rowi*ELM+rowj] /= tmpf;
            matrix_vector_calcv_no_pivoting(block1, &block1[rowi*ELM], rowi+1, rowi, 0);
        }
        
        // Put (A_i, A_i)
        dmaputlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
        dmawait(DMA_TAG);
    }
    
    // LU MAIN LOOP
    for(i = 0; __builtin_expect((i < Bl_N-1), hintbr1); i++) {
        hintbr1 = (i < Bl_N-2);

        /***************************** STEP1 ****************************/
        // (A_j, A_i)  LU decomposition of A_i ROW BLOCKS
        sync_dist(id, ppe_ls, sd, i+1);
        
        input_lista(list1, ppe_a, i, i, n);
        dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
        dmawait(DMA_TAG);
        
        j = i+id+1;
        
        if(j < Bl_N) {
            //==== DOUBLE BUFFER START ====//
            buf = 0;
            page[0] = 0;
            page[1] = 0;

            //BUF PAGE 0
            input_lista(&(listd1[buf][page[buf]]), ppe_a, j, i, n);
            dmagetlx((void*)&(blockd1[buf][page[buf]]), 
                     &(listd1[buf][page[buf]]), LIST_SIZE, BUF_TAG1[buf]);
                
            for(; j < Bl_N-NUMBER_OF_SPES; j+=NUMBER_OF_SPES) {
                nxtbuf = buf^1;
                    
                input_lista(&(listd1[nxtbuf][page[nxtbuf]*ELM]), 
                            ppe_a, j+NUMBER_OF_SPES, i, n);
                dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                         &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);
                    
                dmawait(BUF_TAG1[buf]);
                // Calc
                for(rowi = 0; rowi < ELM-1; rowi++) {                    
                    matrix_vector_calcv_no_pivoting(&(blockd1[buf][page[buf]*ELM_BLK]), 
                                                    &block1[rowi*ELM], 0, rowi, j);
                }

                dmaputlx((void*)&(blockd1[buf][page[buf]*ELM_BLK]), 
                         &(listd1[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG1[buf]);

                page[buf] ^= 1;
                    
                buf = nxtbuf;
            }
            dmawait(BUF_TAG1[buf]);
            // Calc
            for(rowi = 0; rowi < ELM-1; rowi++) {                    
                matrix_vector_calcv_no_pivoting(&(blockd1[buf][page[buf]*ELM_BLK]), 
                                                &block1[rowi*ELM], 0, rowi, j);
            }
            
            dmaputlx((void*)&(blockd1[buf][buf[page]*ELM_BLK]), 
                     &(listd1[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG1[buf]);
                
            dmawait(BUF_TAG1[buf]);

            //==== DOUBLE BUFFER END ====//
        }

        // ## SYNC : all spes
        sync_spes2(id, ppe_ls, sd);

        /***************************** STEP2 ****************************/
        // (A_j, A_h) LU decomposition of A_h ROW BLOCK for all (i < h < Bl_N) 

        h = i+id+1;

        // LU decomposition && Pivoting (h = i+1)
        if(id == 0) {
            // Get (A_i, A_h) BLOCK   h = i+1
            input_lista(list2, ppe_a, i, h, n);
            dmagetlx((void*)block2, list2, LIST_SIZE, DMA_TAG);

            //==== DOUBLE BUFFER START ====//
            buf  = 0;
            page[0] = 0;
            page[1] = 0;

            input_lista(&(listd1[buf][0]), ppe_a, i+1, h, n);
            dmagetlx((void*)&(blockd1[buf][0]), &(listd1[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
            input_lista(&(listd2[buf][0]), ppe_a, i+1, i, n);
            dmagetlx((void*)&(blockd2[buf][0]), &(listd2[buf][0]), LIST_SIZE, BUF_TAG1[buf]);

            dmawait(DMA_TAG);
            
            // Calc (A_i, A_i) (A_i, A_h)
            matrices_calcv(block1, block2);
            // Put (A_i, A_h) BLOCK
            dmaputlx((void*)block2, list2, LIST_SIZE, DMA_TAG);

            for(j = i+1; j < Bl_N-1; j++) {
                nxtbuf = buf^1;

                input_lista(&(listd1[nxtbuf][page[nxtbuf]*ELM]), ppe_a, j+1, h, n);
                dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                         &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);
                input_lista(&(listd2[nxtbuf][page[nxtbuf]*ELM]), ppe_a, j+1, i, n);
                dmagetlx((void*)&(blockd2[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                         &(listd2[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);
                
                dmawait(BUF_TAG1[buf]);

                // Matrix Multi & Sub                
                matrices_mulsubv(&(blockd1[buf][page[buf]*ELM_BLK]), 
                                 &(blockd2[buf][page[buf]*ELM_BLK]), block2);
                
                dmaputlx((void*)&(blockd1[buf][page[buf]*ELM_BLK]), 
                         &(listd1[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG1[buf]);
                
                page[buf] ^= 1;
                
                buf = nxtbuf;
            }
            dmawait(BUF_TAG1[buf]);
            
            // Matrix Multi & Sub                
            matrices_mulsubv(&(blockd1[buf][page[buf]*ELM_BLK]), 
                             &(blockd2[buf][page[buf]*ELM_BLK]), block2);
            
            dmaputlx((void*)&(blockd1[buf][page[buf]*ELM_BLK]), 
                     &(listd1[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);
            dmawait(DMA_TAG);
            //==== DOUBLE BUFFER END ====//

            // Get (A_i+1, A_i+1)
            input_lista(list1, ppe_a, i+1, i+1, n);
            dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
            dmawait(DMA_TAG);
            
            for(rowi = 0; rowi < ELM-1; rowi++) {
                tmpf = block1[rowi*ELM+rowi];
                for(rowj = rowi+1; rowj < ELM; rowj++) block1[rowi*ELM+rowj] /= tmpf;
                matrix_vector_calcv_no_pivoting(block1, &block1[rowi*ELM], rowi+1, rowi, i+1);
            }
            
            // Put (A_i, A_i)
            dmaputlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
            dmawait(DMA_TAG);
        }
        else {
            for(; h < Bl_N-3*(NUMBER_OF_SPES-1); h+=4*(NUMBER_OF_SPES-1)) {
                // Get (A_i, A_h) BLOCK
                input_lista(list2, ppe_a, i, h, n);
                dmagetlx((void*)block2, list2, LIST_SIZE, DMA_TAG01);
                // Get (A_i, A_h_(NUMBER_OF_SPES-1)) BLOCK            
                input_lista(list3, ppe_a, i, h+(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)block3, list3, LIST_SIZE, DMA_TAG02);
                // Get (A_i, A_h_2*(NUMBER_OF_SPES-1)) BLOCK            
                input_lista(list4, ppe_a, i, h+2*(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)block4, list4, LIST_SIZE, DMA_TAG03);
                // Get (A_i, A_h_3*(NUMBER_OF_SPES-1)) BLOCK            
                input_lista(list5, ppe_a, i, h+3*(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)block5, list5, LIST_SIZE, DMA_TAG04);

                //==== MULTI BUFFER START ====//
                buf  = 0;
                page[0] = 0;
                page[1] = 0;

                input_lista(&(listd1[buf][0]), ppe_a, i+1, i, n);
                dmagetlx((void*)&(blockd1[buf][0]), &(listd1[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
                // 1
                input_lista(&(listd2[buf][0]), ppe_a, i+1, h, n);
                dmagetlx((void*)&(blockd2[buf][0]), &(listd2[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
                // 2
                input_lista(&(listd3[buf][0]), ppe_a, i+1, h+(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)&(blockd3[buf][0]), &(listd3[buf][0]), LIST_SIZE, BUF_TAG2[buf]);
                // 3
                input_lista(&(listd4[buf][0]), ppe_a, i+1, h+2*(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)&(blockd4[buf][0]), &(listd4[buf][0]), LIST_SIZE, BUF_TAG3[buf]);
                // 4
                input_lista(&(listd5[buf][0]), ppe_a, i+1, h+3*(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)&(blockd5[buf][0]), &(listd5[buf][0]), LIST_SIZE, BUF_TAG4[buf]);

                dmawait(DMA_TAG01);
                // Calc (A_i, A_i) (A_i, A_h)
                matrices_calcv(block1, block2);
                // Put (A_i, A_h) BLOCK
                dmaputlx((void*)block2, list2, LIST_SIZE, DMA_TAG);

                dmawait(DMA_TAG02);

                // Calc (A_i, A_i) (A_i, A_h+(NUMBER_OF_SPES-1))
                matrices_calcv(block1, block3);
                // Put (A_i, A_h+(NUMBER_OF_SPES-1)) BLOCK
                dmaputlx((void*)block3, list3, LIST_SIZE, DMA_TAG);

                dmawait(DMA_TAG03);

                // Calc (A_i, A_i) (A_i, A_h+(NUMBER_OF_SPES-1))
                matrices_calcv(block1, block4);
                // Put (A_i, A_h+(NUMBER_OF_SPES-1)) BLOCK
                dmaputlx((void*)block4, list4, LIST_SIZE, DMA_TAG);

                dmawait(DMA_TAG04);

                // Calc (A_i, A_i) (A_i, A_h+(NUMBER_OF_SPES-1))
                matrices_calcv(block1, block5);
                // Put (A_i, A_h+(NUMBER_OF_SPES-1)) BLOCK
                dmaputlx((void*)block5, list5, LIST_SIZE, DMA_TAG);

                for(j = i+1; j < Bl_N-1; j++) {
                    nxtbuf = buf^1;

                    input_lista(&(listd1[nxtbuf][page[nxtbuf]*ELM]), ppe_a, j+1, i, n);
                    dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);
                    // 1
                    input_lista(&(listd2[nxtbuf][page[nxtbuf]*ELM]), ppe_a, j+1, h, n);
                    dmagetlx((void*)&(blockd2[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd2[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);

                    dmawait(BUF_TAG1[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                    dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                             &(listd2[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG1[buf]);
                    // 2
                    input_lista(&(listd3[nxtbuf][page[nxtbuf]*ELM]), ppe_a, 
                               j+1, h+(NUMBER_OF_SPES-1), n);
                    dmagetlx((void*)&(blockd3[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd3[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG2[nxtbuf]);

                    dmawait(BUF_TAG2[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd3[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block3);

                    dmaputlx((void*)&(blockd3[buf][page[buf]*ELM_BLK]), 
                             &(listd3[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG2[buf]);
                    // 3
                    input_lista(&(listd4[nxtbuf][page[nxtbuf]*ELM]), ppe_a, 
                               j+1, h+2*(NUMBER_OF_SPES-1), n);
                    dmagetlx((void*)&(blockd4[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd4[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG3[nxtbuf]);

                    dmawait(BUF_TAG3[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd4[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block4);

                    dmaputlx((void*)&(blockd4[buf][page[buf]*ELM_BLK]), 
                             &(listd4[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG3[buf]);
                    // 4
                    input_lista(&(listd5[nxtbuf][page[nxtbuf]*ELM]), ppe_a, 
                               j+1, h+3*(NUMBER_OF_SPES-1), n);
                    dmagetlx((void*)&(blockd5[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd5[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG4[nxtbuf]);

                    dmawait(BUF_TAG4[buf]);

                    // Matrix Multi & Sub
                    matrices_mulsubv(&(blockd5[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block5);

                    dmaputlx((void*)&(blockd5[buf][page[buf]*ELM_BLK]), 
                             &(listd5[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG4[buf]);

                    page[buf] ^= 1;

                    buf = nxtbuf;                
                }
                dmawait(BUF_TAG1[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                         &(listd2[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);

                dmawait(BUF_TAG2[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd3[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block3);

                dmaputlx((void*)&(blockd3[buf][page[buf]*ELM_BLK]), 
                         &(listd3[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);

                dmawait(BUF_TAG3[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd4[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block4);

                dmaputlx((void*)&(blockd4[buf][page[buf]*ELM_BLK]), 
                         &(listd4[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);

                dmawait(BUF_TAG4[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd5[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block5);

                dmaputlx((void*)&(blockd5[buf][page[buf]*ELM_BLK]), 
                         &(listd5[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);
                //==== MULTI BUFFER END ====//
            }
            if(h < Bl_N-2*(NUMBER_OF_SPES-1)) {
                // Get (A_i, A_h) BLOCK
                input_lista(list2, ppe_a, i, h, n);
                dmagetlx((void*)block2, list2, LIST_SIZE, DMA_TAG01);
                // Get (A_i, A_h_(NUMBER_OF_SPES-1)) BLOCK            
                input_lista(list3, ppe_a, i, h+(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)block3, list3, LIST_SIZE, DMA_TAG02);
                // Get (A_i, A_h_2*(NUMBER_OF_SPES-1)) BLOCK            
                input_lista(list4, ppe_a, i, h+2*(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)block4, list4, LIST_SIZE, DMA_TAG03);

                //==== MULTI BUFFER START ====//
                buf  = 0;
                page[0] = 0;
                page[1] = 0;

                input_lista(&(listd1[buf][0]), ppe_a, i+1, i, n);
                dmagetlx((void*)&(blockd1[buf][0]), &(listd1[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
                // 1
                input_lista(&(listd2[buf][0]), ppe_a, i+1, h, n);
                dmagetlx((void*)&(blockd2[buf][0]), &(listd2[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
                // 2
                input_lista(&(listd3[buf][0]), ppe_a, i+1, h+(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)&(blockd3[buf][0]), &(listd3[buf][0]), LIST_SIZE, BUF_TAG2[buf]);
                // 3
                input_lista(&(listd4[buf][0]), ppe_a, i+1, h+2*(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)&(blockd4[buf][0]), &(listd4[buf][0]), LIST_SIZE, BUF_TAG3[buf]);

                dmawait(DMA_TAG01);
                // Calc (A_i, A_i) (A_i, A_h)
                matrices_calcv(block1, block2);
                // Put (A_i, A_h) BLOCK
                dmaputlx((void*)block2, list2, LIST_SIZE, DMA_TAG);

                dmawait(DMA_TAG02);

                // Calc (A_i, A_i) (A_i, A_h+(NUMBER_OF_SPES-1))
                matrices_calcv(block1, block3);
                // Put (A_i, A_h+(NUMBER_OF_SPES-1)) BLOCK
                dmaputlx((void*)block3, list3, LIST_SIZE, DMA_TAG);

                dmawait(DMA_TAG03);

                // Calc (A_i, A_i) (A_i, A_h+2*(NUMBER_OF_SPES-1))
                matrices_calcv(block1, block4);
                // Put (A_i, A_h+2*(NUMBER_OF_SPES-1)) BLOCK
                dmaputlx((void*)block4, list4, LIST_SIZE, DMA_TAG);

                for(j = i+1; j < Bl_N-1; j++) {
                    nxtbuf = buf^1;

                    input_lista(&(listd1[nxtbuf][page[nxtbuf]*ELM]), ppe_a, j+1, i, n);
                    dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);
                    // 1
                    input_lista(&(listd2[nxtbuf][page[nxtbuf]*ELM]), ppe_a, j+1, h, n);
                    dmagetlx((void*)&(blockd2[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd2[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);

                    dmawait(BUF_TAG1[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                    dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                             &(listd2[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG1[buf]);
                    // 2
                    input_lista(&(listd3[nxtbuf][page[nxtbuf]*ELM]), ppe_a, 
                               j+1, h+(NUMBER_OF_SPES-1), n);
                    dmagetlx((void*)&(blockd3[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd3[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG2[nxtbuf]);

                    dmawait(BUF_TAG2[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd3[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block3);

                    dmaputlx((void*)&(blockd3[buf][page[buf]*ELM_BLK]), 
                             &(listd3[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG2[buf]);
                    // 3
                    input_lista(&(listd4[nxtbuf][page[nxtbuf]*ELM]), ppe_a, 
                               j+1, h+2*(NUMBER_OF_SPES-1), n);
                    dmagetlx((void*)&(blockd4[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd4[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG3[nxtbuf]);

                    dmawait(BUF_TAG3[buf]);

                    // Matrix Multi & Sub
                    matrices_mulsubv(&(blockd4[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block4);

                    dmaputlx((void*)&(blockd4[buf][page[buf]*ELM_BLK]), 
                             &(listd4[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG3[buf]);

                    page[buf] ^= 1;

                    buf = nxtbuf;                
                }
                dmawait(BUF_TAG1[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                         &(listd2[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);

                dmawait(BUF_TAG2[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd3[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block3);

                dmaputlx((void*)&(blockd3[buf][page[buf]*ELM_BLK]), 
                         &(listd3[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);

                dmawait(BUF_TAG3[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd4[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block4);

                dmaputlx((void*)&(blockd4[buf][page[buf]*ELM_BLK]), 
                         &(listd4[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);
                //==== MULTI BUFFER END ====//
            }
            else if(h < Bl_N-(NUMBER_OF_SPES-1)) {
                // Get (A_i, A_h) BLOCK
                input_lista(list2, ppe_a, i, h, n);
                dmagetlx((void*)block2, list2, LIST_SIZE, DMA_TAG01);
                // Get (A_i, A_h_(NUMBER_OF_SPES-1)) BLOCK            
                input_lista(list3, ppe_a, i, h+(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)block3, list3, LIST_SIZE, DMA_TAG02);

                //==== MULTI BUFFER START ====//
                buf  = 0;
                page[0] = 0;
                page[1] = 0;

                input_lista(&(listd1[buf][0]), ppe_a, i+1, i, n);
                dmagetlx((void*)&(blockd1[buf][0]), &(listd1[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
                // 1
                input_lista(&(listd2[buf][0]), ppe_a, i+1, h, n);
                dmagetlx((void*)&(blockd2[buf][0]), &(listd2[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
                // 2
                input_lista(&(listd3[buf][0]), ppe_a, i+1, h+(NUMBER_OF_SPES-1), n);
                dmagetlx((void*)&(blockd3[buf][0]), &(listd3[buf][0]), LIST_SIZE, BUF_TAG2[buf]);

                dmawait(DMA_TAG01);
                // Calc (A_i, A_i) (A_i, A_h)
                matrices_calcv(block1, block2);
                // Put (A_i, A_h) BLOCK
                dmaputlx((void*)block2, list2, LIST_SIZE, DMA_TAG);

                dmawait(DMA_TAG02);

                // Calc (A_i, A_i) (A_i, A_h+(NUMBER_OF_SPES-1))
                matrices_calcv(block1, block3);
                // Put (A_i, A_h+(NUMBER_OF_SPES-1)) BLOCK
                dmaputlx((void*)block3, list3, LIST_SIZE, DMA_TAG);

                for(j = i+1; j < Bl_N-1; j++) {
                    nxtbuf = buf^1;

                    input_lista(&(listd1[nxtbuf][page[nxtbuf]*ELM]), ppe_a, j+1, i, n);
                    dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);
                    // 1
                    input_lista(&(listd2[nxtbuf][page[nxtbuf]*ELM]), ppe_a, j+1, h, n);
                    dmagetlx((void*)&(blockd2[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd2[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);

                    dmawait(BUF_TAG1[buf]);

                    // Matrix Multi & Sub
                    matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                    dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                             &(listd2[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG1[buf]);
                    // 2
                    input_lista(&(listd3[nxtbuf][page[nxtbuf]*ELM]), ppe_a, 
                               j+1, h+(NUMBER_OF_SPES-1), n);
                    dmagetlx((void*)&(blockd3[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd3[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG2[nxtbuf]);

                    dmawait(BUF_TAG2[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd3[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block3);

                    dmaputlx((void*)&(blockd3[buf][page[buf]*ELM_BLK]), 
                             &(listd3[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG2[buf]);

                    page[buf] ^= 1;

                    buf = nxtbuf;                
                }
                dmawait(BUF_TAG1[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                         &(listd2[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);

                dmawait(BUF_TAG2[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd3[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block3);

                dmaputlx((void*)&(blockd3[buf][page[buf]*ELM_BLK]), 
                         &(listd3[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);
                dmawait(DMA_TAG);
                //==== MULTI BUFFER END ====//
            }
            else if(h < Bl_N) {
                // Get (A_i, A_h) BLOCK
                input_lista(list2, ppe_a, i, h, n);
                dmagetlx((void*)block2, list2, LIST_SIZE, DMA_TAG01);

                //==== DOUBLE BUFFER START ====//
                buf  = 0;
                page[0] = 0;
                page[1] = 0;

                input_lista(&(listd1[buf][0]), ppe_a, i+1, i, n);
                dmagetlx((void*)&(blockd1[buf][0]), &(listd1[buf][0]), LIST_SIZE, BUF_TAG1[buf]);
                input_lista(&(listd2[buf][0]), ppe_a, i+1, h, n);
                dmagetlx((void*)&(blockd2[buf][0]), &(listd2[buf][0]), LIST_SIZE, BUF_TAG1[buf]);

                dmawait(DMA_TAG01);

                matrices_calcv(block1, block2);

                // Put (A_i, A_h) BLOCK
                dmaputlx((void*)block2, list2, LIST_SIZE, DMA_TAG);

                for(j = i+1; j < Bl_N-1; j++) {
                    nxtbuf = buf^1;

                    input_lista(&(listd1[nxtbuf][page[nxtbuf]*ELM]), ppe_a, j+1, i, n);
                    dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);
                    input_lista(&(listd2[nxtbuf][page[nxtbuf]*ELM]), ppe_a, j+1, h, n);
                    dmagetlx((void*)&(blockd2[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd2[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE, BUF_TAG1[nxtbuf]);

                    dmawait(BUF_TAG1[buf]);

                    // Matrix Multi & Sub                
                    matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]), 
                                     &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                    dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                             &(listd2[buf][page[buf]*ELM]), LIST_SIZE, BUF_TAG1[buf]);

                    page[buf] ^= 1;

                    buf = nxtbuf;                
                }        
                dmawait(BUF_TAG1[buf]);

                // Matrix Multi & Sub
                matrices_mulsubv(&(blockd2[buf][page[buf]*ELM_BLK]),
                                 &(blockd1[buf][page[buf]*ELM_BLK]), block2);

                dmaputlx((void*)&(blockd2[buf][page[buf]*ELM_BLK]), 
                         &(listd2[buf][page[buf]*ELM]), LIST_SIZE, DMA_TAG);

                dmawait(DMA_TAG);
                //==== DOUBLE BUFFER START ====//
            }
        }
    }
}

/*----------------------------------------------------------------------*/
void forward_substitution(int id, uint32_t ppe_a, uint32_t ppe_b,
                          uint32_t ppe_c, int* index,
                          uint32_t* ppe_ls,
                          uint32_t n, uint32_t m,
                          volatile struct spe_sync* sd)
{
    int i, j;
    int mcoli;

    int Bl_N = n/ELM;
    int hintid = (id == 0);
    int hintbr1;

    volatile static float vecb[ELM] _GALIGN;
    volatile static float vecc[ELM] _GALIGN;

    volatile vfloat_t *blockv;
    vfloat_t blockvT[ELM_VEC*ELM];

    int buf, nxtbuf;                // for double buffering
    int page[2];                    // for double buffering
    uint32_t BUF_TAG[2] = {30, 31}; // for double buffering

    int mx = m/(NUMBER_OF_SPES*4);
    int my = m%(NUMBER_OF_SPES*4);

    int scol; // start col
    int ecol; // end col

    hintbr1 = 1;

    if(id < my/4) {
        scol = m%4+id*mx*4+id*4;
        ecol = scol+(mx+1)*4;
    } else {
        scol = m%4+id*mx*4+(my/4)*4;
        ecol = scol+mx*4;
    }
    
    for(i = 0; __builtin_expect((i < Bl_N), hintbr1); i++) {

        hintbr1 = ((i+1) < Bl_N);
        
        // Get (A_i, A_i) BLOCK
        if(index[0] != -1) input_list( list1, ppe_a, &index[i*ELM], i, n);
        else               input_lista(list1, ppe_a, i, i, n);
        dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
        dmawait(DMA_TAG);

        if(__builtin_expect((id == 0), hintid)) {
            for(mcoli = 0; mcoli < m%4; mcoli++) {
                dmaget_vector(ppe_b, (uint32_t)vecb, mcoli, i, n);
                //Calc
                forward_sub_calc2(block1, vecb);
                dmaput_vector(ppe_c, (uint32_t)vecb, mcoli, i, n);            
            }
        }
        if (scol != ecol){
            //==== DOUBLE BUFFER START ====//
            buf  = 0;
            page[0] = 0;
            page[1] = 0;

            input_list2(&(listd1[buf][0]), ppe_b, scol, i, n);
            dmagetlx((void*)&(blockd1[buf][0]), &(listd1[buf][0]), LIST_SIZE2, BUF_TAG[buf]);

            for(mcoli = scol; mcoli < ecol-4; mcoli+=4) {
                nxtbuf = buf^1;
            
                input_list2(&(listd1[nxtbuf][page[nxtbuf]*ELM]), ppe_b, mcoli+4, i, n);
                dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                         &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE2, BUF_TAG[nxtbuf]);

                dmawait(BUF_TAG[buf]);

                // SIMD Calc
                forward_sub_calc(block1, &(blockd1[buf][page[buf]*ELM_BLK]));

                input_list2(&(listd1[buf][page[buf]*ELM]), ppe_c, mcoli, i, n);
                dmaputlx((void*)&(blockd1[buf][page[buf]*ELM_BLK]), 
                         &(listd1[buf][page[buf]*ELM]), LIST_SIZE2, BUF_TAG[buf]);

                page[buf] ^= 1;
                
                buf = nxtbuf;
            }
            dmawait(BUF_TAG[buf]);
            
            // SIMD Calc
            forward_sub_calc(block1, &(blockd1[buf][page[buf]*ELM_BLK]));
            
            input_list2(&(listd1[buf][page[buf]*ELM]), ppe_c, mcoli, i, n);
            dmaputlx((void*)&(blockd1[buf][page[buf]*ELM_BLK]), 
                     &(listd1[buf][page[buf]*ELM]), LIST_SIZE2, BUF_TAG[buf]);

            dmawait(BUF_TAG[buf]);

            //==== DOUBLE BUFFER END ====//
        }

        // ## SYNC : all spes
        sync_spes(id, ppe_ls, sd, FORWARD_KEY & i);
        
        if(__builtin_expect((i >= Bl_N-1), 0)) return;

        // (A_j, A_i) i < j
        for(j = i+id+1; j < Bl_N; j+=NUMBER_OF_SPES) {
            
            // Get (A_j, A_i) BLOCK
            if(index[0] != -1) input_list( list1, ppe_a, &index[j*ELM], i, n);
            else               input_lista(list1, ppe_a, j, i, n);
            dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
            dmawait(DMA_TAG);

            if(m > 3){
                //==== DOUBLE BUFFER START ====//
                buf = 0;
                page[0] = 0;
                page[1] = 0;

                input_list2(&(listd1[buf][0]), ppe_b, 0, j, n);
                dmagetlx((void*)&(blockd1[buf][0]), &(listd1[buf][0]), LIST_SIZE2, BUF_TAG[buf]);
                input_list2(&(listd2[buf][0]), ppe_c, 0, i, n);
                dmagetlx((void*)&(blockd2[buf][0]), &(listd2[buf][0]), LIST_SIZE2, BUF_TAG[buf]);

                for(mcoli = 0; mcoli < (m>>2)-1; mcoli++) {
                    nxtbuf = buf^1;

                    input_list2(&(listd1[nxtbuf][page[nxtbuf]*ELM]), ppe_b, 4*(mcoli+1), j, n);
                    dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE2, BUF_TAG[nxtbuf]);
                    input_list2(&(listd2[nxtbuf][page[nxtbuf]*ELM]), ppe_c, 4*(mcoli+1), i, n);
                    dmagetlx((void*)&(blockd2[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd2[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE2, BUF_TAG[nxtbuf]);

                    dmawait(BUF_TAG[buf]);
                    // SIMD Calc
                    substitusion_calc(block1, &(blockd1[buf][page[buf]*ELM_BLK]), 
                                      &(blockd2[buf][page[buf]*ELM_BLK]));

                    dmaputlx((void*)&(blockd1[buf][page[buf]*ELM_BLK]), 
                             &(listd1[buf][page[buf]*ELM]), LIST_SIZE2, BUF_TAG[buf]);

                    page[buf] ^= 1;

                    buf = nxtbuf;
                }
                dmawait(BUF_TAG[buf]);
                // SIMD Calc
                substitusion_calc(block1, &(blockd1[buf][page[buf]*ELM_BLK]), 
                                  &(blockd2[buf][page[buf]*ELM_BLK]));
                
                dmaputlx((void*)&(blockd1[buf][page[buf]*ELM_BLK]), 
                         &(listd1[buf][page[buf]*ELM]), LIST_SIZE2, BUF_TAG[buf]);
                    
                dmawait(BUF_TAG[buf]);

                //==== DOUBLE BUFFER END ====//
            }
            if(m%4 != 0) {
                blockv = (vfloat_t*)block1;
                create_matrixT2(blockv, blockvT);

                for(mcoli = ((m>>2)<<2); mcoli < m; mcoli++) {
                    dmaget_vector(ppe_c, (uint32_t)vecc, mcoli, i, n);
                    dmaget_vector(ppe_b, (uint32_t)vecb, mcoli, j, n);

                    // SIMD Calc
                    substitusion_calc2(blockvT, vecb, vecc);

                    dmaput_vector(ppe_b, (uint32_t)vecb, mcoli, j, n);
                }
            }
        }
        // ## SYNC : all spes
        sync_spes(id, ppe_ls, sd, FORWARD_KEY);        
    }
}

/*----------------------------------------------------------------------*/
void backward_substitution(int id, uint32_t ppe_a, uint32_t ppe_c,
                           uint32_t ppe_x, int* index,
                           uint32_t* ppe_ls,
                           uint32_t n, uint32_t m,
                           volatile struct spe_sync* sd)
{
    int i, j;
    int mcoli;

    int Bl_N = n/ELM;
    int hintid = (id == 0);
    int hintbr1;

    volatile static float vecc[ELM] _GALIGN;
    volatile static float vecx[ELM] _GALIGN;

    volatile vfloat_t *blockv;
    vfloat_t blockvT[ELM_VEC*ELM];

    int buf, nxtbuf;                // for double buffering
    int page[2];                    // for double buffering
    uint32_t BUF_TAG[2] = {30, 31}; // for double buffering

    int mx = m/(NUMBER_OF_SPES*4);
    int my = m%(NUMBER_OF_SPES*4);

    int scol; // start col
    int ecol; // end col
    
    hintbr1 = 1;

    if(id < my/4) {
        scol = m%4+id*mx*4+id*4;
        ecol = scol+(mx+1)*4;
    } else {
        scol = m%4+id*mx*4+(my/4)*4;
        ecol = scol+mx*4;
    }

    for(i = Bl_N-1; __builtin_expect((i >= 0), hintbr1); i--) {

        hintbr1 = ((i-1) >= 0);

        // Get (A_i, A_i) BLOCK
        if(index[0] != -1) input_list( list1, ppe_a, &index[i*ELM], i, n);
        else               input_lista(list1, ppe_a, i, i, n);
        dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
        dmawait(DMA_TAG);

        if(__builtin_expect((id == 0), hintid)) {
            for(mcoli = 0; mcoli < m%4; mcoli++) {
                dmaget_vector(ppe_c, (uint32_t)vecc, mcoli, i, n);
                // Calc
                backward_sub_calc2(block1, vecc);
                dmaput_vector(ppe_x, (uint32_t)vecc, mcoli, i, n);
            }
        }
        if (scol != ecol){
            //==== DOUBLE BUFFER START ====//
            buf  = 0;
            page[0] = 0;
            page[1] = 0;

            input_list2(&(listd1[buf][0]), ppe_c, scol, i, n);
            dmagetlx((void*)&(blockd1[buf][0]), &(listd1[buf][0]), LIST_SIZE2, BUF_TAG[buf]);

            for(mcoli = scol; mcoli < ecol-4; mcoli+=4) {
                nxtbuf = buf^1;
            
                input_list2(&(listd1[nxtbuf][page[nxtbuf]*ELM]), ppe_c, mcoli+4, i, n);
                dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                         &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE2, BUF_TAG[nxtbuf]);

                dmawait(BUF_TAG[buf]);

                // SIMD Calc
                backward_sub_calc(block1, &(blockd1[buf][page[buf]*ELM_BLK]));

                input_list2(&(listd1[buf][page[buf]*ELM]), ppe_x, mcoli, i, n);
                dmaputlx((void*)&(blockd1[buf][page[buf]*ELM_BLK]), 
                         &(listd1[buf][page[buf]*ELM]), LIST_SIZE2, BUF_TAG[buf]);

                page[buf] ^= 1;
                
                buf = nxtbuf;
            }
            dmawait(BUF_TAG[buf]);
            
            // SIMD Calc
            backward_sub_calc(block1, &(blockd1[buf][page[buf]*ELM_BLK]));
            
            input_list2(&(listd1[buf][page[buf]*ELM]), ppe_x, mcoli, i, n);
            dmaputlx((void*)&(blockd1[buf][page[buf]*ELM_BLK]), 
                     &(listd1[buf][page[buf]*ELM]), LIST_SIZE2, BUF_TAG[buf]);

            dmawait(BUF_TAG[buf]);

            //==== DOUBLE BUFFER END ====//
        }
        // ## SYNC : all spes
        sync_spes(id, ppe_ls, sd, BACKWARD_KEY & i);

        if(__builtin_expect((i == 0), 0)) return;

        // (A_j, A_i) i > j
        for(j = i-id-1; j >= 0; j-=NUMBER_OF_SPES) {

            // Get (A_j, A_i) BLOCK
            if(index[0] != -1) input_list( list1, ppe_a, &index[j*ELM], i, n);
            else               input_lista(list1, ppe_a, j, i, n);
            dmagetlx((void*)block1, list1, LIST_SIZE, DMA_TAG);
            dmawait(DMA_TAG);

            if(m > 3){
                //==== DOUBLE BUFFER START ====//
                buf = 0;
                page[0] = 0;
                page[1] = 0;

                input_list2(&(listd1[buf][0]), ppe_c, 0, j, n);
                dmagetlx((void*)&(blockd1[buf][0]), &(listd1[buf][0]), LIST_SIZE2, BUF_TAG[buf]);
                input_list2(&(listd2[buf][0]), ppe_x, 0, i, n);
                dmagetlx((void*)&(blockd2[buf][0]), &(listd2[buf][0]), LIST_SIZE2, BUF_TAG[buf]);

                for(mcoli = 0; mcoli < (m>>2)-1; mcoli++) {
                    nxtbuf = buf^1;

                    input_list2(&(listd1[nxtbuf][page[nxtbuf]*ELM]), ppe_c, 4*(mcoli+1), j, n);
                    dmagetlx((void*)&(blockd1[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd1[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE2, BUF_TAG[nxtbuf]);
                    input_list2(&(listd2[nxtbuf][page[nxtbuf]*ELM]), ppe_x, 4*(mcoli+1), i, n);
                    dmagetlx((void*)&(blockd2[nxtbuf][page[nxtbuf]*ELM_BLK]), 
                             &(listd2[nxtbuf][page[nxtbuf]*ELM]), LIST_SIZE2, BUF_TAG[nxtbuf]);

                    dmawait(BUF_TAG[buf]);
                    // SIMD Calc
                    substitusion_calc(block1, &(blockd1[buf][page[buf]*ELM_BLK]), 
                                      &(blockd2[buf][page[buf]*ELM_BLK]));

                    dmaputlx((void*)&(blockd1[buf][page[buf]*ELM_BLK]), 
                             &(listd1[buf][page[buf]*ELM]), LIST_SIZE2, BUF_TAG[buf]);

                    page[buf] ^= 1;

                    buf = nxtbuf;
                }
                dmawait(BUF_TAG[buf]);
                // SIMD Calc
                substitusion_calc(block1, &(blockd1[buf][page[buf]*ELM_BLK]), 
                                  &(blockd2[buf][page[buf]*ELM_BLK]));
                
                dmaputlx((void*)&(blockd1[buf][page[buf]*ELM_BLK]), 
                         &(listd1[buf][page[buf]*ELM]), LIST_SIZE2, BUF_TAG[buf]);
                    
                dmawait(BUF_TAG[buf]);
                
                //==== DOUBLE BUFFER END ====//
            }
            if(m%4 != 0) {
                blockv = (vfloat_t*)block1;
                create_matrixT2(blockv, blockvT);

                for(mcoli = ((m>>2)<<2); mcoli < m; mcoli++) {
                    dmaget_vector(ppe_x, (uint32_t)vecx, mcoli, i, n);
                    dmaget_vector(ppe_c, (uint32_t)vecc, mcoli, j, n);
                    // SIMD Calc
                    substitusion_calc2(blockvT, vecc, vecx);

                    dmaput_vector(ppe_c, (uint32_t)vecc, mcoli, j, n);
                }
            }
        }
        // ## SYNC : all spes
        sync_spes(id, ppe_ls, sd, BACKWARD_KEY);
    }
}

/*----------------------------------------------------------------------*/
int check_matrix(uint32_t ppe_a, int n)
{
    volatile static float veca[ELM] _GALIGN;    
    int check;

    dmaget_vector(ppe_a, (uint32_t)veca, 0, 0, n);
    if(fabs(veca[0]) < n) check = 0;
    else                  check = 5;
    
    return check;
}

/*----------------------------------------------------------------------*/
void spe_soleqs(struct spe_ctrl* sc){
    int i;
    int n,m;
    int id;
    uint32_t ppe_a, ppe_b, ppe_x, ppe_c, ppe_d;
    uint32_t ppe_i;

    uint32_t ppe_ls[NUMBER_OF_SPES];
    uint32_t ppe_vec[NUMBER_OF_SPES];

    uint32_t ppe_s;
    volatile static struct spe_sync ss _GALIGN;
    volatile static struct spe_sync sd[NUMBER_OF_SPES] _GALIGN;
    volatile static float vec[ELM] _GALIGN;
    
    int index[N_MAX];
    vuint_t *indexv;
    vuint_t add1 = (vuint_t){0, 1, 2, 3};
    vuint_t add2 = (vuint_t){4, 4, 4, 4};
    indexv = (vuint_t *)index;

    int check;
    
    n  = sc->n;
    m  = sc->m;
    id = sc->id;
    ppe_a = sc->buf;                       // BLOCK A
    ppe_b = ppe_a + n * n * sizeof(float); // BLOCK B
    ppe_x = ppe_b + n * m * sizeof(float); // BLOCK X
    ppe_c = ppe_x + n * m * sizeof(float); // BLOCK C
    ppe_d = ppe_c + n * m * sizeof(float); // BLOCK D 
    ppe_i = ppe_d + n * m * sizeof(float); // INDEX (if n > N_MAX)
    ppe_s = ppe_i + n * sizeof(int);       // SYNC

    // for syncronization
    ss.flag  = 0XFFFFFFFF;
    ss.addr  = (uint32_t)sc->ls_addr[id] + (uint32_t)&sd[0];
    ss.addrv = (uint32_t)sc->ls_addr[id] + (uint32_t)&vec[0];
    dmaput((void*)&ss, (ppe_s+128*id) , 128);

    // Get addresses for each sharing memory of SPE
    ss.flag = 0;
    for(i=0; i < NUMBER_OF_SPES; i++){
        while(ss.flag != 0XFFFFFFFF){
            dmaget((void*)&ss, (ppe_s+128*i), 128);
        }
        ppe_ls[i]  = ss.addr;
        ppe_vec[i] = ss.addrv;
        ss.flag = 0;
    }

    check = check_matrix(ppe_a, n);
    //spe_printf("%d check:%d \n", id, check);

    if(check == 5) { // no pivoting
        index[0] = -1;

        spe_lu_decomposition_no_pivoting(id, ppe_a, ppe_ls, ppe_vec, n, m, sd, vec);

        // SYNC
        sync_spes(id, ppe_ls, sd, 0);
        
        forward_substitution(id, ppe_a, ppe_b, ppe_c, index, ppe_ls, n, m, sd);

        // SYNC
        sync_spes(id, ppe_ls, sd, 0);
        
        backward_substitution(id, ppe_a, ppe_c, ppe_x, index, ppe_ls, n, m, sd);
    }
    else if(n < N_MAX) {
        // initialize index
        for(i = 0; i < n/4; i++) {indexv[i] = add1; add1 = spu_add(add1, add2);}

        spe_lu_decomposition(id, ppe_a, index, ppe_ls, ppe_vec, n, m, sd, vec);
        
        // BLOCK B -- sort --> BLOCK D
        sort_col(id, ppe_b, ppe_d, index, n, m);
        
        // SYNC
        sync_spes(id, ppe_ls, sd, 0);
        
        forward_substitution(id, ppe_a, ppe_d, ppe_c, index, ppe_ls, n, m, sd);

        // SYNC
        sync_spes(id, ppe_ls, sd, 0);
        
        backward_substitution(id, ppe_a, ppe_c, ppe_x, index, ppe_ls, n, m, sd);
    }
    else {
        // initialize index
        init_index(id, ppe_i, n);
        
        spe_lu_decomposition_large(id, ppe_a, ppe_i, ppe_ls, ppe_vec, n, m, sd, vec);
        
        // BLOCK B -- sort --> BLOCK D
        sort_col_large(id, ppe_b, ppe_d, ppe_i, n, m);
        
        // SYNC
        sync_spes(id, ppe_ls, sd, 0);
        
        forward_substitution_large( id, ppe_a, ppe_d, ppe_c, ppe_i, ppe_ls, n, m, sd);

        // SYNC
        sync_spes(id, ppe_ls, sd, 0);
        
        backward_substitution_large( id, ppe_a, ppe_c, ppe_x, ppe_i, ppe_ls, n, m, sd);
    }
}
