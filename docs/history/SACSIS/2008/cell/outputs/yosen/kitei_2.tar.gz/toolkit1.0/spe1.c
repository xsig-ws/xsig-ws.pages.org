/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2008-02-05                */
/*----------------------------------------------------------------------*/
#include <spu_intrinsics.h>
#include <spelib.h>
#include <spe_stdio.h>
#include <stdlib.h>
#include <spu_mfcio.h>
#include <float.h>
#include <math.h>
#include "spe_util.h"
#include "define.h"

#define block_size 32

volatile static float bufx[2][3232] _GALIGN;
volatile static float bufy[4][3232] _GALIGN;
volatile static float bufz[480][32] _GALIGN;
volatile static float bufc[2][32]   _GALIGN;

//max n = 3200, /7 = 480

/*----------------------------------------------------------------------*/
struct spe_sync{
    unsigned int flag;
    unsigned int start_flag;
    unsigned int end_flag;
    unsigned int addr; // address for sd
    unsigned int pivot_flag;
    unsigned int pivot_idx;
    float        pivot_max;
    unsigned int data[25];
};

volatile static struct spe_ctrl sc _GALIGN;

extern void dmaget(void* d, unsigned long long addr, unsigned int size);
extern void dmaput(void* d, unsigned long long addr, unsigned int size);
extern void spe_time_start(struct spe_ctrl* sc,unsigned long long argv);
extern void spe_time_end(struct spe_ctrl* sc);

/*----------------------------------------------------------------------*/

void dmaget_burst(unsigned int ppe_addr, unsigned int spe_addr, unsigned int row, unsigned int col, unsigned int n){
    unsigned int paddr;
    paddr = ppe_addr + n * col * sizeof(float) + (row / 32) * 128;
    dmaget((void*)spe_addr, paddr, 128);
}

float dmaget_value(unsigned int addr, unsigned int row, unsigned int col, unsigned int n){
    volatile static float buf[32] _GALIGN;
    dmaget_burst(addr, (unsigned int)buf, row, col, n);
    return buf[row%32];
}

void sync_dist(unsigned int id, unsigned int* ppe_ls, volatile struct spe_sync* sd, unsigned int key){
    int j;
    volatile static struct spe_sync ss _GALIGN;

    if(id==0){
        ss.start_flag=key;
//        for(j=1;j<NUMBER_OF_SPES;j++){
		for(j=NUMBER_OF_SPES-1;j>0;j--){
            dmaput((void*)&ss, ppe_ls[j]+128*j, 128);
        }
    }
    else{
        while(sd[id].start_flag != key) ;
    }
}

void sync_collect(unsigned int id, unsigned int* ppe_ls, volatile struct spe_sync* sd, unsigned int key){
    int j;
    if(id==0){
//        for(j=1;j<NUMBER_OF_SPES;j++){
		for(j=NUMBER_OF_SPES-1;j>0;j--){
			while(sd[j].end_flag != key) ;
        }
    } 
    else{
        sd[id].end_flag = key;
        dmaput((void*)&sd[id],ppe_ls[0]+128*id,128);
    }
}

void pivoting(int id, unsigned int addr,
              unsigned int n, int s, int* maxj,
              unsigned int* ppe_ls, volatile struct spe_sync* sd,
              unsigned int key){
    int i,j;
    float t1, t2;

    *maxj = s+(n-s)*id/NUMBER_OF_SPES;
    t1 = fabs(dmaget_value(addr, s, s+(n-s)*id/NUMBER_OF_SPES, n));
//    for(j=s+(n-s)*id/NUMBER_OF_SPES+1;j<n*(id+1)/NUMBER_OF_SPES;j++){
    for(j=s+(n-s)*id/NUMBER_OF_SPES+1;j<s+(n-s)*(id+1)/NUMBER_OF_SPES;j++){    
        t2 = fabs(dmaget_value(addr, s, j, n));
        if(t2 > t1){
            *maxj = j;
            t1   = t2;
        }
    }

    if(id == 0){
		for(i=NUMBER_OF_SPES-1;i>0;i--){
            while(sd[i].pivot_flag != key+2) ;

            if(sd[i].pivot_max > t1){
                *maxj = sd[i].pivot_idx;
                t1    = sd[i].pivot_max;
            }
        }

		for(i=NUMBER_OF_SPES-1;i>0;i--){
            sd[i].pivot_flag = key + 8;
            sd[i].pivot_max  = *maxj;
            dmaput((void*)&sd[i],ppe_ls[i]+128*i,128);
        }
    }
    else{
        sd[id].pivot_flag = key+2;
        sd[id].pivot_idx  = *maxj;
        sd[id].pivot_max  = t1;
        dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);

        while(sd[id].pivot_flag != key + 8) ;
        *maxj = sd[id].pivot_max;
    }
}

void swap_row(int id, unsigned int addr, unsigned int r1, unsigned int r2, unsigned int n){
    int i, di;
    volatile static float buf1[480] _GALIGN;
    volatile static float buf2[480] _GALIGN;
    unsigned int ppe_addr1;
    unsigned int ppe_addr2;

    i = (n/32)*id/NUMBER_OF_SPES;
	di = (n/32)*(id+1)/NUMBER_OF_SPES - i;
	ppe_addr1 = addr + sizeof(float) * n * r1 + 128 * i;
	ppe_addr2 = addr + sizeof(float) * n * r2 + 128 * i;

	dmaget((void*)buf1, ppe_addr1, 128*di);
	dmaget((void*)buf2, ppe_addr2, 128*di);
	dmaput((void*)buf2, ppe_addr1, 128*di);
	dmaput((void*)buf1, ppe_addr2, 128*di);
}

void swap_col(int id, unsigned int addr, unsigned int r1, unsigned int r2, unsigned int n, unsigned int m){
    int i, a, b, p1, p2, dp;
    float t;
	volatile static float buf1[32] _GALIGN;
	volatile static float buf2[32] _GALIGN;

	a = r1/32;
	b = r2/32;
	dp = n*sizeof(float);

	if(a != b){
		p1 = addr + a*128;
		p2 = addr + b*128;
		for(i=id;i<m;i=i+NUMBER_OF_SPES){
			dmaget((void*)buf1, p1 + dp*i, 128);
			dmaget((void*)buf2, p2 + dp*i, 128);

			t           = buf1[r1%32];
			buf1[r1%32] = buf2[r2%32];
			buf2[r2%32] = t          ;

			dmaput((void*)buf1, p1 + dp*i, 128);
			dmaput((void*)buf2, p2 + dp*i, 128);
		}
	}else{
		p1 = addr + a*128;
		for(i=id;i<m;i=i+NUMBER_OF_SPES){
			dmaget((void*)buf1, p1+dp*i, 128);

			t           = buf1[r1%32];
			buf1[r1%32] = buf1[r2%32];
			buf1[r2%32] = t          ;

			dmaput((void*)buf1, p1+dp*i, 128);
		}
	}
}

void spe_lu_blocked(int id, unsigned int addr, int row,
				   int n, int m, 
				   unsigned int* ppe_ls, volatile struct spe_sync* sd){
    int p,q,dp;
    int i,k,j;
	int maxj;
	int key = row + 3;
	int ch;

	int di;
	int s, p1, p2, index;

    float t1;
	vector float t;

    float diag;
    
	volatile static float buf[32][480]  _GALIGN;
    volatile static float bufa[2][32]   _GALIGN;
	volatile static float bufb[2][480]  _GALIGN;

    s  =  row/32;
	p2 = addr + 128*s;
	dp = n*sizeof(float);

	mfc_get((void*)bufc[0], p2+dp*row, 128, 1, 0, 0);

	q = row + 1 + id;
	p = p2+dp*q;

	mfc_get((void*)bufz[0], p, 128, 0, 0, 0);

	p += NUMBER_OF_SPES*dp;

	ch = 0;

	index = (s+1)+((n/32)-(s+1))*id/NUMBER_OF_SPES;
	di    = (s+1)+((n/32)-(s+1))*(id+1)/NUMBER_OF_SPES - index;

	p1 = addr + 128*index;
	p2 = addr + 128*s    ;

// j = row; first loop

	mfc_write_tag_mask(1 << 1);
	mfc_write_tag_update_all();
	mfc_read_tag_status();

	diag = bufc[0][0];

	maxj = q;	
	float temp = 0;

	for(i=0;i*NUMBER_OF_SPES+q<n;i++){
		mfc_write_tag_mask(1 << i%2);
		mfc_write_tag_update_all();
		mfc_read_tag_status();

		mfc_get(bufz[i+1], p, 128, (i+1)%2, 0, 0);

		bufz[i][0] /= diag;
		t1 = bufz[i][0];
		t = spu_splats((float)t1);

		for(k=0; k<32; k+=4)
			*(vector float*)&bufz[i][k] = spu_nmsub(*(vector float*)&bufc[0][k], t, *(vector float*)&bufz[i][k]);

		bufz[i][0] = t1; 

		p += NUMBER_OF_SPES*dp;

		if(temp < fabs(bufz[i][1])){
			maxj = i*NUMBER_OF_SPES+q;
			temp = fabs(bufz[i][1]);
		}
	}

	if(id == 0){
		dmaput((void*)bufz[0], p2+dp*(row+1), 128);
	}

	if (id == (maxj-row-1)%NUMBER_OF_SPES){
		dmaput((void*)bufz[(maxj-row-1)/NUMBER_OF_SPES], p2+dp*maxj, 128);
	}

	if(id == 0){
		for(i=1;i<NUMBER_OF_SPES;i++){
			while(sd[i].pivot_flag != key+2);
			if(sd[i].pivot_max > temp){
				maxj  = sd[i].pivot_idx;
				temp  = sd[i].pivot_max;
			}
		}
		
		for(i=1;i<NUMBER_OF_SPES;i++){
			sd[i].pivot_flag = key + 8;
			sd[i].pivot_idx  = maxj;
			dmaput((void*)&sd[i],ppe_ls[i]+128*i,128);
		}
	}else{
		sd[id].pivot_flag = key+2;
		sd[id].pivot_idx  = maxj;
		sd[id].pivot_max  = temp;
		dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);

		while(sd[id].pivot_flag != key + 8) ;
		maxj = sd[id].pivot_idx;
	}

	if( row+1 != maxj){
		swap_row(id, addr, row+1, maxj, n);
		swap_col(id, addr+n*dp, row+1, maxj, n, m);

		if(id == 0){
			for(i=1;i<NUMBER_OF_SPES;i++){
				while(sd[i].pivot_flag != key+3);
			}
			
			for(i=1;i<NUMBER_OF_SPES;i++){
				sd[i].pivot_flag = key + 6;
				dmaput((void*)&sd[i],ppe_ls[i]+128*i,128);
			}
		}else{
			sd[id].pivot_flag = key+3;
			dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);

			while(sd[id].pivot_flag != key + 6);
		}

		if (id == (maxj-row-1)%NUMBER_OF_SPES){
			dmaget((void*)bufz[(maxj-row-1)/NUMBER_OF_SPES], p2+dp*maxj, 128);
		}
	}

	for(j=row+1;j<row+31;j++){
		dmaget_burst(addr, (unsigned int)bufc[0], (j+1), j, n);
		diag = 1.0 / bufc[0][j%32];

		p = p2+dp*q;

		temp = 0;

		if(ch*NUMBER_OF_SPES+q <= j){
			ch++;
		}

		maxj = j + 1;

		for(i=ch;i*NUMBER_OF_SPES+q<n;i++){
			bufz[i][j%32] *= diag; 
			t1 = bufz[i][j%32];
			t = spu_splats((float)t1);
			
			if(j%32 < 29){		
				if((j+1)%4 == 0){ 
					for(k=(j+1)%32; k<32; k+=4)
						*(vector float*)&bufz[i][k] = spu_nmsub(*(vector float*)&bufc[0][k], t, *(vector float*)&bufz[i][k]);
				}else if((j+1)%4 == 1){
					for(k=j%32; k<32; k+=4)
						*(vector float*)&bufz[i][k] = spu_nmsub(*(vector float*)&bufc[0][k], t, *(vector float*)&bufz[i][k]);
					bufz[i][j%32] = t1;
				}else if((j+1)%4 == 3){
					bufz[i][(j+1)%32] -= bufc[0][(j+1)%32] * t1;
					for(k=(j+2)%32; k<32; k+=4)
						*(vector float*)&bufz[i][k] = spu_nmsub(*(vector float*)&bufc[0][k], t, *(vector float*)&bufz[i][k]);
				}else{
					bufz[i][(j+1)%32] -= bufc[0][(j+1)%32] * t1;
					bufz[i][(j+2)%32] -= bufc[0][(j+2)%32] * t1;
					for(k=(j+3)%32; k<32; k+=4)
						*(vector float*)&bufz[i][k] = spu_nmsub(*(vector float*)&bufc[0][k], t, *(vector float*)&bufz[i][k]);
				}
			}else{
				for(k=(j+1)%32;k<32;k++)
					bufz[i][k] -= bufc[0][k] * t1;
			}
		
			if(temp < fabs(bufz[i][(j+1)%32])){
				maxj = i*NUMBER_OF_SPES+q;
				temp = fabs(bufz[i][(j+1)%32]);
			}
		}
 
		if(id == (j-row)%NUMBER_OF_SPES){
			dmaput((void*)bufz[(j-row)/NUMBER_OF_SPES], p2+dp*(j+1), 128);
		}

		if (id == (maxj-row-1)%NUMBER_OF_SPES){
			dmaput((void*)bufz[(maxj-row-1)/NUMBER_OF_SPES], p2+dp*maxj, 128);
		}

		if(id == 0){
			for(i=1;i<NUMBER_OF_SPES;i++){
				while(sd[i].pivot_flag != key+2);
				if(sd[i].pivot_max > temp){
					maxj  = sd[i].pivot_idx;
					temp  = sd[i].pivot_max;
				}
			}

			for(i=1;i<NUMBER_OF_SPES;i++){
				sd[i].pivot_flag = key + 8;
				sd[i].pivot_idx  = maxj;
				dmaput((void*)&sd[i],ppe_ls[i]+128*i,128);
			}
		}else{
			sd[id].pivot_flag = key+2;
			sd[id].pivot_idx  = maxj;
			sd[id].pivot_max  = temp;
			dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);
		
			while(sd[id].pivot_flag != key + 8) ;
			maxj = sd[id].pivot_idx;
		}	

		if( j+1 != maxj){

			swap_row(id, addr, j+1, maxj, n);
			swap_col(id, addr+n*dp, j+1, maxj, n, m);

			if(id == 0){
				for(i=1;i<NUMBER_OF_SPES;i++){
					while(sd[i].pivot_flag != key+3);
				}
			
				for(i=1;i<NUMBER_OF_SPES;i++){
					sd[i].pivot_flag = key + 6;
					dmaput((void*)&sd[i],ppe_ls[i]+128*i,128);
				}
			}else{
				sd[id].pivot_flag = key+3;
				dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);

				while(sd[id].pivot_flag != key + 6) ;
			}

			if (id == (maxj-row-1)%NUMBER_OF_SPES){
				dmaget((void*)bufz[(maxj-row-1)/NUMBER_OF_SPES], p2+dp*maxj, 128);
			}
		}
	}

// ���X�g1��̃s�{�b�g�I�����J�b�g
	diag = 1.0 / dmaget_value(addr, row+31, row+31, n);

	if(id == 2){
		ch++;
	}

	for(i=ch;i*NUMBER_OF_SPES+q<n;i++){
		bufz[i][31] *= diag;
		dmaput((void*)bufz[i], p2+dp*(i*NUMBER_OF_SPES+q), 128);
	}

//spe_lu_block32

	mfc_get(buf[0], p1+dp*row, 128*di, 6, 0, 0);

    mfc_get(bufa[0], p2+dp*(row+1), 128, 5, 0, 0);

    mfc_get(buf[1], p1+dp*(row+1), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 6);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 5);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[2], p1+dp*(row+2), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+2), 128, 0, 0, 0);

	mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[1][k] =
 				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), *(vector float*)&buf[1][k]);
	}

	mfc_put(buf[1], p1+dp*(row+1), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[3], p1+dp*(row+3), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+3), 128   , 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[2][k] =
 				spu_nmsub(*(vector float*)&buf[1][k] ,spu_splats((float)bufa[1][1]) ,spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), *(vector float*)&buf[2][k]));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[2], p1+dp*(row+2), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[4], p1+dp*(row+4), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+4), 128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[3][k] =
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[3][k])));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[3], p1+dp*(row+3), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[5], p1+dp*(row+5), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+5), 128   , 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[4][k] =
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
				*(vector float*)&buf[4][k]))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[4], p1+dp*(row+4), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[6], p1+dp*(row+6), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+6), 128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[5][k] =
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[5][k])))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[5], p1+dp*(row+5), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[7], p1+dp*(row+7), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+7), 128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[6][k] =
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
				*(vector float*)&buf[6][k]))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[6], p1+dp*(row+6), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[8], p1+dp*(row+8), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+8), 128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[7][k] =
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[7][k])))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[7], p1+dp*(row+7), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[9], p1+dp*(row+9), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+9),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[8][k] =
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
				*(vector float*)&buf[8][k]))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[8], p1+dp*(row+8), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[10], p1+dp*(row+10), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+10),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[9][k] =
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[9][k])))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[9], p1+dp*(row+9), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[11], p1+dp*(row+11), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+11),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[10][k] =
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
				*(vector float*)&buf[10][k]))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[10], p1+dp*(row+10), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[12], p1+dp*(row+12), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+12),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[11][k] =
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[11][k])))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[11], p1+dp*(row+11), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[13], p1+dp*(row+13), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+13),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
		*(vector float*)&buf[12][k] =
			spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[1][11]),
			spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[1][10]),
			spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[1][9]),
			spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[1][8]),
			spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[1][7]),
			spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[1][6]),
			spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
			spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
			spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
			spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
			spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
			spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
			*(vector float*)&buf[12][k]))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[12], p1+dp*(row+12), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[14], p1+dp*(row+14), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+14),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[13][k] =
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[13][k])))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[13], p1+dp*(row+13), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[15], p1+dp*(row+15), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+15),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[14][k] =
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
				*(vector float*)&buf[14][k]))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[14], p1+dp*(row+14), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[16], p1+dp*(row+16), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+16),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[15][k] =
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[15][k])))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[15], p1+dp*(row+15), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[17], p1+dp*(row+17), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+17),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[16][k] =
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
				*(vector float*)&buf[16][k]))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[16], p1+dp*(row+16), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[18], p1+dp*(row+18), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+18),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[17][k] =
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[17][k])))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[17], p1+dp*(row+17), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[19], p1+dp*(row+19), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+19),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[18][k] =
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
				*(vector float*)&buf[18][k]))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[18], p1+dp*(row+18), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[20], p1+dp*(row+20), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+20),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[19][k] =
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[19][k])))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[19], p1+dp*(row+19), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[21], p1+dp*(row+21), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+21),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[20][k] =
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[1][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[1][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
				*(vector float*)&buf[20][k]))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[20], p1+dp*(row+20), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[22], p1+dp*(row+22), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+22),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[21][k] =
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[0][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[0][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[21][k])))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[21], p1+dp*(row+21), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[23], p1+dp*(row+23), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+23),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[22][k] =
			    spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufa[1][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[1][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[1][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[1][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
				*(vector float*)&buf[22][k]))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[22], p1+dp*(row+22), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[24], p1+dp*(row+24), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+24),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[23][k] =
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufa[0][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufa[0][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[0][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[0][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[23][k])))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[23], p1+dp*(row+23), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[25], p1+dp*(row+25), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+25),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[24][k] =
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufa[1][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufa[1][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufa[1][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[1][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[1][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[1][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
				*(vector float*)&buf[24][k]))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[24], p1+dp*(row+24), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[26], p1+dp*(row+26), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+26),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[25][k] =
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufa[0][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufa[0][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufa[0][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufa[0][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[0][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[0][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[25][k])))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[25], p1+dp*(row+25), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[27], p1+dp*(row+27), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+27),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[26][k] =
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufa[1][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufa[1][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufa[1][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufa[1][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufa[1][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[1][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[1][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[1][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
				*(vector float*)&buf[26][k]))))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[26], p1+dp*(row+26), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[28], p1+dp*(row+28), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+28),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[27][k] =
				spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufa[0][26]),
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufa[0][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufa[0][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufa[0][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufa[0][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufa[0][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[0][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[0][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[27][k])))))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[27], p1+dp*(row+27), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[29], p1+dp*(row+29), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+29),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[28][k] =
				spu_nmsub(*(vector float*)&buf[27][k], spu_splats((float)bufa[1][27]),
				spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufa[1][26]),
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufa[1][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufa[1][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufa[1][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufa[1][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufa[1][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[1][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[1][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[1][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
				*(vector float*)&buf[28][k]))))))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[28], p1+dp*(row+28), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[30], p1+dp*(row+30), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+30),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[29][k] =
				spu_nmsub(*(vector float*)&buf[28][k], spu_splats((float)bufa[0][28]),
				spu_nmsub(*(vector float*)&buf[27][k], spu_splats((float)bufa[0][27]),
				spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufa[0][26]),
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufa[0][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufa[0][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufa[0][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufa[0][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufa[0][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[0][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[0][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[29][k])))))))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[29], p1+dp*(row+29), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(buf[31], p1+dp*(row+31), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(row+31),  128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[30][k] =
				spu_nmsub(*(vector float*)&buf[29][k], spu_splats((float)bufa[1][29]),
				spu_nmsub(*(vector float*)&buf[28][k], spu_splats((float)bufa[1][28]),
				spu_nmsub(*(vector float*)&buf[27][k], spu_splats((float)bufa[1][27]),
				spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufa[1][26]),
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufa[1][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufa[1][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufa[1][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufa[1][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufa[1][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[1][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[1][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[1][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
				*(vector float*)&buf[30][k]))))))))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[30], p1+dp*(row+30), 128*di, 4, 0, 0);

    mfc_write_tag_mask(1 << 0);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_write_tag_mask(1 << 2);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

    mfc_get(bufb[0], p1+dp*(row+32), 128*di, 2, 0, 0);
	mfc_get(bufa[1], p2+dp*(row+32),    128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
			*(vector float*)&buf[31][k] =
				spu_nmsub(*(vector float*)&buf[30][k], spu_splats((float)bufa[0][30]),
				spu_nmsub(*(vector float*)&buf[29][k], spu_splats((float)bufa[0][29]),
				spu_nmsub(*(vector float*)&buf[28][k], spu_splats((float)bufa[0][28]),
				spu_nmsub(*(vector float*)&buf[27][k], spu_splats((float)bufa[0][27]),
				spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufa[0][26]),
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufa[0][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufa[0][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufa[0][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufa[0][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufa[0][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[0][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[0][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&buf[31][k])))))))))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[31], p1+dp*(row+31), 128*di, 4, 0, 0);

	for(j=row+32;j<n-2;j+=2){

		mfc_write_tag_mask(1 << 0);
		mfc_write_tag_update_all();
		mfc_read_tag_status();

		mfc_write_tag_mask(1 << 2);
		mfc_write_tag_update_all();
		mfc_read_tag_status();

		mfc_write_tag_mask(1 << 4);
		mfc_write_tag_update_all();
		mfc_read_tag_status();

		mfc_get(bufb[1], p1+dp*(j+1), 128*di, 2, 0, 0);
		mfc_get(bufa[0], p2+dp*(j+1),    128, 0, 0, 0);

		for(k=0;k<32*di;k+=4){
			*(vector float*)&bufb[0][k] =
				spu_nmsub(*(vector float*)&buf[31][k], spu_splats((float)bufa[1][31]),
				spu_nmsub(*(vector float*)&buf[30][k], spu_splats((float)bufa[1][30]),
				spu_nmsub(*(vector float*)&buf[29][k], spu_splats((float)bufa[1][29]),
				spu_nmsub(*(vector float*)&buf[28][k], spu_splats((float)bufa[1][28]),
				spu_nmsub(*(vector float*)&buf[27][k], spu_splats((float)bufa[1][27]),
				spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufa[1][26]),
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufa[1][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufa[1][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufa[1][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufa[1][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufa[1][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[1][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[1][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[1][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
				*(vector float*)&bufb[0][k]))))))))))))))))))))))))))))))));
		}

		mfc_put(bufb[0], p1+dp*j, 128*di, 4, 0, 0);

		mfc_write_tag_mask(1 << 0);
		mfc_write_tag_update_all();
		mfc_read_tag_status();
	
		mfc_write_tag_mask(1 << 2);
		mfc_write_tag_update_all();
		mfc_read_tag_status();

		mfc_write_tag_mask(1 << 4);
		mfc_write_tag_update_all();
		mfc_read_tag_status();

		mfc_get(bufb[0], p1+dp*(j+2), 128*di, 2, 0, 0);
		mfc_get(bufa[1], p2+dp*(j+2),    128, 0, 0, 0);

		for(k=0;k<32*di;k+=4){
			*(vector float*)&bufb[1][k] =
				spu_nmsub(*(vector float*)&buf[31][k], spu_splats((float)bufa[0][31]),
				spu_nmsub(*(vector float*)&buf[30][k], spu_splats((float)bufa[0][30]),
				spu_nmsub(*(vector float*)&buf[29][k], spu_splats((float)bufa[0][29]),
				spu_nmsub(*(vector float*)&buf[28][k], spu_splats((float)bufa[0][28]),
				spu_nmsub(*(vector float*)&buf[27][k], spu_splats((float)bufa[0][27]),
				spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufa[0][26]),
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufa[0][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufa[0][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufa[0][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufa[0][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufa[0][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[0][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[0][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
				*(vector float*)&bufb[1][k]))))))))))))))))))))))))))))))));
		}

		mfc_put(bufb[1], p1+dp*(j+1), 128*di, 4, 0, 0);
	}

	mfc_write_tag_mask(1 << 0);
	mfc_write_tag_update_all();
	mfc_read_tag_status();

	mfc_write_tag_mask(1 << 2);
	mfc_write_tag_update_all();
	mfc_read_tag_status();

	mfc_write_tag_mask(1 << 4);
	mfc_write_tag_update_all();
	mfc_read_tag_status();

	mfc_get(bufb[1], p1+dp*(n-1), 128*di, 2, 0, 0);
	mfc_get(bufa[0], p2+dp*(n-1),    128, 0, 0, 0);

	for(k=0;k<32*di;k+=4){
		*(vector float*)&bufb[0][k] =
			spu_nmsub(*(vector float*)&buf[31][k], spu_splats((float)bufa[1][31]),
			spu_nmsub(*(vector float*)&buf[30][k], spu_splats((float)bufa[1][30]),
			spu_nmsub(*(vector float*)&buf[29][k], spu_splats((float)bufa[1][29]),
			spu_nmsub(*(vector float*)&buf[28][k], spu_splats((float)bufa[1][28]),
			spu_nmsub(*(vector float*)&buf[27][k], spu_splats((float)bufa[1][27]),
			spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufa[1][26]),
			spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufa[1][25]),
			spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufa[1][24]),
			spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufa[1][23]),
			spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufa[1][22]),
			spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufa[1][21]), 
			spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[1][20]),
			spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[1][19]),
			spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[1][18]),
			spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[1][17]),
			spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[1][16]),
			spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[1][15]),
			spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[1][14]),
			spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[1][13]), 
			spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[1][12]), 
			spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[1][11]),
			spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[1][10]),
			spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[1][9]),
			spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[1][8]),
			spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[1][7]),
			spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[1][6]),
			spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[1][5]),
			spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[1][4]),
			spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[1][3]),
			spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[1][2]),
			spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[1][1]),
			spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[1][0]), 
			*(vector float*)&bufb[0][k]))))))))))))))))))))))))))))))));
	}

	mfc_put(bufb[0], p1+dp*(n-2), 128*di, 4, 0, 0);

	mfc_write_tag_mask(1 << 0);
	mfc_write_tag_update_all();
	mfc_read_tag_status();

	mfc_write_tag_mask(1 << 2);
	mfc_write_tag_update_all();
	mfc_read_tag_status();

	for(k=0;k<32*di;k+=4){
		*(vector float*)&bufb[1][k] =
			spu_nmsub(*(vector float*)&buf[31][k], spu_splats((float)bufa[0][31]),
			spu_nmsub(*(vector float*)&buf[30][k], spu_splats((float)bufa[0][30]),
			spu_nmsub(*(vector float*)&buf[29][k], spu_splats((float)bufa[0][29]),
			spu_nmsub(*(vector float*)&buf[28][k], spu_splats((float)bufa[0][28]),
			spu_nmsub(*(vector float*)&buf[27][k], spu_splats((float)bufa[0][27]),
			spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufa[0][26]),
			spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufa[0][25]),
			spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufa[0][24]),
			spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufa[0][23]),
			spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufa[0][22]),
			spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufa[0][21]), 
			spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufa[0][20]),
			spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufa[0][19]),
			spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufa[0][18]),
			spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufa[0][17]),
			spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufa[0][16]),
			spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufa[0][15]),
			spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufa[0][14]),
			spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufa[0][13]), 
			spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufa[0][12]), 
			spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufa[0][11]),
			spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufa[0][10]),
			spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufa[0][9]),
			spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufa[0][8]),
			spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufa[0][7]),
			spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufa[0][6]),
			spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufa[0][5]),
			spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufa[0][4]),
			spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufa[0][3]),
			spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufa[0][2]),
			spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufa[0][1]),
			spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufa[0][0]), 
			*(vector float*)&bufb[1][k]))))))))))))))))))))))))))))))));
	}

	mfc_put(bufb[1], p1+dp*(n-1), 128*di, 0, 0, 0);
	
	mfc_write_tag_mask(1 << 4);
	mfc_write_tag_update_all();
	mfc_read_tag_status();

	mfc_write_tag_mask(1 << 0);
	mfc_write_tag_update_all();
	mfc_read_tag_status();
}

void f_and_b_substitution_4(unsigned int ppe_a, unsigned int ppe_b, unsigned int ppe_x, unsigned int idx, unsigned int n){
    int i,j;
	vector float temp  = {0.0, 0.0, 0.0, 0.0};
	vector float temp2 = {0.0, 0.0, 0.0, 0.0};
	
	dmaget((void*)bufy[0], ppe_b+n*sizeof(float)*idx,     4*n);
	dmaget((void*)bufy[1], ppe_b+n*sizeof(float)*(idx+1), 4*n);
	dmaget((void*)bufy[2], ppe_b+n*sizeof(float)*(idx+2), 4*n);
	dmaget((void*)bufy[3], ppe_b+n*sizeof(float)*(idx+3), 4*n);

	mfc_get(bufx[1], ppe_a+n*sizeof(float),128, 0, 0, 0);

    for(i=1;i<n-1;i++){
		temp = spu_insert(bufy[0][i], temp, 0);
		temp = spu_insert(bufy[1][i], temp, 1);
		temp = spu_insert(bufy[2][i], temp, 2);
		temp = spu_insert(bufy[3][i], temp, 3);

		mfc_write_tag_mask(1 << 0);
		mfc_write_tag_update_all();
		mfc_read_tag_status();
		
		mfc_get(bufx[(i+1)%2], ppe_a+n*sizeof(float)*(i+1), 128*(((i+1)/32)+1), 0, 0, 0);

		for(j=0;j<i;j++){
			temp2 = spu_insert(bufy[0][j], temp2, 0);
			temp2 = spu_insert(bufy[1][j], temp2, 1);
			temp2 = spu_insert(bufy[2][j], temp2, 2);
			temp2 = spu_insert(bufy[3][j], temp2, 3);
			temp = spu_nmsub(spu_splats((float)bufx[i%2][j]), temp2, temp);
		}
		bufy[0][i] = spu_extract(temp,0);
		bufy[1][i] = spu_extract(temp,1);
		bufy[2][i] = spu_extract(temp,2);
		bufy[3][i] = spu_extract(temp,3);
	}

	temp = spu_insert(bufy[0][n-1], temp, 0);
	temp = spu_insert(bufy[1][n-1], temp, 1);
	temp = spu_insert(bufy[2][n-1], temp, 2);
	temp = spu_insert(bufy[3][n-1], temp, 3);

	mfc_write_tag_mask(1 << 0);
	mfc_write_tag_update_all();
	mfc_read_tag_status();	

	for(j=0;j<n-1;j++){
		temp2 = spu_insert(bufy[0][j], temp2, 0);
		temp2 = spu_insert(bufy[1][j], temp2, 1);
		temp2 = spu_insert(bufy[2][j], temp2, 2);
		temp2 = spu_insert(bufy[3][j], temp2, 3);
		temp = spu_nmsub(spu_splats((float)bufx[1][j]), temp2, temp);
	}

	bufy[0][n-1] = spu_extract(temp,0);
	bufy[1][n-1] = spu_extract(temp,1);
	bufy[2][n-1] = spu_extract(temp,2);
	bufy[3][n-1] = spu_extract(temp,3);

	bufy[0][n-1] /= bufx[1][n-1];
	bufy[1][n-1] /= bufx[1][n-1];
	bufy[2][n-1] /= bufx[1][n-1];
	bufy[3][n-1] /= bufx[1][n-1];

	for(i=n-2;i>0;i--){
		temp = spu_insert(bufy[0][i], temp, 0);
		temp = spu_insert(bufy[1][i], temp, 1);
		temp = spu_insert(bufy[2][i], temp, 2);
		temp = spu_insert(bufy[3][i], temp, 3);

		mfc_write_tag_mask(1 << 0);
		mfc_write_tag_update_all();
		mfc_read_tag_status();

		mfc_get(bufx[(i-1)%2], ppe_a+n*sizeof(float)*(i-1), 4*n, 0, 0, 0);

		for(j=i+1;j<n;j++){
			temp2 = spu_insert(bufy[0][j], temp2, 0);
			temp2 = spu_insert(bufy[1][j], temp2, 1);
			temp2 = spu_insert(bufy[2][j], temp2, 2);
			temp2 = spu_insert(bufy[3][j], temp2, 3);
			temp = spu_nmsub(spu_splats((float)bufx[i%2][j]), temp2, temp);
		}
		bufy[0][i] = spu_extract(temp,0) / bufx[i%2][i];
		bufy[1][i] = spu_extract(temp,1) / bufx[i%2][i];
		bufy[2][i] = spu_extract(temp,2) / bufx[i%2][i];
		bufy[3][i] = spu_extract(temp,3) / bufx[i%2][i];
	}

	temp = spu_insert(bufy[0][0], temp, 0);
	temp = spu_insert(bufy[1][0], temp, 1);
	temp = spu_insert(bufy[2][0], temp, 2);
	temp = spu_insert(bufy[3][0], temp, 3);

	mfc_write_tag_mask(1 << 0);
	mfc_write_tag_update_all();
	mfc_read_tag_status();

	for(j=1;j<n;j++){
		temp2 = spu_insert(bufy[0][j], temp2, 0);
		temp2 = spu_insert(bufy[1][j], temp2, 1);
		temp2 = spu_insert(bufy[2][j], temp2, 2);
		temp2 = spu_insert(bufy[3][j], temp2, 3);
		temp = spu_nmsub(spu_splats((float)bufx[0][j]), temp2, temp);
	}

	bufy[0][0] = spu_extract(temp,0) / bufx[0][0];
	bufy[1][0] = spu_extract(temp,1) / bufx[0][0];
	bufy[2][0] = spu_extract(temp,2) / bufx[0][0];
	bufy[3][0] = spu_extract(temp,3) / bufx[0][0];

	dmaput((void*)bufy[0], ppe_x+n*sizeof(float)*idx,     4*n);
	dmaput((void*)bufy[1], ppe_x+n*sizeof(float)*(idx+1), 4*n);
	dmaput((void*)bufy[2], ppe_x+n*sizeof(float)*(idx+2), 4*n);
	dmaput((void*)bufy[3], ppe_x+n*sizeof(float)*(idx+3), 4*n);
}


void f_and_b_substitution(unsigned int ppe_a, unsigned int ppe_b, unsigned int ppe_x, unsigned int idx, unsigned int n){
    int i,j;
	vector float temp  = {0.0, 0.0, 0.0, 0.0};

	dmaget((void*)bufx[0], ppe_b+n*sizeof(float)*idx,4*n);

	dmaget((void*)bufy[1], ppe_a+n*sizeof(float), 4*n);
	dmaget((void*)bufy[2], ppe_a+n*sizeof(float)*2, 4*n);
	dmaget((void*)bufy[3], ppe_a+n*sizeof(float)*3, 4*n);

	bufx[0][1] -= bufy[1][0] * bufx[0][0];
	bufx[0][2] -= bufy[2][0] * bufx[0][0] + bufy[2][1] * bufx[0][1];
	bufx[0][3] -= bufy[3][0] * bufx[0][0] + bufy[3][1] * bufx[0][1] + bufy[3][2] * bufx[0][2];

    for(i=4;i<n;i+=4){
		dmaget((void*)bufy[0], ppe_a+n*sizeof(float)*i    , 128*((i/32)+1));
		dmaget((void*)bufy[1], ppe_a+n*sizeof(float)*(i+1), 128*((i/32)+1));
		dmaget((void*)bufy[2], ppe_a+n*sizeof(float)*(i+2), 128*((i/32)+1));
		dmaget((void*)bufy[3], ppe_a+n*sizeof(float)*(i+3), 128*((i/32)+1));

        for(j=0;j<i;j++){
			temp = spu_insert(bufy[0][j], temp, 0);
			temp = spu_insert(bufy[1][j], temp, 1);
			temp = spu_insert(bufy[2][j], temp, 2);
			temp = spu_insert(bufy[3][j], temp, 3);
			*(vector float*)&bufx[0][i] = spu_nmsub(temp, spu_splats((float)bufx[0][j]), *(vector float*)&bufx[0][i]);
        }

		temp = spu_insert(0.0      , temp, 0);
		temp = spu_insert(bufy[1][i], temp, 1);
		temp = spu_insert(bufy[2][i], temp, 2);
		temp = spu_insert(bufy[3][i], temp, 3);
		*(vector float*)&bufx[0][i] = spu_nmsub(temp, spu_splats((float)bufx[0][i]), *(vector float*)&bufx[0][i]);

		bufx[0][i+2] -= bufy[2][i+1] * bufx[0][i+1];
		bufx[0][i+3] -= bufy[3][i+1] * bufx[0][i+1] + bufy[3][i+2] * bufx[0][i+2];
	}

	bufx[0][n-1] /= bufy[3][n-1];

	temp = spu_insert(bufy[0][n-1], temp, 0);
	temp = spu_insert(bufy[1][n-1], temp, 1);
	temp = spu_insert(bufy[2][n-1], temp, 2);
	temp = spu_insert(0.0        , temp, 3);

	*(vector float*)&bufx[0][n-4] = spu_nmsub(temp, spu_splats((float)bufx[0][n-1]), *(vector float*)&bufx[0][n-4]);

	bufx[0][n-2] /= bufy[2][n-2];
	bufx[0][n-3] -= bufy[1][n-2] * bufx[0][n-2];
	bufx[0][n-3] /= bufy[1][n-3];
	bufx[0][n-4] -= bufy[0][n-2] * bufx[0][n-2] + bufy[0][n-3] * bufx[0][n-3];
	bufx[0][n-4] /= bufy[0][n-4];

	for(i=n-8;i>=0;i=i-4){
		dmaget((void*)bufy[0], ppe_a+n*sizeof(float)* i   , 4*n);
		dmaget((void*)bufy[1], ppe_a+n*sizeof(float)*(i+1), 4*n);
		dmaget((void*)bufy[2], ppe_a+n*sizeof(float)*(i+2), 4*n);
		dmaget((void*)bufy[3], ppe_a+n*sizeof(float)*(i+3), 4*n);
		for(j=i+4;j<n;j++){
			temp = spu_insert(bufy[0][j], temp, 0);
			temp = spu_insert(bufy[1][j], temp, 1);
			temp = spu_insert(bufy[2][j], temp, 2);
			temp = spu_insert(bufy[3][j], temp, 3);
			*(vector float*)&bufx[0][i] = spu_nmsub(temp, spu_splats((float)bufx[0][j]), *(vector float*)&bufx[0][i]);
		}
		bufx[0][i+3] /= bufy[3][i+3];
    	temp = spu_insert(bufy[0][i+3], temp, 0);
	    temp = spu_insert(bufy[1][i+3], temp, 1);
    	temp = spu_insert(bufy[2][i+3], temp, 2);
	    temp = spu_insert(0.0        , temp, 3);
    	*(vector float*)&bufx[0][i] = spu_nmsub(temp, spu_splats((float)bufx[0][i+3]), *(vector float*)&bufx[0][i]);
		bufx[0][i+2] /= bufy[2][i+2];
		bufx[0][i+1] -= bufy[1][i+2] * bufx[0][i+2];
		bufx[0][i+1] /= bufy[1][i+1];
		bufx[0][i]   -= bufy[0][i+2] * bufx[0][i+2] + bufy[0][i+1] * bufx[0][i+1];
		bufx[0][i]   /= bufy[0][i];
	}
	dmaput((void*)bufx[0],ppe_x+n*sizeof(float)*idx,4*n);
}

/*
void f_and_b_substitution2(unsigned int ppe_a, unsigned int ppe_b, unsigned int ppe_x, unsigned int idx, unsigned int n){
    int i,j;
    volatile static float buf1[3232] _GALIGN;
    volatile static float buf2[3232] _GALIGN;
	
	dmaget((void*)buf2, ppe_b+n*sizeof(float)*idx,4*n);

    for(i=1;i<n;i++){
		dmaget((void*)buf1, ppe_a+n*sizeof(float)*i,4*n);
        for(j=0;j<i;j++){
            buf2[i] -= buf1[j] * buf2[j];
        }
    }

	buf2[n-1] /= buf1[n-1];
	for(i=n-2;i>=0;i--){
		dmaget((void*)buf1, ppe_a+n*sizeof(float)*i,4*n);
		for(j=i+1;j<n;j++){
			buf2[i] -= buf1[j] * buf2[j];
		}
		buf2[i] /= buf1[i];
	}

	dmaput((void*)buf2,ppe_x+n*sizeof(float)*idx,4*n);
}

void f_and_b_substitution3(unsigned int ppe_a, unsigned int ppe_b, unsigned int ppe_x, unsigned int idx, unsigned int n){
    int i,j;
    volatile static float buf1[3232] _GALIGN;
    volatile static float buf2[3232] _GALIGN;
	
	dmaget((void*)buf2, ppe_b+n*sizeof(float)*idx,4*n);

    for(i=1;i<n;i++){
		dmaget((void*)buf1, ppe_a+n*sizeof(float)*i,4*n);
        for(j=0;j<(i/4)*4;j+=4){
			temp = spu_madd(*(vector float*)&buf1[j], *(vector float*)&buf2[j], temp);
        }
		buf2[i] -= spu_extract(temp,0) + spu_extract(temp,1) + spu_extract(temp,2) + spu_extract(temp,3);
		for(j=(i/4)*4;j<i;j++);
		buf2[i] -= buf1[j] * buf2[j];
    }
//
	buf2[n-1] /= buf1[n-1];

	for(i=n-2;i>=0;i--){
		dmaget((void*)buf1, ppe_a+n*sizeof(float)*i,4*n);
		for(j=i+1;j<n;j++){
			buf2[i] -= buf1[j] * buf2[j];
		}
		buf2[i] /= buf1[i];
	}

	dmaput((void*)buf2,ppe_x+n*sizeof(float)*idx,4*n);
}
*/

void spe_soleqs(struct spe_ctrl* sc){
    int i,j;
    int n,m;
    int id;
    unsigned int ppe_a, ppe_b, ppe_x, ppe_c;

    int maxj;

    unsigned int ppe_ls[NUMBER_OF_SPES];

    unsigned int ppe_s;
    volatile static struct spe_sync ss _GALIGN;
    volatile static struct spe_sync sd[NUMBER_OF_SPES] _GALIGN;
    
    ss.flag = 0;

    n  = sc->n;
    m  = sc->m;
    id = sc->id;
    ppe_a = sc->buf;
    ppe_b = ppe_a + n * n * sizeof(float);
    ppe_x = ppe_b + n * m * sizeof(float);
    ppe_c = ppe_x + n * m * sizeof(float);
    ppe_s = ppe_c + n * m * sizeof(float);
    
    // for syncronization
    ss.flag = 0XFFFFFFFF;
    ss.addr = (unsigned int)sc->ls_addr[id] + (unsigned int)&sd[0];
    dmaput((void*)&ss, (ppe_s+128*id) , 128);

    // Get addresses for each sharing memory of SPE
    ss.flag = 0;
    for(i=0;i<NUMBER_OF_SPES;i++){
        do{
            dmaget((void*)&ss, (ppe_s+128*i), 128);
        }while(ss.flag != 0XFFFFFFFF);
        ppe_ls[i] = ss.addr;
        ss.flag = 0;
    }

    // LU decomposition

    for(i=0;i<n;i=i+block_size){
		pivoting(id, ppe_a, n, i, &maxj, ppe_ls, sd, i+3);

		if(maxj != i){
			swap_row(id, ppe_a, i, maxj, n);
			swap_col(id, ppe_b, i, maxj, n, m);

			// Syncronization : SPE[0] notates (notice starting for all SPE)

			sync_dist(id, ppe_ls, sd, i+8);
			sync_collect(id, ppe_ls, sd, i+4);
		}
        // right looking LU decomposition
		spe_lu_blocked(id, (unsigned int)ppe_a, i, n, m, ppe_ls, sd);

        // Syncronization : notates SPE[0] (notice end of the calculation)

        sync_dist(id, ppe_ls, sd, i+24);
        sync_collect(id, ppe_ls, sd, i+16);
    }

	j = (m/4)*4;

	for(i=id*4;i<j;i=i+4*NUMBER_OF_SPES){
		// forward substitution
		f_and_b_substitution_4(ppe_a, ppe_b, ppe_x, i, n);
	}

	if(j+6-id < m){
		// forward substitution
		f_and_b_substitution(ppe_a, ppe_b, ppe_x, j+6-id, n);
	}
}
