#include <iostream>
#include <iomanip>
#include "itos.h"

using std::cin;
using std::cout;
using std::endl;
using std::left;
using std::setw; 
using std::string;

int main()
{
	int i, j, max, len;
	cout << "������͂��Ă������� : " ;
	cin >> max;
	len = itos(max).size() + 1;
	for(i=1; i<=max; ++i){
		cout << setw(len) << left << i ;
		j = i * i;
		cout << setw(0) << j << endl;
	}
}
