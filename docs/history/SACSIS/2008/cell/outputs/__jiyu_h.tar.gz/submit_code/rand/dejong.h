#ifndef DEJONG_H
#define DEJONG_H

#define N_DIM_F1 3
#define N_DIM_F2 2
#define N_DIM_F3 5
#define N_DIM_F4 30
#define N_DIM_F5 2

vector float dejong_f1(vector float*x);
vector float dejong_f2(vector float*x);
vector float dejong_f3(vector float*x);
vector float dejong_f4(vector float*x);
vector float dejong_f5(vector float*x, vector float (*a)[2]);

#endif
