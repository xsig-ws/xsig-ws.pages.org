#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <spu_intrinsics.h>
#include <spu_mfcio.h>
#include "common.h"
#include "simdmath.h"
#include "dejong.h"

#define SPU_DECREMENTER_INITIAL_VALUE 0x7FFFFFFFU

#define ITE_MAX 500 //学習回数
#define P_NUM 32 //パーティクル数
#define DIM 2 //次元数
#define P_MAX 65.536 //探索空間の範囲
#define N_TRIAL 100
#define LARGE_NUMBER 10000.0
#define E_TH 0//0.999999999999999999

//学習パラメータ
#define C1 0.99
#define C2 0.99
#define OMEGA 0.9

//SFMTパラメータ
#define BLOCK_SIZE (P_NUM*DIM*2*4)

static vector unsigned int array1[BLOCK_SIZE / 4];
FILE *fp;
arg_t arg;

typedef struct particle{
  vector float x[DIM], v[DIM], p[DIM];
  vector float E, E_tmp;
}PARTICLE;


extern void init_gen_rand(uint32_t seed);
extern void fill_array32(uint32_t *array, int size);


vector unsigned int xor128();
vector float func_sin(vector float *x);


vector float func_sin(vector float *x){
  
  return sinf4(spu_splats((float)(0.5)) * x[0]);
  
} 


vector float dejong_f1(vector float *x){
  vector float tmp = spu_splats( (float)(0.0) );
  
  tmp = spu_mul(x[0],  x[0]);
  tmp = spu_madd(x[1], x[1], tmp);
  tmp = spu_madd(x[2], x[2], tmp);
  
  return tmp;
}


vector float dejong_f2(vector float *x){
  vector float tmp1 = spu_splats( (float)(0.0) );
  vector float tmp2 = spu_splats( (float)(0.0) );

  tmp1 = spu_madd(x[0], x[0], - x[1]);
  tmp1 = spu_mul(tmp1, tmp1);
  tmp2 = spu_add(spu_splats( (float)(1.0) ), - x[0]);
  tmp2 = spu_mul(tmp2, tmp2);

  return spu_madd(spu_splats( (float)(100.0)), tmp1, tmp2);
  
}


vector float dejong_f3(vector float *x){
  vector float tmp = spu_splats( (float)(0.0) );
   
  tmp += roundf4( x[0] - spu_splats((float)(0.5)) );
  tmp += roundf4( x[1] - spu_splats((float)(0.5)) );
  tmp += roundf4( x[2] - spu_splats((float)(0.5)) );
  tmp += roundf4( x[3] - spu_splats((float)(0.5)) );
  tmp += roundf4( x[4] - spu_splats((float)(0.5)) );

  return tmp;
  
}


vector float dejong_f4(vector float *x){
  int i;
  vector float tmp0 = spu_splats( (float)(0.0) ), tmp1 = spu_splats( (float)(0.0) ), tmp3 = spu_splats( (float)(0.0) ), a, b, c;
  vector unsigned int z;

  for(i = 0; i <N_DIM_F4; i+=10){
     //i
    tmp0 = spu_mul(x[i] , x[i]);
    tmp0 = spu_mul(tmp0, tmp0);
    tmp1 = spu_madd(spu_splats((float)(i+1)), tmp0, tmp1);
    //i+1
    tmp0 = spu_mul(x[i+1] , x[i+1]);
    tmp0 = spu_mul(tmp0, tmp0);
    tmp1 = spu_madd(spu_splats((float)(i+2)), tmp0, tmp1);
    //i+2
    tmp0 = spu_mul(x[i+2] , x[i+2]);
    tmp0 = spu_mul(tmp0, tmp0);
    tmp1 = spu_madd(spu_splats((float)(i+3)), tmp0, tmp1);
    //i+3
    tmp0 = spu_mul(x[i+3] , x[i+3]);
    tmp0 = spu_mul(tmp0, tmp0);
    tmp1 = spu_madd(spu_splats((float)(i+4)), tmp0, tmp1);
    //i+4
    tmp0 = spu_mul(x[i+4] , x[i+4]);
    tmp0 = spu_mul(tmp0, tmp0);
    tmp1 = spu_madd(spu_splats((float)(i+5)), tmp0, tmp1);
    //i+5
    tmp0 = spu_mul(x[i+5] , x[i+5]);
    tmp0 = spu_mul(tmp0, tmp0);
    tmp1 = spu_madd(spu_splats((float)(i+6)), tmp0, tmp1);
    //i+6
    tmp0 = spu_mul(x[i+6] , x[i+6]);
    tmp0 = spu_mul(tmp0, tmp0);
    tmp1 = spu_madd(spu_splats((float)(i+7)), tmp0, tmp1);
    //i+7
    tmp0 = spu_mul(x[i+7] , x[i+7]);
    tmp0 = spu_mul(tmp0, tmp0);
    tmp1 = spu_madd(spu_splats((float)(i+8)), tmp0, tmp1);
    //i+8
    tmp0 = spu_mul(x[i+8] , x[i+8]);
    tmp0 = spu_mul(tmp0, tmp0);
    tmp1 = spu_madd(spu_splats((float)(i+9)), tmp0, tmp1);
    //i+9
    tmp0 = spu_mul(x[i+9] , x[i+9]);
    tmp0 = spu_mul(tmp0, tmp0);
    tmp1 = spu_madd(spu_splats((float)(i+10)), tmp0, tmp1);
  }
 
  a = spu_splats((float)( 1.0 / (4294967295u - 1.0) ));
  z = xor128();
  b = spu_convtf(z, 0);
  b = a * b;
  z = xor128();
  c = spu_convtf(z, 0);
  c = a * c;
  
  tmp3 = sqrtf4( spu_splats( (float)(-2.0) ) * logf4(a)) * cosf4( spu_splats( (float)(2*M_PI)) * c );
  tmp1 += divf4(tmp3, spu_splats( (float)(155.5) ) );
  
  return tmp1;
}


vector float dejong_f5(vector float*x, vector float (*a)[2]){
  int k;
  vector float tmp1 = spu_splats((float)0.002);
  vector float tmp2 = spu_splats((float)0.0);
  vector float tmp3 = spu_splats((float)0.0);
  vector float tmp4 = spu_splats((float)0.0);
  
  for(k = 0; k < 25; k+=5){
    //k
    tmp2 = spu_splats((float)(k+1));
    tmp3 = spu_add(x[0], - a[k][0]);
    tmp4 = spu_mul(tmp3, tmp3);
    tmp4 = spu_mul(tmp3, tmp4);
    tmp2 = spu_madd(tmp4, tmp4, tmp2);
    
    tmp3 = spu_add(x[1], - a[k][1]);
    tmp4 = spu_mul(tmp3, tmp3);
    tmp4 = spu_mul(tmp3, tmp4);
    tmp2 = spu_madd(tmp4, tmp4, tmp2);
    tmp1 += divf4(spu_splats((float)(1.0)), tmp2);
    
    //k+1
    tmp2 = spu_splats((float)(k+2));
    tmp3 = spu_add(x[0], - a[k+1][0]);
    tmp4 = spu_mul(tmp3, tmp3);
    tmp4 = spu_mul(tmp3, tmp4);
    tmp2 = spu_madd(tmp4, tmp4, tmp2);

    tmp3 = spu_add(x[1], - a[k+1][1]);
    tmp4 = spu_mul(tmp3, tmp3);
    tmp4 = spu_mul(tmp3, tmp4);
    tmp2 = spu_madd(tmp4, tmp4, tmp2);
    tmp1 += divf4(spu_splats((float)(1.0)), tmp2);

    //k+2
    tmp2 = spu_splats((float)(k+3));
    tmp3 = spu_add(x[0], - a[k+2][0]);
    tmp4 = spu_mul(tmp3, tmp3);
    tmp4 = spu_mul(tmp3, tmp4);
    tmp2 = spu_madd(tmp4, tmp4, tmp2);

    tmp3 = spu_add(x[1], - a[k+2][1]);
    tmp4 = spu_mul(tmp3, tmp3);
    tmp4 = spu_mul(tmp3, tmp4);
    tmp2 = spu_madd(tmp4, tmp4, tmp2);
    tmp1 += divf4(spu_splats((float)(1.0)), tmp2);
    
    //k+3
    tmp2 = spu_splats((float)(k+4));
    tmp3 = spu_add(x[0], - a[k+3][0]);
    tmp4 = spu_mul(tmp3, tmp3);
    tmp4 = spu_mul(tmp3, tmp4);
    tmp2 = spu_madd(tmp4, tmp4, tmp2);

    tmp3 = spu_add(x[1], - a[k+3][1]);
    tmp4 = spu_mul(tmp3, tmp3);
    tmp4 = spu_mul(tmp3, tmp4);
    tmp2 = spu_madd(tmp4, tmp4, tmp2);
    tmp1 += divf4(spu_splats((float)(1.0)), tmp2);

    //k+4
    tmp2 = spu_splats((float)(k+5));
    tmp3 = spu_add(x[0], - a[k+4][0]);
    tmp4 = spu_mul(tmp3, tmp3);
    tmp4 = spu_mul(tmp3, tmp4);
    tmp2 = spu_madd(tmp4, tmp4, tmp2);

    tmp3 = spu_add(x[1], - a[k+4][1]);
    tmp4 = spu_mul(tmp3, tmp3);
    tmp4 = spu_mul(tmp3, tmp4);
    tmp2 = spu_madd(tmp4, tmp4, tmp2);
    tmp1 += divf4(spu_splats((float)(1.0)), tmp2);

  }
  return  divf4(spu_splats((float)(1.0)), tmp1);
}


vector unsigned int xor128() {
  static vector unsigned int x = (vector unsigned int){1914768229,1813631753,1066933042,123456789};
  static vector unsigned int y = (vector unsigned int){1924991794,322169939,401805720,362436069};
  static vector unsigned int z = (vector unsigned int){676781941,650659395,136964893,521288629};
  static vector unsigned int w = (vector unsigned int){1450727136,97311992,63449669,88675123};
  vector unsigned int t; 
  t = spu_xor( x, spu_sl( x, 11 ) );
  x = y;
  y = z;
  z = w;
  w = spu_xor( spu_xor( w, spu_rlmask( w, -19 ) ), spu_xor( t, spu_rlmask( t, -8 ) ) ); 
  return w;
}


//メイン
int main(void){
  
  unsigned int i, j, k, cnt = 0;
  PARTICLE P[P_NUM];
  vector float G[DIM], E_g;
  vector float R1, R2;
  vector float p_max_vf, rand_max_vf;
  vector float a, b, c, e, d, f;
  vector unsigned int z;
  vector float ITE_transition[ITE_MAX];
  vector float trial_result[N_TRIAL];
  vector float trough_f5[25][2];
  uint32_t *array32 = (uint32_t *)array1;
  int tag = 1;
  unsigned long long argv;
  unsigned int arg_addr[2];
  
  //get speid
  arg_addr[0] = spu_readch(SPU_RdInMbox);
  arg_addr[1] = spu_readch(SPU_RdInMbox);
  argv = mfc_hl2ea(arg_addr[0], arg_addr[1]);
  
  spu_mfcdma64((void*)&arg, mfc_ea2h(argv), mfc_ea2l(argv),
	       sizeof(arg), tag, MFC_GET_CMD);
  spu_writech(MFC_WrTagMask, 1 << tag);
  spu_mfcstat(MFC_TAG_UPDATE_ALL);

  init_gen_rand((unsigned int)time(NULL) / (arg.spe_id + 1) + arg.spe_id);

  spu_writech(SPU_WrDec, SPU_DECREMENTER_INITIAL_VALUE);
  unsigned int profile = spu_readch(SPU_RdDec);


  p_max_vf = spu_splats((float)(P_MAX));
  rand_max_vf = spu_splats((float)( 1.0 / (4294967295u - 1) ));
  
   
  for(i=0; i<25; i++){
    trough_f5[i][0] = spu_splats((float)(-64.0 + 32*(i%5)) );
    trough_f5[i][1] = spu_splats((float)(-64.0 + 32.0*(i/5)) );
  }
  
  for(k = 0; k < N_TRIAL; k++){
    //SFMT initialzation

    fill_array32(array32, BLOCK_SIZE);

    //パーティクルの初期化
    E_g = spu_splats((float)(LARGE_NUMBER));
    for (i = 0; i < P_NUM; i++){
      for (j = 0; j < DIM; j++){

	//positionの初期化
	P[i].x[j] = spu_mul( spu_splats((float)(2.0)), p_max_vf );
	z = array1[i * DIM * 2 + j * 2 ];
	a = spu_convtf(z, 0);
	a = spu_mul(a, rand_max_vf);
	P[i].x[j] = spu_madd( P[i].x[j], a, -p_max_vf );
	//速度の初期化
	P[i].v[j] = spu_splats((float)(0.0));
	P[i].p[j] = P[i].x[j];
	G[j] = spu_splats((float)(0.0));
	// 評価値の初期化(korekara)
	P[i].E = dejong_f5(P[i].x, trough_f5);
	P[i].p[j] = P[i].x[j];
      }
    }
    //グローバル最適値の保存
    
    for (i = 0; i < P_NUM; i++){
      for (j = 0; j < DIM; j++){
	G[j] = spu_sel(P[i].x[j], G[j], spu_cmpgt(P[i].E, E_g) );
      }
      E_g = spu_sel(P[i].E, E_g, spu_cmpgt(P[i].E, E_g) );
    }
    
    
    //最適化の開始
    cnt = 0;
    while( ((++cnt) < ITE_MAX)){// && ((spu_extract(E_g, 0) >= E_TH) || (spu_extract(E_g, 1) >= E_TH) || (spu_extract(E_g, 2) >= E_TH) || (spu_extract(E_g, 3) >= E_TH)) ){
      
      
      for (i = 0; i < P_NUM; i+=8){
	for (j = 0; j < DIM; j++){

	  //i
	  //パーティクルの更新
	  P[i].x[j] = P[i].x[j] + P[i].v[j];
	  //パーティクルのpositionのhosei
	  P[i].x[j] = spu_sel(P[i].x[j], p_max_vf, spu_cmpgt(P[i].x[j], p_max_vf));
	  P[i].x[j] = spu_sel(-p_max_vf, P[i].x[j], spu_cmpgt(P[i].x[j], -p_max_vf));

	  //i+1
	  //パーティクルの更新
	  P[i+1].x[j] = P[i+1].x[j] + P[i+1].v[j];
	  //パーティクルのpositionのhosei
	  P[i+1].x[j] = spu_sel(P[i+1].x[j], p_max_vf, spu_cmpgt(P[i+1].x[j], p_max_vf));
	  P[i+1].x[j] = spu_sel(-p_max_vf, P[i+1].x[j], spu_cmpgt(P[i+1].x[j], -p_max_vf));

	  //i+2
	  //パーティクルの更新
	  P[i+2].x[j] = P[i+2].x[j] + P[i+2].v[j];
	  //パーティクルのpositionのhosei
	  P[i+2].x[j] = spu_sel(P[i+2].x[j], p_max_vf, spu_cmpgt(P[i+2].x[j], p_max_vf));
	  P[i+2].x[j] = spu_sel(-p_max_vf, P[i+2].x[j], spu_cmpgt(P[i+2].x[j], -p_max_vf));

	  //i+3
	  //パーティクルの更新
	  P[i+3].x[j] = P[i+3].x[j] + P[i+3].v[j];
	  //パーティクルのpositionのhosei
	  P[i+3].x[j] = spu_sel(P[i+3].x[j], p_max_vf, spu_cmpgt(P[i+3].x[j], p_max_vf));
	  P[i+3].x[j] = spu_sel(-p_max_vf, P[i+3].x[j], spu_cmpgt(P[i+3].x[j], -p_max_vf));

	  //i+4
	  //パーティクルの更新
	  P[i+4].x[j] = P[i+4].x[j] + P[i+4].v[j];
	  //パーティクルのpositionのhosei
	  P[i+4].x[j] = spu_sel(P[i+4].x[j], p_max_vf, spu_cmpgt(P[i+4].x[j], p_max_vf));
	  P[i+4].x[j] = spu_sel(-p_max_vf, P[i+4].x[j], spu_cmpgt(P[i+4].x[j], -p_max_vf));

	  //i+5
	  //パーティクルの更新
	  P[i+5].x[j] = P[i+5].x[j] + P[i+5].v[j];
	  //パーティクルのpositionのhosei
	  P[i+5].x[j] = spu_sel(P[i+5].x[j], p_max_vf, spu_cmpgt(P[i+5].x[j], p_max_vf));
	  P[i+5].x[j] = spu_sel(-p_max_vf, P[i+5].x[j], spu_cmpgt(P[i+5].x[j], -p_max_vf));

	  //i+6
	  //パーティクルの更新
	  P[i+6].x[j] = P[i+6].x[j] + P[i+6].v[j];
	  //パーティクルのpositionのhosei
	  P[i+6].x[j] = spu_sel(P[i+6].x[j], p_max_vf, spu_cmpgt(P[i+6].x[j], p_max_vf));
	  P[i+6].x[j] = spu_sel(-p_max_vf, P[i+6].x[j], spu_cmpgt(P[i+6].x[j], -p_max_vf));

	  //i+7
	  //パーティクルの更新
	  P[i+7].x[j] = P[i+7].x[j] + P[i+7].v[j];
	  //パーティクルのpositionのhosei
	  P[i+7].x[j] = spu_sel(P[i+7].x[j], p_max_vf, spu_cmpgt(P[i+7].x[j], p_max_vf));
	  P[i+7].x[j] = spu_sel(-p_max_vf, P[i+7].x[j], spu_cmpgt(P[i+7].x[j], -p_max_vf));
	  
	}
      }
      
      //パーティクルの評価値計算
      for (i = 0; i < P_NUM; i+=8){
	P[i].E_tmp = dejong_f5(P[i].x, trough_f5);
	P[i+1].E_tmp = dejong_f5(P[i+1].x, trough_f5);
	P[i+2].E_tmp = dejong_f5(P[i+2].x, trough_f5);
	P[i+3].E_tmp = dejong_f5(P[i+3].x, trough_f5);
	P[i+4].E_tmp = dejong_f5(P[i+4].x, trough_f5);
	P[i+5].E_tmp = dejong_f5(P[i+5].x, trough_f5);
	P[i+6].E_tmp = dejong_f5(P[i+6].x, trough_f5);
	P[i+7].E_tmp = dejong_f5(P[i+7].x, trough_f5);
       }
      
      
      for (i = 0; i < P_NUM; i+=8){
	for (j = 0; j < DIM; j++){
	  
	  //ローカル最適値の保存
	  P[i].p[j] = spu_sel(P[i].p[j], P[i].x[j], spu_cmpgt(P[i].E, P[i].E_tmp) );
	  P[i+1].p[j] = spu_sel(P[i+1].p[j], P[i+1].x[j], spu_cmpgt(P[i+1].E, P[i+1].E_tmp) );
	  P[i+2].p[j] = spu_sel(P[i+2].p[j], P[i+2].x[j], spu_cmpgt(P[i+2].E, P[i+2].E_tmp) );
	  P[i+3].p[j] = spu_sel(P[i+3].p[j], P[i+3].x[j], spu_cmpgt(P[i+3].E, P[i+3].E_tmp) );
	  P[i+4].p[j] = spu_sel(P[i+4].p[j], P[i+4].x[j], spu_cmpgt(P[i+4].E, P[i+4].E_tmp) );
	  P[i+5].p[j] = spu_sel(P[i+5].p[j], P[i+5].x[j], spu_cmpgt(P[i+5].E, P[i+5].E_tmp) );
	  P[i+6].p[j] = spu_sel(P[i+6].p[j], P[i+6].x[j], spu_cmpgt(P[i+6].E, P[i+6].E_tmp) );
	  P[i+7].p[j] = spu_sel(P[i+7].p[j], P[i+7].x[j], spu_cmpgt(P[i+7].E, P[i+7].E_tmp) );
	}
	P[i].E = spu_sel(P[i].E, P[i].E_tmp, spu_cmpgt(P[i].E, P[i].E_tmp) );
	P[i+1].E = spu_sel(P[i+1].E, P[i+1].E_tmp, spu_cmpgt(P[i+1].E, P[i+1].E_tmp) );
	P[i+2].E = spu_sel(P[i+2].E, P[i+2].E_tmp, spu_cmpgt(P[i+2].E, P[i+2].E_tmp) );
	P[i+3].E = spu_sel(P[i+3].E, P[i+3].E_tmp, spu_cmpgt(P[i+3].E, P[i+3].E_tmp) );
	P[i+4].E = spu_sel(P[i+4].E, P[i+4].E_tmp, spu_cmpgt(P[i+4].E, P[i+4].E_tmp) );
	P[i+5].E = spu_sel(P[i+5].E, P[i+5].E_tmp, spu_cmpgt(P[i+5].E, P[i+5].E_tmp) );
	P[i+6].E = spu_sel(P[i+6].E, P[i+6].E_tmp, spu_cmpgt(P[i+6].E, P[i+6].E_tmp) );
	P[i+7].E = spu_sel(P[i+7].E, P[i+7].E_tmp, spu_cmpgt(P[i+7].E, P[i+7].E_tmp) );
      } 
      
      for (i = 0; i < P_NUM; i+=8){
	for (j = 0; j < DIM; j++){
	  //グローバル最適値の保存
	  G[j] = spu_sel(P[i].p[j], G[j], spu_cmpgt(P[i].E, E_g) );
	  G[j] = spu_sel(P[i+1].p[j], G[j], spu_cmpgt(P[i+1].E, E_g) );
	  G[j] = spu_sel(P[i+2].p[j], G[j], spu_cmpgt(P[i+2].E, E_g) );
	  G[j] = spu_sel(P[i+3].p[j], G[j], spu_cmpgt(P[i+3].E, E_g) );
	  G[j] = spu_sel(P[i+4].p[j], G[j], spu_cmpgt(P[i+4].E, E_g) );
	  G[j] = spu_sel(P[i+5].p[j], G[j], spu_cmpgt(P[i+5].E, E_g) );
	  G[j] = spu_sel(P[i+6].p[j], G[j], spu_cmpgt(P[i+6].E, E_g) );
	  G[j] = spu_sel(P[i+7].p[j], G[j], spu_cmpgt(P[i+7].E, E_g) );
	}
	E_g = spu_sel(P[i].E, E_g, spu_cmpgt(P[i].E, E_g) );
	E_g = spu_sel(P[i+1].E, E_g, spu_cmpgt(P[i+1].E, E_g) );
	E_g = spu_sel(P[i+2].E, E_g, spu_cmpgt(P[i+2].E, E_g) );
	E_g = spu_sel(P[i+3].E, E_g, spu_cmpgt(P[i+3].E, E_g) );
	E_g = spu_sel(P[i+4].E, E_g, spu_cmpgt(P[i+4].E, E_g) );
	E_g = spu_sel(P[i+5].E, E_g, spu_cmpgt(P[i+5].E, E_g) );
	E_g = spu_sel(P[i+6].E, E_g, spu_cmpgt(P[i+6].E, E_g) );
	E_g = spu_sel(P[i+7].E, E_g, spu_cmpgt(P[i+7].E, E_g) );
       }

      fill_array32(array32, BLOCK_SIZE);
      for (i = 0; i < P_NUM; i+=4){
	for (j = 0; j < DIM; j++){
	  //パーティクルの速度の更新
	  //i
	  z = array1[i * DIM * 2 + j * 2 ];
	  a = spu_convtf(z, 0);
	  R1 = spu_mul(a, rand_max_vf);	
	  z = array1[i * DIM * 2 + j * 2 + 1];
	  a = spu_convtf(z, 0);
	  R2 = spu_mul(a, rand_max_vf);
 
	  a = spu_mul(spu_splats((float)(OMEGA)), P[i].v[j] );
	  b = spu_mul(R1, spu_splats((float)(C1)));
	  c = spu_add(P[i].p[j], - P[i].x[j]);
	  d = spu_madd(b, c, a);
 	  e = spu_mul(R2, spu_splats((float)(C2)));
	  f = spu_add(G[j], - P[i].x[j]);
	  P[i].v[j] = spu_madd(e, f, d);

	  //i+1
	  z = array1[(i+1) * DIM * 2 + j * 2 ];
	  a = spu_convtf(z, 0);
	  R1 = spu_mul(a, rand_max_vf);	
	  z = array1[(i+1) * DIM * 2 + j * 2 + 1];
	  a = spu_convtf(z, 0);
	  R2 = spu_mul(a, rand_max_vf);
 
	  a = spu_mul(spu_splats((float)(OMEGA)), P[i+1].v[j] );
	  b = spu_mul(R1, spu_splats((float)(C1)));
	  c = spu_add(P[i+1].p[j], - P[i+1].x[j]);
	  d = spu_madd(b, c, a);
 	  e = spu_mul(R2, spu_splats((float)(C2)));
	  f = spu_add(G[j], - P[i+1].x[j]);
	  P[i+1].v[j] = spu_madd(e, f, d);
	  
	  //i+2
	  z = array1[(i+2) * DIM * 2 + j * 2 ];
	  a = spu_convtf(z, 0);
	  R1 = spu_mul(a, rand_max_vf);	
	  z = array1[(i+2) * DIM * 2 + j * 2 + 1];
	  a = spu_convtf(z, 0);
	  R2 = spu_mul(a, rand_max_vf);
 
	  a = spu_mul(spu_splats((float)(OMEGA)), P[i+2].v[j] );
	  b = spu_mul(R1, spu_splats((float)(C1)));
	  c = spu_add(P[i+2].p[j], - P[i+2].x[j]);
	  d = spu_madd(b, c, a);
 	  e = spu_mul(R2, spu_splats((float)(C2)));
	  f = spu_add(G[j], - P[i+2].x[j]);
	  P[i+2].v[j] = spu_madd(e, f, d);
	  
	  //i+3
	  z = array1[(i+3) * DIM * 2 + j * 2 ];
	  a = spu_convtf(z, 0);
	  R1 = spu_mul(a, rand_max_vf);	
	  z = array1[(i+3) * DIM * 2 + j * 2 + 1];
	  a = spu_convtf(z, 0);
	  R2 = spu_mul(a, rand_max_vf);
 
	  a = spu_mul(spu_splats((float)(OMEGA)), P[i+3].v[j] );
	  b = spu_mul(R1, spu_splats((float)(C1)));
	  c = spu_add(P[i+3].p[j], - P[i+3].x[j]);
	  d = spu_madd(b, c, a);
 	  e = spu_mul(R2, spu_splats((float)(C2)));
	  f = spu_add(G[j], - P[i+3].x[j]);
	  P[i+3].v[j] = spu_madd(e, f, d);	  
	}
      }
      
      ITE_transition[cnt-1] = E_g;
     }
    trial_result[k] = E_g;
    //printf("%d, %.10f\n", arg.spe_id, spu_extract(trial_result[k], 0));
  }
  
  profile -= spu_readch(SPU_RdDec);
  printf("SPE time =  %f ms\n", profile / 79800000.0f * 1000.0f); 
 
  if((fp=fopen("result.dat", "w"))==NULL){
    return(0);
  }
  for(k = 0; k < N_TRIAL; k++){
  fprintf(fp, "%.10f\n", spu_extract(trial_result[k], 0));
  }
  //for(k = 0; k < cnt-1; k++){
  //fprintf(fp, "%f\n", spu_extract(ITE_transition[k], 0));
  //}
  fclose(fp);
  
  return 0;
}


