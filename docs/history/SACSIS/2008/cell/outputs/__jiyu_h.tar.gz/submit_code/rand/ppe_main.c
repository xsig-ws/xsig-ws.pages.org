#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/wait.h>
#include <pthread.h>
#include <libspe2.h>
#include "common.h"

#ifndef SPE_ELF
#define SPE_ELF "spe_main"
#endif

#define SPE_NTHREADS  6
arg_t arg[SPE_NTHREADS];

#if defined(_LP64)
# define ea_hi32(x)  ((unsigned int)((((unsigned long)(x))>>32) & 0xffffffff))
# define ea_lo32(x)  ((unsigned int)((unsigned long)(x)) & 0xffffffff)
#else /* !LP64 */
# define ea_hi32(x)  0x0
# define ea_lo32(x)  (((unsigned int)(x)) & 0xffffffff)
#endif


void *spe_thread_run(void *targ) {
    spe_stop_info_t stop_info;
    unsigned long status;
    unsigned int spe_entry = SPE_DEFAULT_ENTRY;
    spe_context_ptr_t spe_ctx = (spe_context_ptr_t)targ;

    spe_context_run(spe_ctx, &spe_entry, 0, NULL, NULL, &stop_info);

    status = ((stop_info.result.spe_exit_code & 0xff) << 8)
                | (stop_info.result.spe_signal_code & 0xff);
    return (void*)status;
}

int main(int argc, char **argv)
{
    int i, ret = 0;
    spe_program_handle_t *spe_handle = NULL;
    spe_context_ptr_t spe_ctx[SPE_NTHREADS];
    pthread_t pthreads[SPE_NTHREADS];
    int status;
    char name[BUFSIZ];
  
    
    // initialization
    for (i = 0; i < SPE_NTHREADS; i++) {
        arg[i].spe_id = i;
        snprintf(arg[i].message, sizeof(arg[i].message),
                "%s", name);
        spe_ctx[i] = NULL;
    }

    // create spe handle
    spe_handle = spe_image_open(SPE_ELF);
    if (spe_handle == NULL) {
        perror(SPE_ELF);
        ret = errno;
        goto done;
    }

    // create spe context
    for (i = 0; i < SPE_NTHREADS; i++) {
        spe_ctx[i] = spe_context_create(0, NULL);
        if (spe_ctx == NULL) {
            perror("spe_context_create");
            ret = errno;
            goto done;
        }

        // load spe
        status = spe_program_load(spe_ctx[i], spe_handle);
        if (status == -1) {
            perror("spe_program_load");
            ret = errno;
            goto done;
        }
    }

    // run
    for (i = 0; i < SPE_NTHREADS; i++) {
        pthread_create(&pthreads[i], NULL, (void*)spe_thread_run, (void*)spe_ctx[i]);
    }

    // passing argument
    for (i = 0; i < SPE_NTHREADS; i++) {
        int nwrote, left = 2;
        unsigned int arg_addr[2];
        arg_addr[0] = ea_hi32(&arg[i]);
        arg_addr[1] = ea_lo32(&arg[i]);
        while (left > 0) {
            while (spe_in_mbox_status(spe_ctx[i]) == 0);
            nwrote = spe_in_mbox_write(spe_ctx[i], &arg_addr[2 - left], left, 0);
            left -= nwrote;
        }
    }

    // wait
    for (i = 0; i < SPE_NTHREADS; i++) {
        int status;
        pthread_join(pthreads[i], (void*)&status);
        if (WIFEXITED(status)) {
	  //printf("*SPE %d exited with ret=%d\n", i, WEXITSTATUS(status));
        } else {
	  //printf("*SPE %d is terminated by signal %d\n", i, WTERMSIG(status));
        }
    }

  done:
    if (spe_handle != NULL) {
        spe_image_close(spe_handle);
    }
    for (i = 0; i < SPE_NTHREADS; i++) {
        if (spe_ctx[i] != NULL) {
            spe_context_destroy(spe_ctx[i]);
        }
    }

    return ret;
}
