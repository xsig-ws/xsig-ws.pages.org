#ifndef _CELL_TEST_COMMON_H
#define _CELL_TEST_COMMON_H

typedef struct {
    unsigned int spe_id;
    char message[64];
} __attribute__((aligned(128))) arg_t;

#endif /* _CELL_TEST_COMMON_H */
