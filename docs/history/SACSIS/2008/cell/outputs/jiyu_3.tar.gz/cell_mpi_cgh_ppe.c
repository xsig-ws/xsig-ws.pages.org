/* CGHの近似式を用いた計算。cosテーブル,MPI並列バージョン。2008.1.15。荒井 */
//コンパイル	mpicc -lspe2 -lpthread -O3 -lm cell_mpi_cgh_ppe.c
//実行			mpiexec -n 5 /project/MPI/CGH_Cell/cell_mpi3/a.out

#include <stdio.h>		 //ここで使用するヘッダファイルをインクルードする。stanDard input output　facilities(標準入出力)
#include <stdlib.h> 	 //Standard Libraly
#include <malloc.h>  	//動的メモリの確保malloc関数を使うために必要。上記stdlib.hに登録された??
#include <math.h>    	//数学的な演算を行うための関数、および関連するマクロの宣言定義。ルートや三角関数で必要。
#include <time.h>    	//時間を取得する。
#include <sys/time.h>	//システムの時間
#include <mpi.h>		//MPIを使うために必要なヘッダ
#include <libspe2.h>	//speを使うために必要なヘッダ
#include <pthread.h>	//並列処理でスレッドを使うために必要なヘッダ

#define PI			3.141592	//円周率π
#define DOTPITCH	6.5			//画素間隔。単位はnm
#define LAMBDA		0.633		//光波長。単位はnm。赤
#define SIZE_X		1920		//画像の横方向のドット数
#define SIZE_Y		1080		//画像の縦方向のドット数
//#define TENSU		4096			//物体点数調節用

/*ファイル名を変更する↓*/
#define FILENAME	"tyranno11646.3df"	//物体点ファイル。ここを書き換えるだけで扱うファイルを変えることが可能。
#define WFILENAME	"pre.bmp"			//画像ファイルの中間ファイル。	
#define WFILENAME2	"test.bmp"			//書き込む画像ファイル名。
#define FILENAME1	"object_kosuu.3d"	//物体点数を書き込むファイル。
#define FILENAME2	"object.3d"			//物体点データの中間ファイル。
#define	FILET		"time.txt"			//計算時間などを書きこむファイル。

//cell用
#define	NUM_SPE	6			//使用するSPEの個数

//変数の宣言
double		start,end,bcastime,gathertime;			//計算時間計測用。スタートとエンドの差分で計算時間を求める。
int		amountOfObjectPoint;					//物体点数。
int		nproc,rank,mystart,myend;	//mpi用変数

// CGH用宣言
typedef struct _data {
	float x;			//ここでは扱う物体点データがfloat型で、x,y,zの3方向分存在する。
	float y;
	float z;
}ObjectPointData;	//物体点データ

// 結果格納用の領域の定義
static unsigned char	result[SIZE_X*SIZE_Y] __attribute__((aligned(128)));	//結果格納用。ビットマップのサイズ分あればよい。
static unsigned char	result2[SIZE_X*SIZE_Y]={0};							//一つに集める時用。


// DMA転送用構造体
typedef int	KATA[32];	//int型32個分でちょうど128byteになり転送でもっとも効率が良くなる。

// DMA転送用パラメータ
typedef struct{
	int	nproc;					//プロセッサの数。MPIによっていくつのノードを使うか。
	int	mystart;				//計算開始のy座標の値
	int	myend;					//計算終了のy座標の値
	int	size_y;					//作るビットマップファイルのy(縦)方向のサイズ。
	int	spe;					//一つのノードが使うspeの個数。
	int	rank;					//MPIによって割り当てた番号。
	int	amountOfObjectPoint;	//物体点数
	int	speNum;					//speの番号
	KATA	*dataPos;				//ポインタdataPos。これはKATA型。
	KATA	*resultPos;				//ポインタresultPos。これもKATA型。
	char	pat[] __attribute__((aligned(128)));		//バイトアラインメントを128に揃えるためのもの。
}DmaParams __attribute__((aligned(128)));				//上記の構造体をDmaParamsとして宣言。そしてバイトアラインメントを揃える。

static volatile DmaParams dmaParams[NUM_SPE] __attribute__((aligned(128)));	//構造体DmaParamsとしてdmaParamsをSPEの個数分用意しアラインメントを揃える。

// DMA転送点データ用パラメータ
typedef struct{
	float	data[30];		//x,y,zの3方向あるので、物体点データを10個分一度に送れる。
	KATA	*tag;			//ポインタtag
	int	tag2;			//tag2
}DmaTenDataParams __attribute__((aligned(128)));	//上記の構造体をDmaTenDataParamsとして宣言。アラインメントを揃える。

static volatile DmaTenDataParams dmaTenDataParams[1200] __attribute__((aligned(128)));	//構造体DmaTenDataParamsとしてdmaTenDataParamsを1200個用意する。ここでは恐竜11646点ほどの点を送りたい。つまり、3成分で34938ほど必要になる


// スレッド用struct
typedef struct{
	spe_context_ptr_t	speContext;			//speコンテキスト
	DmaParams			*dmaParams;			//ポインタdmaParams;
}ThreadArg;									//スレッドの宣言


float	sortedTenData[36000];	//物体点データを並べ替えて保存しておくための配列。これは先ほど用意したdmaTenDataParamsの30倍(x,y,z方向分*10個分)用意する。


// スレッドに実行させる作業
void *runSpeThread(void *arg){
	int	ret;									//変数retの宣言
	ThreadArg *threadArg = (ThreadArg *) arg;	
	unsigned int	entry;
	spe_stop_info_t	speStopInfo;
	
	entry = SPE_DEFAULT_ENTRY;
	ret = spe_context_run(threadArg->speContext,&entry,0,threadArg->dmaParams,NULL,&speStopInfo);	//成功時には0以上の値を返す。失敗時には-1を返しerrnoにエラーコードを設定する。
	if(ret < 0){							//もし、retが負であればコンテキストの実行エラーを表示し、NULLを返す。
		perror("spe_context_run");
		return NULL;
	}
	
	return NULL;
}

//時間計測用の関数
double gettimeofday_sec()
{
	struct timeval tv;
	gettimeofday(&tv,NULL);
	return tv.tv_sec+(double)tv.tv_usec*1e-6;
}

void endianchanger_object(){
	int	i,j,kosuu;
	char	pre[4];
	FILE	*fr;
	FILE	*fs;
	FILE	*ft;
	FILE	*fu;
	FILE	*fv;
	if((fu=fopen(FILENAME,"rb"))==NULL){		//物体点データファイルをfuに開く。そこでデータがない。もしくは開けないときはエラーメッセージを表示。
		printf("ファイルを開くことができません\n");		//エラーメッセージ
		exit(1);							//プログラムを正しい手続きで正常終了させる。
	}

	for(i=0;i<4;i++){
		fread(&pre[i],1,1,fu);
	}
	fclose(fu);

	//for(i=0;i<4;i++){
	//printf("x[%d]=%d\n",i,x[i]);
	//}

	if((fv=fopen(FILENAME1,"wb"))==NULL){
		printf("ファイルを開くことができません\n");
		exit(1);
	}
	for(i=3;i>=0;i--){
		fwrite(&pre[i],1,1,fv);
	}
	fclose(fv);
	
	if((fr=fopen(FILENAME1,"rb"))==NULL){
		printf("ファイルを開くことができません\n");
		exit(1);
	}
	fread(&kosuu,sizeof(int),1,fr);
	printf("個数は%dです。\n",kosuu);
	fclose(fr);

	if((fs=fopen(FILENAME,"rb"))==NULL){
		printf("ファイルを開くことができません\n");
		exit(1);
	}

	if((ft=fopen(FILENAME2,"wb"))==NULL){
		printf("ファイルを開くことができません\n");
		exit(1);
	}

	for(j=0;j<(3*kosuu+1);j++){
		for(i=0;i<4;i++){
			fread(&pre[i],1,1,fs);
		}
		for(i=3;i>=0;i--){
			fwrite(&pre[i],1,1,ft);
		}
	}

	fclose(fs);
	fclose(ft);

}

void make_bitmap(){
	int i,j;
	unsigned char	rgbBlue[256],rgbGreen[256],rgbRed[256],rgbReserved[256];	//ビットマップファイルのRGBテーブル用
	FILE* fp;

	/*ヘッダの値を設定*/
	unsigned short	bfType			=19778;		//ビットマップファイルの型名BM。ここでは19778が使われる。
	unsigned long		bfSize			=14;
	unsigned short	bfReserved1		=0;			//予約はない。
	unsigned short	bfReserved2		=0;
	unsigned long		bfOffBits		=1078;		//ファイルヘッダ14とインフォヘッダ40、RGB256*4の合計
	unsigned long		biSize			=40;
	long				biWidth			=SIZE_X;
	long				biHeight		=SIZE_Y;
	unsigned short	biPlanes		=1;
	unsigned short	biBitCount		=8;
	unsigned long		biCompression	=0;
	unsigned long		biSizeImage		=0;
	long				biXPelsPerMeter	=0;
	long				biYPelsPerMeter	=0;
	unsigned long		biClrUsed		=0;
	unsigned long		biClrImportant	=0;

	for (i = 0; i < 256; i++){
		rgbBlue[i]		=i;
		rgbGreen[i]		=i;
		rgbRed[i]		=i;
		rgbReserved[i]	=0;
		}

	/*ビットマップファイルに書き込む*/
	if ((fp = fopen(WFILENAME,"wb"))==NULL){
		printf("ファイルを開くことができません\n");
		exit(1);
		}

	fwrite(&bfType, sizeof(unsigned short), 1, fp);  
	fwrite(&bfSize, sizeof(unsigned long), 1, fp);
	fwrite(&bfReserved1, sizeof(unsigned short), 1, fp);
	fwrite(&bfReserved2, sizeof(unsigned short), 1, fp);
	fwrite(&bfOffBits, sizeof(unsigned long), 1, fp);
	fwrite(&biSize, sizeof(unsigned long), 1, fp);
	fwrite(&biWidth, sizeof(long), 1, fp);
	fwrite(&biHeight, sizeof(long), 1, fp);
	fwrite(&biPlanes, sizeof(unsigned short), 1, fp);
	fwrite(&biBitCount, sizeof(unsigned short), 1, fp);
	fwrite(&biCompression, sizeof(unsigned long), 1, fp);
	fwrite(&biSizeImage, sizeof(unsigned long), 1, fp);
	fwrite(&biXPelsPerMeter, sizeof(long), 1, fp);
	fwrite(&biYPelsPerMeter, sizeof(long), 1, fp);
	fwrite(&biClrUsed, sizeof(unsigned long), 1, fp);
	fwrite(&biClrImportant, sizeof(unsigned long), 1, fp);
  
	for (i = 0; i < 256; i++) {
		fwrite(&rgbBlue[i],sizeof(unsigned char),1,fp);
		fwrite(&rgbGreen[i],sizeof(unsigned char),1,fp);
		fwrite(&rgbRed[i],sizeof(unsigned char),1,fp);
		fwrite(&rgbReserved[i],sizeof(unsigned char),1,fp);
		}

	for(i=0;i<SIZE_Y*SIZE_X;i++){
		fwrite(&result2[i],sizeof(result2[i]),1,fp);
		}

	fclose(fp);
}

void endianchanger_bmp(){
	int	i;
	char	data[4];
	FILE	*fx;
	FILE	*fw;

	if((fx=fopen(WFILENAME,"rb"))==NULL){
		printf("ファイルを開くことができません1\n");
		exit(1);
	}

	if((fw=fopen(WFILENAME2,"wb"))==NULL){
		printf("ファイルを開くことができません2\n");
		exit(1);
	}

	//bfType(2byte)
	fread(&data[0],1,1,fx);
	fread(&data[1],1,1,fx);
	fwrite(&data[1],1,1,fw);
	fwrite(&data[0],1,1,fw);
	

	for(i=0;i<4;i++){			//bfSize(4)
		fread(&data[i],1,1,fx);
	}
	for(i=3;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	for(i=0;i<2;i++){			//bfReserved1(2)
		fread(&data[i],1,1,fx);
	}
	for(i=1;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	for(i=0;i<2;i++){			//bfReserved2(2)
		fread(&data[i],1,1,fx);
	}
	for(i=1;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	for(i=0;i<4;i++){			//bf0ffBits(4)
		fread(&data[i],1,1,fx);
	}
	for(i=3;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	for(i=0;i<4;i++){			//biSize(4)
		fread(&data[i],1,1,fx);
	}
	for(i=3;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	for(i=0;i<4;i++){			//biWidth(4)
		fread(&data[i],1,1,fx);
	}
	for(i=3;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	for(i=0;i<4;i++){			//biHeight(4)
		fread(&data[i],1,1,fx);
	}
	for(i=3;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	for(i=0;i<2;i++){			//biPlanes(2)
		fread(&data[i],1,1,fx);
	}
	for(i=1;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	for(i=0;i<2;i++){			//biBitCount(2)
		fread(&data[i],1,1,fx);
	}
	for(i=1;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	for(i=0;i<4;i++){			//biCompression(4)
		fread(&data[i],1,1,fx);
	}
	for(i=3;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	for(i=0;i<4;i++){			//biSizeImage(4)
		fread(&data[i],1,1,fx);
	}
	for(i=3;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	for(i=0;i<4;i++){			//biXPelsPerMeter(4)
		fread(&data[i],1,1,fx);
	}
	for(i=3;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	for(i=0;i<4;i++){			//biYPelsPerMeter(4)
		fread(&data[i],1,1,fx);
	}
	for(i=3;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	for(i=0;i<4;i++){			//biClrUsed(4)
		fread(&data[i],1,1,fx);
	}
	for(i=3;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	for(i=0;i<4;i++){			//biClrImportant(4)
		fread(&data[i],1,1,fx);
	}
	for(i=3;i>=0;i--){
		fwrite(&data[i],1,1,fw);
	}

	
	//unsigned char(1)読み込んでそのまま書き込む。
	for(i=0;i<2074624;i++){
		fread(&data[0],1,1,fx);
		fwrite(&data[0],1,1,fw);
	}

	fclose(fx);
	fclose(fw);
}

//計測時間をファイルに書き込む関数
void time_wite(void){
	int spesuu=NUM_SPE;
	FILE *ft;
	if((ft=fopen(FILET,"a"))==NULL){
		printf("ファイルを開くことができません\n");
		exit(1);
	}
	fprintf(ft,FILENAME);
	fprintf(ft,"\n");
	fprintf(ft,"rank:%d\t物体点数は%d個です。\n",rank,amountOfObjectPoint);
	fprintf(ft,"rank:%d\t計算ノード数は%dです。\n",rank,nproc);
	fprintf(ft,"rank:%d\t計算で使うSPEの数は%dです。\n",rank,spesuu);
	fprintf(ft,"rank:%d\t計算時間は%lf秒かかりました。\n",rank,end-start);
	fprintf(ft,"rank:%d\t画像データの作成に%lf秒かかりました。\n",rank,gathertime - bcastime);
	fprintf(ft,"\n");
	fclose(ft);
	return;
}


int main(int argc,char *argv[]){							//ここからメイン関数
 	int	i,j,k,kosuu,count;			//繰り返しなどで使う変数i,j,kと物体点の個数を格納する関数個数。
	char	pre[4];

	
	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD,&nproc);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	printf("rank %d: MPI initialize...ok\n",rank);

	//まず、Cellはビッグエンディアンであるので物体点データをリトルエンディアンからビッグエンディアンに変換する。
	if(rank==0){
		endianchanger_object();
	  
		FILE *fq;								//ファイルのポインタを設定
			if ((fq=fopen(FILENAME2,"rb"))==NULL){			//物体点データファイルをfqに開く。そこでデータがない。もしくは開けないときはエラーメッセージを表示。
				printf("ファイルを開くことができません\n");			//エラーメッセージ
				exit(1);							//プログラムを正しい手続きで正常終了させる。
				}
	
		/*物体点の個数を読み込む*/  
		fread(&amountOfObjectPoint,sizeof(int),1,fq);				//物体点データの個数を読み込む。引数はまず&をつけ格納する変数、そのサイズ(ここではint型のサイズ)、個数、ファイル名
		
	
//		amountOfObjectPoint=TENSU;				//データ点数調整用 
	
	
		ObjectPointData *objectPointData;
		objectPointData = (ObjectPointData*)calloc(amountOfObjectPoint,sizeof(ObjectPointData));
		if(objectPointData==NULL){
			printf("error1\n");
			return -1;
		}

		//データを読み出す
		fread(objectPointData,sizeof(float),amountOfObjectPoint*3,fq);
		fclose(fq);
	
	
	
		// データ整理
		for(i=0;i<amountOfObjectPoint/4+1;i++){
			for(j=0;j<4;j++){
				sortedTenData[(i*12)+j]=objectPointData[(i*4)+j].x*180+1300;
				sortedTenData[(i*12)+j+4]=objectPointData[(i*4)+j].y*180+2400;
				sortedTenData[(i*12)+j+8]=objectPointData[(i*4)+j].z*180+150000;
			}
		}

		//データ確認
		/*
		printf("並び替えたデータの確認\n");
		for(i=0;i<amountOfObjectPoint/4+1;i++){
			for(j=0;j<4;j++){
				printf("sortedTenData[%d]=%f\n",i*12+j,sortedTenData[i*12+j]);
				printf("sortedTenData[%d]=%f\n",i*12+j+4,sortedTenData[i*12+j+4]);
				printf("sortedTenData[%d]=%f\n",i*12+j+8,sortedTenData[i*12+j+8]);
			}
		}
		*/
	
		free(objectPointData);
		}

	if(rank==0){
		bcastime = gettimeofday_sec();
		}


	MPI_Bcast(&amountOfObjectPoint, 1, MPI_INT, 0, MPI_COMM_WORLD);
	

	printf("rank = %d \t個数は%dです\n",rank,amountOfObjectPoint);		//個数が正しく読み込めたかの確認用
	MPI_Bcast(&sortedTenData[0], amountOfObjectPoint*3, MPI_FLOAT, 0, MPI_COMM_WORLD);

	for(i=0;i<amountOfObjectPoint/10+1;i++){
		for(j=0;j<30;j++){
			dmaTenDataParams[i].data[j]=sortedTenData[(i*30)+j];
		}
		dmaTenDataParams[i].tag = &(dmaTenDataParams[i+1]);
	}

		
	mystart=(SIZE_Y/nproc)*rank;
	myend=(SIZE_Y/nproc)*(rank+1);
//	printf("rank %d: mystart=%d, myend= %d\n",rank,mystart,myend);

	for(i=0;i<NUM_SPE;i++){
		dmaParams[i].nproc=nproc;
		dmaParams[i].mystart=mystart;
		dmaParams[i].myend=myend;
		dmaParams[i].size_y=SIZE_Y;
		dmaParams[i].spe=NUM_SPE;
		dmaParams[i].rank=rank;
		dmaParams[i].amountOfObjectPoint = amountOfObjectPoint;
		dmaParams[i].speNum = i;
		dmaParams[i].resultPos = &result[0];
		dmaParams[i].dataPos = &(dmaTenDataParams[0]);
	}
	
	// spe関連宣言
	spe_program_handle_t *speProgram;
	spe_context_ptr_t speContext[NUM_SPE];
	int ret;
	pthread_t thread[NUM_SPE];
	ThreadArg threadArg[NUM_SPE];
	
	// spe起動
	speProgram = spe_image_open("mpi_fresnel_spe.elf");
	if(!speProgram){
		perror("spe_image_open");
		exit(1);
	}
	printf("spe_image_open...ok\n");

	for(i=0;i<NUM_SPE;i++){
		speContext[i] = spe_context_create(0,NULL);
		
		if(!speContext[i]){
			perror("spe_context_create");
			exit(1);
		}
		
		ret = spe_program_load(speContext[i],speProgram);
		if(ret){
			perror("spe_program_load");
			exit(1);
		}
	}
	printf("spe_context_create...ok\n");
	
		
	// speプログラム実行

	start = gettimeofday_sec();	//計算時間を計り始める
	printf("rank %d:start clock()...ok\n",rank);

	for(i=0;i<NUM_SPE;i++){
		threadArg[i].speContext = speContext[i];
		threadArg[i].dmaParams = &dmaParams[i];
		ret = pthread_create(&thread[i],NULL,runSpeThread,&threadArg[i]);
		if(ret){
			perror("pthread_create");
			exit(1);
		}
	}
	
	
	// spe停止
	for(i=0;i<NUM_SPE;i++){
		pthread_join(thread[i],NULL);
		ret = spe_context_destroy(speContext[i]);
		if(ret){
			perror("spe_context_destroy");
			exit(1);
		}
	}
	
	spe_image_close(speProgram);
	if(ret){
		perror("spe_image_close");
		exit(1);
	}
		
	end = gettimeofday_sec();	//ここまでの計算時間を計測する。

	//SPEプログラムの確認用。
	
	count = SIZE_X*SIZE_Y/nproc;
	//画像データを集める。
	MPI_Gather(&result[count*rank],count,MPI_CHAR,&result2[count*rank],count,MPI_CHAR,0,MPI_COMM_WORLD);

	if(rank==0){
		gathertime = gettimeofday_sec();
		make_bitmap();
		endianchanger_bmp();
		}
	
//	printf("rank:%d\tCLOCKS_PER_SEC = %d\n",rank,CLOCKS_PER_SEC);
	printf("rank:%d\t計算時間は%lf秒かかりました。\n",rank,end-start);		//計算所要時間の表示

	if(rank==0){
		printf("rank:%d\t画像データの作成に%lf秒かかりました。\n",rank,gathertime - bcastime);
		time_wite();
		}
		
	MPI_Finalize();
	return 0;
}
