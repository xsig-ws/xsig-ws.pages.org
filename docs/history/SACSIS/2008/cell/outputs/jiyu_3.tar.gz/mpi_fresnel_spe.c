/* cell上でmpiを用いた並列計算SPE用 2008.1.15 */
//コンパイル方法	spu-gcc -O3 -L/usr/spu/lib/ mpi_fresnel_cgh_spe.c -lsimdmath -lm -o mpi_fresnel_cgh_spe.elf

#include <stdio.h>			//スタンダードインプットアウトプットヘッダ
#include <spu_intrinsics.h>	//SIMD演算に必要なヘッダ
#include <spu_mfcio.h>		//メモリーフローコントロールのヘッダ
#include <math.h>			//計算用ヘッダ
//#include <simdmath.h>		//simdmathここでは上記のspu_intrinsics.hでOK


#define PI 3.141592		//円周率
#define XX 1314.375987	//計算上でてくる定数部分


typedef int KATA[32];	//int型を32配列分用意して新たにKATAとした


// DMA転送用パラメータ
typedef struct{
	int nproc;					//mpiによる並列数
	int mystart;				//mpiで分担したときの計算すべき行の開始位置
	int myend;					//mpiで分担したときの計算すべき行の終了位置
	int size_y;				//作るビットマップファイルの縦方向のサイズ
	int spe;					//一つのCell上で動作するSPEの個数
	int rank;					//mpiによるCellのナンバリング
	int amountOfObjectPoint;	//物体点データの個数
	int speNum;				//一つのcell上のspeの番号
	KATA *dataPos;				//物体点データのポインタ
	KATA *resultPos;			//結果のポインタ
	char pat[] __attribute__((aligned(128)));		//余ったところにアラインメントを揃えるためのデータ
}DmaParams __attribute__((aligned(128)));			//宣言したばかりの構造体にDmaParamsという名前をつける。アラインメントを揃える。DMA転送に関わるものは極力アラインメントを揃える。

static volatile DmaParams dmaParams __attribute__((aligned(128)));	//構造体DmaParamsでdmaParamsを宣言


// DMA転送点データ用パラメータ
typedef struct{
	float	data[30];		//float型で物体点データを30個。一つの物体点データはx,y,z方向の情報を持つので10点分である。
	KATA	*tag;				//KATA型でポインタtag
	int	tag2;				//int型のtag2
} DmaTenDataParams __attribute__((aligned(128)));		//上記の構造体にDmaTenParamsという名前をつける。

static volatile DmaTenDataParams dmaTenDataParams __attribute__((aligned(128)));	//構造体DmaTenParamsのdmaTenDataParamsを宣言。アラインメントを揃える。


// 結果格納用
static unsigned char result[128] __attribute__((aligned(128)));	//DMA転送するのには128バイトでアラインメントを揃えるのが一番効率が良い。


//グローバル変数の宣言と初期化
int 			I[1920] = {0};									//輝度値格納
unsigned char	theta[16] __attribute__((aligned(16)));		//thetaの値はfloatで計算していてSIMD化することによって4つ分まとめることができるので4*4。実際にはcosテーブルを用いるのでchar型にまで落とし込む。0,4,8,12番目を見れば良い。
float			data[36000] __attribute__((aligned(16)));		//物体点データ用とりあえずここでは36000個用意した。x,y,z方向のことを考えるとその1/3の12000点のデータまで格納できる。恐竜まで大丈夫。アラインメントを揃える。


// コサインテーブル
signed char	cosTable[256];	//計算の高速化のためにコサインテーブルを用いる。

//コサインテーブル作成関数
void makeCostable(void){
	int i;
	for(i=0;i<256;i++){
		cosTable[i] = (signed char)(127 * cosf((float)i * PI / 128.0));	//cosテーブルを作成する。sinedchar型(-127〜127)で一周を256等分した。
	}
}

//計算部分
void KID(int no,int amountOfObjectPoint){	//引数として、縦方向のy座標のデータと、物体点数をとる。
	int i,j;					//ループ用変数

	vector float			*vec_x,*vec_y,*vec_z;	//SIMD演算はこのポインタの使い方が肝
	vector unsigned int	*theta_p;				//thetaのポインタ
	vector float			xx,yy,ii;				//計算の途中のデータを格納する。
	vector float			PP = {XX,XX,XX,XX};		//計算途中の定数で初期化する
	vector float			nn = {no,no,no,no};		//y座標のデータで初期化
	
		
	theta_p = &(theta[0]);			//ポインタtheta_pにtheta[0]のアドレスを代入
	for(i=0;i<1920;i++){			//横方向分のループ

		ii = spu_splats((float)i);	//spu_splatsでiを4個の符号付き32ビット量データに展開したベクタデータの作成
/*
		vec_x = &(data[0]);		//vec_xにdata[0]のアドレスを代入
		vec_y = &(data[4]);		//vec_yにdata[4]のアドレスを代入SIMD演算を行うために並び替えたので4つずつ並んでいる。
		vec_z = &(data[8]);		//vec_xにdata[8]のアドレスを代入

//		printf("x = %f y= %f z = %f\n",data[0],data[4],data[8]);

		yy = spu_sub(nn,*vec_y);		//nnと*vec_yの差分を取りyyに代入
  		xx = spu_sub(ii,*vec_x);		//iiと*vec_xの差分を取りxxに代入
  		xx = spu_mul(xx,xx);		//xxの二乗をxxに代入
  		xx = spu_madd(yy,yy,xx);		//yyとyyを乗算してxxを加算しxxに代入
    
  		yy = spu_re(*vec_z);		//yyに*vec_zの逆数を代入
  		xx = spu_mul(xx,yy);		//xxにxxとyyの積を代入
    
  		xx = spu_mul(PP,xx);		//xxに定数PPとxxの積を代入
  	
  		*theta_p = (vector unsigned int)spu_convts(xx,0);	//*thta_pにxxをunsignedint型に型変換して代入
  	
  		I[i] = cosTable[(theta[3])];		//コサインテーブルを参照する。このとき、thetaの4番目theta[3]を見ることによりchar型に落とし込んでいる。cosテーブルの引数はchar型。
  		I[i] += cosTable[(theta[7])];		//4つ同時に計算しているのでthetaの値が4つ分出る。それを輝度に足していく。thetaの8番目theta[7]を見ることで二つ目のthetaをchar型にしている。
  		I[i] += cosTable[(theta[11])];		//thetaの12番目theta[11]を見ることで3つ目のtheta。
  		I[i] += cosTable[(theta[15])];		//thetaの16番目theta[15]を見ることで4つ目のtheta。
*/

		int a = dmaParams.amountOfObjectPoint/4;	//SIMD化で4点分を一度に計算するので1/4になる。ここでは物体点データで分割している。
		int b = dmaParams.amountOfObjectPoint%4;	//4で割り切れなかったあまりの分を計算する用。

		for(j=1;j<a;j++){				//物体点数分のループ。aは4で割り切れる分
			vec_x = &(data[j*12]);		//
			vec_y = &(data[j*12+4]);
			vec_z = &(data[j*12+8]);
			
			yy = spu_sub(nn,*vec_y);
			xx = spu_sub(ii,*vec_x);
			xx = spu_mul(xx,xx);
			xx = spu_madd(yy,yy,xx);
			
			yy = spu_re(*vec_z);
			xx = spu_mul(xx,yy);
			
			xx = spu_mul(PP,xx);
			
			*theta_p = (vector unsigned int) spu_convts(xx,0);	//型変換int型にしている。
			
			I[i] += cosTable[(theta[3])];		//int型の3番目を見ることでchar型として取り出す。それ以上は回転分として引くことができる。
			I[i] += cosTable[(theta[7])];
			I[i] += cosTable[(theta[11])];
			I[i] += cosTable[(theta[15])];
		}
	
		if(b != 0){					//物体点数分のループ。bは4で割り切れなかったあまり。
			vec_x = &(data[a*12]);
			vec_y = &(data[a*12+4]);
			vec_z = &(data[a*12+8]);
			
			yy = spu_sub(nn,*vec_y);
			xx = spu_sub(ii,*vec_x);
			xx = spu_mul(xx,xx);
			xx = spu_madd(yy,yy,xx);
			
			yy = spu_re(*vec_z);
			xx = spu_mul(xx,yy);
			
			xx = spu_mul(PP,xx);
				
			*theta_p = (vector unsigned int) spu_convts(xx,0);
			
			for(j=0;j<b;j++){
				I[i] += cosTable[(theta[j*4+3])];
			}
		}

	}
}


//DMA転送データの読み込み関数
void read_DMA(){
	int i,j;	//繰り返し変数
	
	
	spu_mfcdma64(&dmaTenDataParams,mfc_ea2h(dmaParams.dataPos),mfc_ea2l(dmaParams.dataPos),sizeof(DmaTenDataParams),1,MFC_GET_CMD);	//DMA転送で物体点データを読み込む。一つ目の引数はLS側のDMA転送に利用するメモリ領域の先頭アドレスLSA。第二引数はメインメモリ側の先頭アドレス上位32ビット。第三引数はメインメモリ側の先頭アドレス下位32ビット。第四引数は転送するデータのサイズをバイト数で指定。第五引数は識別用のタグ番号0〜31。第六引数は転送の方向。
	spu_writech(MFC_WrTagMask,1 << 1);		//タグ番号をMFCに伝える。
	spu_mfcstat(MFC_TAG_UPDATE_ALL);		//DMA転送のタグの更新状況を確認。
	
	//1回目
	for(i=0;i<30;i++){
		data[i] = dmaTenDataParams.data[i];	//DMA転送されたデータdmaTenDataParams.data[i]をdata[i]に代入
	}
	
	//2回目以降
	for(i=1;i<((dmaParams.amountOfObjectPoint/10)+1);i++){	//dataは配列で30用意されており、一回のDMA転送でx,y,z方向を考えると10点分ずつ転送できる。よって10で割った値に1を足したもの以下ならループする。
		spu_mfcdma64(&dmaTenDataParams,mfc_ea2h(dmaTenDataParams.tag),mfc_ea2l(dmaTenDataParams.tag),sizeof(DmaTenDataParams),1,MFC_GET_CMD);
		spu_writech(MFC_WrTagMask,1 << 1);		//タグ番号をMFCに伝える。
		spu_mfcstat(MFC_TAG_UPDATE_ALL); 		//DMA転送のタグの更新状況を確認。
		
		for(j=0;j<30;j++){
			data[(i*30)+j] = dmaTenDataParams.data[j];	//DMA転送されたデータdmaTenDataParams.data[jをdata[(i*30)+j]に代入
		}
	}
}

//DMA転送データを送り出す。
void write_DMA(int rowNum){	//引数に計算すべきy軸方向の最初の座標をとる。
	int i,j;				//繰り返し用の変数
	KATA *result_p2;		//KATA型のresult_p2にポインタを設定。
	unsigned char *re_p;	//char型の*re_p
	unsigned int *re_p2;	//int型の*re_p2
	
	re_p = &(result[0]);	//re_pにresult[0]のアドレスを代入
	re_p2 = &(I[0]);		//re_p2にI[0]のアドレスを代入
	
	for(i=0;i<15;i++){		//15*128=1920となるので1ライン分のデータを転送することができる。
		for(j=0;j<128;j++){
			*(re_p+j) = *(re_p2+j+i*128);	//結果に1バイトずつデータを入れていく。
		}
		
		result_p2 = dmaParams.resultPos + i + rowNum*15;	//result_p2にdmaParams.resultPosに行数とこのSPE番号に15をかけたものを代入。
		
		spu_mfcdma64((volatile void*) &(result[0]),mfc_ea2h(result_p2),mfc_ea2l(result_p2),sizeof(KATA),1,MFC_PUT_CMD);	//物体点データをLSからメモリへ転送。
		spu_writech(MFC_WrTagMask,1 << 1);
		spu_mfcstat(MFC_TAG_UPDATE_ALL);
	}
}


void MAP(){
	int i;
	vector signed int *I_po;
	vector unsigned int *I_upo;
	vector signed int zero = {0,0,0,0};
	
	I_po = &(I[0]);
	I_upo = &(I[0]);
	
	for(i=0;i<480;i++){				//1920÷4で480ループすればよい。SIMD化したことによってアンループしている。
		*I_upo = spu_cmpgt(*I_po,zero);		//*I_poとzeroを比較してzeroよりも大きければ対応するビットをすべて1にする。
		I_po++;
		I_upo++;
	}
}


// main関数
int main(unsigned long long spe,unsigned long long argp){
	int rowNum,i,startRowNum;
	
	// DMA転送 メモリからLSに
	spu_mfcdma64(&dmaParams,mfc_ea2h(argp),mfc_ea2l(argp),sizeof(DmaParams),1,MFC_GET_CMD);
	spu_writech(MFC_WrTagMask,1 << 1);
	spu_mfcstat(MFC_TAG_UPDATE_ALL);

//	printf("mystart = %d\t myend=%d\t nproc=%d\n",dmaParams.mystart,dmaParams.myend,dmaParams.nproc);
//	printf("amoutofobjectspe = %d\n",dmaParams.amountOfObjectPoint);
//	printf("NUM = %d¥n",dmaParams.speNum);
//	printf("rank = %d¥n",dmaParams.rank);

	read_DMA();

//	printf("data_x = %f,data_y = %f,data_z = %f¥n",data[0],data[4],data[8]);

	int	NO=dmaParams.size_y/dmaParams.spe/dmaParams.nproc;

//	printf("NO = %d¥n",NO);
	
	// 演算
	makeCostable();

//	for(i=0;i<256;i++){
//		printf("cos[%d] = %d¥n",i,cosTable[i]);
//	}
	
	startRowNum =dmaParams.mystart+NO*dmaParams.speNum;

//	printf("rank = %d speNum = %d startRowNum= %d\n",dmaParams.rank,dmaParams.speNum,startRowNum);	

	for(rowNum=startRowNum;rowNum<(startRowNum+NO);rowNum++){
		KID(rowNum,dmaParams.amountOfObjectPoint);
		MAP();
		write_DMA(rowNum);
	}
	
	
	return(0);
}
