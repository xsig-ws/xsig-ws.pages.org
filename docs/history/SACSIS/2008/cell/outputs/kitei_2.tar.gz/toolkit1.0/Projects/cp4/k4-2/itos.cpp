#include <sstream>
#include "itos.h"

using std::string;
using std::stringstream;

string itos(int n)
{
	stringstream str_s;
	str_s << n;
	return str_s.str();
}