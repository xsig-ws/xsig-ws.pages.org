/* ============================================================================
       Copyright(C) 2005-2006 TOSHIBA CORPORATION, All Rights Reserved.
                  There is NO WARRANTY for this source code.
             You can not MODIFY or COPY or RE-DISTRIBUTE this file.
 ============================================================================*/

#ifndef __SPE_UTIL_H__
#define __SPE_UTIL_H__

#include "util.h"

#define _GALIGN __attribute__((aligned(128)))
#define _LALIGN __attribute__((aligned(16)))

#endif // __SPE_UTIL_H__
