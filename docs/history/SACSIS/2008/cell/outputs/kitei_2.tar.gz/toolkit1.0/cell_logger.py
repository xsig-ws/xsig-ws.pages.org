# -*- encoding: utf-8 -*-
#!/usr/bin/env python

'''
CellLogger sample
'''

import commands, re

class CellLogger:
    def __init__(self):
        self.search_time = re.compile("^execute time:\s+(\S+)\s+usec")
	self.output_time = 0

    def analyze(self, cmd):
        out = commands.getoutput(cmd)
	print out
        for line in out.splitlines():
            match = self.search_time.search(line)
            if match:
                self.output_time = float(match.group(1))

    def get_time(self):
        return self.output_time

round_num = 3
cmd_data = 'make run1'
def test():
    sum_time = 0
    logger = CellLogger()
    for i in range(round_num):
        logger.analyze(cmd_data)
        output_time = logger.get_time()
	print 'time =', output_time
        sum_time += output_time
    print 'average time = ', float(sum_time)/round_num, 'usec'

if __name__ == '__main__':
    test()
