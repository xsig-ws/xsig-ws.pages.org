/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2008-02-05                */
/*----------------------------------------------------------------------*/
#include <spu_intrinsics.h>
#include <spelib.h>
#include <spe_stdio.h>
#include <stdlib.h>
#include <spu_mfcio.h>
#include <float.h>
#include <math.h>
#include "spe_util.h"
#include "define.h"

#define block_size 32
#define MIN(a,b) ((a)>(b))?(b):(a);

volatile static float bufx[3][3232] _GALIGN;
volatile static float bufy[2][3232] _GALIGN;
static int   buft[3232]    _GALIGN;

static int w;

//max n = 3232, /7 = 480

/*----------------------------------------------------------------------*/
struct spe_sync{
    unsigned int flag;
    unsigned int start_flag;
    unsigned int end_flag;
    unsigned int addr; // address for sd
    unsigned int pivot_flag;
    unsigned int pivot_idx;
    float        pivot_max;
    unsigned int data[25];
};

volatile static struct spe_ctrl sc _GALIGN;

extern void dmaget(void* d, unsigned long long addr, unsigned int size);
extern void dmaput(void* d, unsigned long long addr, unsigned int size);
extern void spe_time_start(struct spe_ctrl* sc,unsigned long long argv);
extern void spe_time_end(struct spe_ctrl* sc);

inline void dmawait(int tag){
	mfc_write_tag_mask(1 << tag);
    mfc_write_tag_update_all();
    mfc_read_tag_status();
}


/*----------------------------------------------------------------------*/

void swap_row(int id, unsigned int addr, unsigned int r1, unsigned int r2, unsigned int n){
    int i, di;
    unsigned int ppe_addr1;
    unsigned int ppe_addr2;

    i = (n/32)*id/NUMBER_OF_SPES;
	di = 128*((n/32)*(id+1)/NUMBER_OF_SPES - i);
	ppe_addr1 = addr + sizeof(float) * n * r1 + 128 * i;
	ppe_addr2 = addr + sizeof(float) * n * r2 + 128 * i;

	dmaget((void*)bufy[0], ppe_addr1, di);
	dmaget((void*)bufy[1], ppe_addr2, di);
	dmaput((void*)bufy[1], ppe_addr1, di);
	dmaput((void*)bufy[0], ppe_addr2, di);
}

void spe_lu_blocked(int id, unsigned int addr, int row,
				   int n, int m, 
				   unsigned int* ppe_ls, volatile struct spe_sync* sd){
    int p,q,dp;
    int i,k,j;
	int maxj;
	int key = row + 3;
	int ch;

	int di;
	int s, p1, p2, index;

    float t1;

    float diag;
    
    volatile static float buf[32][480]  _GALIGN;
	volatile static float bufz[463][32] _GALIGN;

	vector float vf[32];

	int o2, o3, o4, o5, o6, o7, o8;
	vector float out1, out2, out3, out4, out5, out6, out7, out8;

    s  =  row/32;
	p2 = addr + 128*s;
	dp = n*sizeof(float);

	mfc_get((void*)bufx[0], p2+dp*row, 128, 1, 0, 0);

	q = row + 1 + id;
	p = p2+dp*q;

	mfc_get((void*)bufz[0], p, 128, 0, 0, 0);

	p += NUMBER_OF_SPES*dp;

	ch = 0;

	o3 = MIN((s+2+(w/32)),n/32);

	index = (s+1)+(o3-(s+1))*id/NUMBER_OF_SPES;
	di    = 32*((s+1)+(o3-(s+1))*(id+1)/NUMBER_OF_SPES - index);

	p1 = addr + 128*index;
	p2 = addr + 128*s    ;

	o2 = MIN((row+31+w),n)

// first pivoting

	mfc_write_tag_mask(1 << 1);
	mfc_write_tag_update_all();
	mfc_read_tag_status();

	diag = bufx[0][0];

	maxj = row;	
	float temp = fabs(bufx[0][0]);

	for(i=0;i*NUMBER_OF_SPES+q<o2;i++){
		mfc_write_tag_mask(1 << (i&1));
		mfc_write_tag_update_all();
		mfc_read_tag_status();

		mfc_get(bufz[i+1], p, 128, (i+1)&1, 0, 0);

		p += NUMBER_OF_SPES*dp;

		if(temp < fabs(bufz[i][0])){
			maxj = i*NUMBER_OF_SPES+q;
			temp = fabs(bufz[i][0]);
		}
	}

	if(id == 0){
		for(i=1;i<NUMBER_OF_SPES;i++){
			while(sd[i].pivot_flag != key+2);
			if(sd[i].pivot_max > temp){
				maxj  = sd[i].pivot_idx;
				temp  = sd[i].pivot_max;
			}
		}	
		for(i=1;i<NUMBER_OF_SPES;i++){
			sd[i].pivot_flag = key + 8;
			sd[i].pivot_idx  = maxj;
			dmaput((void*)&sd[i],ppe_ls[i]+128*i,128);
		}
	}else{
		sd[id].pivot_flag = key+2;
		sd[id].pivot_idx  = maxj;
		sd[id].pivot_max  = temp;
		dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);

		while(sd[id].pivot_flag != key + 8) ;
		maxj = sd[id].pivot_idx;
	}

	if( row != maxj){
		swap_row(id, addr, row, maxj, n);
		buft[row] = maxj;

		if(id == 0){
			for(i=1;i<NUMBER_OF_SPES;i++){
				while(sd[i].pivot_flag != key+3);
			}
			
			for(i=1;i<NUMBER_OF_SPES;i++){
				sd[i].pivot_flag = key + 6;
				dmaput((void*)&sd[i],ppe_ls[i]+128*i,128);
			}
		}else{
			sd[id].pivot_flag = key+3;
			dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);

			while(sd[id].pivot_flag != key + 6);
		}

		if (id == (maxj-row-1)%NUMBER_OF_SPES){
			dmaget((void*)bufz[(maxj-row-1)/NUMBER_OF_SPES], p2+dp*maxj, 128);
		}
	}

	for(j=row;j<row+31;j++){
	
		dmaget((void*)bufx[0], p2+j*dp, 128);

		o4 = j&31;

		diag = 1.0 / bufx[0][o4];

		p = p2+dp*q;

		temp = 0;

		if(ch*NUMBER_OF_SPES+q <= j){
			ch++;
		}

		maxj = j + 1;

		for(i=ch;i*NUMBER_OF_SPES+q<o2;i++){
			bufz[i][o4] *= diag; 
			t1 = bufz[i][o4];
			out1 = spu_splats((float)t1);
		
			if((j+1)%4 == 0){ 
				for(k=o4+1; k<32; k+=4)
					*(vector float*)&bufz[i][k] = spu_nmsub(*(vector float*)&bufx[0][k], out1, *(vector float*)&bufz[i][k]);
			}else if((j+1)%4 == 1){
				for(k=o4; k<32; k+=4)
					*(vector float*)&bufz[i][k] = spu_nmsub(*(vector float*)&bufx[0][k], out1, *(vector float*)&bufz[i][k]);
				bufz[i][o4] = t1;
			}else if((j+1)%4 == 3){
				bufz[i][o4+1] -= bufx[0][o4+1] * t1;
				for(k=o4+2; k<32; k+=4)
					*(vector float*)&bufz[i][k] = spu_nmsub(*(vector float*)&bufx[0][k], out1, *(vector float*)&bufz[i][k]);
			}else{
				bufz[i][o4+1] -= bufx[0][o4+1] * t1;
				bufz[i][o4+2] -= bufx[0][o4+2] * t1;
				for(k=(o4)+3; k<32; k+=4)
					*(vector float*)&bufz[i][k] = spu_nmsub(*(vector float*)&bufx[0][k], out1, *(vector float*)&bufz[i][k]);
			}

			t1 = fabs(bufz[i][o4+1]);

			if(temp < t1){
				maxj = i*NUMBER_OF_SPES+q;
				temp = t1;
			}
		}
 
		if(id == (j-row)%NUMBER_OF_SPES){
			dmaput((void*)bufz[(j-row)/NUMBER_OF_SPES], p2+dp*(j+1), 128);
		}

		if (id == (maxj-row-1)%NUMBER_OF_SPES){
			dmaput((void*)bufz[(maxj-row-1)/NUMBER_OF_SPES], p2+dp*maxj, 128);
		}

		if(id == 0){
			for(i=1;i<NUMBER_OF_SPES;i++){
				while(sd[i].pivot_flag != key+2);
				if(sd[i].pivot_max > temp){
					maxj  = sd[i].pivot_idx;
					temp  = sd[i].pivot_max;
				}
			}

			for(i=1;i<NUMBER_OF_SPES;i++){
				sd[i].pivot_flag = key + 8;
				sd[i].pivot_idx  = maxj;
				dmaput((void*)&sd[i],ppe_ls[i]+128*i,128);
			}
		}else{
			sd[id].pivot_flag = key+2;
			sd[id].pivot_idx  = maxj;
			sd[id].pivot_max  = temp;
			dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);
		
			while(sd[id].pivot_flag != key + 8) ;
			maxj = sd[id].pivot_idx;
		}	

		if( j+1 != maxj){

			swap_row(id, addr, j+1, maxj, n);
			buft[j+1] = maxj;

			if(id == 0){
				for(i=1;i<NUMBER_OF_SPES;i++){
					while(sd[i].pivot_flag != key+3);
				}
			
				for(i=1;i<NUMBER_OF_SPES;i++){
					sd[i].pivot_flag = key + 6;
					dmaput((void*)&sd[i],ppe_ls[i]+128*i,128);
				}
			}else{
				sd[id].pivot_flag = key+3;
				dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);

				while(sd[id].pivot_flag != key + 6) ;
			}

			if (id == (maxj-row-1)%NUMBER_OF_SPES){
				dmaget((void*)bufz[(maxj-row-1)/NUMBER_OF_SPES], p2+dp*maxj, 128);
			}
		}
	}

//last loop

	dmaget((void*)bufx[0], p2+(row+31)*dp, 128);
	diag = 1.0 / bufx[0][31];

	if(id == 2){
		ch++;
	}

	for(i=ch;i*NUMBER_OF_SPES+q<o2;i++){
		bufz[i][31] *= diag;
		dmaput((void*)bufz[i], p2+dp*(i*NUMBER_OF_SPES+q), 128);
	}

//spe_lu_block step2

	s = MIN((n-1),row+32+2*w);

	mfc_get(buf[0], p1+dp*row, 4*di, 6, 0, 0);

    mfc_get(bufx[0], p2+dp*(row+1), 128, 5, 0, 0);

    mfc_get(buf[1], p1+dp*(row+1), 4*di, 4, 0, 0);

	dmawait(6);
    dmawait(5);

    mfc_get(buf[2], p1+dp*(row+2), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+2), 128, 0, 0, 0);

	dmawait(4);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[1][k] =
 				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), *(vector float*)&buf[1][k]);
	}

	mfc_put(buf[1], p1+dp*(row+1), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[3] , p1+dp*(row+3), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+3), 128  , 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[2][k] =
 				spu_nmsub(*(vector float*)&buf[1][k] ,spu_splats((float)bufx[1][1]) ,spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), *(vector float*)&buf[2][k]));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[2], p1+dp*(row+2), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[4], p1+dp*(row+4), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+4), 128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[3][k] =
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[3][k])));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[3], p1+dp*(row+3), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[5], p1+dp*(row+5), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+5), 128   , 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[4][k] =
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), 
				*(vector float*)&buf[4][k]))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[4], p1+dp*(row+4), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[6], p1+dp*(row+6), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+6), 128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[5][k] =
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[5][k])))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[5], p1+dp*(row+5), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[7], p1+dp*(row+7), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+7), 128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[6][k] =
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), 
				*(vector float*)&buf[6][k]))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[6], p1+dp*(row+6), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[8], p1+dp*(row+8), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+8), 128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[7][k] =
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[7][k])))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[7], p1+dp*(row+7), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[9], p1+dp*(row+9), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+9),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[8][k] =
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), 
				*(vector float*)&buf[8][k]))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[8], p1+dp*(row+8), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[10], p1+dp*(row+10), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+10),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[9][k] =
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[9][k])))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[9], p1+dp*(row+9), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[11], p1+dp*(row+11), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+11),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[10][k] =
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), 
				*(vector float*)&buf[10][k]))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[10], p1+dp*(row+10), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[12], p1+dp*(row+12), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+12),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[11][k] =
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[11][k])))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[11], p1+dp*(row+11), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[13], p1+dp*(row+13), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+13),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
		*(vector float*)&buf[12][k] =
			spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[1][11]),
			spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[1][10]),
			spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[1][9]),
			spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[1][8]),
			spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[1][7]),
			spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[1][6]),
			spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[1][5]),
			spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[1][4]),
			spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[1][3]),
			spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[1][2]),
			spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[1][1]),
			spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), 
			*(vector float*)&buf[12][k]))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[12], p1+dp*(row+12), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[14], p1+dp*(row+14), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+14),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[13][k] =
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[13][k])))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[13], p1+dp*(row+13), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[15], p1+dp*(row+15), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+15),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[14][k] =
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), 
				*(vector float*)&buf[14][k]))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[14], p1+dp*(row+14), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[16], p1+dp*(row+16), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+16),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[15][k] =
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[15][k])))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[15], p1+dp*(row+15), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[17], p1+dp*(row+17), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+17),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[16][k] =
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), 
				*(vector float*)&buf[16][k]))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[16], p1+dp*(row+16), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[18], p1+dp*(row+18), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+18),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[17][k] =
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[17][k])))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[17], p1+dp*(row+17), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[19], p1+dp*(row+19), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+19),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[18][k] =
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), 
				*(vector float*)&buf[18][k]))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[18], p1+dp*(row+18), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[20], p1+dp*(row+20), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+20),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[19][k] =
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufx[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[19][k])))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[19], p1+dp*(row+19), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[21], p1+dp*(row+21), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+21),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[20][k] =
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufx[1][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufx[1][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), 
				*(vector float*)&buf[20][k]))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[20], p1+dp*(row+20), 4*di, 4, 0, 0);

 	dmawait(0);
	dmawait(2);

    mfc_get(buf[22], p1+dp*(row+22), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+22),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[21][k] =
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufx[0][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufx[0][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufx[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[21][k])))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[21], p1+dp*(row+21), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[23], p1+dp*(row+23), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+23),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[22][k] =
			    spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufx[1][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufx[1][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufx[1][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufx[1][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), 
				*(vector float*)&buf[22][k]))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[22], p1+dp*(row+22), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[24], p1+dp*(row+24), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+24),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[23][k] =
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufx[0][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufx[0][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufx[0][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufx[0][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufx[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[23][k])))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[23], p1+dp*(row+23), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[25], p1+dp*(row+25), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+25),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[24][k] =
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufx[1][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufx[1][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufx[1][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufx[1][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufx[1][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufx[1][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), 
				*(vector float*)&buf[24][k]))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[24], p1+dp*(row+24), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[26], p1+dp*(row+26), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+26),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[25][k] =
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufx[0][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufx[0][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufx[0][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufx[0][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufx[0][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufx[0][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufx[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[25][k])))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[25], p1+dp*(row+25), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[27], p1+dp*(row+27), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+27),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[26][k] =
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufx[1][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufx[1][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufx[1][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufx[1][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufx[1][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufx[1][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufx[1][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufx[1][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), 
				*(vector float*)&buf[26][k]))))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[26], p1+dp*(row+26), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[28], p1+dp*(row+28), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+28),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[27][k] =
				spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufx[0][26]),
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufx[0][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufx[0][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufx[0][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufx[0][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufx[0][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufx[0][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufx[0][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufx[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[27][k])))))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[27], p1+dp*(row+27), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[29], p1+dp*(row+29), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+29),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[28][k] =
				spu_nmsub(*(vector float*)&buf[27][k], spu_splats((float)bufx[1][27]),
				spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufx[1][26]),
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufx[1][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufx[1][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufx[1][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufx[1][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufx[1][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufx[1][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufx[1][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufx[1][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), 
				*(vector float*)&buf[28][k]))))))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[28], p1+dp*(row+28), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[30], p1+dp*(row+30), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+30),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[29][k] =
				spu_nmsub(*(vector float*)&buf[28][k], spu_splats((float)bufx[0][28]),
				spu_nmsub(*(vector float*)&buf[27][k], spu_splats((float)bufx[0][27]),
				spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufx[0][26]),
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufx[0][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufx[0][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufx[0][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufx[0][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufx[0][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufx[0][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufx[0][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufx[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[29][k])))))))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[29], p1+dp*(row+29), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(buf[31], p1+dp*(row+31), 4*di, 2, 0, 0);
	mfc_get(bufx[0], p2+dp*(row+31),  128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[30][k] =
				spu_nmsub(*(vector float*)&buf[29][k], spu_splats((float)bufx[1][29]),
				spu_nmsub(*(vector float*)&buf[28][k], spu_splats((float)bufx[1][28]),
				spu_nmsub(*(vector float*)&buf[27][k], spu_splats((float)bufx[1][27]),
				spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufx[1][26]),
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufx[1][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufx[1][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufx[1][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufx[1][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufx[1][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufx[1][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufx[1][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufx[1][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[1][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[1][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[1][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[1][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[1][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[1][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[1][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[1][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[1][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[1][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[1][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[1][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[1][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[1][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[1][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[1][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[1][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[1][0]), 
				*(vector float*)&buf[30][k]))))))))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[30], p1+dp*(row+30), 4*di, 4, 0, 0);

	dmawait(0);
	dmawait(2);

    mfc_get(bufy[0], p1+dp*(row+32), 4*di, 2, 0, 0);
	mfc_get(bufx[1], p2+dp*(row+32),    128, 0, 0, 0);

	for(k=0;k<di;k+=4){
			*(vector float*)&buf[31][k] =
				spu_nmsub(*(vector float*)&buf[30][k], spu_splats((float)bufx[0][30]),
				spu_nmsub(*(vector float*)&buf[29][k], spu_splats((float)bufx[0][29]),
				spu_nmsub(*(vector float*)&buf[28][k], spu_splats((float)bufx[0][28]),
				spu_nmsub(*(vector float*)&buf[27][k], spu_splats((float)bufx[0][27]),
				spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufx[0][26]),
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufx[0][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufx[0][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufx[0][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufx[0][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufx[0][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufx[0][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufx[0][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufx[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&buf[31][k])))))))))))))))))))))))))))))));
	}

    mfc_write_tag_mask(1 << 4);
    mfc_write_tag_update_all();
    mfc_read_tag_status();

	mfc_put(buf[31], p1+dp*(row+31), 4*di, 4, 0, 0);

	for(j=row+32;j<s;j++){
		ch = j%2;
		p  = (j+1)%2;
		
		dmawait(0);
		dmawait(2);

		mfc_get(bufx[ch], p2+dp*(j+1), 128, 0, 0, 0);

		vf[0] = spu_splats((float)bufx[p][0]);
		vf[1] = spu_splats((float)bufx[p][1]);
		vf[2] = spu_splats((float)bufx[p][2]);
		vf[3] = spu_splats((float)bufx[p][3]);
		vf[4] = spu_splats((float)bufx[p][4]);
		vf[5] = spu_splats((float)bufx[p][5]);
		vf[6] = spu_splats((float)bufx[p][6]);
		vf[7] = spu_splats((float)bufx[p][7]);
		vf[8] = spu_splats((float)bufx[p][8]);
		vf[9] = spu_splats((float)bufx[p][9]);
		vf[10] = spu_splats((float)bufx[p][10]);
		vf[11] = spu_splats((float)bufx[p][11]);
		vf[12] = spu_splats((float)bufx[p][12]);
		vf[13] = spu_splats((float)bufx[p][13]);
		vf[14] = spu_splats((float)bufx[p][14]);
		vf[15] = spu_splats((float)bufx[p][15]);
		vf[16] = spu_splats((float)bufx[p][16]);
		vf[17] = spu_splats((float)bufx[p][17]);
		vf[18] = spu_splats((float)bufx[p][18]);
		vf[19] = spu_splats((float)bufx[p][19]);
		vf[20] = spu_splats((float)bufx[p][20]);
		vf[21] = spu_splats((float)bufx[p][21]);
		vf[22] = spu_splats((float)bufx[p][22]);
		vf[23] = spu_splats((float)bufx[p][23]);
		vf[24] = spu_splats((float)bufx[p][24]);
		vf[25] = spu_splats((float)bufx[p][25]);
		vf[26] = spu_splats((float)bufx[p][26]);
		vf[27] = spu_splats((float)bufx[p][27]);
		vf[28] = spu_splats((float)bufx[p][28]);
		vf[29] = spu_splats((float)bufx[p][29]);
		vf[30] = spu_splats((float)bufx[p][30]);
		vf[31] = spu_splats((float)bufx[p][31]);

		dmawait(4);

	    mfc_get(bufy[p], p1+dp*(j+1), 4*di, 2, 0, 0);

		for(k=0;k<di;k+=32){

			o2 = k + 4;
			o3 = k + 8;
			o4 = k + 12;
			o5 = k + 16;
			o6 = k + 20;
			o7 = k + 24;
			o8 = k + 28;

			out1 = 
				spu_nmsub(*(vector float*)&buf[31][k], vf[31],
				spu_nmsub(*(vector float*)&buf[30][k], vf[30],
				spu_nmsub(*(vector float*)&buf[29][k], vf[29],
				spu_nmsub(*(vector float*)&buf[28][k], vf[28],
				spu_nmsub(*(vector float*)&buf[27][k], vf[27],
				spu_nmsub(*(vector float*)&buf[26][k], vf[26],
				spu_nmsub(*(vector float*)&buf[25][k], vf[25],
				spu_nmsub(*(vector float*)&buf[24][k], vf[24],
				spu_nmsub(*(vector float*)&buf[23][k], vf[23],
				spu_nmsub(*(vector float*)&buf[22][k], vf[22],
				spu_nmsub(*(vector float*)&buf[21][k], vf[21], 
				spu_nmsub(*(vector float*)&buf[20][k], vf[20],
				spu_nmsub(*(vector float*)&buf[19][k], vf[19],
				spu_nmsub(*(vector float*)&buf[18][k], vf[18],
				spu_nmsub(*(vector float*)&buf[17][k], vf[17],
				spu_nmsub(*(vector float*)&buf[16][k], vf[16],
				spu_nmsub(*(vector float*)&buf[15][k], vf[15],
				spu_nmsub(*(vector float*)&buf[14][k], vf[14],
				spu_nmsub(*(vector float*)&buf[13][k], vf[13], 
				spu_nmsub(*(vector float*)&buf[12][k], vf[12], 
				spu_nmsub(*(vector float*)&buf[11][k], vf[11],
				spu_nmsub(*(vector float*)&buf[10][k], vf[10],
				spu_nmsub(*(vector float*)&buf[9][k], vf[9],
				spu_nmsub(*(vector float*)&buf[8][k], vf[8],
				spu_nmsub(*(vector float*)&buf[7][k], vf[7],
				spu_nmsub(*(vector float*)&buf[6][k], vf[6],
				spu_nmsub(*(vector float*)&buf[5][k], vf[5],
				spu_nmsub(*(vector float*)&buf[4][k], vf[4],
				spu_nmsub(*(vector float*)&buf[3][k], vf[3],
				spu_nmsub(*(vector float*)&buf[2][k], vf[2],
				spu_nmsub(*(vector float*)&buf[1][k], vf[1],
				spu_nmsub(*(vector float*)&buf[0][k], vf[0], 
				*(vector float*)&bufy[ch][k]))))))))))))))))))))))))))))))));

			out2 = 
				spu_nmsub(*(vector float*)&buf[31][o2], vf[31],
				spu_nmsub(*(vector float*)&buf[30][o2], vf[30],
				spu_nmsub(*(vector float*)&buf[29][o2], vf[29],
				spu_nmsub(*(vector float*)&buf[28][o2], vf[28],
				spu_nmsub(*(vector float*)&buf[27][o2], vf[27],
				spu_nmsub(*(vector float*)&buf[26][o2], vf[26],
				spu_nmsub(*(vector float*)&buf[25][o2], vf[25],
				spu_nmsub(*(vector float*)&buf[24][o2], vf[24],
				spu_nmsub(*(vector float*)&buf[23][o2], vf[23],
				spu_nmsub(*(vector float*)&buf[22][o2], vf[22],
				spu_nmsub(*(vector float*)&buf[21][o2], vf[21], 
				spu_nmsub(*(vector float*)&buf[20][o2], vf[20],
				spu_nmsub(*(vector float*)&buf[19][o2], vf[19],
				spu_nmsub(*(vector float*)&buf[18][o2], vf[18],
				spu_nmsub(*(vector float*)&buf[17][o2], vf[17],
				spu_nmsub(*(vector float*)&buf[16][o2], vf[16],
				spu_nmsub(*(vector float*)&buf[15][o2], vf[15],
				spu_nmsub(*(vector float*)&buf[14][o2], vf[14],
				spu_nmsub(*(vector float*)&buf[13][o2], vf[13], 
				spu_nmsub(*(vector float*)&buf[12][o2], vf[12], 
				spu_nmsub(*(vector float*)&buf[11][o2], vf[11],
				spu_nmsub(*(vector float*)&buf[10][o2], vf[10],
				spu_nmsub(*(vector float*)&buf[9][o2], vf[9],
				spu_nmsub(*(vector float*)&buf[8][o2], vf[8],
				spu_nmsub(*(vector float*)&buf[7][o2], vf[7],
				spu_nmsub(*(vector float*)&buf[6][o2], vf[6],
				spu_nmsub(*(vector float*)&buf[5][o2], vf[5],
				spu_nmsub(*(vector float*)&buf[4][o2], vf[4],
				spu_nmsub(*(vector float*)&buf[3][o2], vf[3],
				spu_nmsub(*(vector float*)&buf[2][o2], vf[2],
				spu_nmsub(*(vector float*)&buf[1][o2], vf[1],
				spu_nmsub(*(vector float*)&buf[0][o2], vf[0], 
				*(vector float*)&bufy[ch][o2]))))))))))))))))))))))))))))))));

			out3 = 
				spu_nmsub(*(vector float*)&buf[31][o3], vf[31],
				spu_nmsub(*(vector float*)&buf[30][o3], vf[30],
				spu_nmsub(*(vector float*)&buf[29][o3], vf[29],
				spu_nmsub(*(vector float*)&buf[28][o3], vf[28],
				spu_nmsub(*(vector float*)&buf[27][o3], vf[27],
				spu_nmsub(*(vector float*)&buf[26][o3], vf[26],
				spu_nmsub(*(vector float*)&buf[25][o3], vf[25],
				spu_nmsub(*(vector float*)&buf[24][o3], vf[24],
				spu_nmsub(*(vector float*)&buf[23][o3], vf[23],
				spu_nmsub(*(vector float*)&buf[22][o3], vf[22],
				spu_nmsub(*(vector float*)&buf[21][o3], vf[21], 
				spu_nmsub(*(vector float*)&buf[20][o3], vf[20],
				spu_nmsub(*(vector float*)&buf[19][o3], vf[19],
				spu_nmsub(*(vector float*)&buf[18][o3], vf[18],
				spu_nmsub(*(vector float*)&buf[17][o3], vf[17],
				spu_nmsub(*(vector float*)&buf[16][o3], vf[16],
				spu_nmsub(*(vector float*)&buf[15][o3], vf[15],
				spu_nmsub(*(vector float*)&buf[14][o3], vf[14],
				spu_nmsub(*(vector float*)&buf[13][o3], vf[13], 
				spu_nmsub(*(vector float*)&buf[12][o3], vf[12], 
				spu_nmsub(*(vector float*)&buf[11][o3], vf[11],
				spu_nmsub(*(vector float*)&buf[10][o3], vf[10],
				spu_nmsub(*(vector float*)&buf[9][o3], vf[9],
				spu_nmsub(*(vector float*)&buf[8][o3], vf[8],
				spu_nmsub(*(vector float*)&buf[7][o3], vf[7],
				spu_nmsub(*(vector float*)&buf[6][o3], vf[6],
				spu_nmsub(*(vector float*)&buf[5][o3], vf[5],
				spu_nmsub(*(vector float*)&buf[4][o3], vf[4],
				spu_nmsub(*(vector float*)&buf[3][o3], vf[3],
				spu_nmsub(*(vector float*)&buf[2][o3], vf[2],
				spu_nmsub(*(vector float*)&buf[1][o3], vf[1],
				spu_nmsub(*(vector float*)&buf[0][o3], vf[0], 
				*(vector float*)&bufy[ch][o3]))))))))))))))))))))))))))))))));

			out4 = 
				spu_nmsub(*(vector float*)&buf[31][o4], vf[31],
				spu_nmsub(*(vector float*)&buf[30][o4], vf[30],
				spu_nmsub(*(vector float*)&buf[29][o4], vf[29],
				spu_nmsub(*(vector float*)&buf[28][o4], vf[28],
				spu_nmsub(*(vector float*)&buf[27][o4], vf[27],
				spu_nmsub(*(vector float*)&buf[26][o4], vf[26],
				spu_nmsub(*(vector float*)&buf[25][o4], vf[25],
				spu_nmsub(*(vector float*)&buf[24][o4], vf[24],
				spu_nmsub(*(vector float*)&buf[23][o4], vf[23],
				spu_nmsub(*(vector float*)&buf[22][o4], vf[22],
				spu_nmsub(*(vector float*)&buf[21][o4], vf[21], 
				spu_nmsub(*(vector float*)&buf[20][o4], vf[20],
				spu_nmsub(*(vector float*)&buf[19][o4], vf[19],
				spu_nmsub(*(vector float*)&buf[18][o4], vf[18],
				spu_nmsub(*(vector float*)&buf[17][o4], vf[17],
				spu_nmsub(*(vector float*)&buf[16][o4], vf[16],
				spu_nmsub(*(vector float*)&buf[15][o4], vf[15],
				spu_nmsub(*(vector float*)&buf[14][o4], vf[14],
				spu_nmsub(*(vector float*)&buf[13][o4], vf[13], 
				spu_nmsub(*(vector float*)&buf[12][o4], vf[12], 
				spu_nmsub(*(vector float*)&buf[11][o4], vf[11],
				spu_nmsub(*(vector float*)&buf[10][o4], vf[10],
				spu_nmsub(*(vector float*)&buf[9][o4], vf[9],
				spu_nmsub(*(vector float*)&buf[8][o4], vf[8],
				spu_nmsub(*(vector float*)&buf[7][o4], vf[7],
				spu_nmsub(*(vector float*)&buf[6][o4], vf[6],
				spu_nmsub(*(vector float*)&buf[5][o4], vf[5],
				spu_nmsub(*(vector float*)&buf[4][o4], vf[4],
				spu_nmsub(*(vector float*)&buf[3][o4], vf[3],
				spu_nmsub(*(vector float*)&buf[2][o4], vf[2],
				spu_nmsub(*(vector float*)&buf[1][o4], vf[1],
				spu_nmsub(*(vector float*)&buf[0][o4], vf[0], 
				*(vector float*)&bufy[ch][o4]))))))))))))))))))))))))))))))));

			out5 = 
				spu_nmsub(*(vector float*)&buf[31][o5], vf[31],
				spu_nmsub(*(vector float*)&buf[30][o5], vf[30],
				spu_nmsub(*(vector float*)&buf[29][o5], vf[29],
				spu_nmsub(*(vector float*)&buf[28][o5], vf[28],
				spu_nmsub(*(vector float*)&buf[27][o5], vf[27],
				spu_nmsub(*(vector float*)&buf[26][o5], vf[26],
				spu_nmsub(*(vector float*)&buf[25][o5], vf[25],
				spu_nmsub(*(vector float*)&buf[24][o5], vf[24],
				spu_nmsub(*(vector float*)&buf[23][o5], vf[23],
				spu_nmsub(*(vector float*)&buf[22][o5], vf[22],
				spu_nmsub(*(vector float*)&buf[21][o5], vf[21], 
				spu_nmsub(*(vector float*)&buf[20][o5], vf[20],
				spu_nmsub(*(vector float*)&buf[19][o5], vf[19],
				spu_nmsub(*(vector float*)&buf[18][o5], vf[18],
				spu_nmsub(*(vector float*)&buf[17][o5], vf[17],
				spu_nmsub(*(vector float*)&buf[16][o5], vf[16],
				spu_nmsub(*(vector float*)&buf[15][o5], vf[15],
				spu_nmsub(*(vector float*)&buf[14][o5], vf[14],
				spu_nmsub(*(vector float*)&buf[13][o5], vf[13], 
				spu_nmsub(*(vector float*)&buf[12][o5], vf[12], 
				spu_nmsub(*(vector float*)&buf[11][o5], vf[11],
				spu_nmsub(*(vector float*)&buf[10][o5], vf[10],
				spu_nmsub(*(vector float*)&buf[9][o5], vf[9],
				spu_nmsub(*(vector float*)&buf[8][o5], vf[8],
				spu_nmsub(*(vector float*)&buf[7][o5], vf[7],
				spu_nmsub(*(vector float*)&buf[6][o5], vf[6],
				spu_nmsub(*(vector float*)&buf[5][o5], vf[5],
				spu_nmsub(*(vector float*)&buf[4][o5], vf[4],
				spu_nmsub(*(vector float*)&buf[3][o5], vf[3],
				spu_nmsub(*(vector float*)&buf[2][o5], vf[2],
				spu_nmsub(*(vector float*)&buf[1][o5], vf[1],
				spu_nmsub(*(vector float*)&buf[0][o5], vf[0], 
				*(vector float*)&bufy[ch][o5]))))))))))))))))))))))))))))))));

			out6 = 
				spu_nmsub(*(vector float*)&buf[31][o6], vf[31],
				spu_nmsub(*(vector float*)&buf[30][o6], vf[30],
				spu_nmsub(*(vector float*)&buf[29][o6], vf[29],
				spu_nmsub(*(vector float*)&buf[28][o6], vf[28],
				spu_nmsub(*(vector float*)&buf[27][o6], vf[27],
				spu_nmsub(*(vector float*)&buf[26][o6], vf[26],
				spu_nmsub(*(vector float*)&buf[25][o6], vf[25],
				spu_nmsub(*(vector float*)&buf[24][o6], vf[24],
				spu_nmsub(*(vector float*)&buf[23][o6], vf[23],
				spu_nmsub(*(vector float*)&buf[22][o6], vf[22],
				spu_nmsub(*(vector float*)&buf[21][o6], vf[21], 
				spu_nmsub(*(vector float*)&buf[20][o6], vf[20],
				spu_nmsub(*(vector float*)&buf[19][o6], vf[19],
				spu_nmsub(*(vector float*)&buf[18][o6], vf[18],
				spu_nmsub(*(vector float*)&buf[17][o6], vf[17],
				spu_nmsub(*(vector float*)&buf[16][o6], vf[16],
				spu_nmsub(*(vector float*)&buf[15][o6], vf[15],
				spu_nmsub(*(vector float*)&buf[14][o6], vf[14],
				spu_nmsub(*(vector float*)&buf[13][o6], vf[13], 
				spu_nmsub(*(vector float*)&buf[12][o6], vf[12], 
				spu_nmsub(*(vector float*)&buf[11][o6], vf[11],
				spu_nmsub(*(vector float*)&buf[10][o6], vf[10],
				spu_nmsub(*(vector float*)&buf[9][o6], vf[9],
				spu_nmsub(*(vector float*)&buf[8][o6], vf[8],
				spu_nmsub(*(vector float*)&buf[7][o6], vf[7],
				spu_nmsub(*(vector float*)&buf[6][o6], vf[6],
				spu_nmsub(*(vector float*)&buf[5][o6], vf[5],
				spu_nmsub(*(vector float*)&buf[4][o6], vf[4],
				spu_nmsub(*(vector float*)&buf[3][o6], vf[3],
				spu_nmsub(*(vector float*)&buf[2][o6], vf[2],
				spu_nmsub(*(vector float*)&buf[1][o6], vf[1],
				spu_nmsub(*(vector float*)&buf[0][o6], vf[0], 
				*(vector float*)&bufy[ch][o6]))))))))))))))))))))))))))))))));

			out7 = 
				spu_nmsub(*(vector float*)&buf[31][o7], vf[31],
				spu_nmsub(*(vector float*)&buf[30][o7], vf[30],
				spu_nmsub(*(vector float*)&buf[29][o7], vf[29],
				spu_nmsub(*(vector float*)&buf[28][o7], vf[28],
				spu_nmsub(*(vector float*)&buf[27][o7], vf[27],
				spu_nmsub(*(vector float*)&buf[26][o7], vf[26],
				spu_nmsub(*(vector float*)&buf[25][o7], vf[25],
				spu_nmsub(*(vector float*)&buf[24][o7], vf[24],
				spu_nmsub(*(vector float*)&buf[23][o7], vf[23],
				spu_nmsub(*(vector float*)&buf[22][o7], vf[22],
				spu_nmsub(*(vector float*)&buf[21][o7], vf[21], 
				spu_nmsub(*(vector float*)&buf[20][o7], vf[20],
				spu_nmsub(*(vector float*)&buf[19][o7], vf[19],
				spu_nmsub(*(vector float*)&buf[18][o7], vf[18],
				spu_nmsub(*(vector float*)&buf[17][o7], vf[17],
				spu_nmsub(*(vector float*)&buf[16][o7], vf[16],
				spu_nmsub(*(vector float*)&buf[15][o7], vf[15],
				spu_nmsub(*(vector float*)&buf[14][o7], vf[14],
				spu_nmsub(*(vector float*)&buf[13][o7], vf[13], 
				spu_nmsub(*(vector float*)&buf[12][o7], vf[12], 
				spu_nmsub(*(vector float*)&buf[11][o7], vf[11],
				spu_nmsub(*(vector float*)&buf[10][o7], vf[10],
				spu_nmsub(*(vector float*)&buf[9][o7], vf[9],
				spu_nmsub(*(vector float*)&buf[8][o7], vf[8],
				spu_nmsub(*(vector float*)&buf[7][o7], vf[7],
				spu_nmsub(*(vector float*)&buf[6][o7], vf[6],
				spu_nmsub(*(vector float*)&buf[5][o7], vf[5],
				spu_nmsub(*(vector float*)&buf[4][o7], vf[4],
				spu_nmsub(*(vector float*)&buf[3][o7], vf[3],
				spu_nmsub(*(vector float*)&buf[2][o7], vf[2],
				spu_nmsub(*(vector float*)&buf[1][o7], vf[1],
				spu_nmsub(*(vector float*)&buf[0][o7], vf[0], 
				*(vector float*)&bufy[ch][o7]))))))))))))))))))))))))))))))));

			out8 = 
				spu_nmsub(*(vector float*)&buf[31][o8], vf[31],
				spu_nmsub(*(vector float*)&buf[30][o8], vf[30],
				spu_nmsub(*(vector float*)&buf[29][o8], vf[29],
				spu_nmsub(*(vector float*)&buf[28][o8], vf[28],
				spu_nmsub(*(vector float*)&buf[27][o8], vf[27],
				spu_nmsub(*(vector float*)&buf[26][o8], vf[26],
				spu_nmsub(*(vector float*)&buf[25][o8], vf[25],
				spu_nmsub(*(vector float*)&buf[24][o8], vf[24],
				spu_nmsub(*(vector float*)&buf[23][o8], vf[23],
				spu_nmsub(*(vector float*)&buf[22][o8], vf[22],
				spu_nmsub(*(vector float*)&buf[21][o8], vf[21], 
				spu_nmsub(*(vector float*)&buf[20][o8], vf[20],
				spu_nmsub(*(vector float*)&buf[19][o8], vf[19],
				spu_nmsub(*(vector float*)&buf[18][o8], vf[18],
				spu_nmsub(*(vector float*)&buf[17][o8], vf[17],
				spu_nmsub(*(vector float*)&buf[16][o8], vf[16],
				spu_nmsub(*(vector float*)&buf[15][o8], vf[15],
				spu_nmsub(*(vector float*)&buf[14][o8], vf[14],
				spu_nmsub(*(vector float*)&buf[13][o8], vf[13], 
				spu_nmsub(*(vector float*)&buf[12][o8], vf[12], 
				spu_nmsub(*(vector float*)&buf[11][o8], vf[11],
				spu_nmsub(*(vector float*)&buf[10][o8], vf[10],
				spu_nmsub(*(vector float*)&buf[9][o8], vf[9],
				spu_nmsub(*(vector float*)&buf[8][o8], vf[8],
				spu_nmsub(*(vector float*)&buf[7][o8], vf[7],
				spu_nmsub(*(vector float*)&buf[6][o8], vf[6],
				spu_nmsub(*(vector float*)&buf[5][o8], vf[5],
				spu_nmsub(*(vector float*)&buf[4][o8], vf[4],
				spu_nmsub(*(vector float*)&buf[3][o8], vf[3],
				spu_nmsub(*(vector float*)&buf[2][o8], vf[2],
				spu_nmsub(*(vector float*)&buf[1][o8], vf[1],
				spu_nmsub(*(vector float*)&buf[0][o8], vf[0], 
				*(vector float*)&bufy[ch][o8]))))))))))))))))))))))))))))))));

			*(vector float*)&bufy[ch][k] = out1;
			*(vector float*)&bufy[ch][o2] = out2;
			*(vector float*)&bufy[ch][o3] = out3;
			*(vector float*)&bufy[ch][o4] = out4;
			*(vector float*)&bufy[ch][o5] = out5;
			*(vector float*)&bufy[ch][o6] = out6;
			*(vector float*)&bufy[ch][o7] = out7;
			*(vector float*)&bufy[ch][o8] = out8;

		}

		mfc_put(bufy[j%2], p1+dp*j, 4*di, 4, 0, 0);
	}

	mfc_write_tag_mask(1 << 0);
	mfc_write_tag_update_all();
	mfc_read_tag_status();

	mfc_write_tag_mask(1 << 2);
	mfc_write_tag_update_all();
	mfc_read_tag_status();

	mfc_write_tag_mask(1 << 4);
	mfc_write_tag_update_all();
	mfc_read_tag_status();

	if(s == n-1){
		for(k=0;k<di;k+=4){

			*(vector float*)&bufy[1][k] =
				spu_nmsub(*(vector float*)&buf[31][k], spu_splats((float)bufx[0][31]),
				spu_nmsub(*(vector float*)&buf[30][k], spu_splats((float)bufx[0][30]),
				spu_nmsub(*(vector float*)&buf[29][k], spu_splats((float)bufx[0][29]),
				spu_nmsub(*(vector float*)&buf[28][k], spu_splats((float)bufx[0][28]),
				spu_nmsub(*(vector float*)&buf[27][k], spu_splats((float)bufx[0][27]),
				spu_nmsub(*(vector float*)&buf[26][k], spu_splats((float)bufx[0][26]),
				spu_nmsub(*(vector float*)&buf[25][k], spu_splats((float)bufx[0][25]),
				spu_nmsub(*(vector float*)&buf[24][k], spu_splats((float)bufx[0][24]),
				spu_nmsub(*(vector float*)&buf[23][k], spu_splats((float)bufx[0][23]),
				spu_nmsub(*(vector float*)&buf[22][k], spu_splats((float)bufx[0][22]),
				spu_nmsub(*(vector float*)&buf[21][k], spu_splats((float)bufx[0][21]), 
				spu_nmsub(*(vector float*)&buf[20][k], spu_splats((float)bufx[0][20]),
				spu_nmsub(*(vector float*)&buf[19][k], spu_splats((float)bufx[0][19]),
				spu_nmsub(*(vector float*)&buf[18][k], spu_splats((float)bufx[0][18]),
				spu_nmsub(*(vector float*)&buf[17][k], spu_splats((float)bufx[0][17]),
				spu_nmsub(*(vector float*)&buf[16][k], spu_splats((float)bufx[0][16]),
				spu_nmsub(*(vector float*)&buf[15][k], spu_splats((float)bufx[0][15]),
				spu_nmsub(*(vector float*)&buf[14][k], spu_splats((float)bufx[0][14]),
				spu_nmsub(*(vector float*)&buf[13][k], spu_splats((float)bufx[0][13]), 
				spu_nmsub(*(vector float*)&buf[12][k], spu_splats((float)bufx[0][12]), 
				spu_nmsub(*(vector float*)&buf[11][k], spu_splats((float)bufx[0][11]),
				spu_nmsub(*(vector float*)&buf[10][k], spu_splats((float)bufx[0][10]),
				spu_nmsub(*(vector float*)&buf[9][k], spu_splats((float)bufx[0][9]),
				spu_nmsub(*(vector float*)&buf[8][k], spu_splats((float)bufx[0][8]),
				spu_nmsub(*(vector float*)&buf[7][k], spu_splats((float)bufx[0][7]),
				spu_nmsub(*(vector float*)&buf[6][k], spu_splats((float)bufx[0][6]),
				spu_nmsub(*(vector float*)&buf[5][k], spu_splats((float)bufx[0][5]),
				spu_nmsub(*(vector float*)&buf[4][k], spu_splats((float)bufx[0][4]),
				spu_nmsub(*(vector float*)&buf[3][k], spu_splats((float)bufx[0][3]),
				spu_nmsub(*(vector float*)&buf[2][k], spu_splats((float)bufx[0][2]),
				spu_nmsub(*(vector float*)&buf[1][k], spu_splats((float)bufx[0][1]),
				spu_nmsub(*(vector float*)&buf[0][k], spu_splats((float)bufx[0][0]), 
				*(vector float*)&bufy[1][k]))))))))))))))))))))))))))))))));
		}

		mfc_put(bufy[1], p1+dp*(n-1), 4*di, 0, 0, 0);

		mfc_write_tag_mask(1 << 4);
		mfc_write_tag_update_all();
		mfc_read_tag_status();

		mfc_write_tag_mask(1 << 0);
		mfc_write_tag_update_all();
		mfc_read_tag_status();
	}
}

void f_and_b_substitution3(unsigned int ppe_a, unsigned int ppe_b, unsigned int ppe_x, unsigned int id, unsigned int n, unsigned int m){
    int i,j,r,ch,idx;
	float tf, tf2, tf3;
	vector float temp = {0.0, 0.0, 0.0, 0.0};
	vector float temp1, temp2, temp3;

	for(idx=3*id;idx<m;idx+=3*NUMBER_OF_SPES){

		dmaget((void*)bufx[0], ppe_b+n*sizeof(float)*idx,4*n);
		dmaget((void*)bufx[1], ppe_b+n*sizeof(float)*(idx+1),4*n);
		dmaget((void*)bufx[2], ppe_b+n*sizeof(float)*(idx+2),4*n);

		j = buft[0];
		if(j > 0){
			tf = bufx[0][0];
			tf2 = bufx[1][0];
			tf3 = bufx[2][0];

			bufx[0][0] = bufx[0][j];
			bufx[1][0] = bufx[1][j];
			bufx[2][0] = bufx[2][j];

			bufx[0][j] = tf;
			bufx[1][j] = tf2;
			bufx[2][j] = tf3;
		}

		mfc_get(bufy[1], ppe_a+n*sizeof(float), 128, 0, 0, 0);

		for(i=1;i<n-1;i++){
			r = i/32;
			ch = i&1;

			dmawait(0);
			mfc_get(bufy[(i+1)%2], ppe_a+n*sizeof(float)*(i+1), 128*(r+1), 0, 0, 0);

			j  = buft[i];
			tf = bufx[0][j];
			tf2 = bufx[1][j];
			tf3 = bufx[2][j];
			if(j > i){
				bufx[0][j] = bufx[0][i];
				bufx[1][j] = bufx[1][i];
				bufx[2][j] = bufx[2][i];
			}

			for(j=0;j<r;j++){
				temp1 = temp;
				temp2 = temp;
				temp3 = temp;

				temp1 = spu_madd(*(vector float*)&bufx[0][32*j+28], *(vector float*)&bufy[ch][32*j+28],
					spu_madd(*(vector float*)&bufx[0][32*j+24], *(vector float*)&bufy[ch][32*j+24],
					spu_madd(*(vector float*)&bufx[0][32*j+20], *(vector float*)&bufy[ch][32*j+20],
					spu_madd(*(vector float*)&bufx[0][32*j+16], *(vector float*)&bufy[ch][32*j+16],
					spu_madd(*(vector float*)&bufx[0][32*j+12], *(vector float*)&bufy[ch][32*j+12],
					spu_madd(*(vector float*)&bufx[0][32*j+8], *(vector float*)&bufy[ch][32*j+8],
					spu_madd(*(vector float*)&bufx[0][32*j+4], *(vector float*)&bufy[ch][32*j+4],
					spu_madd(*(vector float*)&bufx[0][32*j], *(vector float*)&bufy[ch][32*j],temp1))))))));

				temp2 = spu_madd(*(vector float*)&bufx[1][32*j+28], *(vector float*)&bufy[ch][32*j+28],
					spu_madd(*(vector float*)&bufx[1][32*j+24], *(vector float*)&bufy[ch][32*j+24],
					spu_madd(*(vector float*)&bufx[1][32*j+20], *(vector float*)&bufy[ch][32*j+20],
					spu_madd(*(vector float*)&bufx[1][32*j+16], *(vector float*)&bufy[ch][32*j+16],
					spu_madd(*(vector float*)&bufx[1][32*j+12], *(vector float*)&bufy[ch][32*j+12],
					spu_madd(*(vector float*)&bufx[1][32*j+8], *(vector float*)&bufy[ch][32*j+8],
					spu_madd(*(vector float*)&bufx[1][32*j+4], *(vector float*)&bufy[ch][32*j+4],
					spu_madd(*(vector float*)&bufx[1][32*j], *(vector float*)&bufy[ch][32*j],temp2))))))));

				temp3 = spu_madd(*(vector float*)&bufx[2][32*j+28], *(vector float*)&bufy[ch][32*j+28],
					spu_madd(*(vector float*)&bufx[2][32*j+24], *(vector float*)&bufy[ch][32*j+24],
					spu_madd(*(vector float*)&bufx[2][32*j+20], *(vector float*)&bufy[ch][32*j+20],
					spu_madd(*(vector float*)&bufx[2][32*j+16], *(vector float*)&bufy[ch][32*j+16],
					spu_madd(*(vector float*)&bufx[2][32*j+12], *(vector float*)&bufy[ch][32*j+12],
					spu_madd(*(vector float*)&bufx[2][32*j+8], *(vector float*)&bufy[ch][32*j+8],
					spu_madd(*(vector float*)&bufx[2][32*j+4], *(vector float*)&bufy[ch][32*j+4],
					spu_madd(*(vector float*)&bufx[2][32*j], *(vector float*)&bufy[ch][32*j],temp3))))))));

				tf -= spu_extract(temp1,0) + spu_extract(temp1,1) + spu_extract(temp1,2) + spu_extract(temp1,3);
				tf2 -= spu_extract(temp2,0) + spu_extract(temp2,1) + spu_extract(temp2,2) + spu_extract(temp2,3);
				tf3 -= spu_extract(temp3,0) + spu_extract(temp3,1) + spu_extract(temp3,2) + spu_extract(temp3,3);
			}

			temp1 = temp;
			temp2 = temp;
			temp3 = temp;

			for(j=32*r;j<(i/4)*4;j+=4){
				temp1 = spu_madd(*(vector float*)&bufx[0][j], *(vector float*)&bufy[ch][j], temp1);
				temp2 = spu_madd(*(vector float*)&bufx[1][j], *(vector float*)&bufy[ch][j], temp2);
				temp3 = spu_madd(*(vector float*)&bufx[2][j], *(vector float*)&bufy[ch][j], temp3);
			}

			tf -= spu_extract(temp1,0) + spu_extract(temp1,1) + spu_extract(temp1,2) + spu_extract(temp1,3);
			tf2 -= spu_extract(temp2,0) + spu_extract(temp2,1) + spu_extract(temp2,2) + spu_extract(temp2,3);
			tf3 -= spu_extract(temp3,0) + spu_extract(temp3,1) + spu_extract(temp3,2) + spu_extract(temp3,3);

			if(i%4 == 1){
				tf -= bufx[0][(i/4)*4] * bufy[ch][(i/4)*4];
				tf2 -= bufx[1][(i/4)*4] * bufy[ch][(i/4)*4];
				tf3 -= bufx[2][(i/4)*4] * bufy[ch][(i/4)*4];
			}else if(i%4 == 2){
				tf -= bufx[0][(i/4)*4] * bufy[ch][(i/4)*4] + bufx[0][(i/4)*4+1] * bufy[ch][(i/4)*4+1];
				tf2 -= bufx[1][(i/4)*4] * bufy[ch][(i/4)*4] + bufx[1][(i/4)*4+1] * bufy[ch][(i/4)*4+1];
				tf3 -= bufx[2][(i/4)*4] * bufy[ch][(i/4)*4] + bufx[2][(i/4)*4+1] * bufy[ch][(i/4)*4+1];
			}else if(i%4 == 3){
				tf -= bufx[0][(i/4)*4] * bufy[ch][(i/4)*4] + bufx[0][(i/4)*4+1] * bufy[ch][(i/4)*4+1]+ bufx[0][(i/4)*4+2] * bufy[ch][(i/4)*4+2];
				tf2 -= bufx[1][(i/4)*4] * bufy[ch][(i/4)*4] + bufx[1][(i/4)*4+1] * bufy[ch][(i/4)*4+1]+ bufx[1][(i/4)*4+2] * bufy[ch][(i/4)*4+2];
				tf3 -= bufx[2][(i/4)*4] * bufy[ch][(i/4)*4] + bufx[2][(i/4)*4+1] * bufy[ch][(i/4)*4+1]+ bufx[2][(i/4)*4+2] * bufy[ch][(i/4)*4+2];
			}

			bufx[0][i] = tf;
			bufx[1][i] = tf2;
			bufx[2][i] = tf3;
		}

		dmawait(0);

		r = (n-1)/32;

		tf = bufx[0][n-1];
		tf2 = bufx[1][n-1];
		tf3 = bufx[2][n-1];
			
		for(j=0;j<r;j++){
			temp1 = temp;
			temp2 = temp;
			temp3 = temp;

			temp1 = spu_madd(*(vector float*)&bufx[0][32*j+28], *(vector float*)&bufy[1][32*j+28],
				spu_madd(*(vector float*)&bufx[0][32*j+24], *(vector float*)&bufy[1][32*j+24],
				spu_madd(*(vector float*)&bufx[0][32*j+20], *(vector float*)&bufy[1][32*j+20],
				spu_madd(*(vector float*)&bufx[0][32*j+16], *(vector float*)&bufy[1][32*j+16],
				spu_madd(*(vector float*)&bufx[0][32*j+12], *(vector float*)&bufy[1][32*j+12],
				spu_madd(*(vector float*)&bufx[0][32*j+8], *(vector float*)&bufy[1][32*j+8],
				spu_madd(*(vector float*)&bufx[0][32*j+4], *(vector float*)&bufy[1][32*j+4],
				spu_madd(*(vector float*)&bufx[0][32*j], *(vector float*)&bufy[1][32*j],temp1))))))));

			temp2 = spu_madd(*(vector float*)&bufx[1][32*j+28], *(vector float*)&bufy[1][32*j+28],
				spu_madd(*(vector float*)&bufx[1][32*j+24], *(vector float*)&bufy[1][32*j+24],
				spu_madd(*(vector float*)&bufx[1][32*j+20], *(vector float*)&bufy[1][32*j+20],
				spu_madd(*(vector float*)&bufx[1][32*j+16], *(vector float*)&bufy[1][32*j+16],
				spu_madd(*(vector float*)&bufx[1][32*j+12], *(vector float*)&bufy[1][32*j+12],
				spu_madd(*(vector float*)&bufx[1][32*j+8], *(vector float*)&bufy[1][32*j+8],
				spu_madd(*(vector float*)&bufx[1][32*j+4], *(vector float*)&bufy[1][32*j+4],
				spu_madd(*(vector float*)&bufx[1][32*j], *(vector float*)&bufy[1][32*j],temp2))))))));

			temp3 = spu_madd(*(vector float*)&bufx[2][32*j+28], *(vector float*)&bufy[1][32*j+28],
				spu_madd(*(vector float*)&bufx[2][32*j+24], *(vector float*)&bufy[1][32*j+24],
				spu_madd(*(vector float*)&bufx[2][32*j+20], *(vector float*)&bufy[1][32*j+20],
				spu_madd(*(vector float*)&bufx[2][32*j+16], *(vector float*)&bufy[1][32*j+16],
				spu_madd(*(vector float*)&bufx[2][32*j+12], *(vector float*)&bufy[1][32*j+12],
				spu_madd(*(vector float*)&bufx[2][32*j+8], *(vector float*)&bufy[1][32*j+8],
				spu_madd(*(vector float*)&bufx[2][32*j+4], *(vector float*)&bufy[1][32*j+4],
				spu_madd(*(vector float*)&bufx[2][32*j], *(vector float*)&bufy[1][32*j],temp3))))))));

			tf -= spu_extract(temp1,0) + spu_extract(temp1,1) + spu_extract(temp1,2) + spu_extract(temp1,3);
			tf2 -= spu_extract(temp2,0) + spu_extract(temp2,1) + spu_extract(temp2,2) + spu_extract(temp2,3);
			tf3 -= spu_extract(temp3,0) + spu_extract(temp3,1) + spu_extract(temp3,2) + spu_extract(temp3,3);
		}

		temp1 = temp;
		temp2 = temp;
		temp3 = temp;

		for(j=32*r;j<n-4;j+=4){
			temp1 = spu_madd(*(vector float*)&bufx[0][j], *(vector float*)&bufy[1][j], temp1);
			temp2 = spu_madd(*(vector float*)&bufx[1][j], *(vector float*)&bufy[1][j], temp2);
			temp3 = spu_madd(*(vector float*)&bufx[2][j], *(vector float*)&bufy[1][j], temp3);
		}

		tf -= spu_extract(temp1,0) + spu_extract(temp1,1) + spu_extract(temp1,2) + spu_extract(temp1,3);
		tf2 -= spu_extract(temp2,0) + spu_extract(temp2,1) + spu_extract(temp2,2) + spu_extract(temp2,3);
		tf3 -= spu_extract(temp3,0) + spu_extract(temp3,1) + spu_extract(temp3,2) + spu_extract(temp3,3);

		tf -= bufx[0][n-4] * bufy[1][n-4] + bufx[0][n-3] * bufy[1][n-3]+ bufx[0][n-2] * bufy[1][n-2];
		tf2 -= bufx[1][n-4] * bufy[1][n-4] + bufx[1][n-3] * bufy[1][n-3]+ bufx[1][n-2] * bufy[1][n-2];
		tf3 -= bufx[2][n-4] * bufy[1][n-4] + bufx[2][n-3] * bufy[1][n-3]+ bufx[2][n-2] * bufy[1][n-2];

		tf /= bufy[1][n-1];
		tf2 /= bufy[1][n-1];
		tf3 /= bufy[1][n-1];

		bufx[0][n-1] = tf;
		bufx[1][n-1] = tf2;
		bufx[2][n-1] = tf3;

		mfc_get(bufy[1], ppe_a+n*sizeof(float)*(n-2)-128, 128, 0, 0, 0);

		bufx[0][n-2] -= bufx[0][n-1] * bufy[0][n-1];
		bufx[1][n-2] -= bufx[1][n-1] * bufy[0][n-1];
		bufx[2][n-2] -= bufx[2][n-1] * bufy[0][n-1];

		bufx[0][n-2] /= bufy[0][n-2];
		bufx[1][n-2] /= bufy[0][n-2];
		bufx[2][n-2] /= bufy[0][n-2];

		for(i=n-3;i>0;i--){
			r = (n-(i+1))/32;
			ch = i&1;

			dmawait(0);
			mfc_get(bufy[(i-1)&1], ppe_a+n*sizeof(float)*i-128*(((n-i)/32)+1), 128*(((n-i)/32)+1), 0, 0, 0);

			tf = bufx[0][i];
			tf2 = bufx[1][i];
			tf3 = bufx[2][i];

			if(i%4 == 2){
				tf -= bufx[0][i+1] * bufy[ch][(i%32)+1];
				tf2 -= bufx[1][i+1] * bufy[ch][(i%32)+1];
				tf3 -= bufx[2][i+1] * bufy[ch][(i%32)+1];
			}else if(i%4 == 1){
				tf -= bufx[0][i+1] * bufy[ch][(i%32)+1] + bufx[0][i+2] * bufy[ch][(i%32)+2];
				tf2 -= bufx[1][i+1] * bufy[ch][(i%32)+1] + bufx[1][i+2] * bufy[ch][(i%32)+2];
				tf3 -= bufx[2][i+1] * bufy[ch][(i%32)+1] + bufx[2][i+2] * bufy[ch][(i%32)+2];
			}else if(i%4 == 0){
				tf -= bufx[0][i+1] * bufy[ch][(i%32)+1] + bufx[0][i+2] * bufy[ch][(i%32)+2]+ bufx[0][i+3] * bufy[ch][(i%32)+3];
				tf2 -= bufx[1][i+1] * bufy[ch][(i%32)+1] + bufx[1][i+2] * bufy[ch][(i%32)+2]+ bufx[1][i+3] * bufy[ch][(i%32)+3];
				tf3 -= bufx[2][i+1] * bufy[ch][(i%32)+1] + bufx[2][i+2] * bufy[ch][(i%32)+2]+ bufx[2][i+3] * bufy[ch][(i%32)+3];
			}

			temp1 = temp;
			temp2 = temp;
			temp3 = temp;

			for(j=(i%32)+4-(i%4);j<32;j+=4){
				temp1 = spu_madd(*(vector float*)&bufx[0][n-32*(r+1)+j], *(vector float*)&bufy[ch][j], temp1);
				temp2 = spu_madd(*(vector float*)&bufx[1][n-32*(r+1)+j], *(vector float*)&bufy[ch][j], temp2);
				temp3 = spu_madd(*(vector float*)&bufx[2][n-32*(r+1)+j], *(vector float*)&bufy[ch][j], temp3);
			}

			tf -= spu_extract(temp1,0) + spu_extract(temp1,1) + spu_extract(temp1,2) + spu_extract(temp1,3);
			tf2 -= spu_extract(temp2,0) + spu_extract(temp2,1) + spu_extract(temp2,2) + spu_extract(temp2,3);
			tf3 -= spu_extract(temp3,0) + spu_extract(temp3,1) + spu_extract(temp3,2) + spu_extract(temp3,3);

			for(j=0;j<r;j++){
				temp1 = temp;
				temp2 = temp;
				temp3 = temp;

				temp1 = spu_madd(*(vector float*)&bufx[0][n-32*(r-j)+28], *(vector float*)&bufy[ch][32*(j+1)+28], 
					spu_madd(*(vector float*)&bufx[0][n-32*(r-j)+24], *(vector float*)&bufy[ch][32*(j+1)+24],
					spu_madd(*(vector float*)&bufx[0][n-32*(r-j)+20], *(vector float*)&bufy[ch][32*(j+1)+20],
					spu_madd(*(vector float*)&bufx[0][n-32*(r-j)+16], *(vector float*)&bufy[ch][32*(j+1)+16],
					spu_madd(*(vector float*)&bufx[0][n-32*(r-j)+12], *(vector float*)&bufy[ch][32*(j+1)+12],
					spu_madd(*(vector float*)&bufx[0][n-32*(r-j)+8], *(vector float*)&bufy[ch][32*(j+1)+8],
					spu_madd(*(vector float*)&bufx[0][n-32*(r-j)+4], *(vector float*)&bufy[ch][32*(j+1)+4],
					spu_madd(*(vector float*)&bufx[0][n-32*(r-j)], *(vector float*)&bufy[ch][32*(j+1)],temp1))))))));

				temp2 = spu_madd(*(vector float*)&bufx[1][n-32*(r-j)+28], *(vector float*)&bufy[ch][32*(j+1)+28], 
					spu_madd(*(vector float*)&bufx[1][n-32*(r-j)+24], *(vector float*)&bufy[ch][32*(j+1)+24],
					spu_madd(*(vector float*)&bufx[1][n-32*(r-j)+20], *(vector float*)&bufy[ch][32*(j+1)+20],
					spu_madd(*(vector float*)&bufx[1][n-32*(r-j)+16], *(vector float*)&bufy[ch][32*(j+1)+16],
					spu_madd(*(vector float*)&bufx[1][n-32*(r-j)+12], *(vector float*)&bufy[ch][32*(j+1)+12],
					spu_madd(*(vector float*)&bufx[1][n-32*(r-j)+8], *(vector float*)&bufy[ch][32*(j+1)+8],
					spu_madd(*(vector float*)&bufx[1][n-32*(r-j)+4], *(vector float*)&bufy[ch][32*(j+1)+4],
					spu_madd(*(vector float*)&bufx[1][n-32*(r-j)], *(vector float*)&bufy[ch][32*(j+1)],temp2))))))));

				temp3 = spu_madd(*(vector float*)&bufx[2][n-32*(r-j)+28], *(vector float*)&bufy[ch][32*(j+1)+28], 
					spu_madd(*(vector float*)&bufx[2][n-32*(r-j)+24], *(vector float*)&bufy[ch][32*(j+1)+24],
					spu_madd(*(vector float*)&bufx[2][n-32*(r-j)+20], *(vector float*)&bufy[ch][32*(j+1)+20],
					spu_madd(*(vector float*)&bufx[2][n-32*(r-j)+16], *(vector float*)&bufy[ch][32*(j+1)+16],
					spu_madd(*(vector float*)&bufx[2][n-32*(r-j)+12], *(vector float*)&bufy[ch][32*(j+1)+12],
					spu_madd(*(vector float*)&bufx[2][n-32*(r-j)+8], *(vector float*)&bufy[ch][32*(j+1)+8],
					spu_madd(*(vector float*)&bufx[2][n-32*(r-j)+4], *(vector float*)&bufy[ch][32*(j+1)+4],
					spu_madd(*(vector float*)&bufx[2][n-32*(r-j)], *(vector float*)&bufy[ch][32*(j+1)],temp3))))))));

				tf -= spu_extract(temp1,0) + spu_extract(temp1,1) + spu_extract(temp1,2) + spu_extract(temp1,3);
				tf2 -= spu_extract(temp2,0) + spu_extract(temp2,1) + spu_extract(temp2,2) + spu_extract(temp2,3);
				tf3 -= spu_extract(temp3,0) + spu_extract(temp3,1) + spu_extract(temp3,2) + spu_extract(temp3,3);
			}

			tf /= bufy[ch][i%32];
			tf2 /= bufy[ch][i%32];
			tf3 /= bufy[ch][i%32];

			bufx[0][i] = tf;
			bufx[1][i] = tf2;
			bufx[2][i] = tf3;
		}

		r = (n-1)/32;
		dmawait(0);

		tf = bufx[0][0];
		tf2 = bufx[1][0];
		tf3 = bufx[2][0];

		tf -= bufx[0][1] * bufy[0][1] + bufx[0][2] * bufy[0][2]+ bufx[0][3] * bufy[0][3];
		tf2 -= bufx[1][1] * bufy[0][1] + bufx[1][2] * bufy[0][2]+ bufx[1][3] * bufy[0][3];
		tf3 -= bufx[2][1] * bufy[0][1] + bufx[2][2] * bufy[0][2]+ bufx[2][3] * bufy[0][3];

		temp1 = temp;
		temp2 = temp;
		temp3 = temp;

		for(j=4;j<32;j+=4){
			temp1 = spu_madd(*(vector float*)&bufx[0][j], *(vector float*)&bufy[0][j], temp1);
			temp2 = spu_madd(*(vector float*)&bufx[1][j], *(vector float*)&bufy[0][j], temp2);
			temp3 = spu_madd(*(vector float*)&bufx[2][j], *(vector float*)&bufy[0][j], temp3);
		}

		tf -= spu_extract(temp1,0) + spu_extract(temp1,1) + spu_extract(temp1,2) + spu_extract(temp1,3);
		tf2 -= spu_extract(temp2,0) + spu_extract(temp2,1) + spu_extract(temp2,2) + spu_extract(temp2,3);
		tf3 -= spu_extract(temp3,0) + spu_extract(temp3,1) + spu_extract(temp3,2) + spu_extract(temp3,3);

		for(j=0;j<r;j++){
			temp1 = temp;
			temp2 = temp;
			temp3 = temp;

			temp1 = spu_madd(*(vector float*)&bufx[0][n-32*(r-j)+28], *(vector float*)&bufy[0][32*(j+1)+28], 
				spu_madd(*(vector float*)&bufx[0][n-32*(r-j)+24], *(vector float*)&bufy[0][32*(j+1)+24],
				spu_madd(*(vector float*)&bufx[0][n-32*(r-j)+20], *(vector float*)&bufy[0][32*(j+1)+20],
				spu_madd(*(vector float*)&bufx[0][n-32*(r-j)+16], *(vector float*)&bufy[0][32*(j+1)+16],
				spu_madd(*(vector float*)&bufx[0][n-32*(r-j)+12], *(vector float*)&bufy[0][32*(j+1)+12],
				spu_madd(*(vector float*)&bufx[0][n-32*(r-j)+8], *(vector float*)&bufy[0][32*(j+1)+8],
				spu_madd(*(vector float*)&bufx[0][n-32*(r-j)+4], *(vector float*)&bufy[0][32*(j+1)+4],
				spu_madd(*(vector float*)&bufx[0][n-32*(r-j)], *(vector float*)&bufy[0][32*(j+1)],temp1))))))));

			temp2 = spu_madd(*(vector float*)&bufx[1][n-32*(r-j)+28], *(vector float*)&bufy[0][32*(j+1)+28], 
				spu_madd(*(vector float*)&bufx[1][n-32*(r-j)+24], *(vector float*)&bufy[0][32*(j+1)+24],
				spu_madd(*(vector float*)&bufx[1][n-32*(r-j)+20], *(vector float*)&bufy[0][32*(j+1)+20],
				spu_madd(*(vector float*)&bufx[1][n-32*(r-j)+16], *(vector float*)&bufy[0][32*(j+1)+16],
				spu_madd(*(vector float*)&bufx[1][n-32*(r-j)+12], *(vector float*)&bufy[0][32*(j+1)+12],
				spu_madd(*(vector float*)&bufx[1][n-32*(r-j)+8], *(vector float*)&bufy[0][32*(j+1)+8],
				spu_madd(*(vector float*)&bufx[1][n-32*(r-j)+4], *(vector float*)&bufy[0][32*(j+1)+4],
				spu_madd(*(vector float*)&bufx[1][n-32*(r-j)], *(vector float*)&bufy[0][32*(j+1)],temp2))))))));

			temp3 = spu_madd(*(vector float*)&bufx[2][n-32*(r-j)+28], *(vector float*)&bufy[0][32*(j+1)+28], 
				spu_madd(*(vector float*)&bufx[2][n-32*(r-j)+24], *(vector float*)&bufy[0][32*(j+1)+24],
				spu_madd(*(vector float*)&bufx[2][n-32*(r-j)+20], *(vector float*)&bufy[0][32*(j+1)+20],
				spu_madd(*(vector float*)&bufx[2][n-32*(r-j)+16], *(vector float*)&bufy[0][32*(j+1)+16],
				spu_madd(*(vector float*)&bufx[2][n-32*(r-j)+12], *(vector float*)&bufy[0][32*(j+1)+12],
				spu_madd(*(vector float*)&bufx[2][n-32*(r-j)+8], *(vector float*)&bufy[0][32*(j+1)+8],
				spu_madd(*(vector float*)&bufx[2][n-32*(r-j)+4], *(vector float*)&bufy[0][32*(j+1)+4],
				spu_madd(*(vector float*)&bufx[2][n-32*(r-j)], *(vector float*)&bufy[0][32*(j+1)],temp3))))))));

			tf -= spu_extract(temp1,0) + spu_extract(temp1,1) + spu_extract(temp1,2) + spu_extract(temp1,3);
			tf2 -= spu_extract(temp2,0) + spu_extract(temp2,1) + spu_extract(temp2,2) + spu_extract(temp2,3);
			tf3 -= spu_extract(temp3,0) + spu_extract(temp3,1) + spu_extract(temp3,2) + spu_extract(temp3,3);
		}

		tf /= bufy[0][0];
		tf2 /= bufy[0][0];
		tf3 /= bufy[0][0];

		bufx[0][0] = tf;
		bufx[1][0] = tf2;
		bufx[2][0] = tf3;

		dmaput((void*)bufx[0],ppe_x+n*sizeof(float)*idx,4*n);
		if(idx+1<m)
			dmaput((void*)bufx[1],ppe_x+n*sizeof(float)*(idx+1),4*n);
		if(idx+2<m)
			dmaput((void*)bufx[2],ppe_x+n*sizeof(float)*(idx+2),4*n);
	}
}

int matrix_distinction(unsigned int ppe_a, int n, int id,
					   unsigned int* ppe_ls, volatile struct spe_sync* sd){
	int h,i,j;
	int l=0,r=0,w=0,length=0;
	int key = 5;
	unsigned int paddr;

	for(i = id;i < n - n%7;i += NUMBER_OF_SPES){
		l=i;
		r=i;
		paddr = ppe_a+n*sizeof(float)*i;
		dmaget((void*)bufy[0], paddr,4*n);
	
		for(j=0;j<i;j++){							
			if(bufy[0][j] != 0.0){
				l = j;
				break;
			}
		}

		for(j=n-1;j>i;j--){ 
			if(bufy[0][j] != 0.0){
				r = j;
				break;
			}
		}
		
		w = (i-l > r-i) ? i-l : r-i;
	
		if(w > length){ 
			length = w;
		}
		if(id == 0){
			for(h=1;h<NUMBER_OF_SPES;h++){
				while(sd[h].pivot_flag != key+2) ;
				if(sd[h].pivot_idx > length){
					length = sd[h].pivot_idx;
				}
			}
			for(h=1;h<NUMBER_OF_SPES;h++){
				sd[h].pivot_flag = key+8;
				sd[h].pivot_idx  = length;
				dmaput((void*)&sd[h],ppe_ls[h]+128*h,128);
			}
			if(length > n/4)return(n);
		}
		else{
			sd[id].pivot_flag = key+2;
			sd[id].pivot_idx  = length;
			dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);
			while(sd[id].pivot_flag != key + 8) ;
			length = sd[id].pivot_idx;
			if(length > n/4)return(n);
		}				
	}

	for(i = n - n%7 + id;i < n - n%7 + 7;i += NUMBER_OF_SPES){
		if(id < n%7){
			l=i;
			r=i;
			paddr = ppe_a+n*sizeof(float)*i;
			dmaget((void*)bufy[0], paddr,4*n);

			for(j=0;j<i;j++){							
				if(bufy[0][j] != 0.0){
					l = j;
					break;
				}
			}

			for(j=n-1;j>i;j--){ 							
				if(bufy[0][j] != 0.0){
					r = j;
					break;
				}
			}

			w = (i-l > r-i) ? i-l : r-i;
	
			if(w > length){ 
				length = w;
			}
		}
		if(id == 0){
			for(h=1;h < NUMBER_OF_SPES;h++){
				while(sd[h].pivot_flag != key+2) ;
				if(sd[h].pivot_idx > length){
					length = sd[h].pivot_idx;
				}
			}
			for(h=1;h<NUMBER_OF_SPES;h++){
				sd[h].pivot_flag = key+8;
				sd[h].pivot_idx  = length;
				dmaput((void*)&sd[h],ppe_ls[h]+128*h,128);
			}
			if(length > n/4)return(n);
		}
		else{
			sd[id].pivot_flag = key+2;
			sd[id].pivot_idx  = length;
			dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);
			while(sd[id].pivot_flag != key + 8) ;
			length = sd[id].pivot_idx;
			if(length > n/4)return(n);
		}				
	}		
	return(length*2);
}

void spe_soleqs(struct spe_ctrl* sc){

    int i, j, k;
    int n,m;
    int id,round;
	float bet;
    unsigned int ppe_a, ppe_b, ppe_x, ppe_c;

    unsigned int ppe_ls[NUMBER_OF_SPES];

    unsigned int ppe_s;
    volatile static struct spe_sync ss _GALIGN;
    volatile static struct spe_sync sd[NUMBER_OF_SPES] _GALIGN;
    
    ss.flag = 0;

    n  = sc->n;
    m  = sc->m;
    id = sc->id;
    ppe_a = sc->buf;
    ppe_b = ppe_a + n * n * sizeof(float);
    ppe_x = ppe_b + n * m * sizeof(float);
    ppe_c = ppe_x + n * m * sizeof(float);
    ppe_s = ppe_c + n * m * sizeof(float);
    
    // for syncronization
    ss.flag = 0XFFFFFFFF;
    ss.addr = (unsigned int)sc->ls_addr[id] + (unsigned int)&sd[0];
    dmaput((void*)&ss, (ppe_s+128*id) , 128);

    // Get addresses for each sharing memory of SPE
    ss.flag = 0;
    for(i=0;i<NUMBER_OF_SPES;i++){
        do{
            dmaget((void*)&ss, (ppe_s+128*i), 128);
        }while(ss.flag != 0XFFFFFFFF);
        ppe_ls[i] = ss.addr;
        ss.flag = 0;
    }

	w = matrix_distinction(ppe_a, n, id, ppe_ls, sd);

	if(w == 2){
		for(j=id;j<m;j+=NUMBER_OF_SPES){

			round=0;

			//�O�i����
			mfc_get(bufx[0],ppe_a,256, 0, 0, 0);

			mfc_get(bufx[2],ppe_b+n*sizeof(float)*j, 256, 9, 0, 0);

			mfc_get(bufx[1],ppe_a+sizeof(float)*n,256, 1, 0, 0);


			mfc_write_tag_mask(1 << 0);
			mfc_write_tag_update_all();
			mfc_read_tag_status();

			mfc_write_tag_mask(1 << 9);
			mfc_write_tag_update_all();
			mfc_read_tag_status();

			bufy[0][0] = bufx[2][0] / (bet = bufx[0][0]);
			bufy[1][0] = bufx[0][1] / bet;

			while(1){
				k = 32*round;
				mfc_get(bufx[0], ppe_a+(k+2)*n*sizeof(float)+k*sizeof(float),256, 0, 0, 0);

				mfc_write_tag_mask(1 << 1);
				mfc_write_tag_update_all();
				mfc_read_tag_status();

				if(round != 0){
					mfc_write_tag_mask(1 << 9);
					mfc_write_tag_update_all();
					mfc_read_tag_status();
				}

				for(i=1;i<30;i++){
					bet = (bufx[i%2][i] - bufy[1][k+i-1] * bufx[i%2][i-1]) * 10;

					bufy[0][k+i] = (bufx[2][i] - bufx[i%2][i-1] * bufy[0][k+i-1])*10/bet;
					bufy[1][k+i] = bufx[i%2][i+1]*10 / bet;

					mfc_get(bufx[i%2], ppe_a+(k+2+i)*n*sizeof(float)+k*sizeof(float),256,i%2,0,0);

					mfc_write_tag_mask(1 << (i+1)%2);
					mfc_write_tag_update_all();
					mfc_read_tag_status();
				}

				bet = bufx[0][30] - bufy[1][k+29] * bufx[0][29];

				bufy[0][k+30] = (bufx[2][30] - bufx[0][29] * bufy[0][k+29]) / bet;
				bufy[1][k+30] = bufx[0][31] / bet;

				if(k+40 > n){
					mfc_write_tag_mask(1 << 1);
					mfc_write_tag_update_all();
					mfc_read_tag_status();

					bet = bufx[1][31] - bufy[1][k+30] * bufx[1][30];
					bufy[0][k+31] = (bufx[2][31] - bufx[1][30] * bufy[0][k+30]) / bet;
					break;
				}

				mfc_get(bufx[0], ppe_a+(k+32)*n*sizeof(float)+k*sizeof(float), 256, 0, 0, 0);

				mfc_write_tag_mask(1<<1);
				mfc_write_tag_update_all();
				mfc_read_tag_status();

				bet = bufx[1][31] - bufy[1][k+30] * bufx[1][30];

				bufy[0][k+31] = (bufx[2][31] - bufx[1][30] * bufy[0][k+30]) / bet;
				bufy[1][k+31] = bufx[1][32] / bet;

				mfc_get(bufx[1], ppe_a+(32*round+33)*n*sizeof(float)+(round+1)*32*sizeof(float),256, 1, 0, 0);

				mfc_write_tag_mask(1<<0);
				mfc_write_tag_update_all();
				mfc_read_tag_status();

				bet = bufx[0][32] - bufy[1][k+31] * bufx[0][31];
				
				round++;

				bufy[0][round*32] = (bufx[2][32] - bufx[0][31] * bufy[0][round*32-1]) / bet;

				mfc_get(bufx[2], ppe_b+n*sizeof(float)*j+round*32*sizeof(float), 256, 9, 0,0);
		
				bufy[1][round*32] = bufx[0][33] / bet;
			}

			for(i=n-2;i>=0;i--){
				bufy[0][i] -= bufy[1][i] * bufy[0][i+1];
			}

			dmaput((void*)bufy[0],ppe_x+n*sizeof(float)*j,4*n);
		}
	}else{  // LU decomposition

		for(i=0;i<n;i++){
			buft[i] = i;
		}

		for(i=0;i<n;i+=block_size){
			if(id == 0){
				for(j=1;j<NUMBER_OF_SPES;j++){
					while(sd[j].pivot_flag != i+8);
				}

				for(j=1;j<NUMBER_OF_SPES;j++){
					sd[j].pivot_flag = i+4;
					dmaput((void*)&sd[j],ppe_ls[j]+128*j,128);
				}
			}else{
				sd[id].pivot_flag = i+8;
				dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);

				while(sd[id].pivot_flag != i+4);
			}

			// right looking LU decomposition 
			spe_lu_blocked(id, (unsigned int)ppe_a, i, n, m, ppe_ls, sd);

			// Syncronization : notates SPE[0] (notice end of the calculation)

			if(id == 0){
				for(j=1;j<NUMBER_OF_SPES;j++){
					while(sd[j].pivot_flag != i+24);
				}
			
				for(j=1;j<NUMBER_OF_SPES;j++){
					sd[j].pivot_flag = i+16;
					dmaput((void*)&sd[j],ppe_ls[j]+128*j,128);
				}
			}else{
				sd[id].pivot_flag = i+24;
				dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);

				while(sd[id].pivot_flag != i+16);
			}
		}

		f_and_b_substitution3(ppe_a, ppe_b, ppe_x, id, n, m);
	}
}
