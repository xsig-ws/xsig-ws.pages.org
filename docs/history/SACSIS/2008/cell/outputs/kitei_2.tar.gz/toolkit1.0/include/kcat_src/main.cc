/*******************************************************/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int no_filename_flag = 0;

/*******************************************************/
void usage(){
  char UsageMessage[] =  "\n\
This is kcat Version 1.1 by Kenji KISE.\n\
kcat prints file contents in a certen format.\n\n\
Usage: kcat [-n] file1 file2 file3 ...\n\n\
";
  printf("%s", UsageMessage); exit(0);
}

/*******************************************************/
void print_file(char *name){
    FILE *fp;
    if((fp = fopen(name, "r")) == NULL) {
        fprintf(stderr, "Bad file name: %s\n", name);
        exit(1);
    }
    
    char buf[4096];
    
    if(no_filename_flag==0){
//        for(int i=0; i<60; i++) printf("-");
        printf("\nfile name: %s\n", name);
    }
    
    int i=1;
    while(1){
        fgets(buf, 4096, fp);
        
        if(feof(fp)) break;
        printf(" %3d  %s", i, buf);
        i++;
    }
    fclose(fp);
}

/*******************************************************/
int main(int argc, char **argv){
    int i;
    int index = 1;
    if(argc==1) usage();
    
    for(i=0; argv[i]!=NULL; i++){
        char opt[1024];
        strcpy(opt, argv[i]);
        if(opt[0]=='-'){
            index = i+1;
            switch(opt[1]){
            case 'n': no_filename_flag=1; break;
            }
        }
    }
    
    for(i=index; i<argc; i++)  print_file(argv[i]);
}
/*******************************************************/
