#ifndef MC_PARAM_64_H_
#define MC_PARAM_64_H_

#define NLINES       64
#define NPARTICLES   4096
#define LAMBDA       4.0f
#define XI           4.0f
#define RCUTOFF      8.0f
#define RDELTA       0.5f
#define DEGDELTA     0.17453294f
#define DIMLEN       202.38577f
#define BLOCKSIZE    12.698522f
#define NLBLOCKS     16
#define MAX_NINBLOCK 64
#define _NSPE        2

#endif // MC_PARAM_64_H_
