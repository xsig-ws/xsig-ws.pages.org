#ifndef BLOCK_H_
#define BLOCK_H_

#include "../SIM_PPU/spe-arg.h"
#include "../SIM_PPU/mc-param.h"

#define DIMLENHALF (DIMLEN * 0.5f)

int is_on_edge(float x, float y);
int get_blockidx(float pos);
int fix_bidx(int idx);
vector float fix_distance(vector float v);
int get_bdist(int a, int b);
int get_bdist_rel(int a, int b);
vector signed short get_bdistv(vector signed short a, vector signed short b);

#endif /*BLOCK_H_*/
