
#include <spu_intrinsics.h>
#include <spu_mfcio.h>

// 本来DMAリストに使うmfc_list_element_t構造体は
// ビットフィールドに関するバグのため使用不可(IBM CBEA forum より)
// バグ発生条件: ビットフィールドに代入する文をspuxlcでコンパイルする
// バグ: ビットフィールドに代入する文は無効になる
typedef struct {
	unsigned short notify;
	unsigned short size;
	unsigned int eal;
} tmp_mfc_list_element_t;
#define mfc_list_element_t tmp_mfc_list_element_t
#define ENABLE_NOTIFY 0x8000

#include <spe_stdio.h>
#include <stdlib.h>
#include <math.h>

#include "particle.h"

typedef unsigned int uint32_t;

#define DIAMETER 1.0f

#define BUF_COUNT 3

#define DIMLENHALF (DIMLEN * 0.5f)
#define RCUTOFFSQ (RCUTOFF*RCUTOFF)

#define TAG_SYN 8
#define TAG_DATAPOS 4

#define VELEM_BL   0
#define VELEM_BC   1
#define VELEM_BI   2
#define VELEM_EDGE 3

typedef union {
	vector signed int v;
	DATAPOS dp;
} uv_int;

///////////////////////////////////////////////////////////////////////////////
// グローバル変数
///////////////////////////////////////////////////////////////////////////////

// eaで始まる変数はメインメモリの実効アドレスを指す
// lsで始まる変数はDMA転送のローカルストア側のバッファ

eaptr_t eapos;
eaptr_t eadeg;
eaptr_t eamag;
eaptr_t eaidx;
eaptr_t eaninblock;

#define caleapos(eapos, i, j) (eapos+((i)*NLBLOCKS+(j))*2*MAX_NINBLOCK*sizeof(float))
#define caleadeg(eadeg, i, j) (eadeg+((i)*NLBLOCKS+(j))*MAX_NINBLOCK*sizeof(float))
#define caleamag(eamag, i, j) (eamag+((i)*NLBLOCKS+(j))*2*MAX_NINBLOCK*sizeof(float))
#define caleaidx(eaidx, i, j) (eaidx+((i)*NLBLOCKS+(j))*MAX_NINBLOCK*sizeof(unsigned int))
#define caleanin(eanin, i, j) (eanin+((i)*NLBLOCKS+(j))*sizeof(NINBLOCK))

eaptr_t eadatapos;
eaptr_t earanddata;

#define caleadatapos(eadatapos, idx) (eadatapos+(idx)*sizeof(DATAPOS))

eaptr_t eadupdata;

volatile float lspos[BUF_COUNT][3][3][2][MAX_NINBLOCK] __attribute__ ((aligned(128)));
volatile float lsdeg[BUF_COUNT][3][3][MAX_NINBLOCK] __attribute__ ((aligned(128)));
volatile float lsmag[BUF_COUNT][3][3][2][MAX_NINBLOCK] __attribute__ ((aligned(128)));
volatile unsigned int lsidx[BUF_COUNT][3][3][MAX_NINBLOCK] __attribute__ ((aligned(128)));
volatile NINBLOCK lsninblock[BUF_COUNT][3][3] __attribute__ ((aligned(128)));
volatile RANDDATA lsranddata[BUF_COUNT] __attribute__ ((aligned(128)));

mfc_list_element_t mlpos[BUF_COUNT][3][3] __attribute__ ((aligned(16)));
mfc_list_element_t mldeg[BUF_COUNT][3][3] __attribute__ ((aligned(16)));
mfc_list_element_t mlmag[BUF_COUNT][3][3] __attribute__ ((aligned(16)));
mfc_list_element_t mlidx[BUF_COUNT][3][3] __attribute__ ((aligned(16)));
mfc_list_element_t mlnin[BUF_COUNT][3][3] __attribute__ ((aligned(16)));

DATAPOS newdatapos[BUF_COUNT] __attribute__ ((aligned(16)));
DATAPOS paddatapos[BUF_COUNT] __attribute__ ((aligned(16)));

int speid;
volatile SPE_SYN_DATA tgsyndata __attribute__ ((aligned(16)));

volatile SPE_INST lsinst __attribute__ ((aligned(16)));

SPE_SYN_DATA lsoutsyndata[MAX_NSPE] __attribute__ ((aligned(16)));
volatile SPE_SYN_DATA lssyndata[MAX_NSPE] __attribute__ ((aligned(16)));
volatile SPE_SYN_DATA *lseasyndata[MAX_NSPE] __attribute__ ((aligned(16)));
mfc_list_element_t mlsyn[MAX_NSPE] __attribute__ ((aligned(16)));

volatile void *lseambin[MAX_NSPE] __attribute__ ((aligned(16)));
volatile void *lseambout[MAX_NSPE] __attribute__ ((aligned(16)));
volatile void *lseambstat[MAX_NSPE] __attribute__ ((aligned(16)));
volatile void *lseasig1[MAX_NSPE] __attribute__ ((aligned(16)));

int dupenable; // 真のときは出力用の複製を転送する
DUPDATA lsdupdata[BUF_COUNT] __attribute__ ((aligned(16)));
void dup(int idx, float x, float y, float deg, int bbuf);

int nstep;

/* デバッグ用 */
int print_overlap = 0;
int test_dep = 0;
int test_ninblock = 16;
int test_rm = 0;
int test_add = 0;
//const int traceA = 2;
//const int traceB = 16257;

///////////////////////////////////////////////////////////////////////////////
// グローバル関数
///////////////////////////////////////////////////////////////////////////////

int is_on_edge(float x, float y);
int get_blockidx(float pos);
int fix_bidx(int idx);
vector float fix_distance(vector float v);
int get_bdist(int a, int b);
int get_bdist_rel(int a, int b);

typedef struct {
	int overlapped; /* 粒子が重なっていたらtrue */
	float energy;
} COM_EN_RESULT;

COM_EN_RESULT com_inter_en(float x, float y, float mx, float my, int idx, int bbuf, int bl, int bc);
COM_EN_RESULT com_energy(float x, float y, float mx, float my, int idx, int bbuf);

COM_EN_RESULT com_den(float x, float y, float deg, float mx, float my, int idx, int bbuf,
          			  float nxtx, float nxty, float nxtdeg, float nxtmx, float nxtmy);

DATAPOS cmd_get_datapos(int idx);


unsigned int randdatabuf;
void cmd_get_randdata(int idx, int bbuf);

void cmd_get_neighbor_block_data(int bl, int bc, int bbuf);

DATAPOS remove_particle(int feabl, int feabc, int flsbl, int flsbc, int flsbi, int flsbuf);
DATAPOS add_particle(int teabl, int teabc, int tlsbl, int tlsbc, int tlsbuf,
						float x, float y, float deg, float mx, float my, int idx);
						
void cmd_send_syn(int prebbuf, int curbbuf);
void cmd_send_syn_rand(int prebbuf, int curbbuf);
void cmd_send_syn_received(int prebbuf, int curbbuf);
void cmd_send_syn_endstep();

void wait_for(uint32_t spe, uint32_t phase);

typedef struct {
	int prefetched;
	int dependency;	
} PREFETCH_RESULT;

typedef struct {
	DATAPOS datapos;
	int padded;
	int padidx;
} MOVE_RESULT;

DATAPOS get_data_immediately(int idx, int curbbuf);

int have_dependency(vector signed int vpre, vector signed int vnxt);
PREFETCH_RESULT prefetch(int nxtidx, int nxtbbuf, int prebbuf, vector signed int vpre, vector signed int vcur, vector signed int vnxt);

uint32_t read_inst();

MOVE_RESULT move(int curidx, int curbbuf, int nxtidx, int nxtbbuf, int prefetched, int dependency, vector signed int vcur, vector signed int vnxt);

///////////////////////////////////////////////////////////////////////////////
// 関数定義
///////////////////////////////////////////////////////////////////////////////

int is_on_edge(float x, float y)
{
	int bl = get_blockidx(y);
	int bc = get_blockidx(x);
	float bx = x - bc*BLOCKSIZE;
	float by = y - bl*BLOCKSIZE;
	return (bx < RDELTA || BLOCKSIZE-RDELTA < bx) || (by < RDELTA || BLOCKSIZE-RDELTA < by);
}

int get_blockidx(float pos)
{
	return (int)(pos / BLOCKSIZE);
}

int fix_bidx(int idx)
{
	return (NLBLOCKS + idx) % NLBLOCKS;	
}

int get_bdist(int a, int b) {
	int ret = b - a;
	if(ret <= -NLBLOCKS/2) {	
		ret += NLBLOCKS;
	} else if(ret > NLBLOCKS/2) {
		ret -= NLBLOCKS;
	}
	
	ret = abs(ret);
	
	return ret;
}

int fix_bdist_rel(int dist) {
	int ret = dist;
	if(ret <= -NLBLOCKS/2) {	
		ret += NLBLOCKS;
	} else if(ret > NLBLOCKS/2) {
		ret -= NLBLOCKS;
	}
	
	return ret;
}

inline vector float cal_distance(vector float v1, vector float v2)
{
	vector float vsub;
	vector float vdimlen;
	vector float vcmpg;
	vector float vcmpl;
	vector float vdadd, vdsub;
	vector unsigned int vresg, vreslt, vreseq, vresle;
	vector float vret;
	
	vsub = spu_sub(v1, v2);
	
	vdimlen = spu_splats(DIMLEN);
	vcmpg = spu_splats(DIMLENHALF);
	vcmpl = spu_splats(-DIMLENHALF);

	vdadd = spu_add(vsub, vdimlen);
	vdsub = spu_sub(vsub, vdimlen);
	
	vresg = spu_cmpgt(vsub, vcmpg);
	vreslt = spu_cmpgt(vcmpl, vsub);
	vreseq = spu_cmpeq(vsub, vcmpl);
	vresle = spu_or(vreslt, vreseq);
	
	vret = spu_sel(vsub, vdadd, vresle);
	vret = spu_sel(vret, vdsub, vresg);
	return vret;
}

inline vector float fix_distance(vector float v)
{
	vector float vdimlen;
	vector float vcmpg;
	vector float vcmpl;
	vector float vdadd, vdsub;
	vector unsigned int vresg, vreslt, vreseq, vresle;
	vector float vret;
	
	vdimlen = spu_splats(DIMLEN);
	vcmpg = spu_splats(DIMLENHALF);
	vcmpl = spu_splats(-DIMLENHALF);

	vdadd = spu_add(v, vdimlen);
	vdsub = spu_sub(v, vdimlen);
	
	vresg = spu_cmpgt(v, vcmpg);
	vreslt = spu_cmpgt(vcmpl, v);
	vreseq = spu_cmpeq(v, vcmpl);
	vresle = spu_or(vreslt, vreseq);
	
	vret = spu_sel(v, vdadd, vresle);
	vret = spu_sel(vret, vdsub, vresg);
	return vret;
}

void set_arg(volatile SPE_ARG *arg)
{
	speid = arg->speid;

	eapos = arg->ppos;
	eadeg = arg->pdeg;
	eamag = arg->pmag;
	eaidx = arg->pidx;
	eaninblock = arg->ninblock;
	eadatapos = arg->pdatapos;
	eadupdata = arg->pdupdata;
        earanddata = arg->pranddata;
	
	randdatabuf = 0;

	nstep = 0;
}

void init_communication()
{
	int i, j;
	eaptr_t eaeasyndata;
	eaptr_t eaeambin, eaeambout, eaeambstat, eaeasig1;

	// 定数がPPUのものと同じ値になっているかどうかを確認する
	// 一致しない場合はPPUが終了処置を行う
	spu_write_out_mbox(NSPE);

	/* 同期をとるためにローカルストアのアドレスを交換する　*/
	spu_write_out_mbox((eaptr_t)&lssyndata);
	spu_write_out_mbox((eaptr_t)&lsinst);
	eaeasyndata = spu_read_in_mbox();
	//spe_printf("SPE(%d): %d %x %x\n", speid, &lssyndata, &lseasyndata, eaeasyndata);
	mfc_get(&lseasyndata, eaeasyndata, sizeof(lseasyndata), TAG_SYN, 0, 0);
	mfc_write_tag_mask(1 << TAG_SYN);
	mfc_read_tag_status_all();
	
	// 同期をとるためのMFCリストコマンドを設定しておく 
	for(i = 0, j = 0; i < NSPE; i++) {
		if(i == speid) {
			continue;
		}

		mlsyn[j].notify = 0;
		mlsyn[j].size	= sizeof(SPE_SYN_DATA);
		mlsyn[j].eal = (uint32_t)&lseasyndata[i][speid];

		//fprintf(stderr, "SPE(%d): spe(%d)'s lssyn address = %x %x %x %d %d %d\n", 
		//		 speid, i, mlsyn[j].eal, temp, tempcmp, mlsyn[j].eal, temp, tempcmp);
		//fprintf(stderr, "SPE(%d): %x %x\n", speid, lseasyndata[i], &lseasyndata[i][speid]);

		j++;
	}
	
	/* メールのやりとりをするためにメールボックスのアドレスを交換する */
	//spe_printf("SPE(%d): get mailbox address\n", speid);
	eaeambin = spu_read_in_mbox();
	mfc_get(&lseambin, eaeambin, sizeof(lseambin), TAG_SYN, 0, 0);
	eaeambout = spu_read_in_mbox();
	mfc_get(&lseambout, eaeambout, sizeof(lseambout), TAG_SYN, 0, 0);
	eaeambstat = spu_read_in_mbox();
	mfc_get(&lseambstat, eaeambstat, sizeof(lseambstat), TAG_SYN, 0, 0);

	// シグナル通知レジスタのアドレスを交換する
	eaeasig1 = spu_read_in_mbox();
	mfc_get(&lseasig1, eaeasig1, sizeof(lseasig1), TAG_SYN, 0, 0);

	mfc_write_tag_mask(1 << TAG_SYN);
	mfc_read_tag_status_all();
	
	//for(i = 0; i < NSPE; i++) {
	//	fprintf(stderr, "SPE(%d): eambstat[%d] = %x, eambin[%d] = %x\n", 
	//	        speid, i, lseambstat[i], i, lseambin[i]);
	//}
	
	//fprintf(stderr, "SPE(%d): eambin addr = %x, eambstat addr = %x\n", speid, eaeambin, eaeambstat);
	
}

/*COM_EN_RESULT com_inter_en(float x, float y, float mx, float my, int idx, int bbuf, int bl, int bc)
{
	vector float vx;
	vector float vy;
	vector float vmx;
	vector float vmy;
	vector signed int vidx;
	vector float vbx0, vby0, vbmx0, vbmy0;
	vector float vbx1, vby1, vbmx1, vbmy1;
	vector signed int vbidx0;
	vector signed int vbidx1;
	vector float vdx0, vdy0; // 距離
	vector float vdx1, vdy1;
	vector float vdysq0; // vdy*vdy
	vector float vdysq1;
	vector float vdsq0; // vdx*vdx + vdy*vdy
	vector float vdsq1;
	vector float vd0; // sqrt(vdsq)
	vector float vd1;
	vector float vred0, vredsq0, vredcb0; // それぞれ距離の逆数、距離の平方の逆数、距離の立方の逆数
	vector float vred1, vredsq1, vredcb1;
	vector float vdxadd0, vdxsub0, vdyadd0, vdysub0; // 周期境界条件で修正後の距離
	vector float vdxadd1, vdxsub1, vdyadd1, vdysub1;
	vector unsigned int vsame0;
	vector unsigned int vsame1;
	vector float vtempdsq;
	vector unsigned int vidxsel0;
	vector unsigned int vidxsel1;
	vector unsigned int voverlap0;
	vector unsigned int voverlap1;
	vector unsigned int vrescoff0, vresgen0;
	vector unsigned int vrescoff1, vresgen1;
	vector float v_3redsq0, v_mxdx0, v_bmxdx0, v_mydy0, v_bmydy0, v_dotmd0, v_dotbmd0, v_dotdot0,
	    v_ie10, v_lredcb0, v_mxbmx0, v_mybmy0, v_dotmbm0, v_dot_sub_ie10, vie0;
	vector float v_3redsq1, v_mxdx1, v_bmxdx1, v_mydy1, v_bmydy1, v_dotmd1, v_dotbmd1, v_dotdot1,
	    v_ie11, v_lredcb1, v_mxbmx1, v_mybmy1, v_dotmbm1, v_dot_sub_ie11, vie1;
	vector float vtie0, vtie1;
	vector signed int vcnt0 = { 0, 1, 2, 3, };
	vector signed int vcnt1 = { 4, 5, 6, 7, };
	vector float vtie;
	vector float vdimlen;
	vector float vcmp;
	vector float vzero;
	vector float vrminsq;
	vector float vcutoff;
	vector float vcutoffsq;
	vector float v3;
	vector float vlambda;
	vector float vtempadd;
	vector signed int vcntadd;
	vector signed int vn;
	vector unsigned int vtoverlap;
	volatile float *bx, *by, *bmx, *bmy;
	volatile unsigned int *bidx;
	float *pv;
	int n;
	float en = 0.0f;
	int i, j, m;
	COM_EN_RESULT ret;
	int overlapped;
	float *pvdsq, *pvred, *pvredsq, *pvredcb, *pvd;
	vector unsigned int voverlap;
	
	vx = spu_splats(x);
	vy = spu_splats(y);
	vmx = spu_splats(mx);
	vmy = spu_splats(my);
	vidx = spu_splats(idx);
	vdimlen = spu_splats(DIMLEN);
	vcmp = spu_splats(DIMLENHALF);
	vzero = spu_splats(0.0f);
	vrminsq = spu_splats(1.0f);
	vcutoff = spu_splats(RCUTOFF);
	vcutoffsq = spu_splats(RCUTOFFSQ);
	v3 = spu_splats(3.0f);
	vlambda = spu_splats(LAMBDA);
	vtempdsq = spu_splats(RCUTOFFSQ+1.0f);
	vtie0 = spu_splats(0.0f);
	vtie1 = spu_splats(0.0f);
	//vcntadd = spu_splats(4);
	vcntadd = spu_splats(8);
	vtoverlap = spu_splats((unsigned int)0);

	bx = lspos[bbuf][bl][bc][POS_X];
	by = lspos[bbuf][bl][bc][POS_Y];
	bmx = lsmag[bbuf][bl][bc][MAG_X];
	bmy = lsmag[bbuf][bl][bc][MAG_Y];
	bidx = lsidx[bbuf][bl][bc];
	n = lsninblock[bbuf][bl][bc].val;
	vn = spu_splats(n);

	//for(i = 0; i < n; i += 4, vcnt = spu_add(vcnt, vcntadd)) {
	for(i = 0; i < n; i += 8, vcnt0 = spu_add(vcnt0, vcntadd), vcnt1 = spu_add(vcnt1, vcntadd)) {
		vbx0 = *(vector float *)&bx[i];
		vby0 = *(vector float *)&by[i];
		vbmx0 = *(vector float *)&bmx[i];
		vbmy0 = *(vector float *)&bmy[i];
		vbidx0 = *(vector signed int *)&bidx[i];
		vbx1 = *(vector float *)&bx[i+4];
		vby1 = *(vector float *)&by[i+4];
		vbmx1 = *(vector float *)&bmx[i+4];
		vbmy1 = *(vector float *)&bmy[i+4];
		vbidx1 = *(vector signed int *)&bidx[i+4];
		
		// 距離を求める
		vdx0 = cal_distance(vbx0, vx);
		vdy0 = cal_distance(vby0, vy);
		vdx1 = cal_distance(vbx1, vx);
		vdy1 = cal_distance(vby1, vy);
		
		// 距離の平方を求める
		vdysq0 = spu_mul(vdy0, vdy0);
		vdsq0 = spu_madd(vdx0, vdx0, vdysq0);
		vdysq1 = spu_mul(vdy1, vdy1);
		vdsq1 = spu_madd(vdx1, vdx1, vdysq1);

		// 同一の粒子間で計算されるときと、インデックスがn以上のときは
		// 距離をカットオフ距離より離れているものと設定してエネルギーの値を 0 にする
		vidxsel0 = spu_cmpgt(vn, vcnt0);
		vsame0 = spu_cmpeq(vbidx0, vidx);
		vdsq0 = spu_sel(vdsq0, vtempdsq, vsame0);
		vdsq0 = spu_sel(vtempdsq, vdsq0, vidxsel0);
		vidxsel1 = spu_cmpgt(vn, vcnt1);
		vsame1 = spu_cmpeq(vbidx1, vidx);
		vdsq1 = spu_sel(vdsq1, vtempdsq, vsame1);
		vdsq1 = spu_sel(vtempdsq, vdsq1, vidxsel1);
		
		// 重なる部分があればエネルギーの値は定義無し
		voverlap0 = spu_cmpgt(vrminsq, vdsq0);
		vtoverlap = spu_or(voverlap0, vtoverlap);
		voverlap1 = spu_cmpgt(vrminsq, vdsq1);
		vtoverlap = spu_or(voverlap1, vtoverlap);

		// 距離の逆数を求める
		vred0 = spu_rsqrte(vdsq0);
		vred1 = spu_rsqrte(vdsq1);
		
		// 距離の平方の逆数を求める
		vredsq0 = spu_re(vdsq0);
		vredsq1 = spu_re(vdsq1);
		
		// 距離の立方の逆数を求める
		vredcb0 = spu_mul(vred0, vredsq0);
		vredcb1 = spu_mul(vred1, vredsq1);
		
		// 元の式
		// ie1 = 3.0 * (mx*dx + my*dy) * (bmx*dx + bmy*dy) * redsq;
		// ie = LAMBDA * (mx*bmx + my*bmy - ie1) * redcb;
		v_3redsq0 = spu_mul(v3, vredsq0);
		v_mxdx0 = spu_mul(vmx, vdx0);
		v_mydy0 = spu_mul(vmy, vdy0);
		v_bmxdx0 = spu_mul(vbmx0, vdx0);
		v_bmydy0 = spu_mul(vbmy0, vdy0);
		v_dotmd0 = spu_add(v_mxdx0, v_mydy0);
		v_dotbmd0 = spu_add(v_bmxdx0, v_bmydy0);
		v_dotdot0 = spu_mul(v_dotmd0, v_dotbmd0);
		v_ie10 = spu_mul(v_3redsq0, v_dotdot0);
		v_lredcb0 = spu_mul(vlambda, vredcb0);
		v_mxbmx0 = spu_mul(vmx, vbmx0);
		v_mybmy0 = spu_mul(vmy, vbmy0);
		v_dotmbm0 = spu_add(v_mxbmx0, v_mybmy0);
		v_dot_sub_ie10 = spu_sub(v_dotmbm0, v_ie10);
		vie0 = spu_mul(v_lredcb0, v_dot_sub_ie10);
		v_3redsq1 = spu_mul(v3, vredsq1);
		v_mxdx1 = spu_mul(vmx, vdx1);
		v_mydy1 = spu_mul(vmy, vdy1);
		v_bmxdx1 = spu_mul(vbmx1, vdx1);
		v_bmydy1 = spu_mul(vbmy1, vdy1);
		v_dotmd1 = spu_add(v_mxdx1, v_mydy1);
		v_dotbmd1 = spu_add(v_bmxdx1, v_bmydy1);
		v_dotdot1 = spu_mul(v_dotmd1, v_dotbmd1);
		v_ie11 = spu_mul(v_3redsq1, v_dotdot1);
		v_lredcb1 = spu_mul(vlambda, vredcb1);
		v_mxbmx1 = spu_mul(vmx, vbmx1);
		v_mybmy1 = spu_mul(vmy, vbmy1);
		v_dotmbm1 = spu_add(v_mxbmx1, v_mybmy1);
		v_dot_sub_ie11 = spu_sub(v_dotmbm1, v_ie11);
		vie1 = spu_mul(v_lredcb1, v_dot_sub_ie11);

		// カットオフ距離以遠の場合はエネルギーの値を 0 にする
		vrescoff0 = spu_cmpgt(vcutoffsq, vdsq0);
		vie0 = spu_sel(vzero, vie0, vrescoff0);
		vrescoff1 = spu_cmpgt(vcutoffsq, vdsq1);
		vie1 = spu_sel(vzero, vie1, vrescoff1);
		
		vtie0 = spu_add(vtie0, vie0);
		vtie1 = spu_add(vtie1, vie1);
	}
	
	//vtie = vtie0;
	vtie = spu_add(vtie0, vtie1);

	vtoverlap = spu_gather(vtoverlap);
	overlapped = spu_extract(vtoverlap, 0);
	if(__builtin_expect(overlapped, 0)) {
		ret.overlapped = 1;
		return ret;	
	}

	pv = (float *)&vtie;
	en = pv[0] + pv[1] + pv[2] + pv[3];

	ret.overlapped = 0;
	ret.energy = en;
	return ret;
}*/

/**
 * 粒子間の相互作用のエネルギーを計算する。
 * x, y, mx, my, idx: 粒子のパラメータ
 * bbuf: 対象のブロック
 */
COM_EN_RESULT com_inter_en(float x, float y, float mx, float my, int idx, int bbuf, int bl, int bc)
{
	vector float vx;
	vector float vy;
	vector float vmx;
	vector float vmy;
	vector signed int vidx;
	vector float vbx, vby, vbmx, vbmy;
	vector signed int vbidx;
	vector float vdx, vdy; // 距離
	vector float vdysq; // vdy*vdy
	vector float vdsq; // vdx*vdx + vdy*vdy
	vector float vred, vredsq, vredcb; // それぞれ距離の逆数、距離の平方の逆数、距離の立方の逆数
	vector float vdimlen;
	vector float vcmp;
	vector float vzero;
	vector float vrminsq;
	vector float vcutoff;
	vector float vcutoffsq;
	vector float v3;
	vector float vlambda;
	vector float vtempdsq;
	vector unsigned int vsame;
	vector float vtie;
	vector unsigned int voverlap;
	vector unsigned int vrescoff, vrescoff_gt, vrescoff_eq;
	volatile float *bx, *by, *bmx, *bmy;
	volatile unsigned int *bidx;
	float *pv;
	vector float v_3redsq, v_mxdx, v_bmxdx, v_mydy, v_bmydy, v_dotmd, v_dotbmd, v_dotdot,
	    v_ie1, v_lredcb, v_mxbmx, v_mybmy, v_dotmbm, v_dot_sub_ie1, vie;
	unsigned int n;
	float en = 0.0f;
	int i, j, m;
	COM_EN_RESULT ret;
	int overlapped;
	vector signed int vcnt = { 0, 1, 2, 3, };
	vector signed int vcntadd;
	vector unsigned int vidxsel;
	vector signed int vn;

	vx = spu_splats(x);
	vy = spu_splats(y);
	vmx = spu_splats(mx);
	vmy = spu_splats(my);
	vidx = spu_splats(idx);
	vdimlen = spu_splats(DIMLEN);
	vcmp = spu_splats(DIMLENHALF);
	vzero = spu_splats(0.0f);
	vrminsq = spu_splats(1.0f);
	vcutoff = spu_splats(RCUTOFF);
	vcutoffsq = spu_splats(RCUTOFFSQ);
	v3 = spu_splats(3.0f);
	vlambda = spu_splats(LAMBDA);
	vtempdsq = spu_splats(RCUTOFFSQ+1.0f);
	vtie = spu_splats(0.0f);
	vcntadd = spu_splats(4);
	
	bx = lspos[bbuf][bl][bc][POS_X];
	by = lspos[bbuf][bl][bc][POS_Y];
	bmx = lsmag[bbuf][bl][bc][MAG_X];
	bmy = lsmag[bbuf][bl][bc][MAG_Y];
	bidx = lsidx[bbuf][bl][bc];
	n = lsninblock[bbuf][bl][bc].val;
	vn = spu_splats((int)n);

	// ループの終了条件は n が 4 の倍数でないときの処理を行うために後で判定する
	for(i = 0; ; i += 4, vcnt = spu_add(vcnt, vcntadd)) {
		vbx = *(vector float *)&bx[i];
		vby = *(vector float *)&by[i];
		vbmx = *(vector float *)&bmx[i];
		vbmy = *(vector float *)&bmy[i];
		vbidx = *(vector signed int *)&bidx[i];
		
		// 距離を求める
		vdx = cal_distance(vbx, vx);
		vdy = cal_distance(vby, vy);
		//vdx = spu_sub(vbx, vx);
		//vdy = spu_sub(vby, vy);
		//vdx = fix_distance(vdx);
		//vdy = fix_distance(vdy);

		// 距離の平方を求める
		vdysq = spu_mul(vdy, vdy);
		vdsq = spu_madd(vdx, vdx, vdysq);

		// 同一の粒子間で計算されるときと、インデックスがn以上のときは
		// 距離をカットオフ距離より離れているものと設定してエネルギーの値を 0 にする
		vidxsel = spu_cmpgt(vn, vcnt);
		vsame = spu_cmpeq(vbidx, vidx);
		vdsq = spu_sel(vdsq, vtempdsq, vsame);
		vdsq = spu_sel(vtempdsq, vdsq, vidxsel);

		// 重なる部分があればエネルギーの値は定義無し
		voverlap = spu_cmpgt(vrminsq, vdsq);
		overlapped = spu_extract(spu_gather(voverlap), 0);
		
		//if(idx == 3277) {
		//	for(j = 0; j < 4; j++) {
		//		if(bidx[i+j] == 3405 && i+j < n) {
		//			fprintf(stderr, "(3277-3405)dsq=%f,pos=%d,%d\n", spu_extract(vdsq, j), i+j, n);				
		//		}
		//	}
		//}
		//if(idx == 3405) {
		//	for(j = 0; j < 4; j++) {
		//		if(bidx[i+j] == 3277 && i+j < n) {
		//			fprintf(stderr, "(3405-3277)dsq=%f,pos=%d,%d\n", spu_extract(vdsq, j), i+j, n);				
		//		}
		//	}
		//}

		if(__builtin_expect(overlapped, 0)) {
			ret.overlapped = 1;
			if(__builtin_expect(print_overlap, 0)) {
				for(j = 0; j < 4 && i+j < n; j++) {
					if(spu_extract(voverlap, j)) {
						spe_printf("n=%d, i=%d, j=%d, %d,%d (%f,%f) - (%f,%f) overlapped, dsq=%f\n", 
								 n, i, j,
								 idx, bidx[i+j],
								 x, y, bx[i+j], by[i+j],
								 spu_extract(vdsq, j));
					}
				}
			}
			return ret;
		}

		// 距離の逆数を求める
		vred = spu_rsqrte(vdsq);
		
		// 距離の平方の逆数を求める
		vredsq = spu_re(vdsq);
		
		// 距離の立方の逆数を求める
		vredcb = spu_mul(vred, vredsq);
		
		// 元の式
		// ie1 = 3.0 * (mx*dx + my*dy) * (bmx*dx + bmy*dy) * redsq;
		// ie = LAMBDA * (mx*bmx + my*bmy - ie1) * redcb;
		
		v_3redsq = spu_mul(v3, vredsq);
		v_mxdx = spu_mul(vmx, vdx);
		v_mydy = spu_mul(vmy, vdy);
		v_bmxdx = spu_mul(vbmx, vdx);
		v_bmydy = spu_mul(vbmy, vdy);
		v_dotmd = spu_add(v_mxdx, v_mydy);
		v_dotbmd = spu_add(v_bmxdx, v_bmydy);
		v_dotdot = spu_mul(v_dotmd, v_dotbmd);
		v_ie1 = spu_mul(v_3redsq, v_dotdot);
		v_lredcb = spu_mul(vlambda, vredcb);
		v_mxbmx = spu_mul(vmx, vbmx);
		v_mybmy = spu_mul(vmy, vbmy);
		v_dotmbm = spu_add(v_mxbmx, v_mybmy);
		v_dot_sub_ie1 = spu_sub(v_dotmbm, v_ie1);
		vie = spu_mul(v_lredcb, v_dot_sub_ie1);

		// カットオフ距離以遠の場合はエネルギーの値を 0 にする
		vrescoff_gt = spu_cmpgt(vdsq, vcutoffsq);
		vrescoff_eq = spu_cmpeq(vdsq, vcutoffsq);
		vrescoff = spu_or(vrescoff_gt, vrescoff_eq);
		vie = spu_sel(vie, vzero, vrescoff);

		// 残りがなくなったらループ終了
		if(i+4 >= n) {
			break;
		}

		vtie = spu_add(vtie, vie);
	}

	// 最後の vie から有効な部分だけを取り出してエネルギーの値に加える。
	pv = (float *)&vie;
	m = n - i;
	for(i = 0; i < m; i++) {
		en += pv[i];
	}
	
	pv = (float *)&vtie;
	en += pv[0] + pv[1] + pv[2] + pv[3];

	ret.overlapped = 0;
	ret.energy = en;
	return ret;
}

//int check = 0;
/**
 * 指定した粒子のエネルギーを計算する。
 * x, y, mx, my, idx: 配列中の値の代わりに使うパラメータ
 */
COM_EN_RESULT com_energy(float x, float y, float mx, float my, int idx, int bbuf)
{
	int i, j;
	float en;
	COM_EN_RESULT result, ret;
	int overlap_count;
	
	en = - XI * my;

	for(i = 0; i < 3; i++) {
		overlap_count = 0;
		for(j = 0; j < 3; j++) {
			result = com_inter_en(x, y, mx, my, idx, bbuf, i, j);
			if(result.overlapped) {
				ret.overlapped = 1;
				return ret;
			} else {
				en += result.energy;
			}
		}
	}

	ret.overlapped = 0;
	ret.energy = en;
	return ret;
}

COM_EN_RESULT com_den(float x, float y, float deg, float mx, float my, int idx, int bbuf,
       			     float nxtx, float nxty, float nxtdeg, float nxtmx, float nxtmy)
{
	COM_EN_RESULT result, ret;
	float curen, nxten, den;

	// 移動前のエネルギーを計算する
	print_overlap = 1;
	result = com_energy(x, y, mx, my, idx, bbuf);
	curen = result.energy;
	if(__builtin_expect((result.overlapped), 0)) {
		spe_printf("SPE(%d): step(%d) particles overlapped before moving\n", speid, nstep);
		spe_printf("SPE(%d): param %f %f %f %f %d %d\n", speid, x, y, mx, my, idx, bbuf);
		//exit(1);
	}
	print_overlap = 0;

	result = com_energy(nxtx, nxty, nxtmx, nxtmy, idx, bbuf);
	nxten = result.energy;
	den = nxten - curen;

	ret.overlapped = result.overlapped;
	ret.energy = den;
	return ret;
}

DATAPOS cmd_get_datapos(int idx)
{
	volatile DATAPOS lsdatapos __attribute__ ((aligned(16)));

	// 粒子の位置を得る
	mfc_get(&lsdatapos, caleadatapos(eadatapos, idx), sizeof(lsdatapos), TAG_DATAPOS, 0, 0);
	mfc_write_tag_mask(1 << TAG_DATAPOS);
	mfc_read_tag_status_all();

	return lsdatapos;
}

void cmd_get_randdata(int idx, int bbuf)
{
	//spe_printf("get randdata from %d\n", (earanddata + randdatabuf*NPARTICLES + idx)*sizeof(RANDDATA));
	mfc_get(&lsranddata[bbuf], earanddata + (randdatabuf*NPARTICLES + idx)*sizeof(RANDDATA), sizeof(lsranddata[bbuf]), bbuf, 0, 0);	
}

/**
 * 粒子番号idxの粒子の周辺のブロックを読み込む。
 */
void cmd_get_neighbor_block_data(int bl, int bc, int bbuf)
{
	int i, j;
	int ibl, ibc;

	// 周辺ブロックのデータを得る
	for(i = 0; i < 3; i++) {
		for(j = 0; j < 3; j++) {
			mlpos[bbuf][i][j].notify = mldeg[bbuf][i][j].notify = mlmag[bbuf][i][j].notify = mlidx[bbuf][i][j].notify = mlnin[bbuf][i][j].notify = 0;
			mlpos[bbuf][i][j].size = sizeof(lspos[bbuf][i][j]);
			mldeg[bbuf][i][j].size = sizeof(lsdeg[bbuf][i][j]);
			mlmag[bbuf][i][j].size = sizeof(lsmag[bbuf][i][j]);
			mlidx[bbuf][i][j].size = sizeof(lsidx[bbuf][i][j]);
			mlnin[bbuf][i][j].size = sizeof(lsninblock[bbuf][i][j]);
			ibl = fix_bidx(bl-1 + i);
			ibc = fix_bidx(bc-1 + j);
			mlpos[bbuf][i][j].eal = caleapos(eapos, ibl, ibc);
			mldeg[bbuf][i][j].eal = caleadeg(eadeg, ibl, ibc);
			mlmag[bbuf][i][j].eal = caleamag(eamag, ibl, ibc);
			mlidx[bbuf][i][j].eal = caleaidx(eaidx, ibl, ibc);
			mlnin[bbuf][i][j].eal = caleanin(eaninblock, ibl, ibc);
		}
	}

	mfc_getl(&lspos[bbuf], 0, &mlpos[bbuf], sizeof(mlpos[bbuf]), bbuf, 0, 0);
	mfc_getl(&lsdeg[bbuf], 0, &mldeg[bbuf], sizeof(mldeg[bbuf]), bbuf, 0, 0);
	mfc_getl(&lsmag[bbuf], 0, &mlmag[bbuf], sizeof(mlmag[bbuf]), bbuf, 0, 0);
	mfc_getl(&lsidx[bbuf], 0, &mlidx[bbuf], sizeof(mlidx[bbuf]), bbuf, 0, 0);
	mfc_getl(&lsninblock[bbuf], 0, &mlnin[bbuf], sizeof(mlnin[bbuf]), bbuf, 0, 0);
}

/**
 * ブロックから粒子を取り除く
 * flsbl, flsbc, flsbi, flsbuf: 対象の粒子の場所
 * 戻り値: データを詰めるために移動した粒子の情報
 */
DATAPOS remove_particle(int feabl, int feabc, int flsbl, int flsbc, int flsbi, int flsbuf)
{
	DATAPOS datapos;
	int pad;

	lsninblock[flsbuf][flsbl][flsbc].val--;
	pad = lsninblock[flsbuf][flsbl][flsbc].val;

	//if(feabl == 13 && feabc == 3 && !test_dep) {
	//	test_ninblock--;
	//	test_rm++;
	//	fprintf(stderr, "SPE(%d): %d step (%d) remove from (%d, %d, %d), aft_n=%d,test=%d,d=%d\n", speid, nstep,
	//			 lsidx[flsbuf][flsbl][flsbc][flsbi], feabl, feabc, flsbi, 
	//			 lsninblock[flsbuf][flsbl][flsbc].val, test_ninblock, test_add-test_rm);
	//}

	if(pad == flsbi || flsbi > lsninblock[flsbuf][flsbl][flsbc].val) {
		datapos.bline = -1;
		return datapos;
	}
	
	//if(feabl == 13 && feabc == 3 && !test_dep) {
	//	fprintf(stderr, "SPE(%d): %d step (%d) (%d, %d, %d) move to (%d, %d, %d)\n",
	//			 speid, nstep, lsidx[flsbuf][flsbl][flsbc][pad],
	//			 feabl, feabc, pad, feabl, feabc, flsbi);
	//}
	
	//if(lsidx[flsbuf][flsbl][flsbc][flsbi] == traceA || lsidx[flsbuf][flsbl][flsbc][flsbi] == traceB) {
	//	fprintf(stderr, "SPE(%d): (%d) remove from (%d, %d)\n", speid,
	//			 lsidx[flsbuf][flsbl][flsbc][flsbi], feabl, feabc);	
	//}
	
	//if(lsidx[flsbuf][flsbl][flsbc][pad] == traceA || lsidx[flsbuf][flsbl][flsbc][pad] == traceB) {
	//	fprintf(stderr, "SPE(%d): (%d) move to (%d, %d, %d)\n", speid,
	//			 lsidx[flsbuf][flsbl][flsbc][pad], feabl, feabc, flsbi);			
	//}

	lspos[flsbuf][flsbl][flsbc][POS_X][flsbi] = lspos[flsbuf][flsbl][flsbc][POS_X][pad];
	lspos[flsbuf][flsbl][flsbc][POS_Y][flsbi] = lspos[flsbuf][flsbl][flsbc][POS_Y][pad];
	lsdeg[flsbuf][flsbl][flsbc][flsbi] = lsdeg[flsbuf][flsbl][flsbc][pad];
	lsmag[flsbuf][flsbl][flsbc][MAG_X][flsbi] = lsmag[flsbuf][flsbl][flsbc][MAG_X][pad];
	lsmag[flsbuf][flsbl][flsbc][MAG_Y][flsbi] = lsmag[flsbuf][flsbl][flsbc][MAG_Y][pad];
	lsidx[flsbuf][flsbl][flsbc][flsbi] = lsidx[flsbuf][flsbl][flsbc][pad];
	
	datapos.bline = feabl;
	datapos.bcol = feabc;
	datapos.bidx = flsbi;
	datapos.on_edge = is_on_edge(lspos[flsbuf][flsbl][flsbc][POS_X][flsbi], lspos[flsbuf][flsbl][flsbc][POS_Y][flsbi]);

	return datapos;
}

/**
 * ブロックに粒子を加える
 * tlsbl, tlsbc, tlsbuf: 対象のブロックの場所
 * x, y, deg, mx, my, idx: 粒子の情報
 * 戻り値: 粒子の新しい情報
 * */
DATAPOS add_particle(int teabl, int teabc, int tlsbl, int tlsbc, int tlsbuf,
					 float x, float y, float deg, float mx, float my, int idx)
{
	DATAPOS datapos;
	int tlsbi = lsninblock[tlsbuf][tlsbl][tlsbc].val;
	lsninblock[tlsbuf][tlsbl][tlsbc].val++;

	//if(teabl == 13 && teabc == 3 && !test_dep) {
	//	test_ninblock++;
	//	test_add++;
	//	fprintf(stderr, "SPE(%d): %d step (%d) add to (%d, %d, %d),aft_n=%d,test=%d,d=%d\n", speid, nstep, 
	//			 idx, teabl, teabc, tlsbi, 
	//			 lsninblock[tlsbuf][tlsbl][tlsbc].val+1, test_ninblock, test_add-test_rm);	
	//}

	//if(idx == traceA || idx == traceB) {
	//	fprintf(stderr, "SPE(%d): (%d) add to (%d, %d, %d)\n", speid,
	//			 idx, teabl, teabc, tlsbi);	
	//}

	lspos[tlsbuf][tlsbl][tlsbc][POS_X][tlsbi] = x;
	lspos[tlsbuf][tlsbl][tlsbc][POS_Y][tlsbi] = y;
	lsdeg[tlsbuf][tlsbl][tlsbc][tlsbi] = deg;
	lsmag[tlsbuf][tlsbl][tlsbc][MAG_X][tlsbi] = mx;
	lsmag[tlsbuf][tlsbl][tlsbc][MAG_Y][tlsbi] = my;
	lsidx[tlsbuf][tlsbl][tlsbc][tlsbi] = idx;
	
	//fprintf(stderr, "SPE(%d): (%d, %d) ninblock = %d\n", 
	//		 speid, teabl, teabc, lsninblock[tlsbuf][tlsbl][tlsbc].val);
	/*if(__builtin_expect((lsninblock[tlsbuf][tlsbl][tlsbc].val >= MAX_NINBLOCK), 0)) {
		fprintf(stderr, "SPE(%d): Too many particles in a block(%d, %d).\n", speid, teabl, teabc);
		fprintf(stderr, "SPE(%d): (%d, %d) val = %d\n", speid, teabl, teabc, lsninblock[tlsbuf][tlsbl][tlsbc].val);
		exit(1);
	}*/

	datapos.bline = teabl;
	datapos.bcol = teabc;
	datapos.bidx = tlsbi;
	datapos.on_edge = 1;
	
	return datapos;
}

void cmd_send_syn(int prebbuf, int curbbuf)
{
	int i;
	
	mfc_write_tag_mask(1 << prebbuf);
	mfc_read_tag_status_all();

	lssyndata[speid].phase++;
	for(i = 0; i < NSPE; i++) {
		lsoutsyndata[i] = lssyndata[speid];
	}

	mfc_sync(curbbuf);
	mfc_putl(&lsoutsyndata, 0, &mlsyn, sizeof(mlsyn[0])*(NSPE-1), curbbuf, 0, 0);

	//fprintf(stderr, "SPE(%d): syn %d\n", speid, lssyndata[speid].synstep);
	//fprintf(stderr, "SPE(%d): syn %d %d %d %d\n",
	//		 speid,
	//		 lssyndata[0].synstep,
	//		 lssyndata[1].synstep,
	//		 lssyndata[2].synstep,
	//		 lssyndata[3].synstep);
}

void cmd_send_syn_received(int prebbuf, int curbbuf)
{
	mfc_write_tag_mask((1 << prebbuf) | (1 << curbbuf));
	mfc_read_tag_status_all();

	lsoutsyndata[0] = lssyndata[speid];

	mfc_eieio(curbbuf, 0, 0);
	mfc_putl(&lsoutsyndata[0], 0, &mlsyn[NSPE-1], sizeof(mlsyn[NSPE-1]), curbbuf, 0, 0);
}

void cmd_send_syn_endstep()
{
	lssyndata[speid].endstep++;
	lsoutsyndata[0] = lssyndata[speid];
	
	mfc_putl(&lsoutsyndata[0], 0, &mlsyn[NSPE-1], sizeof(mlsyn[NSPE-1]), 0, 0, 0);
	
	mfc_write_tag_mask(1 << 0);
	mfc_read_tag_status_all();	
}

void wait_for(uint32_t spe, uint32_t phase)
{
	int wait;
	//fprintf(stderr, "SPE(%d): waiting for spe %d phase %d, current %d\n", speid, spe, phase, lssyndata[spe].synstep);
	do {
		wait = (lssyndata[spe].phase < phase);
	} while(wait);
}

int inst_remain()
{
	return (lsinst.count > lssyndata[speid].ninstreceived);
}

uint32_t read_inst()
{
	int wait;
	do {
		wait = !inst_remain();
	} while(wait);

	return lsinst.array[lssyndata[speid].ninstreceived++ % INST_ARRAY_SIZE];
}

void dup(int idx, float x, float y, float deg, int bbuf)
{
	lsdupdata[bbuf].x = x;
	lsdupdata[bbuf].y = y;
	lsdupdata[bbuf].deg = deg;
	mfc_put(&lsdupdata[bbuf], eadupdata + idx*sizeof(DUPDATA), sizeof(DUPDATA), bbuf, 0, 0);
}

/**
 * 粒子を移動する
 */
MOVE_RESULT move(int curidx, int curbbuf, int nxtidx, int nxtbbuf, int prefetched, int dependency, vector signed int vcur, vector signed int vnxt)
{
	float x, y, deg, mx, my;
	float dx, dy, ddeg;
	float nx, ny, ndeg, nmx, nmy;
	float den;
	COM_EN_RESULT result;
	int newlsbl, newlsbc, dbl, dbc;
	int padidx;
	//int *pcur = (int *)&vcur;
	//int *curbl = &pcur[0];
	//int *curbc = &pcur[1];
	//int *curbi = &pcur[2];
        int curbl = spu_extract(vcur, 0);
        int curbc = spu_extract(vcur, 1);
        int curbi = spu_extract(vcur, 2);
	int nxtbl = spu_extract(vnxt, 0);
	int nxtbc = spu_extract(vnxt, 1);
	int distbl;
	int distbc;
	int nxtlsbl, nxtlsbc, nxtlsfbl, nxtlsfbc, nxtlstbl, nxtlstbc;
	vector signed int vnewbpos;
        int newbl;
        int newbc;
	vector signed int vcurbpos;
	vector signed int vdbpos;
	const vector signed int vzero = { 0, 0, 0, 0 };
	const vector unsigned int vsel = { 0, 0, 1, 1 };
	MOVE_RESULT mvresult __attribute__ ((aligned(16)));

	mfc_write_tag_mask(1 << curbbuf);
	mfc_read_tag_status_all();

	x = lspos[curbbuf][1][1][POS_X][curbi];
	y = lspos[curbbuf][1][1][POS_Y][curbi];
	deg = lsdeg[curbbuf][1][1][curbi];
	mx = lsmag[curbbuf][1][1][MAG_X][curbi];
	my = lsmag[curbbuf][1][1][MAG_Y][curbi];
		
	// 粒子の移動先を確定する
	dx = (lsranddata[curbbuf].x - 0.5f) * 2.0f * RDELTA;
	dy = (lsranddata[curbbuf].y - 0.5f) * 2.0f * RDELTA;
	ddeg = (lsranddata[curbbuf].deg - 0.5f) * 2.0f * DEGDELTA;
	nx = x + dx;
	ny = y + dy;
	ndeg = deg + ddeg;
	nmx = cosf(ndeg);
	nmy = sinf(ndeg);

    // 周期境界条件に従って値をそれぞれの範囲内に収める
	if(nx >= DIMLEN) {
		nx -= DIMLEN;
	} else if(nx < 0.0) {
		nx += DIMLEN;
	}
	if(ny >= DIMLEN) {
		ny -= DIMLEN;
	} else if(ny < 0.0) {
		ny += DIMLEN;
	}
	
	//if(lsninblock[curbbuf][1][1].val <= *curbi) {
	//	fprintf(stderr, "(%d) %d n mismatch(%d/%d),(%d,%d)\n", 
	//			 nstep, curidx, curbi, lsninblock[curbbuf][1][1].val,
	//			 curbl, curbc);
	//}
	
	/*if((nstep == 231) && (curidx == 3341)) {
		int i;
		int n = lsninblock[curbbuf][1][1].val;
		fprintf(stderr, "before %d\n", nstep);
		for(i = 0; i < n; i++) {
			fprintf(stderr, "(%d) %d %f %f\n", i, 
					 lsidx[curbbuf][1][1][i], 
					 lspos[curbbuf][1][1][POS_X][i],
					 lspos[curbbuf][1][1][POS_Y][i]);
		}
	}*/
	
	result = com_den(x, y, deg, mx, my, curidx, curbbuf,
					   nx, ny, ndeg, nmx, nmy);

	//fprintf(stderr, "selection\n");
	
	den = result.energy;
	//if(nstep == 87 && curidx == 307) {
	//	fprintf(stderr, "den=%f, overlapped = %d\n", den, result.overlapped);
	//	fprintf(stderr, "nxt x=%f, y=%f, deg=%f\n", nx, ny, ndeg);
	//}
	//if(curidx == 3277 || curidx == 3405) {
	//	fprintf(stderr, "(%d) idx=%d, (%f,%f) -> (%f,%f)\n", nstep, curidx, x, y, nx, ny);
	//}

	if(result.overlapped || (den >= 0.0 && lsranddata[curbbuf].sel >= expf(-den))) {
		/* エネルギーが計算できないとき、または乱数で状態遷移しないと決定したとき */
		//if(nstep > trace_step) {
		//	if(curidx == traceA || curidx == traceB) {
		//		fprintf(stderr, "SPE(%d): (%d) not moved\n", speid, curidx);	
		//	}
		//}
		
		//if(curidx == 3277 || curidx == 3405) {
		//	fprintf(stderr, "(%d) idx=%d, not moved\n", nstep, curidx);
		//}
		
		//if(nstep == 87 && curidx == 307) {
		//	fprintf(stderr, "not moved den=%f, overlapped = %d\n", den, result.overlapped);
		//}

		//if(nstep == 10) {
		//	fprintf(stderr, "%d %f %f %f\n", curidx, x, y, deg);
		//}
		if(__builtin_expect(dupenable, 0)) {
			dup(curidx, x, y, deg, curbbuf);	
		}
		
		mvresult.padded = 0;
		mvresult.padidx = -1;
		return mvresult;
	} else {
		/* 状態遷移する。 */

		//if(nstep > trace_step) {
		//	if(curidx == traceA || curidx == traceB) {
		//		fprintf(stderr, "SPE(%d): (%d) not moved\n", speid, curidx);	
		//	}
		//}
		//if(nstep == 87 && curidx == 307) {
		//	fprintf(stderr, "moved den=%f, overlapped = %d\n", den, result.overlapped);
		//}

		//if(nstep == 10) {
		//	fprintf(stderr, "%d %f %f %f\n", curidx, nx, ny, ndeg);
		//}

		if(__builtin_expect(dupenable, 0)) {
			dup(curidx, nx, ny, ndeg, curbbuf);	
		}

		vnewbpos = spu_splats(0);
		newbl = get_blockidx(ny);
		newbc = get_blockidx(nx);
                vnewbpos = spu_insert(newbl, vnewbpos, 0);
                vnewbpos = spu_insert(newbc, vnewbpos, 1);
		vcurbpos = spu_sel(vcur, vzero, vsel);
		vdbpos = spu_sub(vnewbpos, vcurbpos);
		dbl = spu_extract(vdbpos, 0);
		dbc = spu_extract(vdbpos, 1);
		if(curbl == NLBLOCKS-1 && newbl == 0) {
			dbl = 1;
		} else if(curbl == 0 && newbl == NLBLOCKS-1) {
			dbl = -1;
		}
		if(curbc == NLBLOCKS-1 && newbc == 0) {
			dbc = 1;
		} else if(curbc == 0 && newbc == NLBLOCKS-1) {
			dbc = -1;
		}

		newlsbl = 1 + dbl;
		newlsbc = 1 + dbc;
		distbl = fix_bdist_rel(nxtbl - curbl);
		distbc = fix_bdist_rel(nxtbc - curbc);

		if(__builtin_expect((newbl != curbl || newbc != curbc), 0)) {
			/* 粒子のデータを格納するブロックを変更する */
			if(dependency) {
				/* 依存関係があるならば次のバッファのデータも同時更新 */
				/* デバッグ用コード */
				//if(abs(*distbl) >= 2 || abs(*distbc) >= 2) {
				//	fprintf(stderr, "SPE(%d): no dependency d(%d, %d)\n", speid, *distbl, *distbc);	
				//}

				nxtlsfbl = 1 - distbl;
				nxtlsfbc = 1 - distbc;
				nxtlstbl = nxtlsfbl + dbl;
				nxtlstbc = nxtlsfbc + dbc;

				//fprintf(stderr, "SPE(%d): cur (%d, %d) nxt (%d, %d)\n", speid,
				//		 curbl, curbc, nxtbl, nxtbc);
				//fprintf(stderr, "SPE(%d): cur ls [1][1] -> [%d][%d]\n", speid,
				//		 newlsbl, newlsbc);
				//fprintf(stderr, "SPE(%d): nxt ls [%d][%d] -> [%d][%d]\n", speid,
				//		 nxtlsfbl, nxtlsfbc, nxtlstbl, nxtlstbc);
				//fprintf(stderr, "SPE(%d): (%d, %d) - (%d, %d)\n", speid,
				//		 curbl+newlsbl-1, curbc+newlsbc-1, nxtbl+nxtlstbl-1, nxtbc+nxtlstbc-1);

				mfc_write_tag_mask(1 << nxtbbuf);
				mfc_read_tag_status_all();
				
				test_dep = 1;
				
				if(0 <= nxtlsfbl && nxtlsfbl <= 2 && 0 <= nxtlsfbc && nxtlsfbc <= 2) {
					remove_particle(curbl, curbc, nxtlsfbl, nxtlsfbc, curbi, nxtbbuf);
					
					//if(lsninblock[nxtbbuf][nxtlsfbl][nxtlsfbc].val >= MAX_NINBLOCK) {
					//	fprintf(stderr, "SPE(%d): lsninblock -> (%d, %d) val = %d\n", speid, *curbl, *curbc, lsninblock[nxtbbuf][nxtlsfbl][nxtlsfbc].val);
					//}
				}
				
				if(0 <= nxtlstbl && nxtlstbl <= 2 && 0 <= nxtlstbc && nxtlstbc <= 2) {
					add_particle(newbl, newbc, nxtlstbl, nxtlstbc, nxtbbuf, nx, ny, ndeg, nmx, nmy, curidx);	
					
					//if(lsninblock[nxtbbuf][nxtlstbl][nxtlstbc].val >= MAX_NINBLOCK) {
					//	fprintf(stderr, "SPE(%d): -> lsninblock (%d, %d) val = %d\n", speid, *newbl, *newbc, lsninblock[nxtbbuf][nxtlstbl][nxtlstbc].val);
					//}
				}
				
				test_dep = 0;
			}
			
			//if(curbl == 6 && curbc == 3 || newbl == 6 && newbc == 3) {
			//	fprintf(stderr, "SPE(%d): %d (%d, %d) -> (%d, %d) ninblock %d\n", speid,
			//			 curidx, curbl, curbc, newbl, newbc,
			//			 lsninblock[curbbuf][newlsbl][newlsbc].val);
			//} else {
			//	if(curidx == traceA || curidx == traceB) {
			//		fprintf(stderr, "SPE(%d): %d (%d, %d) -> (%d, %d) ninblock %d\n", speid,
			//				 curidx, curbl, curbc, newbl, newbc,
			//				 lsninblock[curbbuf][newlsbl][newlsbc].val);
			//	}
			//}
			
			test_dep = 0;

			paddatapos[curbbuf] = remove_particle(curbl, curbc, 1, 1, curbi, curbbuf);
			if(paddatapos[curbbuf].bline != -1) {
				padidx = lsidx[curbbuf][1][1][curbi];
				mvresult.padded = 1;
				mvresult.padidx = padidx;
				mvresult.datapos = paddatapos[curbbuf];
				mfc_put(&paddatapos[curbbuf], caleadatapos(eadatapos, padidx), sizeof(paddatapos[curbbuf]), curbbuf, 0, 0);
				//if(padidx == 3341) {
				//	fprintf(stderr, "3341 padded %d, %d, %d\n", paddatapos[curbbuf].bline, paddatapos[curbbuf].bcol, paddatapos[curbbuf].bidx);
				//}
			} else {
				mvresult.padded = 0;
				mvresult.padidx = -1;
			}
			mfc_put(&lsninblock[curbbuf][1][1], caleanin(eaninblock, curbl, curbc), sizeof(NINBLOCK), curbbuf, 0, 0);

			newdatapos[curbbuf] = add_particle(newbl, newbc, newlsbl, newlsbc, curbbuf, nx, ny, ndeg, nmx, nmy, curidx);
			mfc_put(&newdatapos[curbbuf], caleadatapos(eadatapos, curidx), sizeof(newdatapos[curbbuf]), curbbuf, 0, 0);
			mfc_put(&lsninblock[curbbuf][newlsbl][newlsbc], caleanin(eaninblock, newbl, newbc), sizeof(NINBLOCK), curbbuf, 0, 0);

			//if(lsninblock[curbbuf][newlsbl][newlsbc].val >= MAX_NINBLOCK) {
			//	fprintf(stderr, "SPE(%d): -> ninblock (%d, %d) val = %d\n", speid, *curbl, *curbc, lsninblock[curbbuf][newlsbl][newlsbc].val);
			//}
			//if(lsninblock[curbbuf][1][1].val >= MAX_NINBLOCK) {
			//	fprintf(stderr, "SPE(%d): ninblock -> (%d, %d) val = %d\n", speid, *newbl, *newbc, lsninblock[curbbuf][1][1].val);
			//}

			mfc_put(&lspos[curbbuf][newlsbl][newlsbc], caleapos(eapos, newbl, newbc), sizeof(lspos[curbbuf][newlsbl][newlsbc]), curbbuf, 0, 0);
			mfc_put(&lsdeg[curbbuf][newlsbl][newlsbc], caleadeg(eadeg, newbl, newbc), sizeof(lsdeg[curbbuf][newlsbl][newlsbc]), curbbuf, 0, 0);
			mfc_put(&lsmag[curbbuf][newlsbl][newlsbc], caleamag(eamag, newbl, newbc), sizeof(lsmag[curbbuf][newlsbl][newlsbc]), curbbuf, 0, 0);
			mfc_put(&lsidx[curbbuf][newlsbl][newlsbc], caleaidx(eaidx, newbl, newbc), sizeof(lsidx[curbbuf][newlsbl][newlsbc]), curbbuf, 0, 0);

			mfc_put(&lspos[curbbuf][1][1], caleapos(eapos, curbl, curbc), sizeof(lspos[curbbuf][1][1]), curbbuf, 0, 0);
			mfc_put(&lsdeg[curbbuf][1][1], caleadeg(eadeg, curbl, curbc), sizeof(lsdeg[curbbuf][1][1]), curbbuf, 0, 0);
			mfc_put(&lsmag[curbbuf][1][1], caleamag(eamag, curbl, curbc), sizeof(lsmag[curbbuf][1][1]), curbbuf, 0, 0);
			mfc_putb(&lsidx[curbbuf][1][1], caleaidx(eaidx, curbl, curbc), sizeof(lsidx[curbbuf][1][1]), curbbuf, 0, 0);
		} else {
			if(dependency) {
				/* 依存関係があるならば次のバッファのデータも同時更新 */
				if(abs(distbl) <= 1 && abs(distbc) <= 1) {
					nxtlsbl = 1 - distbl;
					nxtlsbc = 1 - distbc;
	
					mfc_write_tag_mask(1 << nxtbbuf);
					mfc_read_tag_status_all();
					
					if(0 <= nxtlsbl && nxtlsbl <= 2 && 0 <= nxtlsbc && nxtlsbc <= 2) {
						lspos[nxtbbuf][nxtlsbl][nxtlsbc][POS_X][curbi] = nx;
						lspos[nxtbbuf][nxtlsbl][nxtlsbc][POS_Y][curbi] = ny;
						lsdeg[nxtbbuf][nxtlsbl][nxtlsbc][curbi] = ndeg;
						lsmag[nxtbbuf][nxtlsbl][nxtlsbc][MAG_X][curbi] = nmx;
						lsmag[nxtbbuf][nxtlsbl][nxtlsbc][MAG_Y][curbi] = nmy;
						
						//if(curidx == traceA || curidx == traceB) {
						//	fprintf(stderr, "SPE(%d): (%d) update nextbuffer\n", speid, curidx);	
						//}
					}
				}		
			}
			
			*(vector signed int *)&newdatapos[curbbuf] = vcur;
			newdatapos[curbbuf].on_edge = is_on_edge(nx, ny);
			mfc_put(&newdatapos[curbbuf], caleadatapos(eadatapos, curidx), sizeof(newdatapos[curbbuf]), curbbuf, 0, 0);

			lspos[curbbuf][1][1][POS_X][curbi] = nx;
			lspos[curbbuf][1][1][POS_Y][curbi] = ny;
			lsdeg[curbbuf][1][1][curbi] = ndeg;
			lsmag[curbbuf][1][1][MAG_X][curbi] = nmx;
			lsmag[curbbuf][1][1][MAG_Y][curbi] = nmy;
			
			//fprintf(stderr, "put 2\n");

			mfc_put(&lspos[curbbuf][1][1], caleapos(eapos, curbl, curbc), sizeof(lspos[curbbuf][1][1]), curbbuf, 0, 0);
			mfc_put(&lsdeg[curbbuf][1][1], caleadeg(eadeg, curbl, curbc), sizeof(lsdeg[curbbuf][1][1]), curbbuf, 0, 0);
			mfc_putb(&lsmag[curbbuf][1][1], caleamag(eamag, curbl, curbc), sizeof(lsmag[curbbuf][1][1]), curbbuf, 0, 0);

			mvresult.padded = 0;
			mvresult.padidx = -1;
		}
	}
	
	return mvresult;
	
	//mfc_eieio(curbbuf, 0, 0);
}

/**
 * 指定された粒子の計算に必要なデータを直ちに読み込む
 */
DATAPOS get_data_immediately(int idx, int curbbuf)
{
	volatile DATAPOS datapos __attribute__ ((aligned(16)));

	cmd_get_randdata(idx, curbbuf);

	//mfc_get(&datapos, &eadatapos[idx], sizeof(datapos), TAG_DATAPOS, 0, 0);
	//mfc_write_tag_mask(1 << TAG_DATAPOS);
	//mfc_read_tag_status_all();
	datapos = cmd_get_datapos(idx);
	
	cmd_get_neighbor_block_data(datapos.bline, datapos.bcol, curbbuf);
	
	mfc_write_tag_mask(1 << curbbuf);
	mfc_read_tag_status_all();
	
	return datapos;
}

/**
 * 依存関係を計算する。
 * return: 依存関係があるかもしれないときは1、依存関係がありえないときは0
 */
int have_dependency(vector signed int vpre, vector signed int vnxt)
{
	int dbl, dbc, db, dist;

	dbl = get_bdist(spu_extract(vpre, VELEM_BL), spu_extract(vnxt, VELEM_BL));
	dbc = get_bdist(spu_extract(vpre, VELEM_BC), spu_extract(vnxt, VELEM_BC));
	db = (dbl > dbc) ? dbl:dbc;
	dist = (spu_extract(vpre, VELEM_EDGE)) ? 2:1;
	// 今回の粒子と依存関係がある場合は次のデータも同時に更新するため変数を設定する
	if(db <= dist) {
		//fprintf(stderr, "SPE(%d): %d (%d, %d) depends on %d's result\n", 
		//		 speid, nxtidx, datapos.bline, datapos.bcol, curidx);
		return 1;
	} else {
		//printf("SPE(%d): prefetch %d\n", speid, nxtidx);	
		return 0;
	}
}

/**
 * 次の粒子のデータを先読みする。
 * return: 先読みの結果 (依存関係、成功したかどうか)
 */
PREFETCH_RESULT prefetch(int nxtidx, int nxtbbuf, int prebbuf, vector signed int vpre, vector signed int vcur, vector signed int vnxt)
{
	PREFETCH_RESULT result __attribute__ ((aligned(16)));

	result.dependency = have_dependency(vcur, vnxt);
	//if(result.dependency) {
	//	result.prefetched = 0;
	//	return result;	
	//}

	// 前回の粒子と依存関係がある場合はデータの転送が終了するのを待つ。
	//if(have_dependency(vpre, vnxt)) {
	//	mfc_write_tag_mask(1 << prebbuf);
	//	mfc_read_tag_status_all();

	//	result.prefetched = 0;
	//	return result;	
	//}

	cmd_get_randdata(nxtidx, nxtbbuf);
	cmd_get_neighbor_block_data(spu_extract(vnxt, VELEM_BL), spu_extract(vnxt, VELEM_BC), nxtbbuf);
	result.prefetched = 1;
	
	return result;
}

void step()
{
	// cur で始まる変数は計算対象の粒子のデータ
	// nxt で始まる変数は先読みの粒子のデータ
	int i;
	int preidx, curidx, nxtidx;
	uv_int vpre;
	uv_int vcur = { { 0, 0, 0, 0, } };
	uv_int vnxt = { { 0, 0, 0, 0, } };
	int spe;
	int prebbuf, curbbuf, nxtbbuf;
	uint32_t curinst, nxtinst;
	int phase;
	int prefetched = 0;
	int dependency = 0;
	int wait_inst = 0;
	int no_next_inst = 0;
	int prefetch_miss = 0;
	int synchro = 0;
	int op;
	int prepadidx;
	volatile DATAPOS datapos __attribute__ ((aligned(16)));
	volatile DATAPOS prepaddatapos __attribute__ ((aligned(16)));
	MOVE_RESULT mvresult __attribute__ ((aligned(16)));
	PREFETCH_RESULT pfresult __attribute__ ((aligned(16)));
	//int flag = 1;
	//uint32_t dec;
	
	prepadidx = -1;

	prebbuf = 0;
	curbbuf = 1;
	nxtbbuf = 2 % BUF_COUNT;

	for(i = 0; i < NSPE; i++) {
		lssyndata[i].phase = 0;
		lssyndata[i].randstep = 0;
		lssyndata[i].ninstreceived = 0;
		lssyndata[i].endstep = 0;
	}
	
	curinst = 0;
	nxtinst = 0;

        //spe_printf("comspe %d start\n", speid);

	// シミュレーション終了の命令が来るまでループ
	for(;;) {
		curinst = nxtinst;
		
		//fprintf(stderr, "SPE(%d): check\n", speid);
		
		if(__builtin_expect((curinst == 0), 0)) {
			//printf("SPE(%d): wait for a inst\n", speid);
			wait_inst++;
			curinst = read_inst();
		}
				
		//printf("SPE(%d): mb = %x\n", speid, curmb);
		
		if(inst_remain()) {
			nxtinst = read_inst();
		} else {
			//printf("SPE(%d): did not receive next inst\n", speid);
			no_next_inst++;
			nxtinst = 0;
		}
		
		op = INST_GET_OP(curinst);

		if(op == OP_MOVE) {		
			prebbuf = curbbuf;
			curbbuf = nxtbbuf;
			nxtbbuf = (nxtbbuf + 1) % BUF_COUNT;
			vpre = vcur;
			vcur = vnxt;

			preidx = curidx;
			curidx = INST_GET_IDX(curinst);

			//if(__builtin_expect(flag, 0)) {
			//	flag = 0;
			//	spu_write_decrementer(0xFFFFFFFF);
			//}
			
			//if(curidx == traceA || curidx == traceB) {
			//	fprintf(stderr, "SPE(%d): move %d (%d,%d,%d)\n", speid,
			//			 curidx, *curbl, *curbc, *curbi);	
			//}
			
			if(!prefetched) {
				//printf("SPE(%d): get %d\n", speid, curidx);
				prefetch_miss++;

				mfc_write_tag_mask(1 << prebbuf);
				mfc_read_tag_status_all();
				
				datapos = get_data_immediately(curidx, curbbuf);
				vcur.dp = datapos;
			}

			op = INST_GET_OP(nxtinst);
			if(op == OP_MOVE) {
				nxtidx = INST_GET_IDX(nxtinst);

				// 前回でパディングされたデータは更新が見えないもしれないので転送の終了を待つ
				mfc_write_tag_mask(1 << prebbuf);
				mfc_read_tag_status_all();
				
				//if(nxtidx == 3341) {
				//	fprintf(stderr, "3341 pre %d, %d, %d, %d\n", prepadidx, datapos.bline, datapos.bcol, datapos.bidx);
				//}

				if(prepadidx == nxtidx) {
					datapos = prepaddatapos;					
				} else {
					datapos = cmd_get_datapos(nxtidx);
				}
				
				//if(nxtidx == 3341) {
				//	fprintf(stderr, "3341 pos %d, %d, %d\n", datapos.bline, datapos.bcol, datapos.bidx);						
				//}

				vnxt.dp = datapos;
				
				pfresult = prefetch(nxtidx, nxtbbuf, prebbuf, vpre.v, vcur.v, vnxt.v);

				dependency = pfresult.dependency;
				prefetched = pfresult.prefetched;
			} else {
				dependency = 0;
				prefetched = 0;
				nxtidx = -10; // padidxの初期値とは別に設定 
			}
			
			//datapos = get_data_immediately(curidx, curbbuf);					
			//vcur = *(vector signed int *)&datapos;

			mvresult = move(curidx, curbbuf, nxtidx, nxtbbuf, prefetched, dependency, vcur.v, vnxt.v);
			// 今回パディングされたデータは先読みできないので確実な値を代入する
			prepadidx = mvresult.padidx;
			prepaddatapos = mvresult.datapos;
			if(prepadidx == nxtidx) {
				datapos = prepaddatapos;
				vnxt.dp = datapos;				
			}

			//if(mvresult.padded && prepadidx == 3341) {
			//	printf("SPE(%d): %d padded, (%d, %d, %d)\n", speid, prepadidx,
			//	prepaddatapos.bline, prepaddatapos.bcol, prepaddatapos.bidx);
			//}
			
			//if(nxtidx == 911) {
			//	fprintf(stderr, "SPE(%d): 911 (%d,%d,%d), cur (%d, %d, %d), pre (%d,%d,%d)\n",speid,	
			//			 *nxtbl, *nxtbc, *nxtbi, datapos.bline, datapos.bcol, datapos.bidx,
			//			 prepaddatapos.bline, prepaddatapos.bcol, prepaddatapos.bidx);
			//}

			// 同期のステップ数を記録する。
			cmd_send_syn(prebbuf, curbbuf);

		} else if(op == OP_WAIT) {
			// 同期をとる
			spe = INST_GET_SPE(curinst);
			phase = INST_GET_PHASE(curinst);
			
			synchro++;
			wait_for(spe, phase);

			// 同期のステップ数を記録する(タスクマネージャーにのみ報告する)。
			cmd_send_syn_received(prebbuf, curbbuf);

			//fprintf(stderr, "SPE(%d): resumed\n", speid);
		} else if(op == OP_DUP) {
			dupenable = INST_DUP_ENABLE(curinst);
		} else if(op == OP_ENDSTEP) {
			mfc_write_tag_mask((1 << 0) | (1 << 1) | (1 << 2));
			mfc_read_tag_status_all();

			randdatabuf = (randdatabuf+1) % 2;
			nstep++;
			//if(3400 < nstep && nstep < 3500) {
			//	fprintf(stderr, "step %d\n", nstep);
			//}

			// 計測した数値の表示
			//dec = spu_read_decrementer();
			//printf("SPE(%d): wait inst %d, no next inst %d, prefetch miss %d, synchro %d, time=%lf\n",
			//		speid, wait_inst, no_next_inst, prefetch_miss, synchro, (double)(0xFFFFFFFF-dec)/TIMEBASE*1.0e3);
			//printf("SPE(%d): wait inst %d, no next inst %d, prefetch miss %d, synchro %d\n",
			//		speid, wait_inst, no_next_inst, prefetch_miss, synchro);
			//fprintf(stderr, "SPE(%d): %d %d %d\n", speid,
			//		 lssyndata[speid].phase, lssyndata[speid].randstep, lssyndata[speid].nmbreceived);

			for(i = 0; i < NSPE; i++) {
				lssyndata[i].phase = 0;
				lssyndata[i].randstep = 0;
				lssyndata[i].ninstreceived = 0;
				lssyndata[i].endstep = 0;
			}
			lsinst.count = 0;
			wait_inst = 0;
			no_next_inst = 0;
			prefetch_miss = 0;
			synchro = 0;
		} else if(op == OP_END) {
			// 計算を終了する
			//spe_printf("SPE(%d): received OP_END\n", speid);
			break;
		} else {
			// 不明な命令
			//fprintf(stderr, "SPE(%d): unknown op %d\n", speid, op);
			break;	
		}
	}
	
	//prof_stop();
}
