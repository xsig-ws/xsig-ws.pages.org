#ifndef MCPARAM128_H_
#define MCPARAM128_H_

#define NLINES       128
#define NPARTICLES   16384
#define LAMBDA       4.0f
#define XI           4.0f
#define RCUTOFF      8.0f
#define RDELTA       0.5f
#define DEGDELTA     0.17453294f
#define DIMLEN       404.77155f
#define BLOCKSIZE    12.698522f
#define NLBLOCKS     32
#define MAX_NINBLOCK 64
#define _NSPE        6

#endif /*MCPARAM128_H_*/
