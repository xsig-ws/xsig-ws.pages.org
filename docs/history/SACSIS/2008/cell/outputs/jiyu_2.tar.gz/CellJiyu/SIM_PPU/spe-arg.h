#ifndef SPEARG_H_
#define SPEARG_H_

#include "mc-param.h"
#include "particle-data.h"

#include "spe-communication.h"

typedef struct {
	eaptr_t ppos;
	eaptr_t pdeg;
	eaptr_t pmag;
	eaptr_t pidx;
	eaptr_t ninblock;
	eaptr_t pdatapos;
	eaptr_t pranddata;
	eaptr_t movorder;
	unsigned int seed;
	int speid;
	unsigned int nspe;
	eaptr_t pdupdata; // 合計 48Bytes
} SPE_ARG;

typedef struct {
	int bcol_start;
	int bcol_end;
} SPE_COM_TOTAL_ENERGY;

#endif /*SPEARG_H_*/
