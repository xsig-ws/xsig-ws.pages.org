
#include <spu_intrinsics.h>
#include <spu_mfcio.h>

#include "schedule.h"

typedef unsigned int uint32_t;

int main(unsigned long long spe, unsigned long long param)
{
	volatile SPE_ARG arg;
	static const unsigned int tag = 0;
	uint32_t mbdata;
	uint32_t dec;

	// パラメータを受け取る
	mfc_get(&arg, param, sizeof(SPE_ARG), tag, 0, 0);
	mfc_write_tag_mask(1 << tag);
	mfc_read_tag_status_all();
	
	// パラメータの設定
	set_arg(&arg);
	
	// 通信の初期化
	init_communication();

        //spe_printf("SPE(%d): init communication finished\n", arg.speid);
	
	// 以下メールボックスに入ってきた命令を実行する
	for(;;) {
		mbdata = spu_read_in_mbox();
		if(mbdata == SPETMINST_BEGIN) {
			step();
		} else if(mbdata == SPETMINST_DUPSTEP) {
			dup_enable(1);
			
			spu_write_decrementer(0xFFFFFFFF);
			
			step();
			
			dec = spu_read_decrementer();
			
			dup_enable(0);
		} else if(mbdata == SPETMINST_END) {
			//spe_printf("scheduler end\n");
			clear();
			break;	
		} else {
			break;
		}
	}
	
	return 0;	
}
