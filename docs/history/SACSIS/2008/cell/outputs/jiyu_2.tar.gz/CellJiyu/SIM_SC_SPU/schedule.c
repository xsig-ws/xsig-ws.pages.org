
#include <spu_intrinsics.h>
#include <spu_mfcio.h>

typedef struct {
	unsigned short notify;
	unsigned short size;
	unsigned int eal;
} tmp_mfc_list_element_t;
#define mfc_list_element_t tmp_mfc_list_element_t
#define ENABLE_NOTIFY 0x8000

#include <spe_stdio.h>
#include <stdlib.h>
#include <math.h>

#include "schedule.h"
#include "movorder.h"
#include "block.h"

typedef unsigned int uint32_t;

#define DIAMETER 1.0f

#define TAG_SYN 8
#define TAG_DATAPOS 17

#define SPE_XLENGTH (INST_ARRAY_SIZE+1)

///////////////////////////////////////////////////////////////////////////////
// グローバル変数
///////////////////////////////////////////////////////////////////////////////

// eaで始まる変数はメインメモリの実効アドレスを指す
// lsで始まる変数はDMA転送のローカルストア側のバッファ

eaptr_t eadatapos;

#define caleadatapos(eadatapos, idx) (eadatapos+(idx)*sizeof(DATAPOS))

int speid;

int dupenable;

volatile SPE_SYN_DATA lssyndata[MAX_NSPE] __attribute__ ((aligned(16)));
volatile SPE_SYN_DATA *lseasyndata[MAX_NSPE] __attribute__ ((aligned(16)));

SPE_INST lsinst[MAX_NSPE] __attribute__ ((aligned(16)));
eaptr_t lsealsinst[MAX_NSPE] __attribute__ ((aligned(16)));

eaptr_t lseambin[MAX_NSPE] __attribute__ ((aligned(16)));
eaptr_t lseambout[MAX_NSPE] __attribute__ ((aligned(16)));
eaptr_t lseambstat[MAX_NSPE] __attribute__ ((aligned(16)));
eaptr_t lseasig1[MAX_NSPE] __attribute__ ((aligned(16)));

#define GET_MBIN_STAT(status)  ((status >> 8) & 0xFF)
#define GET_MBOUT_STAT(status) ((status     ) & 0xFF)

///////////////////////////////////////////////////////////////////////////////
// グローバル関数
///////////////////////////////////////////////////////////////////////////////

//void gen_all_rand();
//void genrand(uint32_t begin, uint32_t count);

int inst_remain(int spe);

int is_busy(int spe);
void send_inst(int spe, uint32_t inst);
void send_inst_immediately(int spe, uint32_t inst);

///////////////////////////////////////////////////////////////////////////////
// 関数定義
///////////////////////////////////////////////////////////////////////////////

void set_arg(volatile SPE_ARG *arg)
{	

	speid = arg->speid;

	//eapos = arg->ppos;
	//eadeg = arg->pdeg;
	//eamag = arg->pmag;
	//eaidx = arg->pidx;
	//eaninblock = arg->ninblock;
	eadatapos = arg->pdatapos;

	init_movorder(arg->movorder);
	
	dupenable = 0;
}

void init_communication()
{
        int i;
	eaptr_t eaeasyndata, eaealsinst, eaeambin, eaeambout, eaeambstat, eaeasig1;
	
	// 定数がPPUのものと同じ値になっているかどうかを確認する
	// 一致しない場合はPPUが終了処置を行う
	spu_write_out_mbox(NSPE);

	// 同期をとるためにローカルストアのアドレスを交換する
	spu_write_out_mbox((uint32_t)&lssyndata);

	// ローカルストアのアドレスをゲット
	eaeasyndata = spu_read_in_mbox();
	mfc_get(&lseasyndata, eaeasyndata, sizeof(lseasyndata), TAG_SYN, 0, 0);

	
	/* メールのやりとりをするためにメールボックスのアドレスを交換する */
	eaeambin = spu_read_in_mbox();
	mfc_get(&lseambin, eaeambin, sizeof(lseambin), TAG_SYN, 0, 0);
	eaeambout = spu_read_in_mbox();
	mfc_get(&lseambout, eaeambout, sizeof(lseambout), TAG_SYN, 0, 0);
	eaeambstat = spu_read_in_mbox();
	mfc_get(&lseambstat, eaeambstat, sizeof(lseambstat), TAG_SYN, 0, 0);
	
	// シグナル通知レジスタのアドレスを交換する
	eaeasig1 = spu_read_in_mbox();
	mfc_get(&lseasig1, eaeasig1, sizeof(lseasig1), TAG_SYN, 0, 0);

	// 命令送信用のアドレス
	eaealsinst = spu_read_in_mbox();
	mfc_get(&lsealsinst, eaealsinst, sizeof(lsealsinst), TAG_SYN, 0, 0);
	mfc_write_tag_mask(1 << TAG_SYN);
	mfc_read_tag_status_all();

	//for(i = 0; i < NSPE-1; i++) {
	//	spe_printf("SPE(%d): eambstat[%d] = %x, eambin[%d] = %x\n", 
	//	           speid, i, lseambstat[i], i, lseambin[i]);
	//}
}

int inst_full(int spe)
{
	return (lssyndata[spe].ninstreceived + INST_ARRAY_SIZE <= lsinst[spe].count);
}

int is_busy(int spe)
{
	return inst_full(spe);	
}

void send_inst(int spe, uint32_t inst)
{
	int wait;
	//fprintf(stderr, "SPE(%d): (%d) %d,%d\n", speid, spe, lssyndata[spe].ninstreceived + INST_ARRAY_SIZE, lsinst[spe].count);

	do {
		wait = inst_full(spe);
	} while(wait);
	
	mfc_write_tag_mask(1 << spe);
	mfc_read_tag_status_all();
	
	lsinst[spe].array[lsinst[spe].count % INST_ARRAY_SIZE] = inst;
	lsinst[spe].count++;

	mfc_putb(&lsinst[spe], lsealsinst[spe], 16, spe, 0, 0);
	mfc_putb(&lsinst[spe].count, lsealsinst[spe]+16, 16, spe, 0, 0);
}

void send_inst_immediately(int spe, uint32_t inst)
{
	int wait;
	do {
		wait = inst_full(spe);
	} while(wait);
	
	mfc_write_tag_mask(1 << spe);
	mfc_read_tag_status_all();
	
	lsinst[spe].array[lsinst[spe].count % INST_ARRAY_SIZE] = inst;
	lsinst[spe].count++;

	mfc_putb(&lsinst[spe], lsealsinst[spe], 16, spe, 0, 0);
	mfc_putb(&lsinst[spe].count, lsealsinst[spe]+16, 16, spe, 0, 0);
}

void wait_for_spe_computing(int spe, int ncom)
{
	int wait;
	do {
		wait = (lssyndata[spe].phase < ncom);
	} while(wait);
}

void dup_enable(int enable)
{
	int i;

	dupenable = enable;
}

void step()
{
	int i, j, k;
	int m, n;
	int curidx, nxtidx;
	int bl __attribute__ ((aligned(16)));
	int bc __attribute__ ((aligned(16)));
	int on_edge __attribute__ ((aligned(16)));
	int syn;
	int ncom[MAX_NSPE];
	int dl, dc;
	int mdl, mdc;
	int md;
	int mdmin; /* 排他領域までのブロック数 */
	int nearest_spe;
	int spe_com;
	int mincom;
	int nwait;
	volatile int wait;
	volatile struct {
		unsigned char reserved0[4];
		volatile uint32_t stat_out;
		unsigned char reserved1[4];
		volatile uint32_t in;
	} lsmb __attribute__ ((aligned(16))); 
	/* CBEA によるとSPU_In_MBoxのアドレスの下位１バイトの値はC */
	/* SPU_MBox_statのアドレスの下位１バイトの値は4 */
	
	// 計算が終わっていないため依存関係が発生する可能性のある領域
	vector signed short vprebl[MAX_NSPE]; // これの要素が-1のときは領域無し
	vector signed short vprebc[MAX_NSPE];
	vector unsigned short vpreedge[MAX_NSPE];
	vector unsigned short vnxtedge;
	vector signed short vdb[MAX_NSPE];
	const vector signed short vn1 = { -1, -1, -1, -1, -1, -1, -1, -1 };
	const vector signed short v0 = { 0, 0, 0, 0, 0, 0, 0, 0 };
	const vector unsigned short vu0 = { 0, 0, 0, 0, 0, 0, 0, 0 };
	const vector signed short v1 = { 1, 1, 1, 1, 1, 1, 1, 1 };
	const vector unsigned short vu1 = { 1, 1, 1, 1, 1, 1, 1, 1 };
	const vector signed short v2 = { 2, 2, 2, 2, 2, 2, 2, 2 };
	const vector signed short vnlb = { NLBLOCKS, NLBLOCKS, NLBLOCKS, NLBLOCKS, NLBLOCKS, NLBLOCKS, NLBLOCKS, NLBLOCKS };
	const vector unsigned char vshuffle = { 16, 17, 0, 1, 2, 3, 4, 5, 6, 7, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80 };
	const vector unsigned char vgather = { 0, 2, 4, 6, 8, 0x80, 0x80, 0x80, 1, 3, 5, 7, 9, 0x80, 0x80, 0x80 };
	const vector unsigned char vspemininit = { 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x33, 0x33, 0x33, 0x33, 0x22, 0x22, 0x11, 0x0F };
	const vector signed short vwait[8] = { // 計算が終了した領域を消去するためvspelなどにこのベクトルとORをとる
		{  0, -1, -1, -1, -1, -1, -1, -1, },
		{  0,  0, -1, -1, -1, -1, -1, -1, },
		{  0,  0,  0, -1, -1, -1, -1, -1, },
		{  0,  0,  0,  0, -1, -1, -1, -1, },
		{  0,  0,  0,  0,  0, -1, -1, -1, },
		{  0,  0,  0,  0,  0,  0, -1, -1, },
		{  0,  0,  0,  0,  0,  0,  0, -1, },
		{  0,  0,  0,  0,  0,  0,  0,  0, },
		/*{  0,  0,  0,  0,  0,  0,  0,  0, },
		{  0,  0,  0,  0,  0,  0,  0,  0, },
		{  0,  0,  0,  0,  0,  0,  0,  0, },
		{  0,  0,  0,  0,  0,  0,  0,  0, },
		{  0,  0,  0,  0,  0,  0,  0,  0, },
		{  0,  0,  0,  0,  0,  0,  0,  0, },
		{  0,  0,  0,  0,  0,  0,  0,  0, },
		{  0,  0,  0,  0,  0,  0,  0,  0, },*/
	};
	vector unsigned short vedge;
	vector unsigned short vmdle0;
	vector unsigned long long vmdle0gathered;
	vector unsigned short vnopos;
	vector unsigned short vdblgtdbc;
	vector signed short vbl, vbc;
	vector signed short vdbl, vdbc, vd, vdsub1, vdsub2, vmd;
	vector unsigned short vsiedge;
	vector unsigned char vspemin;
	unsigned short mdle0;
	int curdataposbuf, nxtdataposbuf;
	volatile DATAPOS lsdatapos[2] __attribute__ ((aligned(16)));
	int nnwait[NSPE][8];
	int sync;
	uint32_t decbef, decaft;

	//int temp;

	for(i = 0; i < NSPE-1; i++) {
		vprebl[i] = vn1;
		vprebc[i] = vn1;
		vpreedge[i] = vu0;
		ncom[i] = 0;
		
		lssyndata[i].phase = 0;
		lssyndata[i].randstep = 0;
		lssyndata[i].ninstreceived = 0;
		lssyndata[i].endstep = 0;
		
		lsinst[i].count = 0;
		for(j = 0; j < INST_ARRAY_SIZE; j++) {
			lsinst[i].array[j] = 0;	
		}

		for(j = 0; j < 6; j++) {
			nnwait[i][j] = 0;
		}
	}
	
	for(i = 0; i < NSPE-1; i++) {
		send_inst_immediately(i, SPEINST_DUP | dupenable);
	}

	prepare_movorder();
	
	//fprintf(stderr, "SPE(%d): start particle moving\n", speid);
	
	nxtidx = get_next_particle_index();
	
	nxtdataposbuf = 1;
	mfc_get(&lsdatapos[nxtdataposbuf], caleadatapos(eadatapos, nxtidx), sizeof(lsdatapos[nxtdataposbuf]), (TAG_DATAPOS+nxtdataposbuf), 0, 0);

	//decbef = spu_read_decrementer();

        //spe_printf("scheduler start\n");

	syn = 0;
	spe_com = 0;
	for(i = 0; i < NPARTICLES; i++) {
		
		if(i == NPARTICLES-1) {
			curidx = nxtidx;
			curdataposbuf = nxtdataposbuf;
		} else {
			curidx = nxtidx;
			nxtidx = get_next_particle_index();
			curdataposbuf = nxtdataposbuf;
			nxtdataposbuf = (nxtdataposbuf+1) % 2;

			// 粒子の位置情報を先読み
			//spe_printf("read %x\n", caleadatapos(eadatapos, nxtidx));
			mfc_get(&lsdatapos[nxtdataposbuf], caleadatapos(eadatapos, nxtidx), sizeof(lsdatapos[nxtdataposbuf]), (TAG_DATAPOS+nxtdataposbuf), 0, 0);
		}

		// 今回の粒子の情報が読み終わったことを確認する
		mfc_write_tag_mask(1 << (TAG_DATAPOS+curdataposbuf));
		mfc_read_tag_status_all();

		bl = lsdatapos[curdataposbuf].bline;
		bc = lsdatapos[curdataposbuf].bcol;
		on_edge = lsdatapos[curdataposbuf].on_edge;
		
		vbl = spu_splats((signed short)bl);
		vbc = spu_splats((signed short)bc);
		vnxtedge = spu_splats((unsigned short)on_edge);
		vnxtedge = spu_cmpeq(vnxtedge, vu1);
		
		
		// 依存関係を持つSPEを探す 
		nearest_spe = 0;
		mdmin = NLBLOCKS - 2;
		for(j = 0; j < NSPE-1; j++) {
			// 既に計算が終了した領域は依存関係が発生しないため-1にセット
			nwait = ncom[j] - lssyndata[j].phase;
			if(__builtin_expect((nwait < 6), 1)) {
				vprebl[j] = spu_or(vprebl[j], vwait[nwait]);
				nnwait[j][nwait]++;
			} else {
				nnwait[j][5]++;
			}
			
			// 依存関係の調査
			// 粒子の格納されているブロックはX
			// 粒子がブロックをまたぐ可能性があるときはその周りもX
			// 　そうでないならば周りはS
			// XとXまたはXとSが重なるならば依存関係ありとする
			vnopos = spu_cmpeq(vprebl[j], vn1);
			vdbl = get_bdistv(vprebl[j], vbl);
			vdbc = get_bdistv(vprebc[j], vbc);
			vdblgtdbc = spu_cmpgt(vdbl, vdbc);
			vd = spu_sel(vdbc, vdbl, vdblgtdbc);
			vdb[j] = vd = spu_sel(vd, vnlb, vnopos);
			vdsub1 = spu_sub(vd, v1);
			vdsub2 = spu_sub(vd, v2);
			vedge = spu_cmpeq(vpreedge[j], vu1); // 値が1の要素は全てのビットを立たせる
			vedge = spu_or(vedge, vnxtedge);
			vmd = spu_sel(vdsub1, vdsub2, vedge);

			for(k = 0; k < SPE_XLENGTH; k++) {
				md = spu_extract(vmd, k);
				if(md < mdmin) {
					mdmin = md;
					nearest_spe = j;
				}
			}
		}

		// 依存関係を持つSPEを見つけたときは(mdmin <= 0)
		if(mdmin <= 0) {
			sync = 1;
			spe_com = nearest_spe;

			// 他のSPEの持つ領域と重なる場合はそのSPEの処理が終わるのを待つ
			for(j = 0; j < NSPE-1; j++) {
				if(j == spe_com) {
					continue;
				}

				vdsub1 = spu_sub(vdb[j], v1);
				vdsub2 = spu_sub(vdb[j], v2);
				vedge = spu_cmpeq(vpreedge[j], vu1); // 値が1の要素は全てのビットを立たせる
				vedge = spu_or(vedge, vnxtedge);
				vmd = spu_sel(vdsub1, vdsub2, vedge);
				vmdle0 = spu_cmpgt(v1, vmd);

				vmdle0gathered = (vector unsigned long long)spu_shuffle(vmdle0, vu0, vgather);
				
				if(spu_extract(vmdle0gathered, 0)) {
					for(k = 0; k < SPE_XLENGTH; k++) {
						mdle0 = spu_extract(vmdle0, k);
						if(mdle0) {
							// 領域が重なったので同期をとる
							send_inst(spe_com, SPEINST_WAIT | (j << 24) | (ncom[j]-k));

							syn++;

							break;
						}
					}
				}
			}
		} else {
			sync = 0;
			mincom = NPARTICLES+1;
			for(j = 0; j < NSPE-1; j++) {
				if(ncom[j] < mincom) {
					mincom = ncom[j];
					spe_com = j;
				}
			}
			//if(spe_com < 0 || NSPE-1 < spe_com) {
			//	fprintf(stderr, "SPE(%d): (%d) spe_com = %d\n", speid, i, spe_com);
			//}
		}
		
		// 要素をスライドして[0]に新しい値を格納する
		vprebl[spe_com] = spu_shuffle(vprebl[spe_com], vbl, vshuffle);
		vprebc[spe_com] = spu_shuffle(vprebc[spe_com], vbc, vshuffle);
		vpreedge[spe_com] = spu_shuffle(vpreedge[spe_com], spu_splats((unsigned short)on_edge), vshuffle);

                //spe_printf("send inst %d\n", i);

		// 命令を送る
		send_inst(spe_com, SPEINST_MOVE | curidx);
		ncom[spe_com]++;
	}

        //spe_printf("step end\n");

	for(i = 0; i < NSPE-1; i++) {
		// SPEが計算を終えるのを待つ
		wait_for_spe_computing(i, ncom[i]);

		//decaft = spu_read_decrementer();
		//printf("SPE(%d): move time=%lf(msec)\n", speid, (double)(decbef-decaft)/TIMEBASE*1.0e3);

		// 1ステップの終了を伝える
		send_inst(i, SPEINST_ENDSTEP);

		//printf("SPE(%d): ncom spe(%d) = %d\n", speid, i, ncom[i]);
		//fprintf(stderr, "SPE(%d): (%d) %d %d\n", speid,
		//		 i, ncom[i], nmail[i]);
	}
	//printf("SPE(%d): ncom spe(%d) = %d\n", speid, speid, ncom[speid]);

	//printf("SPE(%d): total synchronization = %d\n", speid, syn);
	
	spu_write_out_mbox(SPETMMB_ENDSTEP);
	
	//spe_printf("scheduler end step\n");
}

void clear()
{
	int i;
	
	for(i = 0; i < NSPE-1; i++) {
		lsinst[i].count = 0;
		lssyndata[i].ninstreceived = 0;
		send_inst_immediately(i, SPEINST_END);
	}
	
	mfc_write_tag_mask(-1);
	mfc_read_tag_status_all();
}
