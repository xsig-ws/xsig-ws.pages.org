#ifndef RAND_H_
#define RAND_H_

#define MEXP 19937
#include "SFMT.h"

void init_rand(unsigned int seed);

void fill_randf(float *array, int size);

float gen_randf();
uint32_t gen_rand(uint32_t min, uint32_t sup);

#endif /*RAND_H_*/
