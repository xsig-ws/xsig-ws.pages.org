#ifndef MC_PARAM32_H_
#define MC_PARAM32_H_

#define NLINES       32
#define NPARTICLES   1024
#define LAMBDA       2.0f
#define XI           2.0f
#define RCUTOFF      8.0f
#define RDELTA       0.5f
#define DEGDELTA     0.17453294f
#define DIMLEN       101.19289f
#define BLOCKSIZE    12.698522f
#define NLBLOCKS     8
#define MAX_NINBLOCK 64
#define _NSPE        6

#endif // MC_PARAM32_H_
