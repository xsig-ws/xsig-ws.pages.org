
#include "rand.h"

void init_rand(unsigned int seed)
{
	init_gen_rand(seed);
}

void fill_randf(float *array, int size)
{
	int i;
	for(i = 0; i < size ;i++) {
		array[i] = genrand_real2();
	}
}

float gen_randf()
{
	return (float)genrand_real2();	
}

uint32_t gen_rand(uint32_t min, uint32_t sup)
{
	return min + (int)(genrand_real2() * (sup - min));
}
