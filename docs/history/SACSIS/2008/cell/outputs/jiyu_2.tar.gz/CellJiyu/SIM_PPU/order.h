#ifndef ORDER_H_
#define ORDER_H_

void gen_movorder(unsigned int *order);

#endif /*ORDER_H_*/
