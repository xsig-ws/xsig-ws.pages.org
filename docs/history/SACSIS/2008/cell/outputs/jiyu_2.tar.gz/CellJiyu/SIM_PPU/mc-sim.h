#ifndef MC_H_
#define MC_H_

int simulate(unsigned int nsteps, unsigned int outputstep);

#endif /*MC_H_*/
