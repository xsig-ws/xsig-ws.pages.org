
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <altivec.h>

#include "SFMT.h"

#include "rand.h"
#include "order.h"
#include "mc-particle.h"
#include "particle-data.h"

///////////////////////////////////////////////////////////////////////////////
// グローバル変数
///////////////////////////////////////////////////////////////////////////////

#define DIAMETER 1.0f

#define DIMLENHALF (DIMLEN * 0.5f)
#define RCUTOFFSQ (RCUTOFF*RCUTOFF)

volatile float ppos[NLBLOCKS][NLBLOCKS][2][MAX_NINBLOCK] __attribute__ ((aligned(128)));
volatile float pmag[NLBLOCKS][NLBLOCKS][2][MAX_NINBLOCK] __attribute__ ((aligned(128)));
volatile float pdeg[NLBLOCKS][NLBLOCKS][MAX_NINBLOCK] __attribute__ ((aligned(128)));
volatile unsigned int pidx[NLBLOCKS][NLBLOCKS][MAX_NINBLOCK] __attribute__ ((aligned(128)));

volatile NINBLOCK ninblock[NLBLOCKS][NLBLOCKS] __attribute__ ((aligned(128)));

volatile DATAPOS pdatapos[NPARTICLES] __attribute__ ((aligned(128)));

volatile RANDDATA pranddata[2][NPARTICLES] __attribute__ ((aligned(128)));

unsigned int movorder[2][NPARTICLES] __attribute__ ((aligned(128)));

#define ACCESS_HINT_SIZE (sizeof(ppos)+sizeof(pmag)+sizeof(pdeg)+sizeof(pidx)+sizeof(ninblock)+sizeof(pdatapos)+sizeof(pranddata)+sizeof(movorder))
unsigned int randdatabuf;
unsigned int movorderbuf;

// 以下出力用の控え
int duplicated = 0;
volatile DUPDATA pdupdata[NPARTICLES] __attribute__ ((aligned(128)));

float duppos[NLBLOCKS][NLBLOCKS][2][MAX_NINBLOCK] __attribute__ ((aligned(128)));
float dupmag[NLBLOCKS][NLBLOCKS][2][MAX_NINBLOCK] __attribute__ ((aligned(128)));
float dupdeg[NLBLOCKS][NLBLOCKS][MAX_NINBLOCK] __attribute__ ((aligned(128)));
unsigned int dupidx[NLBLOCKS][NLBLOCKS][MAX_NINBLOCK] __attribute__ ((aligned(128)));
unsigned int dupninblock[NLBLOCKS][NLBLOCKS] __attribute__ ((aligned(128)));
DATAPOS dupdatapos[NPARTICLES] __attribute__ ((aligned(128)));

// 出力スレッド
pthread_t pthread_output = -1;

// 出力ファイル
FILE *output_file = NULL;

// プロファイル用
unsigned long long ts, te; 
unsigned long long tppeworktotal = 0;
unsigned long long tmovetotal = 0;
unsigned long long toutputtotal = 0;

///////////////////////////////////////////////////////////////////////////////
// SPE 操作
///////////////////////////////////////////////////////////////////////////////

#include <spe_wrap.h>
#include <spere_cbea.h>

#include <spe_stdio_srv.h>

#include <pthread.h>

#include "spe-arg.h"
#include "spe-communication.h"

swt_handle *swth[NSPE];
spere_object_id ahint[NSPE];

eaptr_t easyndata[MAX_NSPE] __attribute__ ((aligned(128)));
eaptr_t ealsinst[MAX_NSPE] __attribute__ ((aligned(128)));
eaptr_t eambin[MAX_NSPE] __attribute__ ((aligned(128)));
eaptr_t eambout[MAX_NSPE] __attribute__ ((aligned(128)));
eaptr_t eambstat[MAX_NSPE] __attribute__ ((aligned(128)));
eaptr_t easig1[MAX_NSPE] __attribute__ ((aligned(128)));

///////////////////////////////////////////////////////////////////////////////
// 初期化
///////////////////////////////////////////////////////////////////////////////

int get_blockidx(float pos)
{
	return (int)(pos / BLOCKSIZE);
}

int is_on_edge(float x, float y)
{
	int bl = get_blockidx(y);
	int bc = get_blockidx(x);
	float bx = x - bc*BLOCKSIZE;
	float by = y - bl*BLOCKSIZE;
	return (bx < RDELTA || BLOCKSIZE-RDELTA < bx) || (by < RDELTA || BLOCKSIZE-RDELTA < by);
}


int fix_bidx(int idx)
{
	return (NLBLOCKS + idx) % NLBLOCKS;	
}

void set_parameters()
{
	init_rand(3146);
}

void init_communication()
{
	int i;
	SPE_ARG arg[NSPE] __attribute__ ((aligned(16)));
	lsptr_t lspsyn, lspinst;
	spere_addr eals;
        spere_addr eaps;
	eaptr_t eaeasyndata;
	eaptr_t eaealsinst;
	eaptr_t eaeambin;
	eaptr_t eaeambout;
	eaptr_t eaeambstat;
	eaptr_t eaeasig1;
	uint32_t status;
	uint32_t nspe_check;
	int spe_use;
	
	int seed[8] = { 3146, 4257, 5368, 6479, 7580, 8691, 9702, 813 };
	
	spe_use = NSPE;

	//fprintf(stderr, "PPE: use %d spe(s)\n", spe_use);

        _spe_stdio_init(64);
        _spe_stdio_start();

	//fprintf(stderr, "PPE: create spe threads\n");

	// 最後のSPEはスケジューラ
	for(i = 0; i < NSPE; i++) {
		arg[i].ppos = (eaptr_t)ppos;
		arg[i].pdeg = (eaptr_t)pdeg;
		arg[i].pmag = (eaptr_t)pmag;
		arg[i].pidx = (eaptr_t)pidx;
		arg[i].ninblock = (eaptr_t)ninblock;
		arg[i].pdatapos = (eaptr_t)pdatapos;
		arg[i].pranddata = (eaptr_t)pranddata;
		arg[i].movorder = (eaptr_t)movorder;
		arg[i].seed = seed[i];
		arg[i].speid = i;
		arg[i].nspe = NSPE;
		arg[i].pdupdata = (eaptr_t)pdupdata;
		
		//fprintf(stderr, "PPE: create context\n");

                if(i == NSPE-1) {
                	swth[i] = spe_wrap_create_dedicated_thread("SIM_SC_SPU/scspe", &arg[i], SIGNOTIFY_INIT_MODE);
			if(swth[i] == NULL) {
				exit(1);
                        }
		} else {
			swth[i] = spe_wrap_create_dedicated_thread("SIM_COM_SPU/comspe", &arg[i], SIGNOTIFY_INIT_MODE);
			if(swth[i] == NULL) {
				exit(1);
                        }
		}

                ahint[i] = spe_wrap_add_access_hint(swth[i]->id, ppos, ACCESS_HINT_SIZE);

		spe_wrap_resume_thread(swth[i]->id);
	}

	// 定数がSPUのものと一致しているかどうかを確かめる
	// 一致しない場合は終了する
	for(i = 0; i < NSPE; i++) {
		do {
			spere_spe_thread_read_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_MBOX_STAT, &status);
		} while((status&0xFF) == 0);
                spere_spe_thread_read_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_OUT_MBOX, &nspe_check);
		if(nspe_check != NSPE) {
			fprintf(stderr, "PPE   : SPE(%d) NSPE mis-matched (PPE %d, SPE %d)\n", i, NSPE, nspe_check);
			exit(1);
		}
	}
	
	//fprintf(stderr, "PPE   : constants matched\n");
	
	//fprintf(stderr, "PPE: exchange spe address\n");
	
	/* 同期をとるためローカルストアのアドレスを交換させる */
	/* タスクマネージメントのためにメールボックス関連とシグナル通知レジスタのアドレスを交換させる */
	//fprintf(stderr, "PPE   : address exchange\n");
	for(i = 0; i < NSPE; i++) {
		do {
			spere_spe_thread_read_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_MBOX_STAT, &status);
		} while((status&0xFF) == 0);
                spere_spe_thread_read_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_OUT_MBOX, &lspsyn);
                spere_spe_thread_map_ls(swth[i]->id, &eals);
                spere_spe_thread_map_mmio_regs(swth[i]->id, &eaps);
		if(i < NSPE-1) {
			do {
				spere_spe_thread_read_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_MBOX_STAT, &status);
			} while((status&0xFF) == 0);
                        spere_spe_thread_read_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_OUT_MBOX, &lspinst);
			ealsinst[i] = (eaptr_t)(eals + lspinst);
		}
		easyndata[i] = (eaptr_t)(eals + lspsyn);
		eambin[i] = eaps + SPERE_CBEA_MMIO_OFFSET_SPU_IN_MBOX;
		eambout[i] = eaps + SPERE_CBEA_MMIO_OFFSET_SPU_OUT_MBOX;
		eambstat[i] = eaps + SPERE_CBEA_MMIO_OFFSET_SPU_MBOX_STAT;
		easig1[i] = eaps + SPERE_CBEA_MMIO_OFFSET_SPU_SIG_NOTIFY_1;
		//fprintf(stderr, "PPE   : (%d) eals = %x, eaps = %x, easyndata = %x\n", i, (unsigned int)eals, (unsigned int)eaps, easyndata[i]);
		//fprintf(stderr, "PPE   : (%d) mbin = %x, mbstat = %x\n", i, eambin[i], eambstat[i]);
	}
	
	//fprintf(stderr, "PPE   : send mail\n");

	eaeasyndata = (eaptr_t)&easyndata;
	eaealsinst = (eaptr_t)&ealsinst;
	eaeambin = (eaptr_t)&eambin;
	eaeambout = (eaptr_t)&eambout;
	eaeambstat = (eaptr_t)&eambstat;
	eaeasig1 = (eaptr_t)&easig1;
	//fprintf(stderr, "PPE   : eambin addr = %x, eambstat addr = %x\n", eaeambin, eaeambstat);
	for(i = 0; i < NSPE; i++) {
		do {
			spere_spe_thread_read_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_MBOX_STAT, &status);
		} while((status&0xFF00) == 0);
                spere_spe_thread_write_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_IN_MBOX, eaeasyndata);
		
		do {
			spere_spe_thread_read_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_MBOX_STAT, &status);
		} while((status&0xFF00) == 0);
                spere_spe_thread_write_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_IN_MBOX, eaeambin);
		
		do {
			spere_spe_thread_read_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_MBOX_STAT, &status);
		} while((status&0xFF00) == 0);
                spere_spe_thread_write_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_IN_MBOX, eaeambout);
		
		do {
			spere_spe_thread_read_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_MBOX_STAT, &status);
		} while((status&0xFF00) == 0);
                spere_spe_thread_write_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_IN_MBOX, eaeambstat);
		
		do {
			spere_spe_thread_read_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_MBOX_STAT, &status);
		} while((status&0xFF00) == 0);
                spere_spe_thread_write_mmio_reg(swth[i]->id, SPERE_CBEA_MMIO_OFFSET_SPU_IN_MBOX, eaeasig1);
	}
	
	// スケジューラには命令を送るためのローカルストアのアドレスを与える
	do {
		spere_spe_thread_read_mmio_reg(swth[NSPE-1]->id, SPERE_CBEA_MMIO_OFFSET_SPU_MBOX_STAT, &status);
	} while((status&0xFF00) == 0);
        spere_spe_thread_write_mmio_reg(swth[NSPE-1]->id, SPERE_CBEA_MMIO_OFFSET_SPU_IN_MBOX, eaealsinst);

	//fprintf(stderr, "PPE   : init_communication finished\n");
}

void init_particles()
{
	float trans;
	int i, j;
	float x, y, deg;
	int bc, bl, bi;
	
	for(i = 0; i < NLBLOCKS; i++) {
		for(j = 0; j < NLBLOCKS; j++) {
			ninblock[i][j].val = 0;
			ninblock[i][j].reserved1 = 1;
			ninblock[i][j].reserved2 = 2;
			ninblock[i][j].reserved3 = 3;
		}
	}

	trans = (DIMLEN/NLINES)/2.0f;
	for(i = 0; i < NPARTICLES; i++) {
		x = DIMLEN*(i%NLINES)/NLINES + trans;
		y = DIMLEN*(i/NLINES)/NLINES + trans;
		bl = get_blockidx(y);
		bc = get_blockidx(x);
		pdatapos[i].bline = bl;
		pdatapos[i].bcol = bc;
		pdatapos[i].bidx = bi = ninblock[bl][bc].val++;
		pdatapos[i].on_edge = is_on_edge(x, y);
		if(bi >= MAX_NINBLOCK) {
			fprintf(stderr, "Too many particles in a block(%d, %d).\n", bl, bc);
			exit(1);
		}

		ppos[bl][bc][POS_X][bi] = x;
		ppos[bl][bc][POS_Y][bi] = y;
		pdeg[bl][bc][bi] = deg = gen_randf() * 2.0f * PI;
		pmag[bl][bc][MAG_X][bi] = cos(deg);
		pmag[bl][bc][MAG_Y][bi] = sin(deg);
		pidx[bl][bc][bi] = i;
		
		pdupdata[i].x = x;
		pdupdata[i].y = y;
		pdupdata[i].deg = deg;
	}
	
	duplicated = 1;
	
	movorderbuf = 0;
	gen_movorder(movorder[movorderbuf]);
	
	randdatabuf = 0;
	fill_randf((float *)pranddata[randdatabuf], sizeof(RANDDATA)/sizeof(float)*NPARTICLES);
}

vector signed int get_bdist(vector signed int a, vector signed int b) {
	const vector signed int vnlbdiv2 = { NLBLOCKS/2, NLBLOCKS/2, NLBLOCKS/2, NLBLOCKS/2 };
	const vector signed int vnnlbdiv2 = { - NLBLOCKS/2, - NLBLOCKS/2, - NLBLOCKS/2, - NLBLOCKS/2 };
	const vector signed int vnlb = { NLBLOCKS, NLBLOCKS, NLBLOCKS, NLBLOCKS };
	vector signed int ret;
	vector signed int vd, vdadd, vdsub;
	vector bool int vdle;
	vector bool int vdgt;
	
	vd = vec_sub(b, a);
	vdadd = vec_add(vd, vnlb);
	vdsub = vec_sub(vd, vnlb);
	
	vdle = vec_cmpgt(vnnlbdiv2, vd);
	vdgt = vec_cmpgt(vd, vnlbdiv2);
	ret = vec_sel(vd, vdadd, vdle);
	ret = vec_sel(ret, vdsub, vdgt);
	ret = vec_abs(ret);

	return ret;
}

/**
 * １ステップ実行
 */
int step(int n, int dup)
{
	uint32_t mbdata;
        uint32_t status;

	if(dup && pthread_output != -1) {
		if(pthread_join(pthread_output, NULL)) {
			perror("Failed joining output thread");
			exit(1);
		}
	}

	mbdata = (dup) ? SPETMINST_DUPSTEP : SPETMINST_BEGIN;
        do {
                spere_spe_thread_read_mmio_reg(swth[NSPE-1]->id, SPERE_CBEA_MMIO_OFFSET_SPU_MBOX_STAT, &status);
        } while((status&0xFF00) == 0);
        spere_spe_thread_write_mmio_reg(swth[NSPE-1]->id, SPERE_CBEA_MMIO_OFFSET_SPU_IN_MBOX, mbdata);

	//fprintf(stderr, "PPE: start step %d\n", n);
	
	movorderbuf = (movorderbuf+1) % 2;
	gen_movorder((unsigned int*)movorder[movorderbuf]);
	
	randdatabuf = (randdatabuf+1) % 2;
	fill_randf((float *)pranddata[randdatabuf], sizeof(RANDDATA)/sizeof(float)*NPARTICLES);


        do {
                spere_spe_thread_read_mmio_reg(swth[NSPE-1]->id, SPERE_CBEA_MMIO_OFFSET_SPU_MBOX_STAT, &status);
        } while((status&0xFF) == 0);
        spere_spe_thread_read_mmio_reg(swth[NSPE-1]->id, SPERE_CBEA_MMIO_OFFSET_SPU_OUT_MBOX, &mbdata);

        if(mbdata != SPETMMB_ENDSTEP) {
            fprintf(stderr, "sync miss\n");
        }

        //fprintf(stderr, "step %d end\n", n);

	/*for(;;) {
	        spere_spe_thread_read_mmio_reg(swth[NSPE-1]->id, SPERE_CBEA_MMIO_OFFSET_SPU_OUT_MBOX, &mbdata);
	
		if(mbdata == SPETMMB_ENDSTEP) {
                    break;
                }
	}*/

	duplicated = 1;

	return 0;
}

void clear()
{
	int i;
	uint32_t mbdata;
	uint32_t status;

	//fprintf(stderr, "send end signal\n");
	
	mbdata = SPETMINST_END;
        do {
                spere_spe_thread_read_mmio_reg(swth[NSPE-1]->id, SPERE_CBEA_MMIO_OFFSET_SPU_MBOX_STAT, &status);
        } while((status&0xFF00) == 0);
        spere_spe_thread_write_mmio_reg(swth[NSPE-1]->id, SPERE_CBEA_MMIO_OFFSET_SPU_IN_MBOX, mbdata);

	for(i = 0; i < NSPE; i++) {
                spe_wrap_wait_thread(swth[i]->id);

                spere_spe_thread_unmap_ls(swth[i]->id);

                spere_spe_thread_unmap_mmio_regs(swth[i]->id);

                spe_wrap_remove_access_hint(swth[i]->id, ahint[i]);

                spe_wrap_release_thread(swth[i]);

		//fprintf(stderr, "SPE%d end\n", i);
	}

	_spe_stdio_end();
}

//////////////////////////////////////////////////////////////////////////////////
// 全エネルギーの計算
//////////////////////////////////////////////////////////////////////////////////

void fix_distance(vector float *v)
{
	static const vector float vdimlen = { DIMLEN, DIMLEN, DIMLEN, DIMLEN };
	static const vector float vcmpg = { DIMLENHALF, DIMLENHALF, DIMLENHALF, DIMLENHALF };
	static const vector float vcmpl = { -DIMLENHALF, -DIMLENHALF, -DIMLENHALF, -DIMLENHALF };
	vector float vdadd, vdsub;
	vector bool int vresg, vresl;

	vdadd = vec_add(*v, vdimlen);
	vdsub = vec_sub(*v, vdimlen);
	
	vresg = vec_cmpgt(*v, vcmpg);
	vresl = vec_cmple(*v, vcmpl);
	
	*v = vec_sel(*v, vdadd, vresl);
	*v = vec_sel(*v, vdsub, vresg);
}

/**
 * 粒子間の相互作用のエネルギーを計算する。
 * x, y, mx, my, idx: 粒子のパラメータ
 * bl, bc: 対象のブロック
 * out: エネルギーの値を格納する場所
 * 返り値: エネルギーを計算できたら CEN_NOERR, 未定義なら CEN_UNDEFINED
 */
int com_inter_en(float x, float y, float mx, float my, int idx, int bl, int bc, float *out)
{
	const vector float vx = { x, x, x, x };
	const vector float vy = { y, y, y, y };
	const vector float vmx = { mx, mx, mx, mx };
	const vector float vmy = { my, my, my, my };
	const vector unsigned int vidx = { idx, idx, idx, idx };
	vector float vbx, vby, vbmx, vbmy;
	vector unsigned int vbidx;
	vector float vdx, vdy; // 距離
	vector float vdysq; // vdy*vdy
	vector float vdsq; // vdx*vdx + vdy*vdy
	vector float vred, vredsq, vredcb; // それぞれ距離の逆数、距離の平方の逆数、距離の立方の逆数
	static const vector float zero = { 0.0f, 0.0f, 0.0f, 0.0f };
	static const vector float vcutoffsq = { RCUTOFFSQ, RCUTOFFSQ, RCUTOFFSQ, RCUTOFFSQ };
	static const vector float v3 = { 3.0f, 3.0f, 3.0f, 3.0f };
	static const vector float vlambda = { LAMBDA, LAMBDA, LAMBDA, LAMBDA };
	static const vector float vtempadd = { RCUTOFF+1.0f, RCUTOFF+1.0f, RCUTOFF+1.0f, RCUTOFF+1.0f };
	vector bool int vsame;
	vector float vtempdx;
	vector float vtie = { 0.0f, 0.0f, 0.0f, 0.0f };
	vector bool int vrescoff;
	volatile float *bx, *by, *bmx, *bmy;
	volatile unsigned int *bidx;
	float *pv;
	vector float v_3redsq, v_mxdx, v_bmxdx, v_mydy, v_bmydy, v_dotmd, v_dotbmd, v_dotdot,
	    v_ie1, v_lredcb, v_mxbmx, v_mybmy, v_dotmbm, v_dot_sub_ie1, vie;
	int n = dupninblock[bl][bc];
	float en = 0.0f;
	int i, m;
	int j;
	int overlapped;
	
	bx = duppos[bl][bc][POS_X];
	by = duppos[bl][bc][POS_Y];
	bmx = dupmag[bl][bc][MAG_X];
	bmy = dupmag[bl][bc][MAG_Y];
	bidx = dupidx[bl][bc];

	/* ループの終了条件は n が 4 の倍数でないときの処理を行うために後で判定する */
	for(i = 0; ; i += 4) {
		vbx = *(vector float *)&bx[i];
		vby = *(vector float *)&by[i];
		vbmx = *(vector float *)&bmx[i];
		vbmy = *(vector float *)&bmy[i];
		vbidx = *(vector unsigned int *)&bidx[i];
		
		// 距離を求める
		vdx = vec_sub(vbx, vx);
		vdy = vec_sub(vby, vy);
		fix_distance(&vdx);
		fix_distance(&vdy);

		// 同一の粒子間で計算されるときは距離をカットオフ距離より離れているものと
		// 設定してエネルギーの値を 0 にする
		vsame = vec_cmpeq(vbidx, vidx);
		vtempdx = vec_add(vdx, vtempadd);
		vdx = vec_sel(vdx, vtempdx, vsame);

		// 距離の平方を求める
		vdysq = vec_madd(vdy, vdy, zero);
		vdsq = vec_madd(vdx, vdx, vdysq);

		// 重なる部分があればエネルギーの値は定義無し
		overlapped = 0;
		for(j = 0; j < 4 && i+j < n; j++) {
			if(((float *)&vdsq)[j] < DIAMETER) {
				if(((float *)&vdsq)[j] > DIAMETER * 0.98f) {
					fprintf(stderr, "PPE: warning: overlapped? (%d - %d) distance = %f\n",
							 idx, bidx[i+j], ((float *)&vdsq)[j]);
				} else {
					overlapped = 1;
					break;
				}
			}
		}
		if(overlapped) {
			for(j = 0; j < 4 && i+j < n; j++) {
				if(((float *)&vdsq)[j] < 1.0f) {
					fprintf(stderr, "PPE: (%d - %d), overlapped\n", idx, bidx[i+j]);
					fprintf(stderr, "PPE: (%d) (%f, %f), b(%d, %d)\n", 
							 idx, x, y, get_blockidx(y), get_blockidx(x));
					fprintf(stderr, "PPE: (%d) (%f, %f), b(%d, %d)\n", 
							 bidx[i+j], bx[i+j], by[i+j], bl, bc);
					fprintf(stderr, "PPE: distance = %f\n", ((float *)&vdsq)[j]);
				}
			}

			return CEN_UNDEFINED;
		}

		// 距離の逆数を求める
		vred = vec_rsqrte(vdsq);
		
		// 距離の平方の逆数を求める
		vredsq = vec_re(vdsq);
		
		// 距離の立方の逆数を求める
		vredcb = vec_madd(vred, vredsq, zero);
		
		// 元の式
		// ie1 = 3.0 * (mx*dx + my*dy) * (bmx*dx + bmy*dy) * redsq;
		// ie = LAMBDA * (mx*bmx + my*bmy - ie1) * redcb;
		
		v_3redsq = vec_madd(v3, vredsq, zero);
		v_mxdx = vec_madd(vmx, vdx, zero);
		v_mydy = vec_madd(vmy, vdy, zero);
		v_bmxdx = vec_madd(vbmx, vdx, zero);
		v_bmydy = vec_madd(vbmy, vdy, zero);
		v_dotmd = vec_add(v_mxdx, v_mydy);
		v_dotbmd = vec_add(v_bmxdx, v_bmydy);
		v_dotdot = vec_madd(v_dotmd, v_dotbmd, zero);
		v_ie1 = vec_madd(v_3redsq, v_dotdot, zero);
		v_lredcb = vec_madd(vlambda, vredcb, zero);
		v_mxbmx = vec_madd(vmx, vbmx, zero);
		v_mybmy = vec_madd(vmy, vbmy, zero);
		v_dotmbm = vec_add(v_mxbmx, v_mybmy);
		v_dot_sub_ie1 = vec_sub(v_dotmbm, v_ie1);
		vie = vec_madd(v_lredcb, v_dot_sub_ie1, zero);
						
		// カットオフ距離以遠の場合はエネルギーの値を 0 にする
		vrescoff = vec_cmpge(vdsq, vcutoffsq);
		vie = vec_sel(vie, zero, vrescoff);

		// 残りがなくなったらループ終了
		if(i+4 >= n) {
			break;
		}

		vtie = vec_add(vtie, vie);
	}

	// 最後の vie から有効な部分だけをエネルギーの値に加える。
	pv = (float *)&vie;
	m = n - i;
	for(i = 0; i < m; i++) {
		en += pv[i];
	}
	
	pv = (float *)&vtie;
	en += pv[0] + pv[1] + pv[2] + pv[3];

	*out = en;
	return CEN_NOERR;
}

/**
 * 系の全エネルギーを計算する。
 * out: エネルギーの値を格納する場所
 * 返り値: エネルギーを計算できたら CEN_NOERR, 未定義なら CEN_UNDEFINED
 */
int com_total_energy(float *out)
{
        int i, j, k;
        float tenergy, interen;
        float x, y, mx, my;
        int bl, bc, bi;
        int ibl, ibc;

        tenergy = 0.0;
        for(i = 0; i < NPARTICLES; i++) {
                bl = dupdatapos[i].bline;
                bc = dupdatapos[i].bcol;
                bi = dupdatapos[i].bidx;
                x = duppos[bl][bc][POS_X][bi];
                y = duppos[bl][bc][POS_Y][bi];
                mx = dupmag[bl][bc][MAG_X][bi];
                my = dupmag[bl][bc][MAG_Y][bi];

                tenergy += - XI * my;

                for(j = -1; j <= +1; j++) {
                        for(k = -1; k <= +1; k++) {
                                ibl = fix_bidx(bl + j);
                                ibc = fix_bidx(bc + k);
                                if(com_inter_en(x, y, mx, my, i, ibl, ibc, &interen) == CEN_UNDEFINED) {
                                        return CEN_UNDEFINED;
                                } else {
                                        tenergy += interen * 0.5f;
                                }
                        }
                }
        }

        *out = tenergy;
        return CEN_NOERR;
}

//int check = 0;
/**
 * 指定した粒子のエネルギーを計算する。
 * x, y, mx, my, idx: 配列中の値の代わりに使うパラメータ
 * out: エネルギーの値を格納する場所
 * 返り値: エネルギーを計算できたら CEN_NOERR, 未定義なら CEN_UNDEFINED
 */
int com_energy(float x, float y, float mx, float my, int idx, float *out)
{
	int i, j;
	int bl, bc;
	int ibl, ibc;
	float en, interen;
	
	bl = dupdatapos[idx].bline;
	bc = dupdatapos[idx].bcol;
	
	en = - XI * my;

	for(i = -1; i <= +1; i++) {
		for(j = -1; j <= +1; j++) {
			ibl = fix_bidx(bl + i);
			ibc = fix_bidx(bc + j);
			if(com_inter_en(x, y, mx, my, idx, ibl, ibc, &interen) == CEN_UNDEFINED) {
				return CEN_UNDEFINED;
			} else {
				en += interen;
			}
		}
	}

	*out = en;
	return CEN_NOERR;
}

///////////////////////////////////////////////////////////////////////////////
// 出力スレッド
///////////////////////////////////////////////////////////////////////////////

/**
 * 出力用に控えたパラメータを出力する
 */
void *pthread_run_output(void *arg)
{
        int i, j;
        float x, y, deg;
        int bc, bl, bi;
        int ret;
        float en;

        for(i = 0; i < NLBLOCKS; i++) {
                for(j = 0; j < NLBLOCKS; j++) {
                        dupninblock[i][j] = 0;
                }
        }

        for(i = 0; i < NPARTICLES; i++) {
                x = pdupdata[i].x;
                y = pdupdata[i].y;
                bl = get_blockidx(y);
                bc = get_blockidx(x);
                dupdatapos[i].bline = bl;
                dupdatapos[i].bcol = bc;
                dupdatapos[i].bidx = bi = dupninblock[bl][bc]++;
                //dupdatapos[i].on_edge = is_on_edge(x, y);

                duppos[bl][bc][POS_X][bi] = x;
                duppos[bl][bc][POS_Y][bi] = y;
                dupdeg[bl][bc][bi] = deg = pdupdata[i].deg;
                dupmag[bl][bc][MAG_X][bi] = cos(deg);
                dupmag[bl][bc][MAG_Y][bi] = sin(deg);
                dupidx[bl][bc][bi] = i;

                fprintf(output_file, "%f %f %f\n",
                                 pdupdata[i].x, pdupdata[i].y, pdupdata[i].deg);
        }

        ret = com_total_energy(&en);
        if(ret == CEN_UNDEFINED) {
                fprintf(stderr, "Bad particle position.\n");
                exit(1);
        }

        fprintf(output_file, "%f\n", en);

        duplicated = 0;

        pthread_exit(NULL);
}

//////////////////////////////////////////////////////////////////////////////////
// 出力
//////////////////////////////////////////////////////////////////////////////////

int output_open()
{
	if(output_file == NULL) {
		output_file = fopen(OUTPUT_FILE_NAME, "w");
		if(output_file == NULL) {
			perror("output");
			return OUTPUT_FAILED;
		}
	}
	
	fprintf(output_file, "%d\n", NPARTICLES);
	fprintf(output_file, "%f\n", DIMLEN);
	
	return 0;
}

void output(int step)
{
	//printf("output step %d.\n", step);

	fprintf(output_file, "%d\n", step);
	
	if(pthread_create(&pthread_output, NULL, pthread_run_output, NULL)) {
		perror("Failed creating output thread");
		exit(1);
	}
	
	//if(pthread_join(pthread_output, NULL)) {
	//	perror("Failed joining output thread");
	//	exit(1);
	//}

	/*
	for(i = 0; i < NLBLOCKS; i++) {
		for(j = 0; j < NLBLOCKS; j++) {
			fprintf(output_file, "%d ", ninblock[i][j].val);	
		}
		fprintf(output_file, "\n");
	}
	// */
}

int output_close()
{
	if(pthread_output != -1) {
		if(pthread_join(pthread_output, NULL)) {
			perror("Failed joining output thread");
			exit(1);
		}
	}
	
	if(output_file != NULL) {
		fclose(output_file);
		output_file = NULL;
	}
	
	return OUTPUT_NOERR;	
}
