#ifndef MC_PARAM_16_H_
#define MC_PARAM_16_H_

#define NLINES       16
#define NPARTICLES   256
#define LAMBDA       2.0f
#define XI           4.0f
#define RCUTOFF      8.0f
#define RDELTA       0.5f
#define DEGDELTA     0.17453294f
#define DIMLEN       50.596443f
#define BLOCKSIZE    12.649123f
#define NLBLOCKS     4
#define MAX_NINBLOCK 64
#define _NSPE        1

#endif // MC_PARAM_16_H_
