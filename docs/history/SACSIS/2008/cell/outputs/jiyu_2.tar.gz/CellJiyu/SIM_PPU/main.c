
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "mc-sim.h"

int main(int argc, char *argv[])
{
	unsigned int nsteps, outputstep;

	if(argc != 3) {
		fprintf(stderr, "usage: [step] [outputstep]\n");
		return 0;		
	}
	
	nsteps = atoi(argv[1]);
	outputstep = atoi(argv[2]);
	
	if(nsteps == 0) {
		return 0;
	}
	
	if(outputstep == 0) {
		return 0;
	}
	
	//printf("step = %d, outputstep = %d\n", nsteps, outputstep);

	simulate(nsteps, outputstep);
	return 0;	
}
