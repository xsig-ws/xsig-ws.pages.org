#ifndef MCPARAM256_H_
#define MCPARAM256_H_

#define NLINES       256
#define NPARTICLES   65536
#define LAMBDA       4.0f
#define XI           4.0f
#define RCUTOFF      8.0f
#define RDELTA       0.5f
#define DEGDELTA     0.17453294f
#define DIMLEN       809.5431f
#define BLOCKSIZE    12.698522f
#define NLBLOCKS     64
#define MAX_NINBLOCK 64
#define _NSPE        6

#endif /*MCPARAM256_H_*/
