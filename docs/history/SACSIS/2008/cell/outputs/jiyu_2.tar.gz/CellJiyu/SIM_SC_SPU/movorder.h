#ifndef MOVORDER_H_
#define MOVORDER_H_

#include "../SIM_PPU/spe-communication.h"
#include "../SIM_PPU/mc-param.h"

void init_movorder(eaptr_t ea);
void prepare_movorder();
void movorder_nextstep();
unsigned int get_next_particle_index();

#endif /*MOVORDER_H_*/
