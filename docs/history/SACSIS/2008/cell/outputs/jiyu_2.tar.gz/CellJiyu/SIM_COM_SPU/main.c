
#include <spu_intrinsics.h>
#include <spu_mfcio.h>

#include "particle.h"

int main(unsigned long long spe, unsigned long long param)
{
	volatile SPE_ARG arg;
	static const unsigned int tag = 0;

	
	mfc_get(&arg, param, sizeof(SPE_ARG), tag, 0, 0);
	mfc_write_tag_mask(1 << tag);
	mfc_read_tag_status_all();
	
	set_arg(&arg);
	
	init_communication();

        //spe_printf("SPE(%d): init communication finished\n", arg.speid);
	
	step();

	return 0;	
}
