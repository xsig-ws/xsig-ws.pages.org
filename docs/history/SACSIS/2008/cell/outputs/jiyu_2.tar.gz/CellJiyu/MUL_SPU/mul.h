#ifndef MUL_H_
#define MUL_H_

#include "../MUL_PPU/parameter.h"

void message_loop(eaptr_t eavPosition, eaptr_t eamTransform);

#endif /*MUL_H_*/
