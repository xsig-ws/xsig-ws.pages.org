#ifndef MC_PARAM_H_
#define MC_PARAM_H_

#include "mc-param-64.h"

#define NSPE _NSPE

#if NSPE > 7
  #error "NSPE must be less than 8."
#elseif NSPE < 2
  #error "NSPE must be greater than 1."
#endif

#endif /*MC_PARAM_H_*/
