
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "mc-sim.h"
#include "mc-particle.h"

int run(unsigned int nsteps, unsigned int outputstep);
int main_loop(unsigned int nsteps, unsigned int outputstep);
void finish(int step);

/**
 * シミュレーションを開始する。
 */
int simulate(unsigned int nsteps, unsigned int outputstep)
{
	//printf("Set parameters.\n");
	set_parameters();
	
	//printf("Initialize communication\n");
	init_communication();

	//printf("Initialize particles.\n");
	init_particles();
	
	//printf("Start simulation.\n");
	
	return run(nsteps, outputstep);
}

/**
 * シミュレーションのメインループを回す。
 */
int run(unsigned int nsteps, unsigned int outputstep)
{
	if(output_open() == OUTPUT_FAILED) {
		exit(1);
	}
	
	main_loop(nsteps, outputstep);

	output_close();

	return 0;	
}

/**
 * メインループ
 */
int main_loop(unsigned int nsteps, unsigned int outputstep)
{
	int i;

	for(i = 0; i < nsteps; i++) {
		if(i % outputstep == 0) {
			output(i);
		}

		step(i, (i % outputstep == (outputstep-1)) || (i == (nsteps-1)));
	}
	
	clear();
	
	finish(i);
	
	return 0;
}


void finish(int step)
{	
	output(step);
}
