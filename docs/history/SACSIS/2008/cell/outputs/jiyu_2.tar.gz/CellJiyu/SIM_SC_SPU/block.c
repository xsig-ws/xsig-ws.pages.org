
#include <spu_intrinsics.h>
#include <spu_mfcio.h>

#include "block.h"

int is_on_edge(float x, float y)
{
	int bl = get_blockidx(y);
	int bc = get_blockidx(x);
	float bx = x - bc*BLOCKSIZE;
	float by = y - bl*BLOCKSIZE;
	return (bx < RDELTA || BLOCKSIZE-RDELTA < bx) || (by < RDELTA || BLOCKSIZE-RDELTA < by);
}

int get_blockidx(float pos)
{
	return (int)(pos / BLOCKSIZE);
}

int fix_bidx(int idx)
{
	return (NLBLOCKS + idx) % NLBLOCKS;	
}

int get_bdist(int a, int b) {
	int ret = b - a;
	if(ret <= -NLBLOCKS/2) {	
		ret += NLBLOCKS;
	} else if(ret > NLBLOCKS/2) {
		ret -= NLBLOCKS;
	}
	
	ret = abs(ret);
	
	return ret;
}

vector signed short get_bdistv(vector signed short a, vector signed short b)
{
	const vector signed short vnlbdiv2 = { NLBLOCKS/2, NLBLOCKS/2, NLBLOCKS/2, NLBLOCKS/2, NLBLOCKS/2, NLBLOCKS/2, NLBLOCKS/2, NLBLOCKS/2 };
	const vector signed short vnnlbdiv2 = { - NLBLOCKS/2, - NLBLOCKS/2, - NLBLOCKS/2, - NLBLOCKS/2, - NLBLOCKS/2, - NLBLOCKS/2, - NLBLOCKS/2, - NLBLOCKS/2 };
	const vector signed short vnlb = { NLBLOCKS, NLBLOCKS, NLBLOCKS, NLBLOCKS, NLBLOCKS, NLBLOCKS, NLBLOCKS, NLBLOCKS };
	vector signed short vret;
	vector signed short vd, vdadd, vdsub;
	vector unsigned short vdle;
	vector unsigned short vdgt;
	vector unsigned short vle0;
	vector signed short vnret;
	vector signed short v0 = { 0, 0, 0, 0, 0, 0, 0, 0 };
	
	vd = spu_sub(b, a);
	vdadd = spu_add(vd, vnlb);
	vdsub = spu_sub(vd, vnlb);
	
	vdle = spu_cmpgt(vnnlbdiv2, vd);
	vdgt = spu_cmpgt(vd, vnlbdiv2);
	vret = spu_sel(vd, vdadd, vdle);
	vret = spu_sel(vret, vdsub, vdgt);
	
	/* retの絶対値をとる */
	vle0 = spu_cmpgt(v0, vret);
	vnret = spu_sub(v0, vret);
	vret = spu_sel(vret, vnret, vle0);

	return vret;
}

int fix_bdist_rel(int dist) {
	int ret = dist;
	if(ret <= -NLBLOCKS/2) {	
		ret += NLBLOCKS;
	} else if(ret > NLBLOCKS/2) {
		ret -= NLBLOCKS;
	}
	
	return ret;
}

vector float fix_distance(vector float v)
{
	static const vector float vdimlen = { DIMLEN, DIMLEN, DIMLEN, DIMLEN };
	static const vector float vcmpg = { DIMLENHALF, DIMLENHALF, DIMLENHALF, DIMLENHALF };
	static const vector float vcmpl = { -DIMLENHALF, -DIMLENHALF, -DIMLENHALF, -DIMLENHALF };
	vector float vdadd, vdsub;
	vector unsigned int vresg, vreslt, vreseq, vresle;
	vector float vret;

	vdadd = spu_add(v, vdimlen);
	vdsub = spu_sub(v, vdimlen);
	
	vresg = spu_cmpgt(v, vcmpg);
	vreslt = spu_cmpgt(vcmpl, v);
	vreseq = spu_cmpeq(v, vcmpl);
	vresle = spu_or(vreslt, vreseq);
	
	vret = spu_sel(v, vdadd, vresle);
	vret = spu_sel(vret, vdsub, vresg);
	return vret;
}
