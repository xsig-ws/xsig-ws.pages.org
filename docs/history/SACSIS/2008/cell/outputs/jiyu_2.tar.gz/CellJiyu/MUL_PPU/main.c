
#include <stdio.h>
#include <stdlib.h>

#include <spe_wrap.h>
#include <spere_cbea.h>
#include <spe_stdio_srv.h>

#include "parameter.h"

typedef unsigned int uint32_t;

VECTOR g_vPosition[NPOSITION] __attribute__ ((aligned(16)));
MATRIX g_mTransform __attribute__ ((aligned(16)));
SPE_ARG arg __attribute__ ((aligned(16)));

swt_handle *run_spe(SPE_ARG *pArg)
{
        swt_handle *swth;

        arg = *pArg;

        //fprintf(stderr, "PPE: create context\n");
	_spe_stdio_init(64);
	_spe_stdio_start();

        if((swth = spe_wrap_create_dedicated_thread("MUL_SPU/mulspe", &arg, SIGNOTIFY_INIT_MODE)) == NULL) {
                perror("Failed creating spe thread");
                exit(1);
        }

        spe_wrap_resume_thread(swth->id);

        return swth;
}

int join_spe(swt_handle *swth)
{
        spe_wrap_wait_thread(swth->id);

        spe_wrap_release_thread(swth);

        _spe_stdio_end();

        return 1;
}

SPE_ARG initialize()
{
        SPE_ARG arg;
        int i;
        vector float vLine[4] = {
                { 1.0f, 0.0f, 0.0f, 0.0f, },
                { 0.0f, 1.0f, 0.0f, 0.0f, },
                { 0.0f, 0.0f, 1.0f, 0.0f, },
                { 0.0f, 0.0f, 1.0f, 1.0f, },
        }; // z軸方向に1.0だけ平行移動する行列(右から掛ける)

        g_mTransform.vLine[0] = vLine[0];
        g_mTransform.vLine[1] = vLine[1];
        g_mTransform.vLine[2] = vLine[2];
        g_mTransform.vLine[3] = vLine[3];

        for(i = 0; i < NPOSITION; i++) {
                g_vPosition[i].e[0] = (float)(i / 1000.0f);
                g_vPosition[i].e[1] = (float)(i / 1000.0f);
                g_vPosition[i].e[2] = (float)(i / 1000.0f);
                g_vPosition[i].e[3] = 1.0f;
        }

        arg.eavPosition = (eaptr_t)g_vPosition;
        arg.eamTransform = (eaptr_t)&g_mTransform;

        return arg;
}

uint32_t make_mail(uint32_t buf, uint32_t count)
{
        return MAKE_MAIL(buf, count);
}

int transform(swt_handle *swth)
{
        int i;
	spere_object_id ahint;
        uint32_t mail = make_mail(0, NPOSITION);

	ahint = spe_wrap_add_access_hint(swth->id, g_vPosition, sizeof(g_vPosition));

        spere_spe_thread_write_mmio_reg(swth->id, SPERE_CBEA_MMIO_OFFSET_SPU_IN_MBOX, mail);

        for(;;) {
      		spere_spe_thread_read_mmio_reg(swth->id, SPERE_CBEA_MMIO_OFFSET_SPU_OUT_MBOX, &mail);
		if(mail == SPEREPLY_FINISHED) {
			break;
		}
        }

        mail = MAIL_HALT;
        spere_spe_thread_write_mmio_reg(swth->id, SPERE_CBEA_MMIO_OFFSET_SPU_IN_MBOX, mail);

        spe_wrap_remove_access_hint(swth->id, ahint);

	// 結果の確認
        //for(i = 0; i < NPOSITION; i++) {
        //        if(i % 32767 == 0) {
        //                printf("%5d: %f %f %f\n", i, g_vPosition[i].e[0], g_vPosition[i].e[1], g_vPosition[i].e[2]);
        //        }
        //}

        return 1;
}

int main(int argc, char *argv[])
{
	swt_handle *swth;
	SPE_ARG arg;
	int success;
	
	arg = initialize();
	
	swth = run_spe(&arg);
	if(swth == NULL) {
		return 1;
	}
	
	success = transform(swth);
	if(!success) {
		return 1;
	}
	
	success = join_spe(swth);
	if(!success) {
		return 1;
	}

	return 0;
}
