
#include "mc-param.h"
#include "rand.h"
#include "order.h"

/*typedef struct {
	float r;
	int idx;
} FOR_SORTING;

FOR_SORTING sortidx[NPARTICLES];

int order_cmp(const void *v1, const void *v2)
{
	const FOR_SORTING *s1 = v1;
	const FOR_SORTING *s2 = v2;
	
	if(s1->r > s2->r) {
		return +1;
	} else if(s1->r < s2->r) {
		return -1;
	} else {
		return 0;
	}
}*/

/**
 * 粒子を移動する順番を決定する。
 */
void gen_movorder(unsigned int *movorder)
{
	unsigned int i, r;
	unsigned int temp;
	
	for(i = 0; i < NPARTICLES; i++) {
		movorder[i] = i;
	}
	
    for (i = 0; i < NPARTICLES - 1; i++) {
        r = gen_rand(i, NPARTICLES);
        temp = movorder[i];
        movorder[i] = movorder[r];
        movorder[r] = temp;
    }
    
    //for(i = 0; i < NPARTICLES; i++) {
	//   printf("%d\n", movorder[i]);
    //}

	/*for(i = 0; i < NPARTICLES; i++) {
		sortidx[i].r = gen_rand();
		sortidx[i].idx = i;
	}
	
	qsort(sortidx, NPARTICLES, sizeof(FOR_SORTING), order_cmp);
	
	for(i = 0; i < NPARTICLES; i++) {
		movorder[i] = sortidx[i].idx;
	}*/
}
