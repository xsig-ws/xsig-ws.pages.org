
#include <spu_intrinsics.h>
#include <spu_mfcio.h>

#include <stdio.h>

#include "movorder.h"

#define TAG_ORDER 9

#define MOVORDER_BUFSIZE 128

eaptr_t eamovorder;

volatile unsigned int lsmovorder[2][MOVORDER_BUFSIZE] __attribute__ ((aligned(16)));
unsigned int next;
unsigned int movorderbuf;
unsigned int curbuf, nxtbuf;

// 移動順を格納する配列の実効アドレスを設定する
void init_movorder(eaptr_t ea)
{
	eamovorder = ea;
	movorderbuf = 1;
}

// get_next_particle_index関数を呼び出す前にこの関数で初期化する
// movorderの実効アドレスが設定されている必要がある
void prepare_movorder()
{
	curbuf = 0;
	nxtbuf = 1;

	movorderbuf = (movorderbuf+1) % 2;
	mfc_get(&lsmovorder[nxtbuf], eamovorder + movorderbuf*NPARTICLES*sizeof(unsigned int), sizeof(lsmovorder[nxtbuf]), TAG_ORDER+nxtbuf, 0, 0);
	
	next = 0;
}

// 次に移動する粒子のインデックスを得る
unsigned int get_next_particle_index()
{
	if(next % MOVORDER_BUFSIZE == 0) {
		curbuf = nxtbuf;
		nxtbuf = (nxtbuf+1) % 2;

		mfc_get(&lsmovorder[nxtbuf], eamovorder + (movorderbuf*NPARTICLES + (next+MOVORDER_BUFSIZE)) * sizeof(unsigned int), sizeof(lsmovorder[nxtbuf]), TAG_ORDER+nxtbuf, 0, 0);

		mfc_write_tag_mask(1 << (TAG_ORDER+curbuf));
		mfc_read_tag_status_all();
	}
	
	return lsmovorder[curbuf][next++ % MOVORDER_BUFSIZE];
}
