
#ifndef _SCHEDULE_H_
#define _SCHEDULE_H_

#include "../SIM_PPU/spe-arg.h"
#include "../SIM_PPU/mc-param.h"

void set_arg(volatile SPE_ARG *arg);

void init_communication();

void dup_enable(int enable);
void step();

void clear();

#endif // _SCHEDULE_H_
