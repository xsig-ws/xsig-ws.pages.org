#ifndef SPECOMMUNICATION_H_
#define SPECOMMUNICATION_H_

#define MAX_NSPE 8

typedef unsigned int eaptr_t;
typedef unsigned int lsptr_t;

#define OP_END     0x1
#define OP_MOVE    0x2
#define OP_WAIT    0x3
#define OP_RANDH   0x4
#define OP_RANDL   0x5
#define OP_DUP     0x6
#define OP_RESET   0x7
#define OP_ENDSTEP 0x8

#define SPEINST_END     (OP_END     << 28)
#define SPEINST_MOVE    (OP_MOVE    << 28)
#define SPEINST_WAIT    (OP_WAIT    << 28)
#define SPEINST_RANDH   (OP_RANDH   << 28) // SPEMB_RANDはHL合わせて一組
#define SPEINST_RANDL   (OP_RANDL   << 28)
#define SPEINST_DUP     (OP_DUP     << 28) // パラメータの複製の有り無しを設定する
#define SPEINST_RESET   (OP_RESET   << 28)
#define SPEINST_ENDSTEP (OP_ENDSTEP << 28)

#define SPETMINST_BEGIN   0x10FFFFFF
#define SPETMINST_DUPSTEP 0x20FFFFFF
#define SPETMINST_END     0x40FFFFFF

#define SPEINST_INSTMASK      0xF0000000
#define SPEINST_IDXMASK       0x00FFFFFF
#define SPEINST_PHASEMASK     0x00FFFFFF
#define SPEINST_SPEMASK       0x0F000000
#define SPEINST_RANDSTARTMASK 0x0FFFFFFF
#define SPEINST_RANDCOUNTMASK 0x0FFFFFFF // RANDDATAの個数
#define SPEINST_DUPENABLEMASK 0x0FFFFFFF
#define SPEINST_LINEMASK      0x00000FFF
#define SPEINST_COLLUMNMASK   0x00FFF000

#define INST_GET_OP(inst)        ((inst & SPEINST_INSTMASK     ) >> 28)
#define INST_GET_IDX(inst)        (inst & SPEINST_IDXMASK      )
#define INST_GET_PHASE(inst)      (inst & SPEINST_PHASEMASK    )
#define INST_GET_SPE(inst)       ((inst & SPEINST_SPEMASK      ) >> 24)
#define INST_GET_RANDSTART(inst)  (inst & SPEINST_RANDSTARTMASK)
#define INST_GET_RANDCOUNT(inst)  (inst & SPEINST_RANDCOUNTMASK)
#define INST_DUP_ENABLE(inst)     (inst & SPEINST_DUPENABLEMASK)
#define INST_GET_LINE(inst)       (inst & SPEINST_LINEMASK     )
#define INST_GET_COLLUMN(inst)   ((inst & SPEINST_COLLUMNMASK  ) >> 12)

#define SPETMMB_ENDSTEP    0x20FFFFFF
#define SPETMMB_ENDGENRAND 0x30FFFFFF

#define RANDBUF_SIZE 256

typedef struct {
	volatile unsigned int phase;
	volatile unsigned int randstep;
	volatile unsigned int ninstreceived;
	volatile unsigned int endstep;
} SPE_SYN_DATA;

#define INST_ARRAY_SIZE 4

/* 命令の配列を格納した構造体 */
// 格納している命令は最新のINST_ARRAY_SIZE分の命令
// タスクマネージャーはSPEの実行速度に合わせてデータを更新し
// n番め(0から数えて)の命令は(n % INST_ARRAY_SIZE)で参照可能なことを保証する
typedef struct {
	volatile unsigned int array[INST_ARRAY_SIZE];
	volatile unsigned int count; /* 命令の合計数 */
	char reserved[12];
} SPE_INST;

#endif /*SPECOMMUNICATION_H_*/
