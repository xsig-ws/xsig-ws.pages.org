#ifndef MCPARTICLE_H_
#define MCPARTICLE_H_

#include "mc-param.h"

#define PI (3.14159265f)

#define CEN_NOERR 0
#define CEN_UNDEFINED 1

void set_parameters();

void init_particles();

void init_communication();

int step(int n, int dup);

void clear();

#define OUTPUT_NOERR		0
#define OUTPUT_FAILED	1
#define OUTPUT_FILE_NAME "SIM_PPU/output.txt"

int output_open();
void output(int step);
int output_close();

#endif /*MCPARTICLE_H_*/
