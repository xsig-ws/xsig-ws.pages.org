#ifndef PARTICLEDATA_H_
#define PARTICLEDATA_H_

#define POS_X 0
#define POS_Y 1

#define MAG_X 0
#define MAG_Y 1

typedef struct {
	int bline;
	int bcol;
	int bidx;
	int on_edge;
} DATAPOS;

typedef struct {
	float x;   // x座標用乱数
	float y;   // y座標用乱数
	float deg; // 角度用乱数
	float sel; // 状態採択用乱数
} RANDDATA;

typedef struct {
	float x;
	float y;
	float deg;
	unsigned int reserved;
} DUPDATA;

typedef struct {
	unsigned int val;
	int reserved1;
	int reserved2;
	int reserved3;
} NINBLOCK;

#endif /*PARTICLEDATA_H_*/
