
#ifndef _PARTICLE_H_
#define _PARTICLE_H_

#include "../SIM_PPU/spe-arg.h"
#include "../SIM_PPU/mc-param.h"

#define PI (3.14159265f)

void set_arg(volatile SPE_ARG *arg);

void init_communication();

void step();

#endif // _PARTICLE_H_
