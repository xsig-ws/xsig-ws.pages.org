#ifndef PARAMETER_H_
#define PARAMETER_H_

#define NPOSITION       1048576
#define VECTOR_BUF_SIZE    1024

#if NPOSITION%VECTOR_BUF_SIZE != 0
	#error "Invalid VECTOR_BUF_SIZE\n"
#endif

typedef unsigned int eaptr_t;

// 4次の正方行列
// 各ベクトルは行列の行成分を表す
typedef struct {
	vector float vLine[4];
} MATRIX;

typedef union {
	vector float v;
	float e[4];
} VECTOR;

typedef struct {
	eaptr_t eavPosition;
	eaptr_t eamTransform;
	char pad[8];
} SPE_ARG;

#define MAKE_MAIL(buf, count) ((buf << 30) | (count))

#define MAIL_HALT 0x10000000

#define GET_BUF(mail)   (mail >> 30)
#define GET_COUNT(mail) (mail & 0x3FFFFFFF)

#define SPEREPLY_FINISHED 0x10000000

#endif /*PARAMETER_H_*/
