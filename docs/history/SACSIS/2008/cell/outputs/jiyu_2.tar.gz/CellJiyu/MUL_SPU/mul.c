
#include <spu_intrinsics.h>
#include <spu_mfcio.h>

#include <spe_stdio.h>

#include "mul.h"

eaptr_t g_eavPosition[2];
eaptr_t g_eamTransform;

volatile VECTOR g_vPosition[2][VECTOR_BUF_SIZE] __attribute__ ((aligned(16)));
volatile MATRIX g_mTransform __attribute__ ((aligned(16)));

vector float vl0; // vl0 = (a00 a01 a02 a03)
vector float vl1; // vl1 = (a10 a11 a12 a13)
vector float vl2; // vl2 = (a20 a21 a22 a23)
vector float vl3; // vl3 = (a30 a31 a32 a33)

vector float multiply(VECTOR v)
{
	vector float vx = spu_splats(spu_extract(v.v, 0));
	vector float vy = spu_splats(spu_extract(v.v, 1));
	vector float vz = spu_splats(spu_extract(v.v, 2));
	vector float vw = spu_splats(spu_extract(v.v, 3));
	
	vector float vmulx = spu_mul(vx, vl0);
	vector float vmuly = spu_mul(vy, vl1);
	vector float vmulz = spu_mul(vz, vl2);
	vector float vmulw = spu_mul(vw, vl3);
	
	vector float vadd0 = spu_add(vmulx, vmuly);
	vector float vadd1 = spu_add(vmulz, vmulw);
	
	vector float vmul = spu_add(vadd0, vadd1);

	return vmul;
}

void multiply_all(int buf)
{
	int i;

	vl0 = g_mTransform.vLine[0]; // vl0 = (a00 a01 a02 a03)
	vl1 = g_mTransform.vLine[1]; // vl1 = (a10 a11 a12 a13)
	vl2 = g_mTransform.vLine[2]; // vl2 = (a20 a21 a22 a23)
	vl3 = g_mTransform.vLine[3]; // vl3 = (a30 a31 a32 a33)

	for(i = 0; i < VECTOR_BUF_SIZE; i += 4) {
		//g_vPosition[buf][i].v = multiply(g_vPosition[buf][i]);
		
		vector float v = g_vPosition[buf][i].v;
		vector float v2 = g_vPosition[buf][i+1].v;
		vector float v3 = g_vPosition[buf][i+2].v;
		vector float v4 = g_vPosition[buf][i+3].v;

		vector float vx = spu_splats(spu_extract(v, 0));
		vector float vx2 = spu_splats(spu_extract(v2, 0));
		vector float vx3 = spu_splats(spu_extract(v3, 0));
		vector float vx4 = spu_splats(spu_extract(v4, 0));

		vector float vy = spu_splats(spu_extract(v, 1));
		vector float vy2 = spu_splats(spu_extract(v2, 1));
		vector float vy3 = spu_splats(spu_extract(v3, 1));
		vector float vz4 = spu_splats(spu_extract(v4, 2));

		vector float vz = spu_splats(spu_extract(v, 2));
		vector float vz2 = spu_splats(spu_extract(v2, 2));
		vector float vz3 = spu_splats(spu_extract(v3, 2));
		vector float vy4 = spu_splats(spu_extract(v4, 1));

		vector float vw = spu_splats(spu_extract(v, 3));
		vector float vw2 = spu_splats(spu_extract(v2, 3));
		vector float vw3 = spu_splats(spu_extract(v3, 3));
		vector float vw4 = spu_splats(spu_extract(v4, 3));
		
		vector float vmulx = spu_mul(vx, vl0);
		vector float vmulx2 = spu_mul(vx2, vl0);
		vector float vmulx3 = spu_mul(vx3, vl0);
		vector float vmulx4 = spu_mul(vx4, vl0);

		vector float vmuly = spu_mul(vy, vl1);
		vector float vmuly2 = spu_mul(vy2, vl1);
		vector float vmuly3 = spu_mul(vy3, vl1);
		vector float vmuly4 = spu_mul(vy4, vl1);

		vector float vmulz = spu_mul(vz, vl2);
		vector float vmulz2 = spu_mul(vz2, vl2);
		vector float vmulz3 = spu_mul(vz3, vl2);
		vector float vmulz4 = spu_mul(vz4, vl2);

		vector float vmulw = spu_mul(vw, vl3);
		vector float vmulw2 = spu_mul(vw2, vl3);
		vector float vmulw3 = spu_mul(vw3, vl3);
		vector float vmulw4 = spu_mul(vw4, vl3);
		
		vector float vadd0 = spu_add(vmulx, vmuly);
		vector float vadd02 = spu_add(vmulx2, vmuly2);
		vector float vadd03 = spu_add(vmulx3, vmuly3);
		vector float vadd04 = spu_add(vmulx4, vmuly4);

		vector float vadd1 = spu_add(vmulz, vmulw);
		vector float vadd12 = spu_add(vmulz2, vmulw2);
		vector float vadd13 = spu_add(vmulz3, vmulw3);
		vector float vadd14 = spu_add(vmulz4, vmulw4);
		
		g_vPosition[buf][i].v = spu_add(vadd0, vadd1);
		g_vPosition[buf][i+1].v = spu_add(vadd02, vadd12);
		g_vPosition[buf][i+2].v = spu_add(vadd03, vadd13);
		g_vPosition[buf][i+3].v = spu_add(vadd04, vadd14);
	}
}

/*
void multiply_all(int buf)
{
	// パイプライン処理
	int i;
	vector float v1, v2, v3, v4;
	vector float vx1, vx2, vx3, vx4;
	vector float vy1, vy2, vy3, vy4;
	vector float vz1, vz2, vz3, vz4;
	vector float vw1, vw2, vw3, vw4;
	vector float vmulx1, vmulx2, vmulx3, vmulx4;
	vector float vmuly1, vmuly2, vmuly3, vmuly4;
	vector float vmulz1, vmulz2, vmulz3, vmulz4;
	vector float vmulw1, vmulw2, vmulw3, vmulw4;
	vector float vadd01, vadd02, vadd03, vadd04;
	vector float vadd11, vadd12, vadd13, vadd14;
	vector float vres1, vres2, vres3, vres4;

	vl0 = g_mTransform.vLine[0]; // vl0 = (a00 a01 a02 a03)
	vl1 = g_mTransform.vLine[1]; // vl1 = (a10 a11 a12 a13)
	vl2 = g_mTransform.vLine[2]; // vl2 = (a20 a21 a22 a23)
	vl3 = g_mTransform.vLine[3]; // vl3 = (a30 a31 a32 a33)
	
	v1 = g_vPosition[buf][0].v;
	v2 = g_vPosition[buf][1].v;	
	v3 = g_vPosition[buf][2].v;
	v4 = g_vPosition[buf][3].v;
	vx1 = spu_splats(spu_extract(v1, 0));
	vx2 = spu_splats(spu_extract(v2, 0));
	vy1 = spu_splats(spu_extract(v1, 1));
	vy2 = spu_splats(spu_extract(v2, 1));
	vz1 = spu_splats(spu_extract(v1, 2));
	vz2 = spu_splats(spu_extract(v2, 2));
	vw1 = spu_splats(spu_extract(v1, 3));
	vw2 = spu_splats(spu_extract(v2, 3));
	vmulx1 = spu_mul(vx1, vl0);
	vmulx2 = spu_mul(vx2, vl0);
	vmuly1 = spu_mul(vy1, vl1);
	vmuly2 = spu_mul(vy2, vl1);
	vmulz1 = spu_mul(vz1, vl2);
	vmulz2 = spu_mul(vz2, vl2);
	vmulw1 = spu_mul(vw1, vl3);
	vmulw2 = spu_mul(vw2, vl3);
	vadd01 = spu_add(vmulx1, vmuly1);
	vadd02 = spu_add(vmulx2, vmuly2);
	vadd11 = spu_add(vmulz1, vmulw1);
	vadd12 = spu_add(vmulz2, vmulw2);
	vres1 = spu_add(vadd01, vadd11);
	vres2 = spu_add(vadd02, vadd12);

	for(i = 0; i < VECTOR_BUF_SIZE-4; i += 4) {
		g_vPosition[buf][i].v = vres1;
		g_vPosition[buf][i+1].v = vres2;

		v1 = g_vPosition[buf][i+4].v;
		v2 = g_vPosition[buf][i+5].v;

		vx3 = spu_splats(spu_extract(v3, 0));
		vx4 = spu_splats(spu_extract(v4, 0));
		vy3 = spu_splats(spu_extract(v3, 1));
		vy4 = spu_splats(spu_extract(v4, 1));
		vz3 = spu_splats(spu_extract(v3, 2));
		vz4 = spu_splats(spu_extract(v4, 2));
		vw3 = spu_splats(spu_extract(v3, 3));
		vw4 = spu_splats(spu_extract(v4, 3));
		vmulx3 = spu_mul(vx3, vl0);
		vmulx4 = spu_mul(vx4, vl0);
		vmuly3 = spu_mul(vy3, vl1);
		vmuly4 = spu_mul(vy4, vl1);
		vmulz3 = spu_mul(vz3, vl2);
		vmulz4 = spu_mul(vz4, vl2);
		vmulw3 = spu_mul(vw3, vl3);
		vmulw4 = spu_mul(vw4, vl3);
		vadd03 = spu_add(vmulx3, vmuly3);
		vadd04 = spu_add(vmulx4, vmuly4);
		vadd13 = spu_add(vmulz3, vmulw3);
		vadd14 = spu_add(vmulz4, vmulw4);
		vres3 = spu_add(vadd03, vadd13);
		vres4 = spu_add(vadd04, vadd14);

		v3 = g_vPosition[buf][i+6].v;
		v4 = g_vPosition[buf][i+7].v;

		vx1 = spu_splats(spu_extract(v1, 0));
		vx2 = spu_splats(spu_extract(v2, 0));
		vy1 = spu_splats(spu_extract(v1, 1));
		vy2 = spu_splats(spu_extract(v2, 1));
		vz1 = spu_splats(spu_extract(v1, 2));
		vz2 = spu_splats(spu_extract(v2, 2));
		vw1 = spu_splats(spu_extract(v1, 3));
		vw2 = spu_splats(spu_extract(v2, 3));
		vmulx1 = spu_mul(vx1, vl0);
		vmulx2 = spu_mul(vx2, vl0);
		vmuly1 = spu_mul(vy1, vl1);
		vmuly2 = spu_mul(vy2, vl1);
		vmulz1 = spu_mul(vz1, vl2);
		vmulz2 = spu_mul(vz2, vl2);
		vmulw1 = spu_mul(vw1, vl3);
		vmulw2 = spu_mul(vw2, vl3);
		vadd01 = spu_add(vmulx1, vmuly1);
		vadd02 = spu_add(vmulx2, vmuly2);
		vadd11 = spu_add(vmulz1, vmulw1);
		vadd12 = spu_add(vmulz2, vmulw2);
		vres1 = spu_add(vadd01, vadd11);
		vres2 = spu_add(vadd02, vadd12);
		
		g_vPosition[buf][i+2].v = vres3;
		g_vPosition[buf][i+3].v = vres4;
	}
	g_vPosition[buf][i].v = vres1;
	g_vPosition[buf][i+1].v = vres2;

	vx3 = spu_splats(spu_extract(v3, 0));
	vx4 = spu_splats(spu_extract(v4, 0));
	vy3 = spu_splats(spu_extract(v3, 1));
	vy4 = spu_splats(spu_extract(v4, 1));
	vz3 = spu_splats(spu_extract(v3, 2));
	vz4 = spu_splats(spu_extract(v4, 2));
	vw3 = spu_splats(spu_extract(v3, 3));
	vw4 = spu_splats(spu_extract(v4, 3));
	vmulx3 = spu_mul(vx3, vl0);
	vmulx4 = spu_mul(vx4, vl0);
	vmuly3 = spu_mul(vy3, vl1);
	vmuly4 = spu_mul(vy4, vl1);
	vmulz3 = spu_mul(vz3, vl2);
	vmulz4 = spu_mul(vz4, vl2);
	vmulw3 = spu_mul(vw3, vl3);
	vmulw4 = spu_mul(vw4, vl3);
	vadd03 = spu_add(vmulx3, vmuly3);
	vadd04 = spu_add(vmulx4, vmuly4);
	vadd13 = spu_add(vmulz3, vmulw3);
	vadd14 = spu_add(vmulz4, vmulw4);
	vres3 = spu_add(vadd03, vadd13);
	vres4 = spu_add(vadd04, vadd14);
	g_vPosition[buf][i+2].v = vres3;
	g_vPosition[buf][i+3].v = vres4;
}*/

void transform(int buf, int count)
{
	int pos = 0;
	int lsbuf = 0;
	int lsnextbuf = 1;

	// パイプライン初期化
	mfc_get(g_vPosition[lsnextbuf], g_eavPosition[buf] + pos*sizeof(VECTOR), sizeof(g_vPosition[lsnextbuf]), lsnextbuf, 0, 0);
	
	// 以下パイプライン
	for(pos = 0; pos < count-VECTOR_BUF_SIZE; pos += VECTOR_BUF_SIZE) {
		lsbuf = lsnextbuf;
		lsnextbuf = (lsbuf + 1) % 2;
		
		// プリフェッチ
		mfc_get(g_vPosition[lsnextbuf], g_eavPosition[buf] + (pos+VECTOR_BUF_SIZE)*sizeof(VECTOR), sizeof(g_vPosition[lsnextbuf]), lsnextbuf, 0, 0);
		
		mfc_write_tag_mask(1 << lsbuf);
		mfc_read_tag_status_all();
		
		multiply_all(lsbuf);

		mfc_putb(g_vPosition[lsbuf], g_eavPosition[buf] + pos*sizeof(VECTOR), sizeof(g_vPosition[lsbuf]), lsbuf, 0, 0);
	}
	
	// パイプライン後始末
	mfc_write_tag_mask(1 << lsnextbuf);
	mfc_read_tag_status_all();
	
	multiply_all(lsnextbuf);

	mfc_putb(g_vPosition[lsnextbuf], g_eavPosition[buf] + pos*sizeof(VECTOR), sizeof(g_vPosition[lsnextbuf]), lsnextbuf, 0, 0);
	
	mfc_write_tag_mask((1 << lsbuf) | (1 << lsnextbuf));
	mfc_read_tag_status_all();
}

/*void transform(int buf, int count)
{
	int pos = 0;
	int tag = 0;

	for(pos = 0; pos < count-VECTOR_BUF_SIZE; pos += VECTOR_BUF_SIZE) {		
		mfc_get(g_vPosition[0], g_eavPosition + (pos+VECTOR_BUF_SIZE)*sizeof(VECTOR), sizeof(g_vPosition[0]), tag, 0, 0);
		mfc_write_tag_mask(1 << tag);
		mfc_read_tag_status_all();
		
		multiply_all(0);

		mfc_putb(g_vPosition[0], g_eavPosition + pos*sizeof(VECTOR), sizeof(g_vPosition[0]), tag, 0, 0);
	}

	mfc_sync(tag);
	
	mfc_write_tag_mask(1 << tag);
	mfc_read_tag_status_all();
}*/

void message_loop(eaptr_t eavPosition, eaptr_t eamTransform)
{
	int tag = 0;
	unsigned int s, t;
	int dec;

	g_eavPosition[0] = eavPosition;
	g_eavPosition[1] = eavPosition + VECTOR_BUF_SIZE*sizeof(VECTOR);
	g_eamTransform = eamTransform;
	
	mfc_get(&g_mTransform, g_eamTransform, sizeof(g_mTransform), tag, 0, 0);
	mfc_write_tag_mask(1 << tag);
	mfc_read_tag_status_all();

	for(;;) {
		unsigned int mail = spu_read_in_mbox();
		
		if(mail == MAIL_HALT) {
			return;
		} else {
			spu_write_decrementer(0xFFFFFFFF);
                        s = spu_read_decrementer();
			transform(GET_BUF(mail), GET_COUNT(mail));
                        t = spu_read_decrementer();
                        dec = s-t;

                        spe_printf("dec = %d, %lf(sec)\n", dec, (dec)/(100.0*1024.0*1024.0));
			
			spu_write_out_mbox(SPEREPLY_FINISHED);
		}	
	}
}
