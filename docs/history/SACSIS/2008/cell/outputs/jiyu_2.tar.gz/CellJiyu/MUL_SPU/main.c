
#include <spu_intrinsics.h>
#include <spu_mfcio.h>

#include <stdio.h>

#include "mul.h"

#include "../MUL_PPU/parameter.h"

int main(unsigned long long spe, unsigned long long param)
{
	volatile SPE_ARG arg __attribute__ ((aligned(16)));
	int tag = 0;

	mfc_get(&arg, param, sizeof(arg), tag, 0, 0);
	mfc_write_tag_mask(1 << tag);
	mfc_read_tag_status_all();

	message_loop(arg.eavPosition, arg.eamTransform);

	return 0;	
}

