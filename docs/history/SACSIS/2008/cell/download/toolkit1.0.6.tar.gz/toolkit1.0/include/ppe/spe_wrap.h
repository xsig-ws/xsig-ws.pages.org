/* ============================================================================
   Copyright(C) 2005-2006 TOSHIBA CORPORATION, All Rights Reserved.
   There is NO WARRANTY for this source code.
   You can not MODIFY or COPY or RE-DISTRIBUTE this file.
   ============================================================================*/

#ifndef __SPE_WRAP_H__
#define __SPE_WRAP_H__

#include <spere.h>
#include <spere_resource.h>
#include <spere_attribute.h>
#include <spere_thread.h>
#include <lib/spere_lib_elf.h>
#include <lib/spere_lib_thread.h>
#include <stdlib.h>
#include "util.h"

#define SIGNOTIFY_INIT_MODE 0x00
#define SIGNOTIFY1_OR_MODE 0x01
#define SIGNOTIFY2_OR_MODE 0x02

/* SPE ����åɾ���¤�� */
typedef struct _spe_wrap_thread_handle {
    spere_object_id id;
    spere_object_id attrid;
    spere_lib_spe_context_t *context;
} swt_handle;

swt_handle
*spe_wrap_create_dedicated_thread(char *elf_name, void* targ, int flags);
void spe_wrap_load_image(char *elf_name, spere_lib_spe_context_t **context);
void spe_wrap_set_dedicated_config(swt_handle *handle, void* targ, int flags);
void spe_wrap_create_thread(swt_handle *handle);
void spe_wrap_resume_thread(spere_object_id thid);
void spe_wrap_release_thread(swt_handle *handle);
spere_object_id
spe_wrap_add_access_hint(spere_object_id thid, void* ptr, int size);
void spe_wrap_remove_access_hint(spere_object_id thid, spere_object_id hintid);
void spe_wrap_wait_thread(spere_object_id thid);

/* SPE Dedicated ����å����� */
swt_handle
*spe_wrap_create_dedicated_thread(char *elf_name, void* targ, int flags)
{
    swt_handle *handle = NULL;

    /* SPE ����åɾ���¤���ΰ���� */
    handle = (swt_handle *)malloc(sizeof(swt_handle));
    handle->context = NULL;

    /* dedicated ����å��������ƥå׼¹� */
    spe_wrap_load_image(elf_name, &handle->context);
    spe_wrap_set_dedicated_config(handle, targ, flags);
    spe_wrap_create_thread(handle);

    return handle;
}

/* ELF ���᡼�������� */
void spe_wrap_load_image(char *elf_name, spere_lib_spe_context_t **context)
{
    /* ELF �ե���������� */
    spere_lib_elf_load(elf_name, context);
}

/* SPE ����å�����(dedicated ) */
void spe_wrap_set_dedicated_config(swt_handle *handle, void* targ, int flags)
{
    spere_object_id resid;
    spere_value value = { 0 };

    handle->id = SPERE_INVALID_OBJECT_ID;
    handle->attrid = SPERE_INVALID_OBJECT_ID;
    resid = SPERE_INVALID_OBJECT_ID;

    /* SPE ����åɤؤΰ����Ϥ� */
    spere_lib_elf_set_arg_uint64(handle->context, 1,
                                 (spere_addr)(uint)targ);

    /* SPE �꥽������ͽ�� */
    spere_resource_reserve(SPERE_DEFAULT_OBJECT_ID, SPERE_RESOURCE_SPE, 1, 0,
                           &resid);

    /* °�������� */
    spere_attribute_create(SPERE_ATTRIBUTE_TYPE_TEMPORARY, &handle->attrid);

    /* SPE ��ͭ���� */
    value.u_key = SPERE_THREAD_CLASS_BEST_EFFORT;
    spere_attribute_set(handle->attrid, SPERE_THREAD_ATTRIBUTE_CLASS, value);

    /* ����ե�����졼�����쥸��������(signal notification �⡼��) */
    if (flags & SIGNOTIFY1_OR_MODE)
        value.u_key = SPERE_THREAD_SPU_SIG_NOTIFY_MODE_LOGICAL_OR;
    else
        value.u_key = SPERE_THREAD_SPU_SIG_NOTIFY_MODE_OVERWRITE;

    spere_attribute_set(handle->attrid,
                        SPERE_THREAD_ATTRIBUTE_SPU_SIG_NOTIFY_1_MODE, value);

    if (flags & SIGNOTIFY2_OR_MODE)
        value.u_key = SPERE_THREAD_SPU_SIG_NOTIFY_MODE_LOGICAL_OR;
    else
        value.u_key = SPERE_THREAD_SPU_SIG_NOTIFY_MODE_OVERWRITE;

    spere_attribute_set(handle->attrid,
                        SPERE_THREAD_ATTRIBUTE_SPU_SIG_NOTIFY_2_MODE, value);

    /* SPE ��bind */
    value.u_obj_id = resid;
    spere_attribute_set(handle->attrid, SPERE_THREAD_ATTRIBUTE_BIND_PROCESSOR,
                        value);
}

/* SPE ����å����� */
void spe_wrap_create_thread(swt_handle *handle)
{
    spere_spu_regs regs;

    /* SPE ����åɤ����� */
    spere_spe_thread_create(handle->context->m_image,
                            handle->context->m_image_size,
                            handle->context->m_load_addr, &(handle->context->m_regs),
                            handle->context->m_entry_point,
                            handle->attrid, &handle->id);

    spere_spe_thread_read_regs(handle->id, &regs);

    /* GPR3(arg0) �إ���å�ID �񤭹��� */
    regs.m_reg[3].m_field[0] = handle->id & 0xffffffff;
    spere_spe_thread_write_regs(handle->id, &regs);
}

/* SPE ����åɥ쥸�塼�� */
void spe_wrap_resume_thread(spere_object_id thid)
{
    /* SPE ����åɤΥ쥸�塼�� */
    spere_lib_thread_resume(thid);
}

/* SPE ����å��˴� */
void spe_wrap_release_thread(swt_handle *handle)
{
    /* ����ƥ����Ȥβ��� */
    spere_lib_elf_free_context(handle->context);
	
    free((void *)handle);
    handle = NULL;
}

/* ���������ҥ�Ⱥ��� */
spere_object_id
spe_wrap_add_access_hint(spere_object_id thid, void* ptr, int size)
{
    spere_object_id hintid;

    /* ���������ҥ�Ȥκ��� */
    spere_thread_add_access_hint(thid, (spere_addr)(uint)ptr, size,
                                 SPERE_FLAG_AH_SET_INIT_INFO | SPERE_FLAG_AH_SEGMENT_ADDR_TRANS_MUST
                                 | SPERE_FLAG_AH_PAGE_ADDR_TRANS_MUST | SPERE_FLAG_AH_PAGE_PIN_MUST,
                                 &hintid);

    return hintid;
}

/* ���������ҥ�Ⱥ�� */
void spe_wrap_remove_access_hint(spere_object_id thid, spere_object_id hintid)
{
    /* ���������ҥ�Ȥκ�� */
    spere_thread_remove_access_hint(thid, hintid);
}

/* SPE ����åɽ�λ���� */
void spe_wrap_wait_thread(spere_object_id thid)
{
    spere_uint64 status;

    while (1) {
        spere_lib_spe_thread_get_internal_state(thid, &status);
        /* �쥸��������SPE ����åɤξ��֤��������STOP ���֤ʤ�н�λ */
        if (((status & SPERE_LIB_SPE_THREAD_FLAG_SPU_RUNNING) == 0)
            && (SPERE_LIB_SPE_THREAD_GET_STOP_CODE(status) == 0x2000))
            break;
    }
}

#endif /* __SPE_WRAP_H__ */
