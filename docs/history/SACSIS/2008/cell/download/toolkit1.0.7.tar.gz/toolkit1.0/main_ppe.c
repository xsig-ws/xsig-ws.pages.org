/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2008-01-11                */
/*----------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <fenv.h>
#include <math.h>
#include <time.h>
#include <malloc.h>
#include <spe/sys/spelib_types.h>
#include <spe_stdio_srv.h>
#include <spere_cbea.h>
#include "spe_wrap.h"
#include "ppe_util.h"
#include "define.h"
#include "spe.h"

#define _XOPEN_SOURCE 600

/*----------------------------------------------------------------------*/
double my_clock();

volatile static float buf[USER_MEM] _ALIGN;
volatile static char  buf_ctrl[16*1024] _ALIGN;

volatile static struct argument sarg[NUMBER_OF_SPES] _ALIGN;
volatile static struct spe_ctrl ctrl[NUMBER_OF_SPES] _ALIGN;
volatile static struct spe_sync_block sync_addr[NUMBER_OF_SPES] _ALIGN;

void get_matrix(int n, int m, float* a, unsigned int s);
void generate_matrix(int n, int m, float* buf, unsigned int s);
void matrix_multiplication(int n, int m, float* a, float* x, float* b);
void disp_matrix(int n, int m, float* a);
double check(int n, int m, float* buf, double etime, unsigned int s);
double calculate_flops(int n, int m, double etime);
void get_prob(int n, int m, int s, float* buf);

double t1,t2; // start and end time stamp

/*----------------------------------------------------------------------*/
void spe_active(volatile float* buf, int n, int m, unsigned int s){
    int i,j;
    swt_handle *h[NUMBER_OF_SPES];
    spere_object_id hint[NUMBER_OF_SPES][6];    
    spere_addr ls_addr[NUMBER_OF_SPES];
    char *spe_obj[7] = {EXE_SPE1, EXE_SPE2, EXE_SPE3, EXE_SPE4, 
                        EXE_SPE5, EXE_SPE6, EXE_SPE7};
    float* x;
    x = (float*)((unsigned int)buf+sizeof(float)*(n*n+n*m));

    _spe_stdio_init(SPE_STDIO_BUF_SIZE);
    _spe_stdio_start();

    for(i=0; i<NUMBER_OF_SPES; i++){
        h[i] = spe_wrap_create_dedicated_thread(
            spe_obj[i], (void*)&sarg[i], SIGNOTIFY_INIT_MODE);
        sarg[i].id      = i;
        sarg[i].sc_addr = (unsigned int)&ctrl[i];
        spere_spe_thread_map_ls(h[i]->id, &ls_addr[i]);
    }

    for(i=0; i<NUMBER_OF_SPES; i++){
        ctrl[i].flag     = 0;
        ctrl[i].id       = i;
        ctrl[i].buf_ctrl = (unsigned int)buf_ctrl;

        ctrl[i].n        = n;
        ctrl[i].m        = m;
        ctrl[i].buf      = (unsigned int)buf;
        ctrl[i].spe_num  = NUMBER_OF_SPES;
        ctrl[i].dec_cnt  = 0;
        ctrl[i].sync_addr = (unsigned int)sync_addr;
        for(j=0;j<NUMBER_OF_SPES;j++){
            ctrl[i].ls_addr[j] = ls_addr[j];
        }
    }
    
    for(i=0; i<NUMBER_OF_SPES; i++){
        hint[i][0] = spe_wrap_add_access_hint(
            h[i]->id, (void*)&sarg[i], SPE_DMA_ALIGN);
        hint[i][1] = spe_wrap_add_access_hint(
            h[i]->id, (void*)&ctrl[i], SPE_DMA_ALIGN);
        hint[i][2] = spe_wrap_add_access_hint(
            h[i]->id, (void*)buf, sizeof(float)*USER_MEM);
        // control flag
        hint[i][3] = spe_wrap_add_access_hint(
            h[i]->id, (void*)buf_ctrl, 16*1024);
        // for sync spes
        hint[i][4] = spe_wrap_add_access_hint(
            h[i]->id, (void*)&sync_addr[0], sizeof(struct spe_sync_block)*NUMBER_OF_SPES);
        hint[i][5] = spe_wrap_add_access_hint(
            h[i]->id, (void*)((unsigned int)ls_addr[i]), 256*1024);
    }
    
    for(i=0; i<NUMBER_OF_SPES; i++) spe_wrap_resume_thread(h[i]->id);

    t1 = my_clock();
    for(i=0; i<NUMBER_OF_SPES; i++) ctrl[i].flag = 1;
    for(i=0; i<NUMBER_OF_SPES; i++) while(ctrl[i].flag != 2) ;
    for(i=0;i<n;i++) x[i] = 0.0;

    for(i=0; i<NUMBER_OF_SPES; i++) ctrl[i].flag = 3;
    for(i=0; i<NUMBER_OF_SPES; i++) spe_wrap_wait_thread(h[i]->id);
    t2 = my_clock();
    
    for(i=0; i<NUMBER_OF_SPES; i++){
        spe_wrap_remove_access_hint(h[i]->id, hint[i][0]);
        spe_wrap_remove_access_hint(h[i]->id, hint[i][1]);
        spe_wrap_remove_access_hint(h[i]->id, hint[i][2]);
        spe_wrap_remove_access_hint(h[i]->id, hint[i][3]);
        spe_wrap_remove_access_hint(h[i]->id, hint[i][4]);
        spe_wrap_remove_access_hint(h[i]->id, hint[i][5]);

        spere_spe_thread_unmap_ls(h[i]->id);
        spe_wrap_release_thread(h[i]);
    }
    _spe_stdio_end();
};

/*----------------------------------------------------------------------*/
/* PPE main program                                                     */
/*----------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    int n; // matrix vector
    int m; // number of solution vector

    double flops;
    double etime;
    double result;
    unsigned int s;

    if(argc != 4){
        printf("solver algebra : N (matrix size) M (vector number) S (Matrix No.).\n");
        exit(1);
    }
    if(atoi(argv[1])%32 != 0){
        printf("solver algebra : N (matrix size) [%d] must be a multiple of 32.\n",atoi(argv[1]));
        exit(1);
    }

    n = atoi(argv[1]);
    m = atoi(argv[2]);
    s = atoi(argv[3]);

    printf("[ppe_] N %4d  M %4d Mem %1.2f[KByte].\n",
           n,m,(float)sizeof(float)*(n*n+n*m*2)/1024.0);

    // Generate matrix
    get_prob(n, m, s, (float*)buf);
    spe_active(buf, n, m, s);

    etime = ctrl[0].dec_cnt / (100.0 * 1024.0 * 1024.0);
    flops = calculate_flops(n, m, etime);
    result = check(n,m,(float*)buf, etime, s);
    if(result < 3.0){
        printf("SUCCESSFUL. ");
    }
    else{
        printf("***** FAILED ! *****");
    }
    printf(" : %5.6f [MFlops]\n", flops);
    
    return 0;
}
