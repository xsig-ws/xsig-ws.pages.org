/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2008-01-11                */
/*----------------------------------------------------------------------*/
#define EXE_PATH "toolkit1.0/"
#define EXE_SPE1 EXE_PATH"spe1"
#define EXE_SPE2 EXE_PATH"spe1"
#define EXE_SPE3 EXE_PATH"spe1"
#define EXE_SPE4 EXE_PATH"spe1"
#define EXE_SPE5 EXE_PATH"spe1"
#define EXE_SPE6 EXE_PATH"spe1"
#define EXE_SPE7 EXE_PATH"spe1"
/*----------------------------------------------------------------------*/
