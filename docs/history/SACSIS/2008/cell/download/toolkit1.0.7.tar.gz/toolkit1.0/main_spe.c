/*----------------------------------------------------------------------*/
/* Cell Speed Challenge 2008, ToolKit Version 2008-01-11                */
/*----------------------------------------------------------------------*/
#include <spu_intrinsics.h>
#include <spelib.h>
#include <spe_stdio.h>
#include <stdlib.h>
#include <spu_mfcio.h>
#include <float.h>
#include <math.h>
#include "spe_util.h"
#include "define.h"

/*----------------------------------------------------------------------*/
struct spe_sync{
    unsigned int flag;
    unsigned int start_flag;
    unsigned int end_flag;
    unsigned int addr; // address for sd
    unsigned int pivot_flag;
    unsigned int pivot_idx;
    float        pivot_max;
    unsigned int data[25];
};

volatile static struct spe_ctrl sc _GALIGN;

extern void dmaget(void* d, unsigned long long addr, unsigned int size);
extern void dmaput(void* d, unsigned long long addr, unsigned int size);
extern void spe_time_start(struct spe_ctrl* sc,unsigned long long argv);
extern void spe_time_end(struct spe_ctrl* sc);

/*----------------------------------------------------------------------*/
void dmaget_burst(unsigned int ppe_addr, unsigned int spe_addr, unsigned int row, unsigned int col, unsigned int n){
    unsigned int paddr;
    paddr = ppe_addr + n * col * sizeof(float) + (row / 32) * 128;
    dmaget((void*)spe_addr, paddr, 128);
}

float dmaget_value(unsigned int addr, unsigned int row, unsigned int col, unsigned int n){
    volatile static float buf[32] _GALIGN;
    dmaget_burst(addr, (unsigned int)buf, row, col, n);
    return buf[row%32];
}

void dmaput_value(unsigned int addr, unsigned int row, unsigned int col, unsigned int n, float value){
    unsigned int paddr;
    volatile static float buf[32] _GALIGN;

    paddr = addr + n * col * sizeof(float) + (row / 32) * 128;
    dmaget((void*)buf, paddr, 128);
    buf[row%32] = value;

    dmaput((void*)buf, paddr, 128);
}

void sync_dist(unsigned int id, unsigned int* ppe_ls, volatile struct spe_sync* sd, unsigned int key){
    int j;
    volatile static struct spe_sync ss _GALIGN;

    if(id==0){
        ss.start_flag=key;
        for(j=1;j<NUMBER_OF_SPES;j++){
            dmaput((void*)&ss, ppe_ls[j]+128*j, 128);
        }
    }
    else{
        while(sd[id].start_flag != key) ;
    }
}

void sync_collect(unsigned int id, unsigned int* ppe_ls, volatile struct spe_sync* sd, unsigned int key){
    int j;
    if(id==0){
        for(j=1;j<NUMBER_OF_SPES;j++){
            while(sd[j].end_flag != key) ;
        }
    }
    else{
        sd[id].end_flag = key;
        dmaput((void*)&sd[id],ppe_ls[0]+128*id,128);
    }
}

void pivoting(int id, unsigned int addr,
              unsigned int n, int s, int* maxj,
              unsigned int* ppe_ls, volatile struct spe_sync* sd,
              unsigned int key){
    int i,j;
    float t1, t2;

    *maxj = s+(n-s)*id/NUMBER_OF_SPES;
    t1 = fabs(dmaget_value(addr, s, s+(n-s)*id/NUMBER_OF_SPES, n));
    for(j=s+(n-s)*id/NUMBER_OF_SPES+1;j<n*(id+1)/NUMBER_OF_SPES;j++){
        t2 = fabs(dmaget_value(addr, s, j, n));
        if(t2 > t1){
            *maxj = j;
            t1   = t2;
        }
    }
    
    if(id == 0){
        for(i=1;i<NUMBER_OF_SPES;i++){
            while(sd[i].pivot_flag != key) ;

            if(sd[i].pivot_max > t1){
                *maxj = sd[i].pivot_idx;
                t1    = sd[i].pivot_max;
            }
        }
        for(i=1;i<NUMBER_OF_SPES;i++){
            sd[i].pivot_flag = key + 1;
            sd[i].pivot_max  = *maxj;
            dmaput((void*)&sd[i],ppe_ls[i]+128*i,128);
        }
    }
    else{
        sd[id].pivot_flag = key;
        sd[id].pivot_idx  = *maxj;
        sd[id].pivot_max  = t1;
        dmaput((void*)&sd[id], ppe_ls[0]+128*id,128);

        while(sd[id].pivot_flag != key + 1) ;
        *maxj = sd[id].pivot_max;
    }
}

void swap_row(int id, unsigned int addr, unsigned int r1, unsigned int r2, unsigned int n){
    int i;
    volatile static float buf1[32] _GALIGN;
    volatile static float buf2[32] _GALIGN;
    unsigned int ppe_addr1;
    unsigned int ppe_addr2;

    for(i=id; i<n/32; i=i+NUMBER_OF_SPES){
        ppe_addr1 = addr + sizeof(float) * n * r1 + 128 * i;
        ppe_addr2 = addr + sizeof(float) * n * r2 + 128 * i;

        dmaget((void*)buf1, ppe_addr1, 128);
        dmaget((void*)buf2, ppe_addr2, 128);
        dmaput((void*)buf2, ppe_addr1, 128);
        dmaput((void*)buf1, ppe_addr2, 128);
    }
}

void swap_col(int id, unsigned int addr, unsigned int r1, unsigned int r2, unsigned int n, unsigned int m){
    int i;
    float t1, t2;

    for(i=id;i<m;i=i+NUMBER_OF_SPES){
        t1 = dmaget_value(addr, r1, i, n);
        t2 = dmaget_value(addr, r2, i, n);
        dmaput_value(addr, r1, i, n, t2);
        dmaput_value(addr, r2, i, n, t1);
    }
}

void spe_lu_decomposition(int id, unsigned int addr, int row, int n){
    int p,q,s;
    int i,k;
    int r;
    float t1;

    float diag;
    
    volatile static float buf1[32] _GALIGN;
    volatile static float buf2[32] _GALIGN;
    volatile static float buf3[32] _GALIGN;

    s = n /32;
    r = (row+1)/32;

    diag = dmaget_value(addr, row, row, n);
    dmaget_burst(addr, (unsigned int)buf2, (row+1), row, n);
    
    for(i=row+1+id;i<n;i=i+NUMBER_OF_SPES){
        t1 = dmaget_value(addr, row, i, n) / diag;
        dmaput_value(addr, row, i, n, t1);
        
        p = addr+n*i*sizeof(float);

        dmaget((void*)buf1,p+128*r,128);
        for(k=row+1; k<32*(r+1); k++)
            buf1[k%32] -= buf2[k%32] * t1;
        dmaput((void*)buf1,p+128*r,128);

        for(q=r+1;q<s;q++){
            dmaget((void*)buf1, p+q*128,128);
            dmaget((void*)buf3, addr+n*row*sizeof(float)+q*128,128);
            for(k=0; k<32; k++)
                buf1[k] -= buf3[k] * t1;
            dmaput((void*)buf1,p+q*128,128);
        }
    }
}

void forward_substitution(unsigned int ppe_a, unsigned int ppe_b, unsigned int ppe_c, unsigned int idx, unsigned int n){
    int i,j,p;
    float t1;
    volatile static float buf1[32] _GALIGN;
    volatile static float buf2[32] _GALIGN;

    for(i=0;i<n;i++){
        t1 = dmaget_value(ppe_b, i, idx, n);
        p=0;
        for(j=0;j<i;j++){
            if(j%32==0){
                dmaget((void*)buf1, ppe_a+n*sizeof(float)*i+p*128,128);
                dmaget((void*)buf2, ppe_c+n*sizeof(float)*idx+p*128,128);
                p++;
            }
            t1 -= buf1[j%32] * buf2[j%32];
        }
        dmaput_value(ppe_c, i, idx, n, t1);
    }
}

void backward_substitution(int id, unsigned int ppe_a, unsigned int ppe_b, unsigned int ppe_c, unsigned int ppe_x, unsigned int idx, unsigned int n){
    int i,j;
    float t1;
    float diag;

    volatile static float buf1[32] _GALIGN;
    volatile static float buf2[32] _GALIGN;

    for(i=n-1;i>=0;i--){
        t1 = dmaget_value(ppe_c, i, idx, n);
        
        diag = dmaget_value(ppe_a, i, i, n);

        for(j=i+1;j<n;j++){
            if((j==i+1) || (j%32==0)){
                dmaget_burst(ppe_a,(unsigned int)buf1, j, i,   n);
                dmaget_burst(ppe_x,(unsigned int)buf2, j, idx, n);
            }

            t1 -= buf1[j%32] * buf2[j%32];
        }
        t1 = t1 / diag;
        dmaput_value(ppe_x, i, idx, n, t1);
    }
}

void spe_soleqs(struct spe_ctrl* sc){
    int i;
    int n,m;
    int id;
    unsigned int ppe_a, ppe_b, ppe_x, ppe_c;

    int maxj;

    unsigned int ppe_ls[7];

    unsigned int ppe_s;
    volatile static struct spe_sync ss _GALIGN;
    volatile static struct spe_sync sd[NUMBER_OF_SPES] _GALIGN;
    
    n  = sc->n;
    m  = sc->m;
    id = sc->id;
    ppe_a = sc->buf;
    ppe_b = ppe_a + n * n * sizeof(float);
    ppe_x = ppe_b + n * m * sizeof(float);
    ppe_c = ppe_x + n * m * sizeof(float);
    ppe_s = ppe_c + n * m * sizeof(float);
    
    // for syncronization
    ss.flag = 0XFFFFFFFF;
    ss.addr = (unsigned int)sc->ls_addr[id] + (unsigned int)&sd[0];
    dmaput((void*)&ss, (ppe_s+128*id) , 128);

    // Get addresses for each sharing memory of SPE
    ss.flag = 0;
    for(i=0;i<NUMBER_OF_SPES;i++){
        while(ss.flag != 0XFFFFFFFF){
            dmaget((void*)&ss, (ppe_s+128*i), 128);
        }
        ppe_ls[i] = ss.addr;
        ss.flag = 0;
    }

    // LU decomposition
    for(i=0;i<n;i++){
        pivoting(id, ppe_a, n, i, &maxj, ppe_ls, sd, i+1);

        swap_row(id, ppe_a, i, maxj, n);
        swap_col(id, ppe_b, i, maxj, n, m);

        // Syncronization : SPE[0] notates (notice starting for all SPE)
        sync_dist(id, ppe_ls, sd, i+1);

        // right looking LU decomposition
        spe_lu_decomposition(id, (unsigned int)ppe_a, i, n);
        // Syncronization : notates SPE[0] (notice end of the calculation)
        sync_collect(id, ppe_ls, sd, i+1);
    }
    
    for(i=id;i<m;i=i+NUMBER_OF_SPES){        
        // forward substitution
        forward_substitution(ppe_a, ppe_b, ppe_c, i, n);
        // backward substitution
        backward_substitution(id, ppe_a, ppe_b, ppe_c, ppe_x, i, n);
    }
}

/*----------------------------------------------------------------------*/
/* SPE main program                                                     */
/*----------------------------------------------------------------------*/

int main(int speid, unsigned long long argv)
{
    spe_time_start((struct spe_ctrl*)&sc, argv);
/*-----------------------*/
    // modify codes in function "spe_soleqs".
    spe_soleqs((struct spe_ctrl*)&sc);
/*-----------------------*/
    spe_time_end((struct spe_ctrl*)&sc);

    return 0;
}
/*----------------------------------------------------------------------*/
